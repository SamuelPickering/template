import Link from "next/link";
import { currentRun, datasetSummary, traderRows } from "@/lib/queries";
import { METRIC_BY_ID } from "@/lib/config/metrics";
import { fmtUsd, fmtDate } from "@/lib/format";
import { getDataset } from "@/lib/config/store";

export const dynamic = "force-dynamic";

export default function Dashboard() {
  const run = currentRun();
  const summary = datasetSummary().find((s) => s.source === run.dataset);
  const totalUsd = run.stats.reduce((s, m) => s + m.usd_total, 0);
  const traders = traderRows(run).filter((t) => t.alerts > 0);
  const top = run.alerts.slice(0, 15);

  return (
    <>
      <h1>Dashboard</h1>
      <p className="note">
        {run.trades.toLocaleString("en-US")} {getDataset()} executions analysed
        {summary ? `, ${summary.first_date} to ${summary.last_date}` : ""}.
      </p>

      <p className="stats">
        <span>
          <b>Trades:</b> {run.trades.toLocaleString("en-US")}
        </span>
        <span>
          <b>Alerts:</b> {run.alerts.length}
        </span>
        <span>
          <b>Instances scored:</b> {run.instances.length}
        </span>
        <span>
          <b>Total USD Value:</b> {fmtUsd(totalUsd)}
        </span>
        <span>
          <b>Alert rate:</b> {((run.alerts.length / Math.max(1, run.trades)) * 100).toFixed(2)}%
        </span>
      </p>

      <h2>USD Value by metric</h2>
      <table>
        <thead>
          <tr>
            <th>Metric</th>
            <th className="n">Instances</th>
            <th className="n">Alerts</th>
            <th className="n">Threshold</th>
            <th className="n">Total USD Value</th>
            <th className="n">Largest</th>
          </tr>
        </thead>
        <tbody>
          {run.stats.map((s) => (
            <tr key={s.metric}>
              <td>
                <Link href={`/alerts/${s.metric}`}>{s.label}</Link>
                <div className="note">{METRIC_BY_ID[s.metric].short}</div>
              </td>
              <td className="n">{s.instances}</td>
              <td className="n">{s.alerts}</td>
              <td className="n">{fmtUsd(s.threshold)}</td>
              <td className="n">{fmtUsd(s.usd_total)}</td>
              <td className="n">{fmtUsd(s.top_usd)}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <h2>Risk by trader</h2>
      <p className="note">
        Traders with at least one alert, by total USD Value across every metric.
      </p>
      <table>
        <thead>
          <tr>
            <th>Trader</th>
            <th className="n">Alerts</th>
            <th className="n">USD Value</th>
            <th className="n">Trades</th>
          </tr>
        </thead>
        <tbody>
          {traders.map((t) => (
            <tr key={t.trader_id}>
              <td>
                <Link href={`/blotter?trader=${t.trader_id}`}>{t.name}</Link>{" "}
                <span className="note">{t.trader_id}</span>
              </td>
              <td className="n">{t.alerts}</td>
              <td className="n">{fmtUsd(t.usd_value)}</td>
              <td className="n">{t.trades}</td>
            </tr>
          ))}
          {traders.length === 0 && (
            <tr>
              <td colSpan={4}>No alerts at the current thresholds.</td>
            </tr>
          )}
        </tbody>
      </table>

      <h2>Highest-scoring alerts</h2>
      <table>
        <thead>
          <tr>
            <th className="n">USD Value</th>
            <th>Metric</th>
            <th>Trader</th>
            <th>Instrument</th>
            <th>Date</th>
            <th>What happened</th>
          </tr>
        </thead>
        <tbody>
          {top.map((a) => (
            <tr key={a.instance_id}>
              <td className="n">{fmtUsd(a.usd_value)}</td>
              <td>{METRIC_BY_ID[a.metric].label}</td>
              <td>{a.trader_name}</td>
              <td className="mono">{a.instrument}</td>
              <td className="mono">{fmtDate(a.start_ms)}</td>
              <td>
                <Link href={`/instance/${encodeURIComponent(a.instance_id)}`}>{a.headline}</Link>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <p>
        <Link href="/alerts">All alerts</Link>
      </p>
    </>
  );
}
