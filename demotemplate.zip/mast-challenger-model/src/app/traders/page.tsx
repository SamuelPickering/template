import Link from "next/link";
import { currentRun, traderRows } from "@/lib/queries";
import { fmtUsd } from "@/lib/format";

export const dynamic = "force-dynamic";

export default function TradersPage() {
  const run = currentRun();
  const rows = traderRows(run);

  return (
    <>
      <h1>Traders</h1>
      <p className="note">
        Every trader in the simulated firm. Trade counts come from the active dataset; alert counts
        are live against the current thresholds.
      </p>

      <p className="stats">
        <span>
          <b>Traders:</b> {rows.length}
        </span>
        <span>
          <b>With alerts:</b> {rows.filter((r) => r.alerts > 0).length}
        </span>
        <span>
          <b>Total USD Value:</b> {fmtUsd(rows.reduce((s, r) => s + r.usd_value, 0))}
        </span>
      </p>

      <table>
        <thead>
          <tr>
            <th>Trader</th>
            <th>ID</th>
            <th>Primary role</th>
            <th className="n">Trades</th>
            <th className="n">Notional</th>
            <th className="n">Alerts</th>
            <th className="n">USD Value</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.trader_id}>
              <td>
                <Link href={`/blotter?trader=${r.trader_id}`}>{r.name}</Link>
              </td>
              <td className="mono">{r.trader_id}</td>
              <td>{r.trade_role.replace("_", " ")}</td>
              <td className="n">{r.trades.toLocaleString("en-US")}</td>
              <td className="n">{fmtUsd(r.notional_usd)}</td>
              <td className="n">{r.alerts || ""}</td>
              <td className="n">{r.usd_value ? fmtUsd(r.usd_value) : ""}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}
