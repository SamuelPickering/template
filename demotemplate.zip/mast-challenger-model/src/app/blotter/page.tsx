import Link from "next/link";
import { getDataset } from "@/lib/config/store";
import { distinctDates, distinctPairs, queryTrades } from "@/lib/queries";
import { loadTraders } from "@/lib/db/repo";
import { fmtAmount, fmtDateTime, fmtRate, fmtUsd } from "@/lib/format";

export const dynamic = "force-dynamic";

const PAGE_SIZE = 150;

export default async function Blotter({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | undefined>>;
}) {
  const sp = await searchParams;
  const dataset = getDataset();
  const page = Math.max(0, Number(sp.page ?? 0) || 0);
  const highlight = new Set((sp.highlight ?? "").split(",").filter(Boolean));

  const { rows, total } = queryTrades(dataset, {
    trader: sp.trader,
    pair: sp.pair,
    date: sp.date,
    role: sp.role,
    search: sp.q,
    limit: PAGE_SIZE,
    offset: page * PAGE_SIZE,
  });

  const traders = loadTraders();
  const pairs = distinctPairs(dataset);
  const dates = distinctDates(dataset);
  const pages = Math.ceil(total / PAGE_SIZE);
  const qs = (over: Record<string, string | number | undefined>) => {
    const p = new URLSearchParams();
    for (const [k, v] of Object.entries({ ...sp, ...over })) {
      if (v !== undefined && v !== "") p.set(k, String(v));
    }
    return `/blotter?${p.toString()}`;
  };

  return (
    <>
      <h1>Trade Blotter</h1>
      <p className="note">
        {total.toLocaleString("en-US")} {dataset} executions match the current filters.
        {highlight.size > 0 && ` ${highlight.size} trades from the selected alert are highlighted.`}
      </p>

      <form method="get">
        <fieldset>
          <legend>Filters</legend>
          <label className="f">
            Trader{" "}
            <select name="trader" defaultValue={sp.trader ?? ""}>
              <option value="">(all)</option>
              {traders.map((t) => (
                <option key={t.trader_id} value={t.trader_id}>
                  {t.name}
                </option>
              ))}
            </select>
          </label>
          <label className="f">
            Pair{" "}
            <select name="pair" defaultValue={sp.pair ?? ""}>
              <option value="">(all)</option>
              {pairs.map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>
          </label>
          <label className="f">
            Date{" "}
            <select name="date" defaultValue={sp.date ?? ""}>
              <option value="">(all)</option>
              {dates.map((d) => (
                <option key={d} value={d}>
                  {d}
                </option>
              ))}
            </select>
          </label>
          <label className="f">
            Role{" "}
            <select name="role" defaultValue={sp.role ?? ""}>
              <option value="">(any)</option>
              <option value="client_facilitation">client facilitation</option>
              <option value="prop">prop</option>
            </select>
          </label>
          <label className="f">
            Search <input name="q" defaultValue={sp.q ?? ""} size={22} />
          </label>
          {sp.highlight && <input type="hidden" name="highlight" value={sp.highlight} />}
          <button type="submit">Apply</button> <Link href="/blotter">reset</Link>
        </fieldset>
      </form>

      {pages > 1 && (
        <p className="small">
          Page {page + 1} of {pages}{" "}
          {page > 0 && <Link href={qs({ page: page - 1 })}>[prev]</Link>}{" "}
          {page + 1 < pages && <Link href={qs({ page: page + 1 })}>[next]</Link>}
        </p>
      )}

      {rows.length === 0 ? (
        <p className="note">No trades match these filters.</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Trade</th>
              <th>Execution time</th>
              <th>Trader</th>
              <th>Pair</th>
              <th className="n">Buy</th>
              <th className="n">Sell</th>
              <th className="n">Rate</th>
              <th className="n">Notional USD</th>
              <th>Counterparty</th>
              <th>Role</th>
              <th>Source</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((t) => (
              <tr key={t.trade_id} className={highlight.has(t.trade_id) ? "hit" : ""}>
                <td className="mono">{t.trade_id}</td>
                <td className="mono">{fmtDateTime(t.execution_ms)}</td>
                <td>
                  <Link href={qs({ trader: t.trader_id, page: 0 })}>{t.trader_name}</Link>
                </td>
                <td className="mono">{t.currency_pair}</td>
                <td className="n">
                  {fmtAmount(t.buy_amount)} {t.buy_currency}
                </td>
                <td className="n">
                  {fmtAmount(t.sell_amount)} {t.sell_currency}
                </td>
                <td className="n">{fmtRate(t.execution_rate)}</td>
                <td className="n">{fmtUsd(t.notional_usd)}</td>
                <td>{t.counterparty_id ?? "-"}</td>
                <td>{t.trade_role.replace("_", " ")}</td>
                <td>{t.source}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </>
  );
}
