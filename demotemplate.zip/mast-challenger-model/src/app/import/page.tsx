import { ImportClient } from "@/components/ImportClient";
import { getDataset } from "@/lib/config/store";
import { datasetSummary } from "@/lib/queries";
import { CANONICAL_FIELDS } from "@/lib/import/csv";
import { fmtUsd } from "@/lib/format";

export const dynamic = "force-dynamic";

export default function ImportPage() {
  const dataset = getDataset();
  const summary = datasetSummary();

  return (
    <>
      <h1>Import Data</h1>
      <p className="note">
        Load a CSV of real executions, map its columns onto the canonical trade schema, and run
        every metric against it instead of the synthetic population.
      </p>

      <h2>Loaded datasets</h2>
      <table>
        <thead>
          <tr>
            <th>Source</th>
            <th className="n">Trades</th>
            <th>Range</th>
            <th className="n">Notional</th>
          </tr>
        </thead>
        <tbody>
          {summary.map((s) => (
            <tr key={s.source}>
              <td>
                {s.source}
                {s.source === dataset ? " (active)" : ""}
              </td>
              <td className="n">{s.trades.toLocaleString("en-US")}</td>
              <td className="mono">
                {s.first_date} to {s.last_date}
              </td>
              <td className="n">{fmtUsd(s.notional)}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <ImportClient dataset={dataset} />

      <h2>Canonical schema</h2>
      <table>
        <thead>
          <tr>
            <th>Field</th>
            <th>Column</th>
            <th>Required</th>
            <th>Notes</th>
          </tr>
        </thead>
        <tbody>
          {CANONICAL_FIELDS.map((f) => (
            <tr key={f.key}>
              <td>{f.label}</td>
              <td className="mono">{f.key}</td>
              <td>{f.required ? "yes" : "no"}</td>
              <td className="note" style={{ whiteSpace: "normal", maxWidth: 460 }}>
                {f.help}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}
