import { NextResponse } from "next/server";
import { getConfig, resetAll, resetMetric, setParams } from "@/lib/config/store";
import { METRIC_BY_ID, type MetricId } from "@/lib/config/metrics";

export async function GET() {
  return NextResponse.json({ config: getConfig() });
}

export async function POST(req: Request) {
  const body = (await req.json()) as {
    action?: "save" | "reset" | "reset_all";
    metric?: MetricId;
    params?: Record<string, number>;
  };

  if (body.action === "reset_all") {
    return NextResponse.json({ config: resetAll() });
  }
  if (!body.metric || !METRIC_BY_ID[body.metric]) {
    return NextResponse.json({ error: "Unknown metric" }, { status: 400 });
  }
  if (body.action === "reset") {
    return NextResponse.json({ config: resetMetric(body.metric) });
  }
  return NextResponse.json({ config: setParams(body.metric, body.params ?? {}) });
}
