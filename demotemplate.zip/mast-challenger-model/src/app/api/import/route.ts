import { NextResponse } from "next/server";
import { MarketData } from "@/lib/models/market";
import {
  buildTrades,
  parseCsv,
  suggestMapping,
  CANONICAL_FIELDS,
} from "@/lib/import/csv";
import {
  deleteTradesBySource,
  insertTrades,
  loadEvents,
  loadMarketDaily,
} from "@/lib/db/repo";
import { invalidateAnalysis } from "@/lib/detect/engine";
import { setDataset } from "@/lib/config/store";

export const maxDuration = 60;

function market(): MarketData {
  const m = new MarketData(loadMarketDaily());
  m.setEvents(loadEvents());
  return m;
}

export async function POST(req: Request) {
  const body = (await req.json()) as {
    action: "preview" | "commit";
    csv: string;
    mapping?: Record<string, string>;
    activate?: boolean;
  };

  if (!body?.csv || typeof body.csv !== "string") {
    return NextResponse.json({ error: "No CSV content received." }, { status: 400 });
  }
  const parsed = parseCsv(body.csv);
  if (!parsed.headers.length) {
    return NextResponse.json({ error: "Could not read a header row." }, { status: 400 });
  }

  if (body.action === "preview") {
    return NextResponse.json({
      headers: parsed.headers,
      sample: parsed.rows.slice(0, 5),
      rows: parsed.rows.length,
      mapping: suggestMapping(parsed.headers),
      fields: CANONICAL_FIELDS,
    });
  }

  const result = buildTrades(parsed, body.mapping ?? {}, market());
  if (result.errors.length) {
    return NextResponse.json({ ...result, trades: undefined, imported: 0 }, { status: 400 });
  }

  deleteTradesBySource("imported");
  insertTrades(result.trades);
  invalidateAnalysis();
  if (body.activate !== false) setDataset("imported");

  return NextResponse.json({
    imported: result.trades.length,
    rowsRead: result.rowsRead,
    warnings: result.warnings,
    missingOptional: result.missingOptional,
    limitations: result.limitations,
    activated: body.activate !== false,
  });
}
