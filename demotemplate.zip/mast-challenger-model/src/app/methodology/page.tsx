import Link from "next/link";
import { METRICS } from "@/lib/config/metrics";
import { MIM_DEFAULTS } from "@/lib/models/mim";

export const dynamic = "force-dynamic";

export default function MethodologyPage() {
  return (
    <>
      <h1>Methodology</h1>

      <h2>1. The synthetic instrument (General Market Model)</h2>
      <p>
        An FX trade is an exchange of two currencies, so a trader can build a position in one
        currency through any number of pairs. Looking at headline pairs in isolation misses that
        entirely.
      </p>
      <p>
        So every trade is split into <b>equivalent trades</b> against USD. A trade between two
        non-USD currencies produces two — one per leg; a trade that already involves USD produces
        one. Each lands on a <b>synthetic instrument</b> representing that currency against USD.
      </p>
      <pre className="small">
        {`sell 115 EUR / buy 100 GBP
  -> EUR/USD, sensitivity -115 EUR
  -> GBP/USD, sensitivity +100 GBP`}
      </pre>
      <p>
        The signed amount on the synthetic instrument is the trade&apos;s <b>Sensitivity</b>, and it
        is what every metric consumes — never the raw buy and sell amounts. A trader who accumulates
        JPY through EUR/JPY, GBP/JPY and AUD/JPY shows up as one position on JPY/USD, which is what
        makes cross-currency abuse visible.
      </p>

      <h2>2. The Market Impact Model</h2>
      <p>Buying pushes a price up, selling pushes it down. The model estimates by how much:</p>
      <pre className="small">
        {`impact    = K x volatility x (notional / ADTV)
impact(t) = impact x exp(-lambda x t)`}
      </pre>
      <ul>
        <li>proportional to trade size</li>
        <li>proportional to the volatility of the instrument</li>
        <li>inversely proportional to average daily traded volume</li>
        <li>instantaneous, and additive across nearby trades</li>
        <li>
          decaying exponentially back toward zero — half-life {MIM_DEFAULTS.halfLifeMinutes} minutes
          here
        </li>
      </ul>
      <p>
        The same five trades produce far more impact in a thin, volatile instrument than in a deep,
        calm one. K is a calibration constant chosen so that a very large clip in a liquid major
        moves the modelled price by a couple of basis points; a single trade&apos;s impact is capped
        at 25 bps, because a linear model overstates very large clips in thin emerging-market
        instruments. This is the v1 formulation — linear in size with exponential decay. A v2
        formulation would make impact logarithmic in size and let it diffuse against a market memory
        of recent flow.
      </p>
      <p>
        The model is agnostic about whether the price actually moved. It measures what the
        trader&apos;s actions should have done to the market — which is a statement about intent,
        and it holds whether or not the trader got lucky.
      </p>

      <h2>3. USD Value</h2>
      <p>
        Every metric ends in the same place: a single dollar figure estimating what the trader was
        trying to gain.
      </p>
      <pre className="small">USD Value = EMI x PTC</pre>
      <ul>
        <li>
          <b>EMI</b> — Expected Market Impact: the price impact through time of the action being
          scored.
        </li>
        <li>
          <b>PTC</b> — Profit-Taking Component: the size of the position positioned to benefit from
          that impact.
        </li>
      </ul>
      <p>
        <b>The exhaustion principle:</b> if the position benefiting is larger than the trades that
        created the impact, only the portion the impact could plausibly have benefited counts, so
        the PTC is capped at the impacting notional.
      </p>
      <p>
        Some metrics — Wash Trading and Layering/Spoofing — are not really about impact but about
        whether an innocent explanation exists. Those score a <b>Narrative</b> (what the abusive
        reading is worth) against a <b>Counter-Narrative</b> (genuine market risk taken, real client
        business, the cost of being filled), and alert only where the Narrative dominates.
      </p>

      <h2>4. The Allocation Algorithm</h2>
      <p>
        To know whether a trade built a proprietary position or simply filled a client order, you
        have to connect buys with sells. The allocation algorithm matches opposite-direction trades
        inside a book, on the heuristic that two trades are more likely to be a pair the closer they
        are in both timestamp and size — with client facilitation given priority, because filling
        client orders is the main reason a sell-side book trades at all.
      </p>
      <p>
        Matching is partial: a 600k sell can be one third facilitation and two thirds proprietary.
        Whatever cannot be explained as facilitation is treated as proprietary, and that residual is
        what Front Running and Ramping care about.
      </p>

      <h2>5. The Event Generator</h2>
      <p>
        Insider Trading needs something to be insider to. The simulation generates a calendar of
        scheduled releases and surprise shocks — rate decisions, inflation prints, sovereign
        headlines — each with an affected currency, a signed price move and the timestamp at which
        it became public.
      </p>
      <p>
        The move is applied to the instrument as a step change at exactly that public timestamp. A
        position held into the announcement is therefore worth precisely what the model says it is
        worth, which is what makes the metric measurable rather than hand-waved.
      </p>
      <p>
        The comparison is between the position a trader actually held and the position a fair trader
        could have been expected to hold. Position built well before the event is ordinary business;
        position built in the final hours before it is not, and it is that excess — not the whole
        position — that gets valued at the realised move.
      </p>

      <h2>6. The data behind all of this</h2>
      <p>
        Every trader, counterparty, trade, order, rate and event in this application is synthetic.
        Market reference data is a generated daily mid series per instrument, plus a volatility and
        an ADTV figure; intraday mids come from a deterministic Brownian bridge pinned to each
        day&apos;s open and close, so a mid is available at any millisecond.
      </p>
      <p>
        The overwhelming majority of trades are ordinary activity, including things that
        structurally resemble abuse — a trader working a large order in clips, then closing the
        position later in the session, looks a lot like a ramp. That is the point: a pattern match
        alone produces noise, which is why everything is scored in dollars and compared against a
        threshold.
      </p>
      <p>
        A handful of instances per metric are deliberately engineered, with three severity tiers for
        Ramping and Wash Trading. Those trades carry an internal tag used only to check coverage
        when testing — <b>no detection engine reads it</b>. Every alert in the app was computed from
        trade and market data alone.
      </p>

      <h2>The metrics</h2>
      {METRICS.map((m) => (
        <div key={m.id}>
          <h3>
            <Link href={`/alerts/${m.id}`}>{m.label}</Link>
          </h3>
          <p>{m.about}</p>
          <p className="note">Scoring: {m.usdValue}</p>
        </div>
      ))}
    </>
  );
}
