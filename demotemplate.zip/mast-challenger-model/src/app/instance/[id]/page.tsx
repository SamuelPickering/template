import Link from "next/link";
import { notFound } from "next/navigation";
import { ImpactChart } from "@/components/ImpactChart";
import { METRIC_BY_ID } from "@/lib/config/metrics";
import { currentRun, findInstance, instanceChart, tradesByIds } from "@/lib/queries";
import { loadOrders } from "@/lib/db/repo";
import { fmtAmount, fmtComponent, fmtDateTime, fmtRate, fmtUsd } from "@/lib/format";
import type { OrderRow } from "@/lib/types";

export const dynamic = "force-dynamic";

export default async function InstanceDetail({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const instanceId = decodeURIComponent(id);
  const run = currentRun();
  const instance = findInstance(run, instanceId);
  if (!instance) notFound();

  const def = METRIC_BY_ID[instance.metric];
  const stats = run.stats.find((s) => s.metric === instance.metric)!;
  const isAlert = instance.usd_value > stats.threshold;
  const trades = tradesByIds(instance.trade_ids);
  const chart = instanceChart(instance);
  const roleOf = new Map(instance.markers.map((m) => [m.trade_id, m]));
  const orderIds = new Set(instance.order_ids ?? []);
  const orders: OrderRow[] = orderIds.size
    ? loadOrders().filter((o) => orderIds.has(o.order_id))
    : [];

  return (
    <>
      <h1>
        {def.label}: {fmtUsd(instance.usd_value)}
      </h1>
      <p className="note">
        {instance.headline} — {isAlert ? "above" : "below"} the {fmtUsd(stats.threshold)} threshold.{" "}
        <Link href={`/alerts/${instance.metric}`}>Back to {def.label}</Link>
      </p>

      <p className="stats">
        <span>
          <b>Trader:</b> {instance.trader_name} ({instance.trader_id})
        </span>
        <span>
          <b>Instrument:</b> {instance.instrument}
        </span>
        <span>
          <b>Date:</b> {instance.trade_date}
        </span>
        <span>
          <b>Trades:</b> {instance.trade_ids.length}
          {orders.length ? ` + ${orders.length} orders` : ""}
        </span>
      </p>

      <h2>Why this instance triggered</h2>
      <p>{instance.explanation}</p>

      <h2>Computed values</h2>
      <table>
        <thead>
          <tr>
            <th>Value</th>
            <th className="n">Amount</th>
            <th>What it is</th>
          </tr>
        </thead>
        <tbody>
          {instance.components.map((c) => (
            <tr key={c.label}>
              <td>{c.label}</td>
              <td className="n">{fmtComponent(c.value, c.unit)}</td>
              <td style={{ whiteSpace: "normal", maxWidth: 520 }} className="note">
                {c.help}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {chart.length > 0 && (
        <>
          <h2>Modelled market impact</h2>
          <p className="note small">
            Market Impact Model estimate of how this flow moved the synthetic instrument, and how
            that impact decayed afterwards.
          </p>
          <ImpactChart data={chart} markers={instance.markers} />
        </>
      )}

      <h2>Trades in this instance</h2>
      <p className="small">
        <Link
          href={`/blotter?trader=${instance.trader_id}&date=${instance.trade_date}&highlight=${instance.trade_ids.join(",")}`}
        >
          Show these on the blotter
        </Link>
      </p>
      <table>
        <thead>
          <tr>
            <th>Part played</th>
            <th>Trade</th>
            <th>Execution time</th>
            <th>Trader</th>
            <th>Pair</th>
            <th className="n">Buy</th>
            <th className="n">Sell</th>
            <th className="n">Rate</th>
            <th className="n">Notional USD</th>
            <th>Counterparty</th>
            <th>Role</th>
          </tr>
        </thead>
        <tbody>
          {trades.map((t) => {
            const m = roleOf.get(t.trade_id);
            return (
              <tr key={t.trade_id} className={m?.role ?? ""}>
                <td>{m ? m.label : "Context"}</td>
                <td className="mono">{t.trade_id}</td>
                <td className="mono">{fmtDateTime(t.execution_ms)}</td>
                <td>{t.trader_name}</td>
                <td className="mono">{t.currency_pair}</td>
                <td className="n">
                  {fmtAmount(t.buy_amount)} {t.buy_currency}
                </td>
                <td className="n">
                  {fmtAmount(t.sell_amount)} {t.sell_currency}
                </td>
                <td className="n">{fmtRate(t.execution_rate)}</td>
                <td className="n">{fmtUsd(t.notional_usd)}</td>
                <td>{t.counterparty_id ?? "-"}</td>
                <td>{t.trade_role.replace("_", " ")}</td>
              </tr>
            );
          })}
        </tbody>
      </table>

      {orders.length > 0 && (
        <>
          <h2>Orders in this instance</h2>
          <table>
            <thead>
              <tr>
                <th>Order</th>
                <th>Pair</th>
                <th>Side</th>
                <th className="n">Limit</th>
                <th className="n">Size USD</th>
                <th>Placed</th>
                <th>Cancelled</th>
                <th className="n">Filled</th>
                <th className="n">Life</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((o) => (
                <tr key={o.order_id}>
                  <td className="mono">{o.order_id}</td>
                  <td className="mono">{o.currency_pair}</td>
                  <td>{o.side}</td>
                  <td className="n">{fmtRate(o.limit_price)}</td>
                  <td className="n">{fmtUsd(o.size_usd)}</td>
                  <td className="mono">{fmtDateTime(o.placed_ms).slice(11)}</td>
                  <td className="mono">
                    {o.cancelled_ms ? fmtDateTime(o.cancelled_ms).slice(11) : "-"}
                  </td>
                  <td className="n">{fmtUsd(o.filled_size_usd)}</td>
                  <td className="n">
                    {o.cancelled_ms ? `${((o.cancelled_ms - o.placed_ms) / 1000).toFixed(0)}s` : "-"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </>
      )}

      <h2>What {def.label.toLowerCase()} is, and why it matters</h2>
      <p>{def.about}</p>
      <p className="note">{def.usdValue}</p>
    </>
  );
}
