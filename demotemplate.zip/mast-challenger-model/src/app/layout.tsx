import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { Nav } from "@/components/Nav";
import { getDataset } from "@/lib/config/store";

export const metadata: Metadata = {
  title: "MAST Challenger Model",
  description: "Educational FX trade surveillance simulation",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>
        <Nav dataset={getDataset()} />
        <div id="wrap">{children}</div>
      </body>
    </html>
  );
}
