import Link from "next/link";
import { MetricConfigCard } from "@/components/MetricConfigCard";
import { METRICS } from "@/lib/config/metrics";
import { getConfig } from "@/lib/config/store";
import { currentRun } from "@/lib/queries";
import { fmtUsd } from "@/lib/format";

export const dynamic = "force-dynamic";

export default function AdminPage() {
  const cfg = getConfig();
  const run = currentRun();
  const byMetric = new Map(run.stats.map((s) => [s.metric, s]));

  return (
    <>
      <h1>Admin — Thresholds &amp; Sensitivities</h1>
      <p className="note">
        Parameters are evaluated live. Applying a change re-runs the detection pipeline against the
        current dataset, so the <Link href="/alerts">alerts</Link> and dashboard immediately reflect
        what now qualifies. Nothing is snapshotted.
      </p>

      <p className="stats">
        <span>
          <b>Alerts now:</b> {run.alerts.length}
        </span>
        <span>
          <b>Instances scored:</b> {run.instances.length}
        </span>
        <span>
          <b>Total USD Value:</b> {fmtUsd(run.stats.reduce((s, m) => s + m.usd_total, 0))}
        </span>
        <span>
          <b>Config fingerprint:</b> {run.config_hash}
        </span>
      </p>

      {METRICS.map((def) => {
        const s = byMetric.get(def.id)!;
        return (
          <MetricConfigCard
            key={def.id}
            def={def}
            values={cfg[def.id]}
            alerts={s.alerts}
            instances={s.instances}
            topUsd={s.top_usd}
          />
        );
      })}
    </>
  );
}
