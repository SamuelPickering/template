import Link from "next/link";
import { AlertsTable } from "@/components/AlertsTable";
import { METRICS } from "@/lib/config/metrics";
import { currentRun } from "@/lib/queries";
import { fmtUsd } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function AlertsInbox({
  searchParams,
}: {
  searchParams: Promise<{ sort?: string }>;
}) {
  const { sort } = await searchParams;
  const run = currentRun();
  const thresholds = new Map(run.stats.map((s) => [s.metric, s.threshold]));

  const alerts = [...run.alerts];
  if (sort === "recent") alerts.sort((a, b) => b.start_ms - a.start_ms);
  else if (sort === "metric")
    alerts.sort((a, b) => a.metric.localeCompare(b.metric) || b.usd_value - a.usd_value);
  else alerts.sort((a, b) => b.usd_value - a.usd_value);

  const totalUsd = alerts.reduce((s, a) => s + a.usd_value, 0);

  return (
    <>
      <h1>Alerts Inbox</h1>
      <p className="note">
        Every instance whose USD Value exceeds its metric&apos;s threshold. Change a threshold on
        the Admin page and this list changes with it.
      </p>

      <p className="stats">
        <span>
          <b>Open alerts:</b> {alerts.length}
        </span>
        <span>
          <b>Total USD Value:</b> {fmtUsd(totalUsd)}
        </span>
        <span>
          <b>Traders involved:</b> {new Set(alerts.map((a) => a.trader_id)).size}
        </span>
        <span>
          <b>Metrics firing:</b> {run.stats.filter((s) => s.alerts > 0).length} of {METRICS.length}
        </span>
      </p>

      <p className="small">
        Sort:{" "}
        {[
          ["usd", "USD Value"],
          ["recent", "Most recent"],
          ["metric", "Metric"],
        ].map(([key, label], i) => (
          <span key={key}>
            {i > 0 ? " | " : ""}
            {(sort ?? "usd") === key ? <b>{label}</b> : <Link href={`/alerts?sort=${key}`}>{label}</Link>}
          </span>
        ))}
      </p>

      <AlertsTable alerts={alerts} thresholds={thresholds} />
    </>
  );
}
