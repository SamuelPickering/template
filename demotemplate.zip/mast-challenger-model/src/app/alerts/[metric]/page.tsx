import Link from "next/link";
import { notFound } from "next/navigation";
import { AlertsTable } from "@/components/AlertsTable";
import { METRICS, METRIC_BY_ID, type MetricId } from "@/lib/config/metrics";
import { currentRun } from "@/lib/queries";
import { fmtUsd } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function AlertsByMetric({
  params,
}: {
  params: Promise<{ metric: string }>;
}) {
  const { metric } = await params;
  const def = METRIC_BY_ID[metric as MetricId];
  if (!def) notFound();

  const run = currentRun();
  const stats = run.stats.find((s) => s.metric === def.id)!;
  const thresholds = new Map(run.stats.map((s) => [s.metric, s.threshold]));
  const alerts = run.alerts.filter((a) => a.metric === def.id);
  const below = run.instances
    .filter((i) => i.metric === def.id && i.usd_value <= stats.threshold)
    .slice(0, 20);

  return (
    <>
      <h1>{def.label}</h1>
      <p>{def.about}</p>

      <p className="small">
        Metric:{" "}
        {METRICS.map((m, i) => {
          const s = run.stats.find((x) => x.metric === m.id)!;
          return (
            <span key={m.id}>
              {i > 0 ? " | " : ""}
              {m.id === def.id ? (
                <b>
                  {m.label} ({s.alerts})
                </b>
              ) : (
                <Link href={`/alerts/${m.id}`}>
                  {m.label} ({s.alerts})
                </Link>
              )}
            </span>
          );
        })}
      </p>

      <p className="stats">
        <span>
          <b>Alerts:</b> {stats.alerts}
        </span>
        <span>
          <b>Instances scored:</b> {stats.instances}
        </span>
        <span>
          <b>Threshold:</b> {fmtUsd(stats.threshold)} (<Link href="/admin">edit</Link>)
        </span>
        <span>
          <b>Total USD Value:</b> {fmtUsd(stats.usd_total)}
        </span>
      </p>

      <h2>Scoring</h2>
      <p className="note">{def.usdValue}</p>

      <h2>Alerts</h2>
      <AlertsTable alerts={alerts} thresholds={thresholds} showMetric={false} />

      <details>
        <summary>
          Below threshold ({below.length} shown of{" "}
          {Math.max(0, stats.instances - stats.alerts)})
        </summary>
        <p className="note small">
          Scored but not alerting. Not noteworthy on their own — they are here to show what the
          threshold and sensitivity settings are actually doing. Lower the threshold on the Admin
          page and these are the first to appear.
        </p>
        {below.length === 0 ? (
          <p className="note small">No sub-threshold instances.</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th className="n">USD Value</th>
                <th>Trader</th>
                <th>Instrument</th>
                <th>Instance</th>
              </tr>
            </thead>
            <tbody>
              {below.map((i) => (
                <tr key={i.instance_id}>
                  <td className="n">{fmtUsd(i.usd_value)}</td>
                  <td>{i.trader_name}</td>
                  <td className="mono">{i.instrument}</td>
                  <td>
                    <Link href={`/instance/${encodeURIComponent(i.instance_id)}`}>
                      {i.headline}
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </details>
    </>
  );
}
