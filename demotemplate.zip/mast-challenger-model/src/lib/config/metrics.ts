export type MetricId =
  | "insider_trading"
  | "front_running"
  | "internal_front_running"
  | "ramping"
  | "banging_the_close"
  | "wash_trading"
  | "cross_trading"
  | "off_market_trading"
  | "layering_spoofing";

export interface ParamDef {
  key: string;
  label: string;
  help: string;
  type: "number" | "toggle";
  default: number;
  min?: number;
  max?: number;
  step?: number;
  unit?: string;
}

export interface MetricDef {
  id: MetricId;
  label: string;
  short: string;
  /** Plain-English explainer shown on alert detail pages. */
  about: string;
  /** How USD Value is specialised for this metric (EMI x PTC). */
  usdValue: string;
  params: ParamDef[];
}

const threshold = (def: number): ParamDef => ({
  key: "threshold_usd_value",
  label: "USD Value threshold",
  help: "An instance becomes an alert when its USD Value score exceeds this amount.",
  type: "number",
  default: def,
  min: 0,
  max: 5_000_000,
  step: 500,
  unit: "USD",
});

export const METRICS: MetricDef[] = [
  {
    id: "insider_trading",
    label: "Insider Trading",
    short: "Position built ahead of a non-public price move.",
    about:
      "Insider Trading looks for traders who held an unusually large position in the direction of a price shock immediately before that shock became public. Unlike every other metric here, it is not about causing a price move - it is about exploiting one. No Market Impact Model is involved.",
    usdValue:
      "EMI is replaced by the realised price move of the event; PTC is the excess of the trader's actual position over the time-weighted position a fair trader could have been expected to hold. USD Value = excess position x price move.",
    params: [
      threshold(50_000),
      {
        key: "lookback_hours",
        label: "Lookback window",
        help: "How far before the event becoming public we examine position-building.",
        type: "number",
        default: 48,
        min: 1,
        max: 240,
        step: 1,
        unit: "hours",
      },
      {
        key: "min_event_move_pct",
        label: "Event sensitivity",
        help: "Minimum absolute price move for an event to be considered material.",
        type: "number",
        default: 0.35,
        min: 0,
        max: 5,
        step: 0.05,
        unit: "%",
      },
      {
        key: "expectation_half_life_hours",
        label: "Expectation half-life",
        help: "How quickly the position a fair trader could be expected to hold decays back toward flat as the event approaches.",
        type: "number",
        default: 18,
        min: 1,
        max: 120,
        step: 1,
        unit: "hours",
      },
    ],
  },
  {
    id: "front_running",
    label: "Front Running",
    short: "Prop position exited into the impact of the trader's own client flow.",
    about:
      "A trader who knows a large client order is coming can open a proprietary position first and exit into the price impact that filling the client order creates. Materiality rises as the gap between the prop exit and the client facilitation trade shrinks.",
    usdValue:
      "EMI is the modelled price impact of the client facilitation trades; PTC is the size of the prop position exiting into that impact, capped at the size of the impacting trades (exhaustion principle).",
    params: [
      threshold(20_000),
      {
        key: "max_lead_seconds",
        label: "Max lead time",
        help: "Largest gap between the prop exit and the client facilitation trade that still counts as front running.",
        type: "number",
        default: 900,
        min: 5,
        max: 14_400,
        step: 5,
        unit: "seconds",
      },
      {
        key: "min_prop_notional_usd",
        label: "Min prop notional",
        help: "Prop exits smaller than this are ignored.",
        type: "number",
        default: 250_000,
        min: 0,
        max: 50_000_000,
        step: 50_000,
        unit: "USD",
      },
      {
        key: "require_same_trader",
        label: "Same trader only",
        help: "When on, the prop position and the client facilitation must belong to the same trader. Turn off to catch arrangements between two traders.",
        type: "toggle",
        default: 1,
      },
    ],
  },
  {
    id: "internal_front_running",
    label: "Internal Front Running",
    short: "One book trading ahead of the impact caused by another book in the firm.",
    about:
      "The same pattern as Front Running, but the market impact is created by a different book inside the firm. It captures information leakage across internal walls: one trader positions themselves just before another trader's large flow moves the synthetic instrument.",
    usdValue:
      "EMI is the impact of the other book's trades; PTC is the position the benefiting book holds into that impact, capped at the impacting notional.",
    params: [
      threshold(25_000),
      {
        key: "max_lead_seconds",
        label: "Max lead time",
        help: "Largest gap between the benefiting trade and the other book's impacting flow.",
        type: "number",
        default: 1_200,
        min: 5,
        max: 14_400,
        step: 5,
        unit: "seconds",
      },
      {
        key: "min_impact_bps",
        label: "Min modelled impact",
        help: "Ignore impacting flow whose modelled price impact is below this, in basis points.",
        type: "number",
        default: 0.05,
        min: 0,
        max: 50,
        step: 0.01,
        unit: "bps",
      },
    ],
  },
  {
    id: "ramping",
    label: "Ramping",
    short: "Aggressive directional buying or selling, then a profitable reversal.",
    about:
      "Ramping is a run of aggressive same-direction trades that pushes the price of an instrument, followed by an exit into the price the trader just created. The build phase generates the market impact; the reversal is where the trader takes the profit.",
    usdValue:
      "EMI is the cumulative modelled impact of the build-phase trades at the moment of reversal; PTC is the notional reversed out, capped at the build notional.",
    params: [
      threshold(15_000),
      {
        key: "min_trade_count",
        label: "Min trades in build",
        help: "Minimum number of same-direction trades before a reversal is considered ramping.",
        type: "number",
        default: 4,
        min: 2,
        max: 50,
        step: 1,
        unit: "trades",
      },
      {
        key: "max_reversal_window_minutes",
        label: "Max reversal window",
        help: "How long after the build phase the reversal must begin.",
        type: "number",
        default: 90,
        min: 1,
        max: 1_440,
        step: 1,
        unit: "minutes",
      },
      {
        key: "min_directional_ratio",
        label: "Min directional purity",
        help: "Share of build-phase notional that must be in the same direction.",
        type: "number",
        default: 0.8,
        min: 0.5,
        max: 1,
        step: 0.01,
      },
      {
        key: "max_build_minutes",
        label: "Max build duration",
        help: "Longest span of time the build phase may cover.",
        type: "number",
        default: 180,
        min: 5,
        max: 1_440,
        step: 5,
        unit: "minutes",
      },
    ],
  },
  {
    id: "banging_the_close",
    label: "Banging the Close",
    short: "Concentrated trading inside the fixing window to move the fix price.",
    about:
      "Many contracts settle against a published closing or fixing price. A trader with exposure to that fix can concentrate their trading inside the fixing window to drag the fix in a favourable direction, instead of spreading the same volume evenly.",
    usdValue:
      "EMI is the difference between the actual fix and the modelled fair fix that evenly-spread trading would have produced; PTC is the trader's exposure to the fix.",
    params: [
      threshold(20_000),
      {
        key: "closing_window_minutes",
        label: "Closing window",
        help: "Length of the simulated daily FX fix window.",
        type: "number",
        default: 15,
        min: 1,
        max: 120,
        step: 1,
        unit: "minutes",
      },
      {
        key: "min_window_notional_usd",
        label: "Min window notional",
        help: "Ignore traders with less than this notional inside the window.",
        type: "number",
        default: 2_000_000,
        min: 0,
        max: 500_000_000,
        step: 250_000,
        unit: "USD",
      },
      {
        key: "min_concentration",
        label: "Min concentration",
        help: "Share of the trader's daily notional in that instrument that must fall inside the window.",
        type: "number",
        default: 0.3,
        min: 0,
        max: 1,
        step: 0.01,
      },
    ],
  },
  {
    id: "wash_trading",
    label: "Wash Trading",
    short: "Offsetting legs that leave no genuine market risk.",
    about:
      "Wash Trading is trading with yourself, or with a related party, so that the two legs cancel out. It creates the appearance of volume and price without transferring real risk. The cross-currency variant hides the offset behind two different currency pairs that map to the same synthetic instrument.",
    usdValue:
      "Narrative is the modelled impact and apparent cost the paired legs create; Counter-Narrative is the genuine market risk actually run between the legs plus any client facilitation explanation. An alert is raised where the Narrative dominates.",
    params: [
      threshold(15_000),
      {
        key: "max_leg_gap_minutes",
        label: "Max gap between legs",
        help: "Longest time between the two offsetting legs.",
        type: "number",
        default: 30,
        min: 0,
        max: 1_440,
        step: 1,
        unit: "minutes",
      },
      {
        key: "size_match_tolerance_pct",
        label: "Size match tolerance",
        help: "How closely the two legs must offset in size.",
        type: "number",
        default: 15,
        min: 0,
        max: 100,
        step: 1,
        unit: "%",
      },
      {
        key: "require_instrument_match",
        label: "Require instrument match",
        help: "When on, both legs must land on the same synthetic instrument. Turning this off is what surfaces cross-currency wash trades.",
        type: "toggle",
        default: 1,
      },
      {
        key: "require_price_match",
        label: "Require price match",
        help: "When on, the two legs must also execute at a near-identical rate.",
        type: "toggle",
        default: 0,
      },
    ],
  },
  {
    id: "cross_trading",
    label: "Cross Trading",
    short: "Two internal books trading against each other at the same instant.",
    about:
      "Cross Trading is two books inside the same firm taking opposite sides of the same instrument at effectively the same moment. Risk moves between them without going to the street, which can be used to shift value or PnL from one book to another.",
    usdValue:
      "EMI is the modelled cost imposed by executing away from the prevailing mid; PTC is the notional crossed between the two books.",
    params: [
      threshold(15_000),
      {
        key: "max_timestamp_gap_seconds",
        label: "Max timestamp gap",
        help: "How close in time the two sides must be.",
        type: "number",
        default: 10,
        min: 0,
        max: 3_600,
        step: 1,
        unit: "seconds",
      },
      {
        key: "size_match_tolerance_pct",
        label: "Size match tolerance",
        help: "How closely the two sides must match in size.",
        type: "number",
        default: 15,
        min: 0,
        max: 100,
        step: 1,
        unit: "%",
      },
    ],
  },
  {
    id: "off_market_trading",
    label: "Off-Market Trading",
    short: "Execution priced away from the prevailing market mid.",
    about:
      "A trade booked meaningfully away from where the market actually was transfers value between the two sides. It can conceal losses, move PnL between books or periods, or compensate a counterparty off the record.",
    usdValue:
      "EMI is the per-unit deviation of the execution rate from the modelled mid; PTC is the notional executed at that rate. USD Value is the value transferred.",
    params: [
      threshold(10_000),
      {
        key: "deviation_bps",
        label: "Deviation from mid",
        help: "How far from the modelled mid a trade must print to qualify.",
        type: "number",
        default: 25,
        min: 0.5,
        max: 500,
        step: 0.5,
        unit: "bps",
      },
      {
        key: "min_notional_usd",
        label: "Min notional",
        help: "Ignore small trades regardless of deviation.",
        type: "number",
        default: 250_000,
        min: 0,
        max: 100_000_000,
        step: 50_000,
        unit: "USD",
      },
    ],
  },
  {
    id: "layering_spoofing",
    label: "Layering / Spoofing",
    short: "Competitive orders placed to move price, then cancelled unfilled.",
    about:
      "Spoofing is placing orders you never intend to have filled. Because the orders sit close to the touch, they shift the perceived balance of supply and demand and move the price - and are then pulled before they can trade. The cross-currency variant places the decoy orders in a different pair from the one being exploited.",
    usdValue:
      "Narrative is the modelled price impact the resident orders create, weighted by how competitive they are; Counter-Narrative is the theoretical cost of unwinding had the orders unexpectedly filled. An alert is raised where the Narrative dominates.",
    params: [
      threshold(12_000),
      {
        key: "min_competitiveness",
        label: "Min order competitiveness",
        help: "How close to the touch an order must sit (1 = at or through the mid, 0 = far away).",
        type: "number",
        default: 0.5,
        min: 0,
        max: 1,
        step: 0.01,
      },
      {
        key: "cancel_ratio_threshold",
        label: "Cancel ratio threshold",
        help: "Share of the cluster's order notional that must be cancelled unfilled.",
        type: "number",
        default: 0.8,
        min: 0,
        max: 1,
        step: 0.01,
      },
      {
        key: "max_order_life_seconds",
        label: "Max order life",
        help: "Orders resting longer than this are treated as genuine liquidity.",
        type: "number",
        default: 120,
        min: 1,
        max: 3_600,
        step: 1,
        unit: "seconds",
      },
    ],
  },
];

export const METRIC_BY_ID: Record<MetricId, MetricDef> = Object.fromEntries(
  METRICS.map((m) => [m.id, m]),
) as Record<MetricId, MetricDef>;

export const METRIC_IDS: MetricId[] = METRICS.map((m) => m.id);

export type MetricConfig = Record<string, number>;
export type FullConfig = Record<MetricId, MetricConfig>;

export function defaultConfig(): FullConfig {
  const out = {} as FullConfig;
  for (const m of METRICS) {
    out[m.id] = Object.fromEntries(m.params.map((p) => [p.key, p.default]));
  }
  return out;
}
