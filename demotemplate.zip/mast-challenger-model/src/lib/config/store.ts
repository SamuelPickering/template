import crypto from "node:crypto";
import { getConfigStore, saveConfigStore } from "@/lib/db";
import {
  METRIC_BY_ID,
  METRIC_IDS,
  defaultConfig,
  type FullConfig,
  type MetricId,
} from "./metrics";

/** Live config: defaults overlaid with whatever the admin has saved. */
export function getConfig(): FullConfig {
  const cfg = defaultConfig();
  const saved = getConfigStore().config;
  for (const [metric, params] of Object.entries(saved)) {
    const target = cfg[metric as MetricId];
    if (!target) continue;
    for (const [key, value] of Object.entries(params)) {
      if (key in target) target[key] = value;
    }
  }
  return cfg;
}

export function setParams(
  metric: MetricId,
  params: Record<string, number>,
): FullConfig {
  const def = METRIC_BY_ID[metric];
  if (!def) throw new Error(`Unknown metric ${metric}`);
  const store = getConfigStore();
  const saved = (store.config[metric] ??= {});
  for (const [key, raw] of Object.entries(params)) {
    const p = def.params.find((x) => x.key === key);
    if (!p) continue;
    let v = Number(raw);
    if (!Number.isFinite(v)) continue;
    if (p.type === "toggle") v = v ? 1 : 0;
    if (p.min !== undefined) v = Math.max(p.min, v);
    if (p.max !== undefined) v = Math.min(p.max, v);
    saved[key] = v;
  }
  saveConfigStore(store);
  return getConfig();
}

export function resetMetric(metric: MetricId): FullConfig {
  const store = getConfigStore();
  delete store.config[metric];
  saveConfigStore(store);
  return getConfig();
}

export function resetAll(): FullConfig {
  const store = getConfigStore();
  store.config = {};
  saveConfigStore(store);
  return getConfig();
}

/** Stable hash of the live config — the cache key for a detection run. */
export function configHash(cfg: FullConfig): string {
  const canonical = METRIC_IDS.map((m) => {
    const params = Object.keys(cfg[m])
      .sort()
      .map((k) => `${k}=${cfg[m][k]}`)
      .join(",");
    return `${m}:{${params}}`;
  }).join("|");
  return crypto.createHash("sha1").update(canonical).digest("hex").slice(0, 16);
}

/* ---------- generic app settings ---------- */

export function getSetting(key: string, fallback: string): string {
  return getConfigStore().settings[key] ?? fallback;
}

export function setSetting(key: string, value: string): void {
  const store = getConfigStore();
  store.settings[key] = value;
  saveConfigStore(store);
}

export type Dataset = "synthetic" | "imported";

export function getDataset(): Dataset {
  return getSetting("dataset", "synthetic") === "imported" ? "imported" : "synthetic";
}

export function setDataset(ds: Dataset): void {
  setSetting("dataset", ds);
}
