/** Calendar and session helpers. Everything in the simulation is UTC. */

export const SESSION_START_MIN = 7 * 60; // 07:00 UTC
export const SESSION_END_MIN = 17 * 60; // 17:00 UTC
export const FIX_MIN = 16 * 60; // 16:00 UTC — the simulated daily FX fix

export const MS_MIN = 60_000;
export const MS_HOUR = 3_600_000;
export const MS_DAY = 86_400_000;

export function dateKey(ms: number): string {
  return new Date(ms).toISOString().slice(0, 10);
}

export function dayStartMs(date: string): number {
  return Date.parse(`${date}T00:00:00.000Z`);
}

export function isoMs(ms: number): string {
  return new Date(ms).toISOString();
}

export function isWeekend(date: string): boolean {
  const d = new Date(`${date}T00:00:00.000Z`).getUTCDay();
  return d === 0 || d === 6;
}

/** `count` business days ending on (and including) `endDate`. */
export function businessDays(endDate: string, count: number): string[] {
  const out: string[] = [];
  let ms = dayStartMs(endDate);
  while (out.length < count) {
    const key = dateKey(ms);
    if (!isWeekend(key)) out.unshift(key);
    ms -= MS_DAY;
  }
  return out;
}

export function minuteOfDay(ms: number): number {
  const d = new Date(ms);
  return d.getUTCHours() * 60 + d.getUTCMinutes() + d.getUTCSeconds() / 60;
}

export function atMinute(date: string, minute: number, msOffset = 0): number {
  return dayStartMs(date) + Math.round(minute * MS_MIN) + msOffset;
}

export function fmtDuration(ms: number): string {
  const s = Math.abs(ms) / 1000;
  if (s < 60) return `${s.toFixed(s < 10 ? 1 : 0)}s`;
  if (s < 3600) return `${(s / 60).toFixed(1)}m`;
  if (s < 86400) return `${(s / 3600).toFixed(1)}h`;
  return `${(s / 86400).toFixed(1)}d`;
}
