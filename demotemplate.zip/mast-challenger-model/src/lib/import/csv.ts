import type { Trade } from "@/lib/types";
import type { MarketData } from "@/lib/models/market";
import { conventionalPair } from "@/lib/gen/universe";
import { dateKey, isoMs } from "@/lib/time";

export interface CanonicalField {
  key: keyof Trade | "side";
  label: string;
  required: boolean;
  help: string;
  /** Header names we will match automatically. */
  aliases: string[];
}

export const CANONICAL_FIELDS: CanonicalField[] = [
  { key: "trade_id", label: "Trade ID", required: false, help: "Generated if absent.", aliases: ["trade_id", "tradeid", "id", "deal_id", "execution_id", "trade reference"] },
  { key: "trader_id", label: "Trader ID", required: false, help: "Falls back to the trader name.", aliases: ["trader_id", "traderid", "user_id", "trader code"] },
  { key: "trader_name", label: "Trader name", required: true, help: "Who executed the trade.", aliases: ["trader_name", "trader", "name", "dealer", "user"] },
  { key: "trade_role", label: "Trade role", required: false, help: "client_facilitation or prop. Defaults to prop, which limits Front Running.", aliases: ["trade_role", "role", "capacity", "trade_type"] },
  { key: "counterparty_id", label: "Counterparty", required: false, help: "Needed for Wash and Cross Trading relatedness.", aliases: ["counterparty_id", "counterparty", "cpty", "client_id", "account"] },
  { key: "currency_pair", label: "Currency pair", required: false, help: "Derived from the two currencies if absent.", aliases: ["currency_pair", "pair", "ccy_pair", "symbol", "instrument"] },
  { key: "buy_currency", label: "Buy currency", required: true, help: "Currency received.", aliases: ["buy_currency", "buy_ccy", "bought_currency", "base_currency_bought"] },
  { key: "sell_currency", label: "Sell currency", required: true, help: "Currency paid away.", aliases: ["sell_currency", "sell_ccy", "sold_currency"] },
  { key: "buy_amount", label: "Buy amount", required: true, help: "Amount received, in the buy currency.", aliases: ["buy_amount", "buy_amt", "bought_amount", "amount_bought"] },
  { key: "sell_amount", label: "Sell amount", required: true, help: "Amount paid away, in the sell currency.", aliases: ["sell_amount", "sell_amt", "sold_amount", "amount_sold"] },
  { key: "execution_rate", label: "Execution rate", required: false, help: "Derived from the amounts if absent.", aliases: ["execution_rate", "rate", "price", "fx_rate", "exec_price"] },
  { key: "notional_usd", label: "Notional USD", required: false, help: "Derived from market data if absent.", aliases: ["notional_usd", "usd_notional", "notional", "usd_amount"] },
  { key: "execution_datetime", label: "Execution timestamp", required: true, help: "ISO 8601 preferred; millisecond precision is used where present.", aliases: ["execution_datetime", "execution_time", "timestamp", "trade_time", "datetime", "exec_time", "time"] },
  { key: "order_id", label: "Order ID", required: false, help: "Only relevant to Layering/Spoofing.", aliases: ["order_id", "orderid", "parent_order"] },
  { key: "pnl", label: "PnL", required: false, help: "Optional. Displayed where present; no metric depends on it.", aliases: ["pnl", "p&l", "profit", "realised_pnl"] },
];

export interface ParsedCsv {
  headers: string[];
  rows: string[][];
}

/** Minimal RFC4180-ish parser: handles quotes, embedded commas and CRLF. */
export function parseCsv(text: string): ParsedCsv {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = "";
  let quoted = false;
  const src = text.replace(/^﻿/, "");

  for (let i = 0; i < src.length; i++) {
    const c = src[i];
    if (quoted) {
      if (c === '"') {
        if (src[i + 1] === '"') {
          field += '"';
          i++;
        } else quoted = false;
      } else field += c;
      continue;
    }
    if (c === '"') quoted = true;
    else if (c === ",") {
      row.push(field);
      field = "";
    } else if (c === "\n") {
      row.push(field);
      rows.push(row);
      row = [];
      field = "";
    } else if (c !== "\r") field += c;
  }
  if (field.length || row.length) {
    row.push(field);
    rows.push(row);
  }
  const nonEmpty = rows.filter((r) => r.some((v) => v.trim() !== ""));
  const headers = (nonEmpty.shift() ?? []).map((h) => h.trim());
  return { headers, rows: nonEmpty };
}

const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, "");

export function suggestMapping(headers: string[]): Record<string, string> {
  const out: Record<string, string> = {};
  for (const f of CANONICAL_FIELDS) {
    const hit = headers.find((h) => f.aliases.some((a) => norm(a) === norm(h)));
    if (hit) out[f.key] = hit;
  }
  return out;
}

export interface ImportResult {
  trades: Trade[];
  errors: string[];
  warnings: string[];
  missingOptional: string[];
  limitations: string[];
  rowsRead: number;
}

const num = (v: string | undefined): number => {
  if (v === undefined) return NaN;
  const cleaned = v.replace(/[, ]/g, "").replace(/[$€£]/g, "");
  return Number(cleaned);
};

export function buildTrades(
  parsed: ParsedCsv,
  mapping: Record<string, string>,
  market: MarketData,
): ImportResult {
  const errors: string[] = [];
  const warnings: string[] = [];
  const trades: Trade[] = [];
  const idx = new Map(parsed.headers.map((h, i) => [h, i]));
  const col = (key: string, row: string[]): string | undefined => {
    const header = mapping[key];
    if (!header) return undefined;
    const i = idx.get(header);
    return i === undefined ? undefined : row[i]?.trim();
  };

  for (const f of CANONICAL_FIELDS) {
    if (f.required && !mapping[f.key]) errors.push(`Required field "${f.label}" is not mapped.`);
  }
  if (errors.length) {
    return { trades: [], errors, warnings, missingOptional: [], limitations: [], rowsRead: 0 };
  }

  parsed.rows.forEach((row, n) => {
    if (trades.length > 250_000) return;
    const line = n + 2;
    const buyCcy = (col("buy_currency", row) ?? "").toUpperCase();
    const sellCcy = (col("sell_currency", row) ?? "").toUpperCase();
    const buyAmt = num(col("buy_amount", row));
    const sellAmt = num(col("sell_amount", row));
    const rawTime = col("execution_datetime", row) ?? "";
    const ms = parseTime(rawTime);

    if (!/^[A-Z]{3}$/.test(buyCcy) || !/^[A-Z]{3}$/.test(sellCcy)) {
      if (warnings.length < 25) warnings.push(`Line ${line}: unrecognised currency codes (${buyCcy}/${sellCcy}) — row skipped.`);
      return;
    }
    if (!Number.isFinite(buyAmt) || !Number.isFinite(sellAmt) || buyAmt <= 0 || sellAmt <= 0) {
      if (warnings.length < 25) warnings.push(`Line ${line}: buy/sell amounts missing or not numeric — row skipped.`);
      return;
    }
    if (!Number.isFinite(ms)) {
      if (warnings.length < 25) warnings.push(`Line ${line}: could not parse the execution timestamp "${rawTime}" — row skipped.`);
      return;
    }

    const pairRaw = col("currency_pair", row);
    const [base, quote] = pairRaw && pairRaw.includes("/")
      ? (pairRaw.toUpperCase().split("/") as [string, string])
      : conventionalPair(buyCcy, sellCcy);

    let rate = num(col("execution_rate", row));
    if (!Number.isFinite(rate) || rate <= 0) {
      rate = buyCcy === base ? sellAmt / buyAmt : buyAmt / sellAmt;
    }
    let notional = num(col("notional_usd", row));
    if (!Number.isFinite(notional) || notional <= 0) {
      notional =
        buyCcy === "USD"
          ? buyAmt
          : sellCcy === "USD"
            ? sellAmt
            : market.toUsd(buyAmt, buyCcy, ms);
    }

    const traderName = col("trader_name", row) || "Unknown trader";
    const traderId = col("trader_id", row) || `IMP-${traderName.replace(/\s+/g, "_").slice(0, 24)}`;
    const roleRaw = (col("trade_role", row) ?? "").toLowerCase();
    const role: Trade["trade_role"] =
      roleRaw.includes("client") || roleRaw.includes("facil") ? "client_facilitation" : "prop";
    const pnlRaw = num(col("pnl", row));

    trades.push({
      trade_id: col("trade_id", row) || `IMP${String(n + 1).padStart(7, "0")}`,
      trader_id: traderId,
      trader_name: traderName,
      trade_role: role,
      counterparty_id: col("counterparty_id", row) || null,
      currency_pair: `${base}/${quote}`,
      buy_currency: buyCcy,
      sell_currency: sellCcy,
      buy_amount: buyAmt,
      sell_amount: sellAmt,
      execution_rate: rate,
      notional_usd: notional,
      execution_ms: ms,
      execution_datetime: isoMs(ms),
      trade_date: dateKey(ms),
      order_id: col("order_id", row) || null,
      pnl: Number.isFinite(pnlRaw) ? pnlRaw : null,
      source: "imported",
      scenario_tag: null,
    });
  });

  const missingOptional = CANONICAL_FIELDS.filter((f) => !f.required && !mapping[f.key]).map(
    (f) => f.label,
  );
  const limitations: string[] = [];
  if (!mapping.trade_role)
    limitations.push(
      "Trade role is unmapped, so every trade is treated as proprietary. Front Running needs client facilitation flow to have anything to measure.",
    );
  if (!mapping.counterparty_id)
    limitations.push(
      "Counterparty is unmapped, so Wash Trading cannot tell an internal account from a street name and will score every match at its lowest relatedness.",
    );
  if (!mapping.notional_usd)
    limitations.push(
      "USD notional is unmapped and will be derived from the simulation's own market data, which may not match your books exactly.",
    );
  limitations.push(
    "Layering/Spoofing scores orders, not executions. An execution-only import produces no spoofing alerts.",
  );
  if (!mapping.pnl)
    limitations.push("PnL is unmapped. Nothing depends on it — it is displayed where present.");

  return { trades, errors, warnings, missingOptional, limitations, rowsRead: parsed.rows.length };
}

function parseTime(raw: string): number {
  if (!raw) return NaN;
  const direct = Date.parse(raw);
  if (Number.isFinite(direct)) return direct;
  // "YYYY-MM-DD HH:MM:SS.mmm" without a zone marker
  const m = raw.match(
    /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?(?:\.(\d{1,3}))?$/,
  );
  if (m) {
    return Date.UTC(
      +m[1],
      +m[2] - 1,
      +m[3],
      +m[4],
      +m[5],
      m[6] ? +m[6] : 0,
      m[7] ? +m[7].padEnd(3, "0") : 0,
    );
  }
  // "DD/MM/YYYY HH:MM"
  const d = raw.match(/^(\d{2})\/(\d{2})\/(\d{4})[ T](\d{2}):(\d{2})(?::(\d{2}))?$/);
  if (d) {
    return Date.UTC(+d[3], +d[2] - 1, +d[1], +d[4], +d[5], d[6] ? +d[6] : 0);
  }
  return NaN;
}
