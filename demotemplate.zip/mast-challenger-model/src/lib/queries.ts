import { loadTraders, loadTrades } from "@/lib/db/repo";
import { getData } from "@/lib/db";
import { buildContext, runAnalysis, type RunResult } from "@/lib/detect/engine";
import { getConfig, getDataset } from "@/lib/config/store";
import type { ImpactPoint, Instance } from "@/lib/detect/types";
import { impactChart } from "@/lib/detect/util";
import type { Trade } from "@/lib/types";

export function currentRun(): RunResult {
  return runAnalysis({ config: getConfig(), dataset: getDataset() });
}

export interface TraderRow {
  trader_id: string;
  name: string;
  trade_role: string;
  trades: number;
  notional_usd: number;
  alerts: number;
  usd_value: number;
}

export function traderRows(run: RunResult): TraderRow[] {
  const activity = new Map<string, { n: number; notional: number }>();
  for (const t of loadTrades(run.dataset)) {
    const e = activity.get(t.trader_id) ?? { n: 0, notional: 0 };
    e.n += 1;
    e.notional += t.notional_usd;
    activity.set(t.trader_id, e);
  }
  const alerts = new Map<string, { n: number; usd: number }>();
  for (const a of run.alerts) {
    const e = alerts.get(a.trader_id) ?? { n: 0, usd: 0 };
    e.n += 1;
    e.usd += a.usd_value;
    alerts.set(a.trader_id, e);
  }
  return loadTraders()
    .map((t) => ({
      trader_id: t.trader_id,
      name: t.name,
      trade_role: t.trade_role,
      trades: activity.get(t.trader_id)?.n ?? 0,
      notional_usd: activity.get(t.trader_id)?.notional ?? 0,
      alerts: alerts.get(t.trader_id)?.n ?? 0,
      usd_value: alerts.get(t.trader_id)?.usd ?? 0,
    }))
    .sort((a, b) => b.usd_value - a.usd_value || b.trades - a.trades);
}

export interface TradeFilters {
  trader?: string;
  pair?: string;
  date?: string;
  role?: string;
  search?: string;
  limit?: number;
  offset?: number;
}

export function queryTrades(
  dataset: string,
  f: TradeFilters,
): { rows: Trade[]; total: number } {
  const needle = f.search?.toLowerCase();
  const matched = loadTrades(dataset).filter((t) => {
    if (f.trader && t.trader_id !== f.trader) return false;
    if (f.pair && t.currency_pair !== f.pair) return false;
    if (f.date && t.trade_date !== f.date) return false;
    if (f.role && t.trade_role !== f.role) return false;
    if (needle) {
      const hay = `${t.trade_id} ${t.trader_name} ${t.counterparty_id ?? ""}`.toLowerCase();
      if (!hay.includes(needle)) return false;
    }
    return true;
  });
  // Most recent first, which is how a blotter is usually read.
  const ordered = matched.slice().sort((a, b) => b.execution_ms - a.execution_ms);
  const offset = f.offset ?? 0;
  return {
    rows: ordered.slice(offset, offset + (f.limit ?? 100)),
    total: ordered.length,
  };
}

export function tradesByIds(ids: string[], dataset = getDataset()): Trade[] {
  if (!ids.length) return [];
  const wanted = new Set(ids);
  return loadTrades(dataset)
    .filter((t) => wanted.has(t.trade_id))
    .sort((a, b) => a.execution_ms - b.execution_ms);
}

export function distinctPairs(dataset: string): string[] {
  return [...new Set(loadTrades(dataset).map((t) => t.currency_pair))].sort();
}

export function distinctDates(dataset: string): string[] {
  return [...new Set(loadTrades(dataset).map((t) => t.trade_date))].sort().reverse();
}

export function findInstance(run: RunResult, id: string): Instance | undefined {
  return run.instances.find((i) => i.instance_id === id);
}

/** Market impact curve for one instance, computed when the alert is opened. */
export function instanceChart(instance: Instance): ImpactPoint[] {
  const ctx = buildContext(getDataset());
  return impactChart(
    ctx,
    instance.instrument,
    instance.start_ms,
    instance.end_ms,
    instance.trade_ids,
  );
}

export interface DatasetSummaryRow {
  source: string;
  trades: number;
  first_date: string;
  last_date: string;
  notional: number;
}

export function datasetSummary(): DatasetSummaryRow[] {
  const out: DatasetSummaryRow[] = [];
  for (const [source, trades] of Object.entries(getData().trades)) {
    if (!trades.length) continue;
    let first = trades[0].trade_date;
    let last = trades[0].trade_date;
    let notional = 0;
    for (const t of trades) {
      if (t.trade_date < first) first = t.trade_date;
      if (t.trade_date > last) last = t.trade_date;
      notional += t.notional_usd;
    }
    out.push({ source, trades: trades.length, first_date: first, last_date: last, notional });
  }
  return out.sort((a, b) => a.source.localeCompare(b.source));
}
