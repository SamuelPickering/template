export type TradeRole = "client_facilitation" | "prop";
export type DataSource = "synthetic" | "imported";

export interface Trader {
  trader_id: string;
  name: string;
  trade_role: TradeRole;
}

export interface Counterparty {
  counterparty_id: string;
  name: string;
  kind: "client" | "street" | "internal";
}

export interface Currency {
  code: string;
  name: string;
  tier: "major" | "em";
  base_rate: number;
  ann_vol: number;
  adtv_usd: number;
  pip: number;
}

export interface MarketDay {
  currency: string;
  trade_date: string;
  mid_open: number;
  mid_close: number;
  volatility: number;
  adtv_usd: number;
  day_seed: number;
}

export interface Trade {
  trade_id: string;
  trader_id: string;
  trader_name: string;
  trade_role: TradeRole;
  counterparty_id: string | null;
  currency_pair: string;
  buy_currency: string;
  sell_currency: string;
  buy_amount: number;
  sell_amount: number;
  execution_rate: number;
  notional_usd: number;
  execution_ms: number;
  execution_datetime: string;
  trade_date: string;
  order_id: string | null;
  pnl: number | null;
  source: DataSource;
  scenario_tag: string | null;
}

export interface OrderRow {
  order_id: string;
  trader_id: string;
  trader_name: string;
  currency_pair: string;
  side: "buy" | "sell";
  limit_price: number;
  size_usd: number;
  placed_ms: number;
  cancelled_ms: number | null;
  filled_size_usd: number;
  trade_date: string;
  source: string;
  scenario_tag: string | null;
}

export interface MarketEvent {
  event_id: string;
  headline: string;
  description: string;
  currency: string;
  kind: "scheduled" | "surprise";
  move_pct: number;
  public_ms: number;
  public_datetime: string;
  trade_date: string;
}

/**
 * An equivalent trade on a synthetic instrument (see GMM, §4.1).
 * `sensitivity` is signed: positive = bought the non-USD currency.
 */
export interface EquivalentTrade {
  eq_id: string;
  trade_id: string;
  instrument: string; // e.g. "EUR/USD" — quoted USD per 1 unit of EUR
  currency: string; // "EUR"
  sensitivity: number; // signed amount in the non-USD currency
  sensitivity_usd: number; // signed USD-equivalent of that amount
  direction: 1 | -1;
  trade: Trade;
}
