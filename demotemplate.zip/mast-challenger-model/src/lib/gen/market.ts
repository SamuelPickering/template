import type { MarketDay } from "@/lib/types";
import { CURRENCIES } from "./universe";
import { gauss, hashSeed, mulberry32 } from "./rng";

/**
 * Daily market reference data per synthetic instrument: a mid-rate series
 * (USD per 1 unit of the currency), a daily volatility figure and an ADTV
 * figure. This is what feeds the Market Impact Model and the Off-Market
 * Trading deviation check.
 */
export function generateMarketDaily(dates: string[], seed = 20260101): MarketDay[] {
  const out: MarketDay[] = [];
  for (const ccy of CURRENCIES) {
    const rng = mulberry32(hashSeed("market", seed, ccy.code));
    let level = ccy.base_rate;
    // Daily vol implied by the annualised figure, with a slow-moving regime.
    const baseDaily = ccy.ann_vol / Math.sqrt(252);
    let regime = 1;
    for (const date of dates) {
      regime = 0.9 * regime + 0.1 * (0.7 + rng() * 0.7);
      const dailyVol = baseDaily * regime;
      const open = level;
      const drift = -0.02 * dailyVol; // mild mean reversion toward the base rate
      const pull = 0.01 * (ccy.base_rate - level) / ccy.base_rate;
      const close = open * (1 + drift + pull + dailyVol * gauss(rng));
      const adtv = ccy.adtv_usd * (0.75 + rng() * 0.5);
      out.push({
        currency: ccy.code,
        trade_date: date,
        mid_open: open,
        mid_close: close,
        volatility: dailyVol,
        adtv_usd: adtv,
        day_seed: hashSeed("intraday", seed, ccy.code, date) % 2147483647,
      });
      level = close;
    }
  }
  return out;
}
