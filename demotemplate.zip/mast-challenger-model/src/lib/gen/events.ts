import type { MarketEvent } from "@/lib/types";
import type { MarketData } from "@/lib/models/market";
import { atMinute, isoMs } from "@/lib/time";
import { hashSeed, mulberry32, pick, randInt, randRange } from "./rng";

/**
 * Event Generator (§4.4).
 *
 * A small calendar of FX-relevant macro and policy events. Each carries the
 * currency it moves, a signed move magnitude and the timestamp at which it
 * became public. The market model applies the move as a step change at exactly
 * that timestamp, so Insider Trading can measure what a position held into the
 * announcement was actually worth.
 */
const SCHEDULED = [
  { title: "{CCY} central bank rate decision", detail: "Policy rate {dir} against consensus; the statement {tone}." },
  { title: "{CCY} inflation print", detail: "Headline CPI came in {dir} of the survey median." },
  { title: "{CCY} employment report", detail: "Payrolls and wage growth printed {dir} of expectations." },
  { title: "{CCY} GDP release", detail: "Quarterly growth {dir} of consensus, revising the policy path." },
];

const SURPRISE = [
  { title: "Unscheduled {CCY} policy statement", detail: "An unscheduled statement from the central bank {tone}." },
  { title: "Sovereign rating action on {CCY} issuer", detail: "A ratings agency moved the sovereign outlook; positioning unwound fast." },
  { title: "Geopolitical headline hits {CCY}", detail: "A cross-border security headline reset risk premia on the currency." },
  { title: "{CCY} intervention speculation", detail: "Officials were reported to be checking rates with dealers." },
];

const CURRENCY_NAMES: Record<string, string> = {
  EUR: "Euro area", GBP: "UK", JPY: "Japan", CHF: "Swiss", AUD: "Australian",
  CAD: "Canadian", NZD: "New Zealand", SEK: "Swedish", NOK: "Norwegian",
  MXN: "Mexican", ZAR: "South African", PLN: "Polish", SGD: "Singapore", TRY: "Turkish",
};

export function generateEvents(opts: {
  dates: string[];
  market: MarketData;
  seed?: number;
  count?: number;
}): MarketEvent[] {
  const rng = mulberry32(hashSeed("events", opts.seed ?? 20260101));
  const currencies = opts.market.currencies;
  // Skip the first few sessions so every event has a full lookback window.
  const usable = opts.dates.slice(3, opts.dates.length - 1);
  const count = opts.count ?? 34;
  const out: MarketEvent[] = [];
  const used = new Set<string>();

  for (let i = 0; i < count; i++) {
    const currency = pick(rng, currencies);
    let date = pick(rng, usable);
    let guard = 0;
    while (used.has(`${currency}|${date}`) && guard++ < 20) date = pick(rng, usable);
    used.add(`${currency}|${date}`);

    const scheduled = rng() < 0.6;
    const template = scheduled ? pick(rng, SCHEDULED) : pick(rng, SURPRISE);
    // Surprises hit harder than scheduled releases.
    const magnitude = scheduled ? randRange(rng, 0.25, 1.1) : randRange(rng, 0.6, 2.4);
    const move = (rng() < 0.5 ? -1 : 1) * magnitude;
    // Scheduled releases land on the hour; surprises land anywhere in session.
    const minute = scheduled
      ? pick(rng, [8 * 60, 9 * 60, 12 * 60 + 30, 13 * 60 + 30, 14 * 60, 18 * 60])
      : randInt(rng, 7 * 60, 17 * 60);
    const publicMs = atMinute(date, minute, randInt(rng, 0, 59_000));
    const name = CURRENCY_NAMES[currency] ?? currency;
    const dir = move > 0
      ? pick(rng, ["ahead", "on the hawkish side"])
      : pick(rng, ["short", "on the dovish side"]);
    const tone = move > 0 ? "read hawkish" : "read dovish";

    out.push({
      event_id: `EV${String(i + 1).padStart(3, "0")}`,
      headline: template.title.replace("{CCY}", name),
      description: template.detail
        .replace("{CCY}", name)
        .replace("{dir}", dir)
        .replace("{tone}", tone),
      currency,
      kind: scheduled ? "scheduled" : "surprise",
      move_pct: Number(move.toFixed(3)),
      public_ms: publicMs,
      public_datetime: isoMs(publicMs),
      trade_date: date,
    });
  }
  out.sort((a, b) => a.public_ms - b.public_ms);
  return out;
}
