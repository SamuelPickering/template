import type { Trade, Trader } from "@/lib/types";
import type { MarketData } from "@/lib/models/market";
import { dateKey, isoMs } from "@/lib/time";

let counter = 0;
export function resetTradeIds() {
  counter = 0;
}
export function nextTradeId(): string {
  counter += 1;
  return `TR${String(counter).padStart(6, "0")}`;
}

export interface BuildTradeArgs {
  trader: Trader;
  base: string;
  quote: string;
  /** 'buy' means buying the base currency. */
  side: "buy" | "sell";
  notionalUsd: number;
  ms: number;
  market: MarketData;
  counterpartyId?: string | null;
  role?: Trade["trade_role"];
  /** Half-spread paid, as a fraction of the mid. Negative prints inside the mid. */
  spread?: number;
  /** Overrides the executed rate entirely (used by off-market scenarios). */
  rateOverride?: number;
  orderId?: string | null;
  scenarioTag?: string | null;
}

export function buildTrade(a: BuildTradeArgs): Trade {
  const { market, base, quote, ms } = a;
  const mid = market.midRate(base, quote, ms);
  const spread = a.spread ?? 0.00004;
  const signedSpread = a.side === "buy" ? spread : -spread;
  const rate = a.rateOverride ?? mid * (1 + signedSpread);
  const baseAmount = a.notionalUsd / market.usdRate(base, ms);
  const quoteAmount = baseAmount * rate;
  const buying = a.side === "buy";
  return {
    trade_id: nextTradeId(),
    trader_id: a.trader.trader_id,
    trader_name: a.trader.name,
    trade_role: a.role ?? a.trader.trade_role,
    counterparty_id: a.counterpartyId ?? null,
    currency_pair: `${base}/${quote}`,
    buy_currency: buying ? base : quote,
    sell_currency: buying ? quote : base,
    buy_amount: buying ? baseAmount : quoteAmount,
    sell_amount: buying ? quoteAmount : baseAmount,
    execution_rate: rate,
    notional_usd: a.notionalUsd,
    execution_ms: Math.round(ms),
    execution_datetime: isoMs(Math.round(ms)),
    trade_date: dateKey(ms),
    order_id: a.orderId ?? null,
    pnl: null,
    source: "synthetic",
    scenario_tag: a.scenarioTag ?? null,
  };
}
