import type { Counterparty, Currency, Trader } from "@/lib/types";
import { hashSeed, mulberry32, pick, type Rng } from "./rng";

/**
 * Currency universe. `base_rate` is USD per 1 unit of the currency, which is the
 * quoting convention used by every synthetic instrument (see GMM, §4.1).
 */
export const CURRENCIES: Currency[] = [
  { code: "EUR", name: "Euro", tier: "major", base_rate: 1.084, ann_vol: 0.072, adtv_usd: 1.6e12, pip: 0.0001 },
  { code: "GBP", name: "Pound Sterling", tier: "major", base_rate: 1.268, ann_vol: 0.082, adtv_usd: 9.7e11, pip: 0.0001 },
  { code: "JPY", name: "Japanese Yen", tier: "major", base_rate: 0.00662, ann_vol: 0.094, adtv_usd: 1.1e12, pip: 0.01 },
  { code: "CHF", name: "Swiss Franc", tier: "major", base_rate: 1.121, ann_vol: 0.076, adtv_usd: 3.9e11, pip: 0.0001 },
  { code: "AUD", name: "Australian Dollar", tier: "major", base_rate: 0.664, ann_vol: 0.098, adtv_usd: 4.8e11, pip: 0.0001 },
  { code: "CAD", name: "Canadian Dollar", tier: "major", base_rate: 0.733, ann_vol: 0.068, adtv_usd: 4.1e11, pip: 0.0001 },
  { code: "NZD", name: "New Zealand Dollar", tier: "major", base_rate: 0.611, ann_vol: 0.106, adtv_usd: 1.4e11, pip: 0.0001 },
  { code: "SEK", name: "Swedish Krona", tier: "major", base_rate: 0.0951, ann_vol: 0.104, adtv_usd: 9.0e10, pip: 0.0001 },
  { code: "NOK", name: "Norwegian Krone", tier: "major", base_rate: 0.0932, ann_vol: 0.112, adtv_usd: 7.5e10, pip: 0.0001 },
  { code: "MXN", name: "Mexican Peso", tier: "em", base_rate: 0.0542, ann_vol: 0.142, adtv_usd: 5.5e10, pip: 0.0001 },
  { code: "ZAR", name: "South African Rand", tier: "em", base_rate: 0.0538, ann_vol: 0.168, adtv_usd: 3.2e10, pip: 0.0001 },
  { code: "PLN", name: "Polish Zloty", tier: "em", base_rate: 0.2532, ann_vol: 0.121, adtv_usd: 2.6e10, pip: 0.0001 },
  { code: "SGD", name: "Singapore Dollar", tier: "em", base_rate: 0.7405, ann_vol: 0.054, adtv_usd: 1.3e11, pip: 0.0001 },
  { code: "TRY", name: "Turkish Lira", tier: "em", base_rate: 0.0296, ann_vol: 0.231, adtv_usd: 1.5e10, pip: 0.0001 },
];

export const CURRENCY_CODES = CURRENCIES.map((c) => c.code);

/**
 * Headline quoting convention: currencies listed here are quoted as USD/XXX,
 * everything else as XXX/USD. The GMM strips this back to synthetic XXX/USD
 * instruments regardless.
 */
const USD_BASE = new Set(["JPY", "CHF", "CAD", "SEK", "NOK", "MXN", "ZAR", "PLN", "SGD", "TRY"]);

export function conventionalPair(a: string, b: string): [string, string] {
  if (a === "USD") return USD_BASE.has(b) ? ["USD", b] : [b, "USD"];
  if (b === "USD") return USD_BASE.has(a) ? ["USD", a] : [a, "USD"];
  // Cross pairs: rank by the usual FX seniority order.
  const order = ["EUR", "GBP", "AUD", "NZD", "USD", "CAD", "CHF", "SEK", "NOK", "SGD", "PLN", "MXN", "ZAR", "TRY", "JPY"];
  const ia = order.indexOf(a);
  const ib = order.indexOf(b);
  return ia <= ib ? [a, b] : [b, a];
}

const FIRST = [
  "Alan", "Bridget", "Caleb", "Dana", "Elliot", "Frances", "Gordon", "Harriet", "Isaac", "Janet",
  "Keith", "Laurel", "Martin", "Nadine", "Owen", "Paula", "Quentin", "Renee", "Stanley", "Tessa",
  "Ulysses", "Vivian", "Walter", "Yvonne", "Zachary", "Marcus", "Deborah", "Curtis", "Sheila", "Roland",
  "Priya", "Devon", "Camille", "Reggie", "Noel", "Bianca", "Terrence", "Marisol", "Grant", "Adele",
];

const LAST = [
  "Whitfield", "Carrow", "Blanchard", "Ostrander", "Falkner", "Renshaw", "Mabry", "Kilgore", "Dunphy",
  "Vandermeer", "Prescott", "Alderman", "Cutler", "Hollins", "Stroud", "Beaumont", "Ridley", "Marlowe",
  "Halstead", "Wexford", "Crane", "Ferris", "Lockhart", "Sandoval", "Thorne", "Ellery", "Bramwell",
  "Nagata", "Okafor", "Reyes", "Castellano", "Draper", "Quilling", "Vance", "Ashworth", "Pettigrew",
];

export function generateTraders(seed = 20260101): Trader[] {
  const rng = mulberry32(hashSeed("traders", seed));
  const traders: Trader[] = [];
  const used = new Set<string>();
  for (let n = 1; n <= 72; n++) {
    let name = "";
    do {
      name = `${pick(rng, FIRST)} ${pick(rng, LAST)}`;
    } while (used.has(name));
    used.add(name);
    // Roughly two thirds of the population works client flow, the rest runs
    // proprietary risk — Front Running needs both populations to exist.
    traders.push({
      trader_id: `T${String(n).padStart(3, "0")}`,
      name,
      trade_role: rng() < 0.65 ? "client_facilitation" : "prop",
    });
  }
  return traders;
}

/**
 * Which corner of the market a trader tends to work in. Derived from the
 * trader id rather than stored, so it only shapes generated activity.
 */
export type TraderFocus = "g10" | "em" | "mixed";

export function focusOf(traderId: string): TraderFocus {
  const r = hashSeed("focus", traderId) % 100;
  if (r < 55) return "g10";
  if (r < 80) return "em";
  return "mixed";
}

const CLIENT_NAMES = [
  "Halcyon Asset Management", "Bridgeport Capital", "Sierra Vista Pension Fund", "Kesterly Global Macro",
  "Ardent Insurance Group", "Northgate Treasury Services", "Pemberton Industries", "Vireo Energy Corp",
  "Landmark Retirement Trust", "Ashgrove Partners", "Calderwood Holdings", "Tri-State Freight Systems",
  "Miller Brand Foods", "Oakline Semiconductor", "Granite Peak Advisors", "Corbin Family Office",
];

const STREET_NAMES = [
  "Meridian Bank", "Fifth Harbor Securities", "Ellisberg & Co.", "Wychwood Bank",
  "Continental Trust Bank", "Ravensworth Markets", "Petersen Global", "Ironside Brokerage",
];

export function generateCounterparties(): Counterparty[] {
  const out: Counterparty[] = [];
  CLIENT_NAMES.forEach((name, i) =>
    out.push({ counterparty_id: `C${String(i + 1).padStart(3, "0")}`, name, kind: "client" }),
  );
  STREET_NAMES.forEach((name, i) =>
    out.push({ counterparty_id: `S${String(i + 1).padStart(3, "0")}`, name, kind: "street" }),
  );
  // Internal books, used by cross trading and wash trading scenarios.
  ["Internal Book A", "Internal Book B", "Internal Nominee Account", "Affiliate: Kestrel Overseas Ltd"].forEach(
    (name, i) => out.push({ counterparty_id: `I${String(i + 1).padStart(3, "0")}`, name, kind: "internal" }),
  );
  return out;
}

/** Currencies a trader actually deals in. */
export function focusCurrencies(focus: TraderFocus): string[] {
  const g10 = ["EUR", "GBP", "JPY", "CHF", "AUD", "CAD", "NZD", "SEK", "NOK"];
  const em = ["MXN", "ZAR", "PLN", "SGD", "TRY"];
  switch (focus) {
    case "em":
      return [...em, "EUR", "USD"];
    case "mixed":
      return [...g10, "MXN", "ZAR"];
    default:
      return g10;
  }
}

export function randomPairFor(rng: Rng, focus: TraderFocus): [string, string] {
  const pool = focusCurrencies(focus);
  const a = pick(rng, pool);
  let b = "USD";
  // ~30% of activity is a genuine cross (non-USD vs non-USD).
  if (rng() < 0.3) {
    do {
      b = pick(rng, pool);
    } while (b === a || b === "USD");
  }
  return conventionalPair(a, b);
}
