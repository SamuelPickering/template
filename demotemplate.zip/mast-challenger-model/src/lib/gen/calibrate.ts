import type { MarketData } from "@/lib/models/market";
import { MIM_DEFAULTS } from "@/lib/models/mim";

/**
 * Scenario sizing helpers.
 *
 * Most metrics score as USD Value = EMI x PTC, and both terms scale with the
 * notional traded, so USD Value is roughly quadratic in size:
 *
 *   USD Value ~ decay x K x volatility x N^2 / ADTV
 *
 * Inverting that gives the notional an engineered scenario needs in order to
 * land at a chosen USD Value on a given instrument and day. This keeps the
 * severity tiers meaningful across instruments of very different liquidity
 * instead of hard-coding notionals that only work for one pair.
 */
export function notionalForTarget(
  market: MarketData,
  currency: string,
  date: string,
  targetUsd: number,
  decayFactor = 0.7,
): number {
  const vol = market.volatility(currency, date);
  const adtv = market.adtv(currency, date);
  const coef = decayFactor * MIM_DEFAULTS.k * vol;
  const n = Math.sqrt((targetUsd * adtv) / coef);
  return Math.round(n);
}

/** Notional needed for a linear-in-size score (deviation x notional). */
export function notionalForLinearTarget(
  targetUsd: number,
  deviationFraction: number,
): number {
  return Math.round(targetUsd / Math.max(1e-9, deviationFraction));
}
