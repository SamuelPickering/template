import type {
  Counterparty,
  MarketEvent,
  OrderRow,
  Trade,
  Trader,
} from "@/lib/types";
import type { MarketData } from "@/lib/models/market";
import { buildTrade } from "./trade";
import { conventionalPair } from "./universe";
import {
  hashSeed,
  mulberry32,
  pick,
  randInt,
  randRange,
  type Rng,
} from "./rng";
import { notionalForTarget } from "./calibrate";
import { FIX_MIN, MS_MIN, atMinute, dateKey } from "@/lib/time";

/**
 * Scenario-engineered trades (§5.4).
 *
 * Each in-scope metric gets a handful of deliberately-constructed instances;
 * Ramping and Wash Trading get three severity tiers so the admin threshold
 * slider visibly changes what is flagged. Every engineered trade carries a
 * `scenario_tag`, which exists purely so the QA script can check coverage —
 * the detection engines never read it.
 */
export interface ScenarioBundle {
  trades: Trade[];
  orders: OrderRow[];
}

interface Ctx {
  rng: Rng;
  dates: string[];
  traders: Trader[];
  counterparties: Counterparty[];
  market: MarketData;
  events: MarketEvent[];
  trades: Trade[];
  orders: OrderRow[];
}

/** Instruments liquid enough to be believable but small enough for realistic clip sizes. */
const SCENARIO_CCYS = ["NZD", "SEK", "NOK", "MXN", "ZAR", "PLN", "CAD", "AUD", "SGD"];
const CROSS_AGAINST = ["JPY", "EUR", "GBP", "CHF"];

let orderCounter = 0;
const nextOrderId = () => `OR${String(++orderCounter).padStart(6, "0")}`;

/** Direction: +1 means acquiring the currency, -1 means selling it. */
function legFor(currency: string, against: string, direction: 1 | -1) {
  const [base, quote] = conventionalPair(currency, against);
  const side: "buy" | "sell" =
    base === currency ? (direction > 0 ? "buy" : "sell") : direction > 0 ? "sell" : "buy";
  return { base, quote, side };
}

function pickTrader(ctx: Ctx, role: Trader["trade_role"], exceptId?: string): Trader {
  const pool = ctx.traders.filter(
    (t) => t.trade_role === role && (!exceptId || t.trader_id !== exceptId),
  );
  return pick(ctx.rng, pool.length ? pool : ctx.traders);
}

function cpOf(ctx: Ctx, kind: Counterparty["kind"]): string {
  const pool = ctx.counterparties.filter((c) => c.kind === kind);
  return pick(ctx.rng, pool).counterparty_id;
}

function midDate(ctx: Ctx): string {
  // Avoid the very first and last sessions so lookbacks and exits fit inside the window.
  const usable = ctx.dates.slice(5, ctx.dates.length - 2);
  return pick(ctx.rng, usable);
}

/* ------------------------------------------------------------------ */
/* Ramping                                                             */
/* ------------------------------------------------------------------ */

function ramping(ctx: Ctx, tier: "barely" | "significant" | "major", targetUsd: number) {
  const trader = pickTrader(ctx, "prop");
  const ccy = pick(ctx.rng, SCENARIO_CCYS);
  const date = midDate(ctx);
  const dir: 1 | -1 = ctx.rng() < 0.5 ? 1 : -1;
  const total = notionalForTarget(ctx.market, ccy, date, targetUsd, 0.72);
  const n = randInt(ctx.rng, 5, 8);
  const startMin = randRange(ctx.rng, 8 * 60, 13.5 * 60);
  const buildMinutes = randRange(ctx.rng, 22, 45);
  const tag = `ramping_${tier}`;
  const { base, quote, side } = legFor(ccy, "USD", dir);

  // Build phase: aggressive same-direction clips, all with street counterparties.
  for (let i = 0; i < n; i++) {
    const ms = atMinute(date, startMin + (buildMinutes * i) / n, randInt(ctx.rng, 0, 20_000));
    const size = (total / n) * randRange(ctx.rng, 0.82, 1.18);
    ctx.trades.push(
      buildTrade({
        trader,
        base,
        quote,
        side,
        notionalUsd: Math.round(size),
        ms,
        market: ctx.market,
        counterpartyId: cpOf(ctx, "street"),
        role: "prop",
        spread: 0.00012, // paying up: aggressive execution
        scenarioTag: tag,
      }),
    );
  }
  // Reversal: exit into the price the build just created.
  const revStart = startMin + buildMinutes + randRange(ctx.rng, 4, 18);
  const revLegs = randInt(ctx.rng, 2, 3);
  for (let i = 0; i < revLegs; i++) {
    const ms = atMinute(date, revStart + i * randRange(ctx.rng, 1, 4), randInt(ctx.rng, 0, 20_000));
    ctx.trades.push(
      buildTrade({
        trader,
        base,
        quote,
        side: side === "buy" ? "sell" : "buy",
        notionalUsd: Math.round((total / revLegs) * randRange(ctx.rng, 0.9, 1.1)),
        ms,
        market: ctx.market,
        counterpartyId: cpOf(ctx, "street"),
        role: "prop",
        spread: 0.00006,
        scenarioTag: tag,
      }),
    );
  }
}

/* ------------------------------------------------------------------ */
/* Wash trading                                                        */
/* ------------------------------------------------------------------ */

function washSingle(ctx: Ctx, tier: string, targetUsd: number) {
  const trader = pickTrader(ctx, "prop");
  const ccy = pick(ctx.rng, SCENARIO_CCYS);
  const date = midDate(ctx);
  const dir: 1 | -1 = ctx.rng() < 0.5 ? 1 : -1;
  const size = notionalForTarget(ctx.market, ccy, date, targetUsd, 0.95);
  const startMin = randRange(ctx.rng, 8 * 60, 15 * 60);
  const gapMin = randRange(ctx.rng, 1.5, 9);
  const internal = cpOf(ctx, "internal");
  const tag = `wash_${tier}`;
  const { base, quote, side } = legFor(ccy, "USD", dir);
  const legs: [number, "buy" | "sell"][] = [
    [startMin, side],
    [startMin + gapMin, side === "buy" ? "sell" : "buy"],
  ];
  legs.forEach(([min, s], i) => {
    ctx.trades.push(
      buildTrade({
        trader,
        base,
        quote,
        side: s,
        notionalUsd: Math.round(size * (i === 0 ? 1 : randRange(ctx.rng, 0.97, 1.03))),
        ms: atMinute(date, min, randInt(ctx.rng, 0, 30_000)),
        market: ctx.market,
        counterpartyId: internal,
        role: "prop",
        spread: 0.000005,
        scenarioTag: tag,
      }),
    );
  });
}

/** Cross-currency wash: the offsetting legs hide behind two different pairs. */
function washCrossCurrency(ctx: Ctx, targetUsd: number) {
  const trader = pickTrader(ctx, "prop");
  const ccy = pick(ctx.rng, SCENARIO_CCYS);
  const date = midDate(ctx);
  const dir: 1 | -1 = ctx.rng() < 0.5 ? 1 : -1;
  const size = notionalForTarget(ctx.market, ccy, date, targetUsd, 0.95);
  const startMin = randRange(ctx.rng, 8 * 60, 15 * 60);
  const gapMin = randRange(ctx.rng, 2, 12);
  const against1 = pick(ctx.rng, CROSS_AGAINST);
  let against2 = pick(ctx.rng, CROSS_AGAINST);
  if (against2 === against1) against2 = against1 === "JPY" ? "EUR" : "JPY";
  const internal = cpOf(ctx, "internal");

  const a = legFor(ccy, against1, dir);
  const b = legFor(ccy, against2, dir === 1 ? -1 : 1);
  [
    { leg: a, min: startMin },
    { leg: b, min: startMin + gapMin },
  ].forEach(({ leg, min }) => {
    ctx.trades.push(
      buildTrade({
        trader,
        base: leg.base,
        quote: leg.quote,
        side: leg.side,
        notionalUsd: Math.round(size * randRange(ctx.rng, 0.98, 1.02)),
        ms: atMinute(date, min, randInt(ctx.rng, 0, 30_000)),
        market: ctx.market,
        counterpartyId: internal,
        role: "prop",
        spread: 0.00001,
        scenarioTag: "wash_cross_currency",
      }),
    );
  });
}

/** Multi-counterparty wash: a round trip through related accounts that nets flat. */
function washMultiCounterparty(ctx: Ctx, targetUsd: number) {
  const trader = pickTrader(ctx, "prop");
  const ccy = pick(ctx.rng, SCENARIO_CCYS);
  const date = midDate(ctx);
  const dir: 1 | -1 = ctx.rng() < 0.5 ? 1 : -1;
  const size = notionalForTarget(ctx.market, ccy, date, targetUsd, 0.95);
  const startMin = randRange(ctx.rng, 8 * 60, 14.5 * 60);
  const internals = ctx.counterparties.filter((c) => c.kind === "internal");
  const { base, quote, side } = legFor(ccy, "USD", dir);
  const opposite = side === "buy" ? "sell" : "buy";
  const legs: { s: "buy" | "sell"; min: number; cp: string; frac: number }[] = [
    { s: side, min: startMin, cp: internals[0].counterparty_id, frac: 1 },
    { s: opposite, min: startMin + randRange(ctx.rng, 2, 6), cp: internals[1 % internals.length].counterparty_id, frac: 0.5 },
    { s: opposite, min: startMin + randRange(ctx.rng, 7, 14), cp: internals[2 % internals.length].counterparty_id, frac: 0.5 },
  ];
  for (const l of legs) {
    ctx.trades.push(
      buildTrade({
        trader,
        base,
        quote,
        side: l.s,
        notionalUsd: Math.round(size * l.frac * randRange(ctx.rng, 0.97, 1.03)),
        ms: atMinute(date, l.min, randInt(ctx.rng, 0, 30_000)),
        market: ctx.market,
        counterpartyId: l.cp,
        role: "prop",
        spread: 0.00001,
        scenarioTag: "wash_multi_counterparty",
      }),
    );
  }
}

/* ------------------------------------------------------------------ */
/* Front running / internal front running                              */
/* ------------------------------------------------------------------ */

function frontRunning(ctx: Ctx, targetUsd: number, internal: boolean) {
  const facilitator = pickTrader(ctx, "client_facilitation");
  const beneficiary = internal
    ? pickTrader(ctx, "prop", facilitator.trader_id)
    : facilitator;
  const ccy = pick(ctx.rng, SCENARIO_CCYS);
  const date = midDate(ctx);
  const dir: 1 | -1 = ctx.rng() < 0.5 ? 1 : -1;
  const size = notionalForTarget(ctx.market, ccy, date, targetUsd, 0.9);
  const startMin = randRange(ctx.rng, 8 * 60, 14 * 60);
  const tag = internal ? "internal_front_running" : "front_running";
  const { base, quote, side } = legFor(ccy, "USD", dir);
  const exit = side === "buy" ? "sell" : "buy";

  // 1. Prop position opened ahead of the client flow.
  ctx.trades.push(
    buildTrade({
      trader: beneficiary,
      base,
      quote,
      side,
      notionalUsd: Math.round(size * randRange(ctx.rng, 0.9, 1.05)),
      ms: atMinute(date, startMin, 0),
      market: ctx.market,
      counterpartyId: cpOf(ctx, "street"),
      role: "prop",
      spread: 0.00004,
      scenarioTag: tag,
    }),
  );
  // 2. The client order is filled in the market, moving the price.
  const legs = randInt(ctx.rng, 2, 4);
  const facMin = startMin + randRange(ctx.rng, 2, 6);
  for (let i = 0; i < legs; i++) {
    ctx.trades.push(
      buildTrade({
        trader: facilitator,
        base,
        quote,
        side,
        notionalUsd: Math.round((size / legs) * randRange(ctx.rng, 0.85, 1.15)),
        ms: atMinute(date, facMin + i * randRange(ctx.rng, 0.2, 0.8), randInt(ctx.rng, 0, 20_000)),
        market: ctx.market,
        counterpartyId: cpOf(ctx, "client"),
        role: "client_facilitation",
        spread: 0.00009,
        scenarioTag: tag,
      }),
    );
  }
  // 3. The prop position exits straight into that impact.
  ctx.trades.push(
    buildTrade({
      trader: beneficiary,
      base,
      quote,
      side: exit,
      notionalUsd: Math.round(size * randRange(ctx.rng, 0.9, 1.05)),
      ms: atMinute(date, facMin + randRange(ctx.rng, 1.5, 5), randInt(ctx.rng, 0, 20_000)),
      market: ctx.market,
      counterpartyId: cpOf(ctx, "street"),
      role: "prop",
      spread: 0.00004,
      scenarioTag: tag,
    }),
  );
}

/* ------------------------------------------------------------------ */
/* Insider trading                                                     */
/* ------------------------------------------------------------------ */

function insider(ctx: Ctx, event: MarketEvent, targetUsd: number) {
  const trader = pickTrader(ctx, "prop");
  const move = event.move_pct / 100;
  if (Math.abs(move) < 0.002) return;
  const position = Math.round(targetUsd / Math.abs(move));
  const dir: 1 | -1 = move > 0 ? 1 : -1;
  const { base, quote, side } = legFor(event.currency, "USD", dir);
  const legs = randInt(ctx.rng, 3, 5);

  // Build the position through the hours before the announcement.
  for (let i = 0; i < legs; i++) {
    const hoursBefore = randRange(ctx.rng, 1.5, 9) + (legs - i) * 0.7;
    const ms = event.public_ms - hoursBefore * 3_600_000;
    const date = dateKey(ms);
    const minute = new Date(ms).getUTCHours() * 60 + new Date(ms).getUTCMinutes();
    // Keep the trades inside a plausible session.
    const clamped = Math.max(7 * 60 + 5, Math.min(16 * 60 + 45, minute));
    ctx.trades.push(
      buildTrade({
        trader,
        base,
        quote,
        side,
        notionalUsd: Math.round((position / legs) * randRange(ctx.rng, 0.8, 1.2)),
        ms: atMinute(date, clamped, randInt(ctx.rng, 0, 50_000)),
        market: ctx.market,
        counterpartyId: cpOf(ctx, "street"),
        role: "prop",
        spread: 0.00004,
        scenarioTag: "insider_trading",
      }),
    );
  }
  // Take the profit shortly after the news is out.
  ctx.trades.push(
    buildTrade({
      trader,
      base,
      quote,
      side: side === "buy" ? "sell" : "buy",
      notionalUsd: position,
      ms: event.public_ms + randRange(ctx.rng, 8, 70) * MS_MIN,
      market: ctx.market,
      counterpartyId: cpOf(ctx, "street"),
      role: "prop",
      spread: 0.00005,
      scenarioTag: "insider_trading",
    }),
  );
}

/* ------------------------------------------------------------------ */
/* Banging the close                                                   */
/* ------------------------------------------------------------------ */

function bangingTheClose(ctx: Ctx, targetUsd: number) {
  const trader = pickTrader(ctx, "prop");
  const ccy = pick(ctx.rng, SCENARIO_CCYS);
  const date = midDate(ctx);
  const dir: 1 | -1 = ctx.rng() < 0.5 ? 1 : -1;
  const size = notionalForTarget(ctx.market, ccy, date, targetUsd, 0.55);
  const { base, quote, side } = legFor(ccy, "USD", dir);

  // Morning exposure that settles against the fix.
  ctx.trades.push(
    buildTrade({
      trader,
      base,
      quote,
      side,
      notionalUsd: Math.round(size * randRange(ctx.rng, 0.85, 1.1)),
      ms: atMinute(date, randRange(ctx.rng, 8 * 60, 11 * 60), 0),
      market: ctx.market,
      counterpartyId: cpOf(ctx, "client"),
      role: "client_facilitation",
      spread: 0.00005,
      scenarioTag: "banging_the_close",
    }),
  );
  // Concentrated push inside the fixing window.
  const legs = randInt(ctx.rng, 4, 7);
  for (let i = 0; i < legs; i++) {
    const minute = FIX_MIN - randRange(ctx.rng, 0.5, 11);
    ctx.trades.push(
      buildTrade({
        trader,
        base,
        quote,
        side,
        notionalUsd: Math.round((size / legs) * randRange(ctx.rng, 0.8, 1.2)),
        ms: atMinute(date, minute, randInt(ctx.rng, 0, 30_000)),
        market: ctx.market,
        counterpartyId: cpOf(ctx, "street"),
        role: "prop",
        spread: 0.00014,
        scenarioTag: "banging_the_close",
      }),
    );
  }
}

/* ------------------------------------------------------------------ */
/* Cross trading                                                       */
/* ------------------------------------------------------------------ */

function crossTrading(ctx: Ctx, targetUsd: number) {
  const a = pickTrader(ctx, "prop");
  const b = pickTrader(ctx, "client_facilitation", a.trader_id);
  const ccy = pick(ctx.rng, SCENARIO_CCYS);
  const date = midDate(ctx);
  const deviation = randRange(ctx.rng, 0.0008, 0.0035); // 8-35 bps off mid
  const size = Math.round(targetUsd / deviation);
  const ms = atMinute(date, randRange(ctx.rng, 8 * 60, 16 * 60), randInt(ctx.rng, 0, 59_000));
  const { base, quote, side } = legFor(ccy, "USD", 1);
  const mid = ctx.market.midRate(base, quote, ms);
  const rate = mid * (1 + deviation);

  ctx.trades.push(
    buildTrade({
      trader: a,
      base,
      quote,
      side,
      notionalUsd: size,
      ms,
      market: ctx.market,
      counterpartyId: cpOf(ctx, "internal"),
      role: "prop",
      rateOverride: rate,
      scenarioTag: "cross_trading",
    }),
  );
  ctx.trades.push(
    buildTrade({
      trader: b,
      base,
      quote,
      side: side === "buy" ? "sell" : "buy",
      notionalUsd: Math.round(size * randRange(ctx.rng, 0.99, 1.01)),
      ms: ms + randInt(ctx.rng, 100, 4_000),
      market: ctx.market,
      counterpartyId: cpOf(ctx, "internal"),
      role: "prop",
      rateOverride: rate,
      scenarioTag: "cross_trading",
    }),
  );
}

/* ------------------------------------------------------------------ */
/* Off-market trading                                                  */
/* ------------------------------------------------------------------ */

function offMarket(ctx: Ctx, targetUsd: number) {
  const trader = pick(ctx.rng, ctx.traders);
  const ccy = pick(ctx.rng, SCENARIO_CCYS);
  const date = midDate(ctx);
  const deviation = randRange(ctx.rng, 0.004, 0.014) * (ctx.rng() < 0.5 ? -1 : 1);
  const size = Math.round(targetUsd / Math.abs(deviation));
  const ms = atMinute(date, randRange(ctx.rng, 8 * 60, 16.5 * 60), randInt(ctx.rng, 0, 59_000));
  const { base, quote, side } = legFor(ccy, "USD", ctx.rng() < 0.5 ? 1 : -1);
  const mid = ctx.market.midRate(base, quote, ms);
  ctx.trades.push(
    buildTrade({
      trader,
      base,
      quote,
      side,
      notionalUsd: size,
      ms,
      market: ctx.market,
      counterpartyId: ctx.rng() < 0.5 ? cpOf(ctx, "internal") : cpOf(ctx, "client"),
      rateOverride: mid * (1 + deviation),
      scenarioTag: "off_market",
    }),
  );
}

/* ------------------------------------------------------------------ */
/* Layering / spoofing                                                 */
/* ------------------------------------------------------------------ */

function spoofing(ctx: Ctx, targetUsd: number, crossCurrency: boolean) {
  const trader = pickTrader(ctx, "prop");
  const ccy = pick(ctx.rng, SCENARIO_CCYS);
  const date = midDate(ctx);
  const dir: 1 | -1 = ctx.rng() < 0.5 ? 1 : -1; // direction the trader pushes the price
  const orderCcyAgainst = crossCurrency ? pick(ctx.rng, CROSS_AGAINST) : "USD";
  const orderLeg = legFor(ccy, orderCcyAgainst, dir);
  const execLeg = legFor(ccy, "USD", dir === 1 ? -1 : 1);
  const tag = crossCurrency ? "spoofing_cross_currency" : "spoofing";

  const orderTotal = notionalForTarget(ctx.market, ccy, date, targetUsd, 0.9) * 1.6;
  const startMin = randRange(ctx.rng, 8 * 60, 15.5 * 60);
  const startMs = atMinute(date, startMin, 0);
  const nOrders = randInt(ctx.rng, 4, 7);
  const mid = ctx.market.midRate(orderLeg.base, orderLeg.quote, startMs);

  for (let i = 0; i < nOrders; i++) {
    const placed = startMs + i * randInt(ctx.rng, 800, 4_000);
    // Sitting right at the touch: highly competitive, and never meant to fill.
    const edge = randRange(ctx.rng, -0.00002, 0.00004);
    const price = orderLeg.side === "buy" ? mid * (1 - edge) : mid * (1 + edge);
    const life = randInt(ctx.rng, 4_000, 55_000);
    ctx.orders.push({
      order_id: nextOrderId(),
      trader_id: trader.trader_id,
      trader_name: trader.name,
      currency_pair: `${orderLeg.base}/${orderLeg.quote}`,
      side: orderLeg.side,
      limit_price: price,
      size_usd: Math.round((orderTotal / nOrders) * randRange(ctx.rng, 0.85, 1.15)),
      placed_ms: placed,
      cancelled_ms: placed + life,
      filled_size_usd: ctx.rng() < 0.2 ? Math.round((orderTotal / nOrders) * 0.03) : 0,
      trade_date: date,
      source: "synthetic",
      scenario_tag: tag,
    });
  }
  // The genuine trade, executed on the other side while the decoys are resting.
  const execLegs = randInt(ctx.rng, 1, 3);
  const execTotal = orderTotal * randRange(ctx.rng, 0.35, 0.6);
  for (let i = 0; i < execLegs; i++) {
    ctx.trades.push(
      buildTrade({
        trader,
        base: execLeg.base,
        quote: execLeg.quote,
        side: execLeg.side,
        notionalUsd: Math.round(execTotal / execLegs),
        ms: startMs + randInt(ctx.rng, 5_000, 60_000),
        market: ctx.market,
        counterpartyId: cpOf(ctx, "street"),
        role: "prop",
        spread: 0.00003,
        scenarioTag: tag,
      }),
    );
  }
}

/** Ordinary resting orders, so the spoofing metric has a fair population too. */
function backgroundOrders(ctx: Ctx, count: number) {
  for (let i = 0; i < count; i++) {
    const trader = pick(ctx.rng, ctx.traders);
    const ccy = pick(ctx.rng, SCENARIO_CCYS);
    const date = pick(ctx.rng, ctx.dates);
    const dir: 1 | -1 = ctx.rng() < 0.5 ? 1 : -1;
    const leg = legFor(ccy, ctx.rng() < 0.25 ? pick(ctx.rng, CROSS_AGAINST) : "USD", dir);
    const placed = atMinute(date, randRange(ctx.rng, 7 * 60, 17 * 60), randInt(ctx.rng, 0, 59_000));
    const mid = ctx.market.midRate(leg.base, leg.quote, placed);
    // Genuine liquidity rests away from the touch and often gets filled.
    const edge = randRange(ctx.rng, 0.00005, 0.0009);
    const price = leg.side === "buy" ? mid * (1 - edge) : mid * (1 + edge);
    const size = Math.round(randRange(ctx.rng, 3e5, 1.2e7));
    const filled = ctx.rng() < 0.55 ? size : ctx.rng() < 0.5 ? Math.round(size * 0.4) : 0;
    const life = randInt(ctx.rng, 30_000, 40 * 60_000);
    ctx.orders.push({
      order_id: nextOrderId(),
      trader_id: trader.trader_id,
      trader_name: trader.name,
      currency_pair: `${leg.base}/${leg.quote}`,
      side: leg.side,
      limit_price: price,
      size_usd: size,
      placed_ms: placed,
      cancelled_ms: filled >= size ? null : placed + life,
      filled_size_usd: filled,
      trade_date: date,
      source: "synthetic",
      scenario_tag: null,
    });
  }
}

/* ------------------------------------------------------------------ */

export function generateScenarios(o: {
  dates: string[];
  traders: Trader[];
  counterparties: Counterparty[];
  market: MarketData;
  events: MarketEvent[];
  seed?: number;
  existing: Trade[];
}): ScenarioBundle {
  orderCounter = 0;
  const ctx: Ctx = {
    rng: mulberry32(hashSeed("scenarios", o.seed ?? 20260101)),
    dates: o.dates,
    traders: o.traders,
    counterparties: o.counterparties,
    market: o.market,
    events: o.events,
    trades: [],
    orders: [],
  };

  // Severity tiers — targets sit just above, well above and far above the
  // default thresholds for Ramping (15k) and Wash Trading (15k).
  for (let i = 0; i < 3; i++) ramping(ctx, "barely", 30_000);
  for (let i = 0; i < 3; i++) ramping(ctx, "significant", 150_000);
  for (let i = 0; i < 3; i++) ramping(ctx, "major", 800_000);

  for (let i = 0; i < 3; i++) washSingle(ctx, "barely", 24_000);
  for (let i = 0; i < 3; i++) washSingle(ctx, "significant", 110_000);
  for (let i = 0; i < 3; i++) washSingle(ctx, "major", 700_000);
  for (let i = 0; i < 3; i++) washCrossCurrency(ctx, 140_000);
  for (let i = 0; i < 3; i++) washMultiCounterparty(ctx, 160_000);

  for (let i = 0; i < 4; i++) frontRunning(ctx, 60_000 * (1 + i), false);
  for (let i = 0; i < 4; i++) frontRunning(ctx, 70_000 * (1 + i), true);

  const material = o.events
    .filter((e) => Math.abs(e.move_pct) > 0.5)
    .slice(0, 12);
  const chosen = material.filter((_, i) => i % 2 === 0).slice(0, 5);
  chosen.forEach((e, i) => insider(ctx, e, 90_000 * (1 + i * 0.6)));

  for (let i = 0; i < 4; i++) bangingTheClose(ctx, 45_000 * (1 + i * 0.8));
  for (let i = 0; i < 4; i++) crossTrading(ctx, 40_000 * (1 + i * 0.9));
  for (let i = 0; i < 5; i++) offMarket(ctx, 35_000 * (1 + i * 0.7));
  for (let i = 0; i < 4; i++) spoofing(ctx, 40_000 * (1 + i * 0.8), false);
  for (let i = 0; i < 2; i++) spoofing(ctx, 90_000 * (1 + i), true);

  backgroundOrders(ctx, 900);

  ctx.trades.sort((a, b) => a.execution_ms - b.execution_ms);
  ctx.orders.sort((a, b) => a.placed_ms - b.placed_ms);
  return { trades: ctx.trades, orders: ctx.orders };
}
