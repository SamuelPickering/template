import type { Counterparty, Trade, Trader } from "@/lib/types";
import type { MarketData } from "@/lib/models/market";
import { focusOf, randomPairFor } from "./universe";
import { buildTrade } from "./trade";
import { hashSeed, lognormal, mulberry32, pick, randInt } from "./rng";
import { SESSION_END_MIN, SESSION_START_MIN, atMinute } from "@/lib/time";

/**
 * The "fair" trade population: ordinary, non-abusive activity that makes up the
 * overwhelming majority of the dataset, so alerts stay a minority the way they
 * are in a real surveillance run.
 */
export function generateBackgroundTrades(opts: {
  dates: string[];
  traders: Trader[];
  counterparties: Counterparty[];
  market: MarketData;
  seed?: number;
  tradesPerTraderDay?: number;
}): Trade[] {
  const { dates, traders, counterparties, market } = opts;
  const seed = opts.seed ?? 20260101;
  const perDay = opts.tradesPerTraderDay ?? 1.8;
  const clients = counterparties.filter((c) => c.kind === "client");
  const street = counterparties.filter((c) => c.kind === "street");
  const trades: Trade[] = [];

  for (const date of dates) {
    for (const trader of traders) {
      const rng = mulberry32(hashSeed("bg", seed, trader.trader_id, date));
      // Activity varies day to day; some traders are quiet, some are busy.
      const activity = perDay * (0.4 + 1.6 * rng());
      let n = Math.floor(activity);
      if (rng() < activity - n) n += 1;
      const focus = focusOf(trader.trader_id);

      // Perfectly ordinary working of a large order: a burst of same-direction
      // clips, sometimes closed out later in the session. Structurally similar
      // to a ramp, which is exactly why a surveillance tool needs a USD Value
      // threshold rather than a pattern match.
      if (rng() < 0.16) {
        const [base, quote] = randomPairFor(rng, focus);
        const side = rng() < 0.5 ? "buy" : "sell";
        const clips = randInt(rng, 3, 6);
        const startMin = sessionMinute(rng);
        const spanMin = 8 + rng() * 40;
        const clipSize = lognormal(rng, 1.4e6, 0.6, 1e5, 2.5e7);
        const cp = pick(rng, trader.trade_role === "client_facilitation" ? clients : street);
        for (let c = 0; c < clips; c++) {
          trades.push(
            buildTrade({
              trader,
              base,
              quote,
              side,
              notionalUsd: Math.round(clipSize * (0.8 + rng() * 0.4)),
              ms: atMinute(date, startMin + (spanMin * c) / clips, randInt(rng, 0, 45_000)),
              market,
              counterpartyId: cp.counterparty_id,
              role: trader.trade_role,
              spread: 0.00003 + rng() * 0.00006,
            }),
          );
        }
        if (rng() < 0.6) {
          const exitLegs = randInt(rng, 1, 3);
          for (let c = 0; c < exitLegs; c++) {
            trades.push(
              buildTrade({
                trader,
                base,
                quote,
                side: side === "buy" ? "sell" : "buy",
                notionalUsd: Math.round((clipSize * clips) / exitLegs),
                ms: atMinute(
                  date,
                  Math.min(16.8 * 60, startMin + spanMin + 5 + rng() * 70 + c * 3),
                  randInt(rng, 0, 45_000),
                ),
                market,
                counterpartyId: cp.counterparty_id,
                role: trader.trade_role,
                spread: 0.00003 + rng() * 0.00006,
              }),
            );
          }
        }
      }

      for (let i = 0; i < n; i++) {
        const [base, quote] = randomPairFor(rng, focus);
        const minute = sessionMinute(rng);
        const ms = atMinute(date, minute, randInt(rng, 0, 59_999));
        const isClientFacing = trader.trade_role === "client_facilitation";
        const withClient = isClientFacing && rng() < 0.55;
        const cp = withClient ? pick(rng, clients) : pick(rng, street);
        const sizeMedian = focus === "em" ? 1.2e6 : focus === "mixed" ? 2.4e6 : 3.0e6;
        const notional = lognormal(rng, sizeMedian, 0.85, 1.0e5, 9.0e7);
        trades.push(
          buildTrade({
            trader,
            base,
            quote,
            side: rng() < 0.5 ? "buy" : "sell",
            notionalUsd: Math.round(notional),
            ms,
            market,
            counterpartyId: cp.counterparty_id,
            role: withClient ? "client_facilitation" : trader.trade_role,
            spread: 0.00002 + rng() * 0.00008,
          }),
        );
      }
    }
  }
  trades.sort((a, b) => a.execution_ms - b.execution_ms);
  return trades;
}

/**
 * Intraday activity profile: busier around the European open, the US open and
 * the 16:00 fix, quiet in between.
 */
function sessionMinute(rng: () => number): number {
  const peaks = [
    { center: 8 * 60, spread: 60, weight: 0.28 },
    { center: 13 * 60 + 30, spread: 75, weight: 0.34 },
    { center: 16 * 60, spread: 35, weight: 0.16 },
  ];
  const r = rng();
  let acc = 0;
  for (const p of peaks) {
    acc += p.weight;
    if (r < acc) {
      const m = p.center + p.spread * (rng() + rng() + rng() - 1.5) * 1.2;
      return clampSession(m);
    }
  }
  return clampSession(SESSION_START_MIN + rng() * (SESSION_END_MIN - SESSION_START_MIN));
}

function clampSession(m: number): number {
  return Math.max(SESSION_START_MIN, Math.min(SESSION_END_MIN - 1, m));
}
