import {
  loadEvents,
  loadMarketDaily,
  loadOrders,
  loadTrades,
  loadTraders,
} from "@/lib/db/repo";
import { MarketData } from "@/lib/models/market";
import { MarketImpactModel } from "@/lib/models/mim";
import { groupByInstrument, splitAll } from "@/lib/models/gmm";
import { METRICS, type FullConfig, type MetricId } from "@/lib/config/metrics";
import { configHash, getConfig, getDataset, type Dataset } from "@/lib/config/store";
import type { DetectionContext, Detector, Instance } from "./types";

import { detectRamping } from "./ramping";
import { detectWashTrading } from "./washTrading";
import { detectFrontRunning } from "./frontRunning";
import { detectInternalFrontRunning } from "./internalFrontRunning";
import { detectInsiderTrading } from "./insiderTrading";
import { detectBangingTheClose } from "./bangingTheClose";
import { detectCrossTrading } from "./crossTrading";
import { detectOffMarket } from "./offMarket";
import { detectLayeringSpoofing } from "./layeringSpoofing";

const DETECTORS: Record<MetricId, Detector> = {
  insider_trading: detectInsiderTrading,
  front_running: detectFrontRunning,
  internal_front_running: detectInternalFrontRunning,
  ramping: detectRamping,
  banging_the_close: detectBangingTheClose,
  wash_trading: detectWashTrading,
  cross_trading: detectCrossTrading,
  off_market_trading: detectOffMarket,
  layering_spoofing: detectLayeringSpoofing,
};

/** Instances retained per metric, highest USD Value first. */
const MAX_INSTANCES_PER_METRIC = 750;

export interface MetricStats {
  metric: MetricId;
  label: string;
  instances: number;
  alerts: number;
  threshold: number;
  usd_total: number;
  usd_over_threshold: number;
  top_usd: number;
}

export interface RunResult {
  dataset: Dataset;
  config_hash: string;
  computed_at: string;
  data_fingerprint: string;
  trades: number;
  instances: Instance[];
  alerts: Instance[];
  stats: MetricStats[];
}

/* ------------------------- context ------------------------- */

let ctxCache: { key: string; ctx: DetectionContext } | null = null;

function dataFingerprint(dataset: Dataset): string {
  const trades = loadTrades(dataset);
  let maxMs = 0;
  let notional = 0;
  for (const t of trades) {
    if (t.execution_ms > maxMs) maxMs = t.execution_ms;
    notional += t.notional_usd;
  }
  return `${dataset}:${trades.length}:${maxMs}:${Math.round(notional)}:${loadOrders().length}:${loadEvents().length}`;
}

export function buildContext(dataset: Dataset): DetectionContext {
  const key = dataFingerprint(dataset);
  if (ctxCache && ctxCache.key === key) return ctxCache.ctx;

  const market = new MarketData(loadMarketDaily());
  const events = loadEvents();
  market.setEvents(events);
  const trades = loadTrades(dataset);
  const eqs = splitAll(trades, market);
  const mim = new MarketImpactModel(market, eqs);
  const traders = new Map(loadTraders().map((t) => [t.trader_id, t]));
  const ctx: DetectionContext = {
    trades,
    eqs,
    byInstrument: groupByInstrument(eqs),
    orders: dataset === "synthetic" ? loadOrders() : [],
    events,
    market,
    mim,
    traders,
    tradeById: new Map(trades.map((t) => [t.trade_id, t])),
  };
  ctxCache = { key, ctx };
  return ctx;
}

/* ------------------------- run ------------------------- */

const memCache = new Map<string, RunResult>();

export function runAnalysis(opts?: { config?: FullConfig; dataset?: Dataset }): RunResult {
  const dataset = opts?.dataset ?? getDataset();
  const cfg = opts?.config ?? getConfig();
  const hash = configHash(cfg);
  const fingerprint = dataFingerprint(dataset);
  const runKey = `${fingerprint}|${hash}`;

  const hit = memCache.get(runKey);
  if (hit) return hit;


  const ctx = buildContext(dataset);
  const instances: Instance[] = [];
  const alerts: Instance[] = [];
  const stats: MetricStats[] = [];

  for (const def of METRICS) {
    const params = cfg[def.id];
    const threshold = params.threshold_usd_value ?? 0;
    let found: Instance[] = [];
    try {
      found = DETECTORS[def.id](ctx, params);
    } catch (err) {
      console.error(`[detect] ${def.id} failed`, err);
    }
    found.sort((a, b) => b.usd_value - a.usd_value);
    const kept = found.slice(0, MAX_INSTANCES_PER_METRIC);
    const metricAlerts = kept.filter((i) => i.usd_value > threshold);
    instances.push(...kept);
    alerts.push(...metricAlerts);
    stats.push({
      metric: def.id,
      label: def.label,
      instances: found.length,
      alerts: metricAlerts.length,
      threshold,
      usd_total: metricAlerts.reduce((s, i) => s + i.usd_value, 0),
      // Portfolio-style scoring: only the excess over the threshold counts.
      usd_over_threshold: metricAlerts.reduce(
        (s, i) => s + Math.max(0, i.usd_value - threshold),
        0,
      ),
      top_usd: kept.length ? kept[0].usd_value : 0,
    });
  }

  alerts.sort((a, b) => b.usd_value - a.usd_value);

  const result: RunResult = {
    dataset,
    config_hash: hash,
    computed_at: new Date().toISOString(),
    data_fingerprint: fingerprint,
    trades: ctx.trades.length,
    instances,
    alerts,
    stats,
  };

  memCache.set(runKey, result);
  if (memCache.size > 12) {
    const oldest = memCache.keys().next().value;
    if (oldest) memCache.delete(oldest);
  }
  return result;
}

export function invalidateAnalysis() {
  memCache.clear();
  ctxCache = null;
}
