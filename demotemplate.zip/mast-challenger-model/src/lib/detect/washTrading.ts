import type { EquivalentTrade } from "@/lib/types";
import { narrativeScore } from "@/lib/models/usdvalue";
import { MS_MIN } from "@/lib/time";
import type { Detector, Instance } from "./types";
import {
  bpsStr,
  groupBy,
  makeInstance,
  marker,
  minutesStr,
  notionalUsd,
  sumNotional,
  uniqueTradeIds,
  usd,
  usdCompact,
} from "./util";

/**
 * Wash Trading (§7), including the cross-currency and multi-counterparty
 * variants.
 *
 * Offsetting legs on the same synthetic instrument, close together in time and
 * near-identical in size, with no genuine market risk taken in between. The
 * score is a Narrative / Counter-Narrative contest:
 *
 *   Narrative         = the price impact the manufactured activity creates,
 *                       applied to the volume it manufactures, weighted by how
 *                       closely related the two sides are
 *   Counter-Narrative = the genuine market risk actually run between the legs,
 *                       plus any client-facilitation explanation
 *
 * Because the legs are matched on the synthetic instrument rather than the
 * headline pair, a wash split across EUR/NZD and GBP/NZD is caught the same way
 * as one done twice in NZD/USD — that is the cross-currency variant. Turning
 * "require instrument match" on restricts matching to identical headline pairs.
 */
export const detectWashTrading: Detector = (ctx, p) => {
  const maxGapMs = p.max_leg_gap_minutes * MS_MIN;
  const tol = p.size_match_tolerance_pct / 100;
  const requirePairMatch = p.require_instrument_match >= 0.5;
  const requirePriceMatch = p.require_price_match >= 0.5;
  const out: Instance[] = [];

  const books = groupBy(
    ctx.eqs,
    (e) => `${e.trade.trader_id}|${e.instrument}|${e.trade.trade_date}`,
  );

  for (const eqs of books.values()) {
    if (eqs.length < 2) continue;
    const used = new Set<string>();
    for (let i = 0; i < eqs.length; i++) {
      const anchor = eqs[i];
      if (used.has(anchor.eq_id)) continue;
      const anchorSize = notionalUsd(anchor);
      if (anchorSize <= 0) continue;

      // Greedily accumulate opposite-direction legs until they offset the
      // anchor within tolerance. One leg covers the classic wash; several
      // cover the multi-counterparty round trip.
      const legs: EquivalentTrade[] = [];
      let cum = 0;
      for (let j = i + 1; j < eqs.length; j++) {
        const cand = eqs[j];
        if (used.has(cand.eq_id)) continue;
        if (cand.trade.execution_ms - anchor.trade.execution_ms > maxGapMs) break;
        if (cand.direction === anchor.direction) continue;
        if (requirePairMatch && cand.trade.currency_pair !== anchor.trade.currency_pair) continue;
        if (requirePriceMatch && !priceMatches(anchor, cand)) continue;
        legs.push(cand);
        cum += notionalUsd(cand);
        if (cum >= anchorSize * (1 - tol)) break;
      }
      if (!legs.length) continue;
      if (Math.abs(cum - anchorSize) > anchorSize * tol) continue;

      const related = relatedness(anchor, legs);
      if (related < 0.4) continue;

      const matched = Math.min(anchorSize, cum);
      const lastLeg = legs[legs.length - 1];
      const startMs = anchor.trade.execution_ms;
      const endMs = lastLeg.trade.execution_ms;
      const emi = ctx.mim.magnitude(anchor.currency, startMs, matched);

      // Genuine market risk: how far the instrument actually moved while the
      // position was open, applied to the matched notional.
      const midStart = ctx.market.usdRate(anchor.currency, startMs);
      const midEnd = ctx.market.usdRate(anchor.currency, endMs);
      const realisedMove = Math.abs(midEnd / midStart - 1);
      const marketRiskUsd = 0.5 * realisedMove * matched;
      const clientLegs = [anchor, ...legs].filter(
        (e) => e.trade.trade_role === "client_facilitation",
      );
      const clientExplanationUsd = clientLegs.length ? matched * 0.0004 : 0;
      const counter = marketRiskUsd + clientExplanationUsd;
      const narrative = emi * matched * related;
      const score = narrativeScore(narrative, counter);
      if (score.usdValue < 1) continue;

      used.add(anchor.eq_id);
      legs.forEach((l) => used.add(l.eq_id));

      const all = [anchor, ...legs];
      const tradeIds = uniqueTradeIds(all);
      const variant = describeVariant(anchor, legs);

      out.push(
        makeInstance({
          ctx,
          metric: "wash_trading",
          instrument: anchor.instrument,
          traderId: anchor.trade.trader_id,
          traderName: anchor.trade.trader_name,
          counterpartyId: anchor.trade.counterparty_id,
          tradeDate: anchor.trade.trade_date,
          startMs,
          endMs,
          usdValue: score.usdValue,
          headline: `${usdCompact(matched)} ${variant.label} on ${anchor.instrument}, offset in ${minutesStr(
            endMs - startMs,
          )}`,
          explanation:
            `${anchor.trade.trader_name} ${anchor.direction > 0 ? "bought" : "sold"} ${usd(anchorSize)} of ` +
            `${anchor.instrument} sensitivity and reversed it with ${legs.length} offsetting ` +
            `leg${legs.length > 1 ? "s" : ""} totalling ${usd(cum)} ${minutesStr(endMs - startMs)} later. ` +
            `${variant.reason} The manufactured activity carries a modelled impact of ${bpsStr(emi)}, giving a ` +
            `Narrative of ${usd(narrative)}. Against that, the instrument moved only ` +
            `${(realisedMove * 10_000).toFixed(2)} bps while the position was open, so the genuine market risk ` +
            `run between the legs is worth ${usd(marketRiskUsd)}` +
            (clientExplanationUsd
              ? ` and there is a client facilitation explanation worth ${usd(clientExplanationUsd)}`
              : ``) +
            `. Narrative less Counter-Narrative = ${usd(score.usdValue)}.`,
          components: [
            {
              label: "Narrative",
              value: narrative,
              unit: "usd",
              help: "Modelled impact of the manufactured activity applied to the volume it manufactured, weighted by how related the two sides are.",
            },
            {
              label: "Counter-Narrative",
              value: counter,
              unit: "usd",
              help: "Legitimate explanations: genuine market risk run between the legs, plus any client facilitation.",
            },
            {
              label: "Matched notional",
              value: matched,
              unit: "usd",
              help: "Sensitivity that offsets between the legs.",
            },
            {
              label: "Modelled impact",
              value: emi * 10_000,
              unit: "bps",
              help: "Market Impact Model estimate for a clip of the matched size.",
            },
            {
              label: "Gap between legs",
              value: endMs - startMs,
              unit: "duration",
              help: "Time the position was actually exposed to the market.",
            },
            {
              label: "Price move over the gap",
              value: realisedMove * 10_000,
              unit: "bps",
              help: "How far the instrument moved while the position was open.",
            },
            {
              label: "Relatedness",
              value: related,
              unit: "ratio",
              help: "How closely the two sides are connected: internal accounts score highest, unrelated street counterparties lowest.",
            },
            {
              label: "Variant",
              value: variant.label,
              unit: "text",
              help: "Which wash trading pattern this instance matches.",
            },
          ],
          tradeIds,
          markers: [
            marker(anchor, "impacting", "Opening leg"),
            ...legs.map((l) => marker(l, "benefiting", "Offsetting leg")),
          ],
        }),
      );
    }
  }
  return out;
};

function priceMatches(a: EquivalentTrade, b: EquivalentTrade): boolean {
  if (a.trade.currency_pair !== b.trade.currency_pair) return false;
  const ra = a.trade.execution_rate;
  const rb = b.trade.execution_rate;
  return Math.abs(rb / ra - 1) <= 0.0005; // within 5 bps
}

/** How connected the two sides are — the core of "no genuine risk transfer". */
function relatedness(anchor: EquivalentTrade, legs: EquivalentTrade[]): number {
  const cps = [anchor, ...legs].map((e) => e.trade.counterparty_id);
  const kinds = cps.map((id) => (id ?? "").charAt(0));
  const allInternal = kinds.every((k) => k === "I");
  if (allInternal) return 1;
  const someInternal = kinds.some((k) => k === "I");
  const allSame = cps.every((id) => id === cps[0]);
  if (allSame) return 0.85;
  if (someInternal) return 0.7;
  return 0.45;
}

function describeVariant(anchor: EquivalentTrade, legs: EquivalentTrade[]) {
  const pairs = new Set([anchor, ...legs].map((e) => e.trade.currency_pair));
  const cps = new Set([anchor, ...legs].map((e) => e.trade.counterparty_id));
  if (pairs.size > 1) {
    return {
      label: "cross-currency wash",
      reason: `The legs were booked in different headline pairs (${[...pairs].join(
        " and ",
      )}), but the General Market Model maps both onto ${anchor.instrument}, where they cancel.`,
    };
  }
  if (legs.length > 1 || cps.size > 1) {
    return {
      label: "multi-counterparty wash",
      reason: `The offset was spread across ${cps.size} counterparties (${[...cps].join(
        ", ",
      )}), which disguises the round trip on any single account.`,
    };
  }
  return {
    label: "wash",
    reason: `Both legs were booked against ${anchor.trade.counterparty_id ?? "the same account"}, so no risk left the firm.`,
  };
}

export const _internal = { relatedness, sumNotional };
