import type { EquivalentTrade } from "@/lib/types";
import { usdValue } from "@/lib/models/usdvalue";
import { allocate } from "@/lib/models/allocation";
import { MS_MIN } from "@/lib/time";
import type { Detector, Instance } from "./types";
import {
  bpsStr,
  dir,
  groupBy,
  makeInstance,
  marker,
  minutesStr,
  notionalUsd,
  sumNotional,
  uniqueTradeIds,
  usd,
  usdCompact,
} from "./util";

/**
 * Ramping (§7).
 *
 * Looks for a run of same-direction trades on one synthetic instrument that
 * builds a position and moves the modelled price, followed by a reversal that
 * exits into the price the trader just created.
 *
 *   EMI = cumulative modelled impact of the build phase, measured at the
 *         moment the reversal starts (so a slow ramp that has already decayed
 *         scores less than a tight one)
 *   PTC = notional reversed out, capped at the build notional (exhaustion)
 */
export const detectRamping: Detector = (ctx, p) => {
  const minTrades = Math.max(2, Math.round(p.min_trade_count));
  const reversalWindowMs = p.max_reversal_window_minutes * MS_MIN;
  const buildWindowMs = p.max_build_minutes * MS_MIN;
  const minRatio = p.min_directional_ratio;
  const out: Instance[] = [];

  const books = groupBy(
    ctx.eqs,
    (e) => `${e.trade.trader_id}|${e.instrument}|${e.trade.trade_date}`,
  );

  for (const eqs of books.values()) {
    if (eqs.length < minTrades + 1) continue;
    let i = 0;
    while (i < eqs.length) {
      const seg = collectBuild(eqs, i, buildWindowMs, minRatio);
      if (!seg || seg.build.length < minTrades) {
        i = seg ? Math.max(i + 1, seg.nextIndex) : i + 1;
        continue;
      }
      const rev = collectReversal(eqs, seg.nextIndex, seg.direction, reversalWindowMs, seg.lastMs);
      if (!rev || rev.eqs.length === 0) {
        i = seg.nextIndex;
        continue;
      }

      const buildNotional = sumNotional(seg.build);
      const reversalNotional = sumNotional(rev.eqs);
      const emi = Math.abs(ctx.mim.impactFrom(seg.build, rev.startMs));
      // The Allocation Algorithm decides how much of the reversal genuinely
      // unwinds the build rather than opening fresh exposure (§4.3).
      const alloc = allocate([...seg.build, ...rev.eqs]);
      const allocated = rev.eqs.reduce(
        (s, e) => s + (alloc.matchedUsd.get(e.eq_id) ?? 0),
        0,
      );
      const ptcRequested = allocated > 0 ? Math.min(reversalNotional, allocated) : reversalNotional;
      const parts = usdValue(emi, ptcRequested, buildNotional);
      if (parts.usdValue >= 1) {
        out.push(build(ctx, seg, rev, parts, buildNotional, reversalNotional, emi, allocated));
      }
      i = rev.nextIndex;
    }
  }
  return out;
};

interface BuildSeg {
  build: EquivalentTrade[];
  direction: 1 | -1;
  startMs: number;
  lastMs: number;
  nextIndex: number;
  oppositeNotional: number;
}

/** Greedily extend a same-direction run, absorbing immaterial opposite clips. */
function collectBuild(
  eqs: EquivalentTrade[],
  start: number,
  buildWindowMs: number,
  minRatio: number,
): BuildSeg | null {
  const first = eqs[start];
  if (!first) return null;
  const direction = first.direction;
  const build: EquivalentTrade[] = [first];
  let sameNotional = notionalUsd(first);
  let oppositeNotional = 0;
  let j = start + 1;
  for (; j < eqs.length; j++) {
    const e = eqs[j];
    if (e.trade.execution_ms - first.trade.execution_ms > buildWindowMs) break;
    if (e.direction === direction) {
      build.push(e);
      sameNotional += notionalUsd(e);
      continue;
    }
    // An opposite clip small relative to the build so far is noise, not the exit.
    const size = notionalUsd(e);
    if (size <= (1 - minRatio) * sameNotional && oppositeNotional + size <= (1 - minRatio) * sameNotional) {
      oppositeNotional += size;
      build.push(e);
      continue;
    }
    break;
  }
  const ratio = sameNotional / (sameNotional + oppositeNotional);
  if (ratio < minRatio) return null;
  const dirTrades = build.filter((e) => e.direction === direction);
  return {
    build: dirTrades,
    direction,
    startMs: first.trade.execution_ms,
    lastMs: dirTrades[dirTrades.length - 1].trade.execution_ms,
    nextIndex: j,
    oppositeNotional,
  };
}

function collectReversal(
  eqs: EquivalentTrade[],
  from: number,
  direction: 1 | -1,
  reversalWindowMs: number,
  buildEndMs: number,
) {
  const picked: EquivalentTrade[] = [];
  let j = from;
  let startMs = 0;
  for (; j < eqs.length; j++) {
    const e = eqs[j];
    if (e.direction === direction) break;
    if (e.trade.execution_ms - buildEndMs > reversalWindowMs) break;
    if (picked.length === 0) startMs = e.trade.execution_ms;
    picked.push(e);
  }
  if (!picked.length) return null;
  return { eqs: picked, startMs, nextIndex: j };
}

function build(
  ctx: Parameters<Detector>[0],
  seg: BuildSeg,
  rev: { eqs: EquivalentTrade[]; startMs: number },
  parts: ReturnType<typeof usdValue>,
  buildNotional: number,
  reversalNotional: number,
  emi: number,
  allocatedUsd: number,
): Instance {
  const first = seg.build[0];
  const lastRev = rev.eqs[rev.eqs.length - 1];
  const tradeIds = uniqueTradeIds([...seg.build, ...rev.eqs]);
  const gapMs = rev.startMs - seg.lastMs;
  const startMs = seg.startMs;
  const endMs = lastRev.trade.execution_ms;

  return makeInstance({
    ctx,
    metric: "ramping",
    instrument: first.instrument,
    traderId: first.trade.trader_id,
    traderName: first.trade.trader_name,
    tradeDate: first.trade.trade_date,
    startMs,
    endMs,
    usdValue: parts.usdValue,
    headline: `${seg.build.length} ${dir(seg.direction)} clips totalling ${usdCompact(
      buildNotional,
    )} on ${first.instrument}, reversed after ${minutesStr(gapMs)}`,
    explanation:
      `${first.trade.trader_name} ${dir(seg.direction)} ${first.instrument} ${seg.build.length} times in ` +
      `${minutesStr(seg.lastMs - seg.startMs)}, a total of ${usd(buildNotional)} of sensitivity in one direction. ` +
      `The Market Impact Model puts the cumulative impact of that build at ${bpsStr(emi)} by the time the position ` +
      `started to reverse, ${minutesStr(gapMs)} after the last build clip. ` +
      `${usd(reversalNotional)} was then traded back the other way, of which ${usd(parts.ptcUsd)} is treated as the ` +
      `Profit-Taking Component` +
      (parts.ptcRequestedUsd > parts.ptcUsd
        ? ` (capped at the build notional under the exhaustion principle)`
        : ``) +
      `. USD Value = ${bpsStr(emi)} x ${usd(parts.ptcUsd)} = ${usd(parts.usdValue)}.`,
    components: [
      {
        label: "Expected Market Impact (EMI)",
        value: emi * 10_000,
        unit: "bps",
        help: "Cumulative modelled impact of the build-phase trades, measured when the reversal begins.",
      },
      {
        label: "Profit-Taking Component (PTC)",
        value: parts.ptcUsd,
        unit: "usd",
        help: "Notional reversed out into that impact, capped at the build notional.",
      },
      {
        label: "Build notional",
        value: buildNotional,
        unit: "usd",
        help: "Total sensitivity accumulated in the dominant direction.",
      },
      {
        label: "Reversal notional",
        value: reversalNotional,
        unit: "usd",
        help: "Total sensitivity traded back the other way.",
      },
      {
        label: "Allocated against the build",
        value: allocatedUsd,
        unit: "usd",
        help: "Portion of the reversal the Allocation Algorithm matches back to the build-phase trades, rather than treating as new exposure.",
      },
      {
        label: "Build clips",
        value: seg.build.length,
        unit: "count",
        help: "Number of same-direction trades in the build phase.",
      },
      {
        label: "Reversal delay",
        value: gapMs,
        unit: "duration",
        help: "Time between the last build clip and the start of the reversal.",
      },
      {
        label: "Directional purity",
        value: buildNotional / (buildNotional + seg.oppositeNotional),
        unit: "ratio",
        help: "Share of build-phase notional traded in the dominant direction.",
      },
    ],
    tradeIds,
    markers: [
      ...seg.build.map((e) => marker(e, "impacting", "Build")),
      ...rev.eqs.map((e) => marker(e, "benefiting", "Reversal")),
    ],
  });
}
