import type { Detector } from "./types";
import { frontRunningCore } from "./frontRunning";

/**
 * Internal Front Running (§7).
 *
 * Same mechanic as Front Running, except the impact comes from a different
 * portfolio inside the firm: one book positions itself just before another
 * book's flow moves the synthetic instrument, and exits into that impact.
 */
export const detectInternalFrontRunning: Detector = (ctx, p) =>
  frontRunningCore(ctx, {
    maxLeadMs: p.max_lead_seconds * 1000,
    minPropUsd: 250_000,
    sameTraderOnly: false,
    minImpact: p.min_impact_bps / 10_000,
    metric: "internal_front_running",
  });
