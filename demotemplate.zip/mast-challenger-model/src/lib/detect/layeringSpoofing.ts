import type { OrderRow } from "@/lib/types";
import { narrativeScore } from "@/lib/models/usdvalue";
import { instrumentFor } from "@/lib/models/gmm";
import { MS_MIN } from "@/lib/time";
import type { Detector, Instance } from "./types";
import { groupBy, impactChart, makeInstance, minutesStr, usd, usdCompact } from "./util";

/**
 * Layering / Spoofing (§7).
 *
 * The only metric driven by orders rather than executions, and — following the
 * source material — the only one that looks at the original currency pair
 * rather than the synthetic instrument, because orders cannot be split into USD
 * legs the way trades can. The impact those orders create is still measured on
 * the underlying currency, which is what makes the cross-currency variant
 * visible: decoy orders in one pair, the real execution in another.
 *
 *   Narrative         = impact the resting orders create, weighted by how
 *                       competitive they are, applied to the notional the
 *                       trader actually executed on the other side
 *   Counter-Narrative = theoretical cost of unwinding had the orders been
 *                       filled, scaled by how long they were exposed to that
 *                       risk
 */
const COMPETITIVE_SCALE = 0.0005; // 5 bps from the mid is "not competitive"
const CLUSTER_GAP_MS = 60_000;
const HALF_SPREAD = 0.00005;

export const detectLayeringSpoofing: Detector = (ctx, p) => {
  if (!ctx.orders.length) return [];
  const out: Instance[] = [];
  const maxLifeMs = p.max_order_life_seconds * 1000;

  const books = groupBy(
    ctx.orders,
    (o) => `${o.trader_id}|${o.currency_pair}|${o.trade_date}`,
  );

  for (const orders of books.values()) {
    for (const cluster of clusterOrders(orders)) {
      if (cluster.length < 2) continue;
      const first = cluster[0];
      const [base, quote] = first.currency_pair.split("/");

      const total = cluster.reduce((s, o) => s + o.size_usd, 0);
      if (total <= 0) continue;
      const cancelledUnfilled = cluster
        .filter((o) => o.cancelled_ms !== null && o.filled_size_usd < o.size_usd * 0.1)
        .reduce((s, o) => s + o.size_usd, 0);
      const cancelRatio = cancelledUnfilled / total;
      if (cancelRatio < p.cancel_ratio_threshold) continue;

      const lives = cluster.map((o) => (o.cancelled_ms ?? o.placed_ms) - o.placed_ms);
      const avgLife = lives.reduce((s, v) => s + v, 0) / lives.length;
      if (avgLife > maxLifeMs) continue;

      const comp = competitiveness(ctx, cluster);
      if (comp < p.min_competitiveness) continue;

      const startMs = first.placed_ms;
      const endMs = Math.max(...cluster.map((o) => o.cancelled_ms ?? o.placed_ms));

      // An order in BASE/QUOTE pushes on both currencies at once: buying the
      // pair bids the base and offers the quote. The currency actually being
      // exploited is whichever one the trader was executing against while the
      // orders rested — which is how the cross-currency variant surfaces, with
      // the decoy orders in one pair and the real trade in another.
      const candidates = [
        { currency: base, dir: first.side === "buy" ? 1 : -1 },
        { currency: quote, dir: first.side === "buy" ? -1 : 1 },
      ].filter((c) => c.currency !== "USD");

      let best: { currency: string; dir: number; eqs: typeof ctx.eqs; usd: number } | null = null;
      for (const c of candidates) {
        const eqs = (ctx.byInstrument.get(instrumentFor(c.currency)) ?? []).filter(
          (e) =>
            e.trade.trader_id === first.trader_id &&
            e.direction === (c.dir > 0 ? -1 : 1) &&
            e.trade.execution_ms >= startMs - MS_MIN &&
            e.trade.execution_ms <= endMs + 2 * MS_MIN,
        );
        const sum = eqs.reduce((s, e) => s + Math.abs(e.sensitivity_usd), 0);
        if (!best || sum > best.usd) best = { currency: c.currency, dir: c.dir, eqs, usd: sum };
      }
      if (!best || best.usd <= 0) continue;
      const currency = best.currency;
      const instrument = instrumentFor(currency);
      const exploited = best.eqs;
      const exploitedUsd = best.usd;

      const orderImpact = comp * ctx.mim.magnitude(currency, startMs, total);
      const narrative = orderImpact * Math.min(exploitedUsd, total);
      // If filled, the position would have to be unwound at a cost; exposure to
      // that risk scales with how long the orders actually rested.
      const exposure = Math.min(1, avgLife / (5 * MS_MIN));
      const unwindCost =
        total * exposure * (HALF_SPREAD + 0.5 * ctx.mim.magnitude(currency, startMs, total));
      const score = narrativeScore(narrative, unwindCost);
      if (score.usdValue < 1) continue;

      const crossPair = exploited.some((e) => e.trade.currency_pair !== first.currency_pair);
      const tradeIds = [...new Set(exploited.map((e) => e.trade_id))];

      out.push(
        makeInstance({
          ctx,
          metric: "layering_spoofing",
          instrument,
          traderId: first.trader_id,
          traderName: first.trader_name,
          tradeDate: first.trade_date,
          startMs,
          endMs,
          usdValue: score.usdValue,
          headline: `${cluster.length} ${first.side} orders worth ${usdCompact(total)} in ${first.currency_pair} pulled unfilled, with ${usdCompact(exploitedUsd)} executed the other way`,
          explanation:
            `${first.trader_name} placed ${cluster.length} ${first.side} orders in ${first.currency_pair} totalling ` +
            `${usd(total)}, sitting an average of ${(distanceBps(ctx, cluster)).toFixed(2)} bps from the mid — ` +
            `competitive enough to shift the visible balance of the book. ` +
            `${(cancelRatio * 100).toFixed(0)}% of that notional was cancelled without filling, after an average life ` +
            `of ${minutesStr(avgLife)}. While the orders rested, the trader executed ${usd(exploitedUsd)} in the ` +
            `opposite direction on ${instrument}` +
            (crossPair
              ? `, booked in a different pair — the orders and the execution only line up once the General Market ` +
                `Model maps them onto the same currency. `
              : `. `) +
            `The Narrative — order impact of ${(orderImpact * 10_000).toFixed(2)} bps applied to that execution — is ` +
            `worth ${usd(narrative)}. The Counter-Narrative, the cost of unwinding had the orders been filled, is ` +
            `${usd(unwindCost)} once scaled by how briefly they were exposed. Narrative less Counter-Narrative = ` +
            `${usd(score.usdValue)}.`,
          components: [
            {
              label: "Narrative",
              value: narrative,
              unit: "usd",
              help: "Competitiveness-weighted order impact applied to the notional executed on the other side.",
            },
            {
              label: "Counter-Narrative",
              value: unwindCost,
              unit: "usd",
              help: "Theoretical cost of unwinding the orders had they been filled, scaled by how long they rested.",
            },
            {
              label: "Order competitiveness",
              value: comp,
              unit: "ratio",
              help: "1 means the orders sat at or through the mid; 0 means far away from it.",
            },
            {
              label: "Cancel ratio",
              value: cancelRatio,
              unit: "ratio",
              help: "Share of the cluster's notional cancelled without filling.",
            },
            {
              label: "Order notional",
              value: total,
              unit: "usd",
              help: "Total size placed in the cluster.",
            },
            {
              label: "Executed the other way",
              value: exploitedUsd,
              unit: "usd",
              help: "Notional the trader executed in the opposite direction while the orders rested.",
            },
            {
              label: "Average order life",
              value: avgLife,
              unit: "duration",
              help: "How long the orders rested before being pulled.",
            },
            {
              label: "Variant",
              value: crossPair ? "Cross-currency layering" : "Single-pair layering",
              unit: "text",
              help: "Whether the decoy orders and the execution sat in different headline pairs.",
            },
          ],
          tradeIds,
          orderIds: cluster.map((o) => o.order_id),
          markers: exploited.map((e) => ({
            trade_id: e.trade_id,
            ms: e.trade.execution_ms,
            role: "benefiting" as const,
            label: "Executed while orders rested",
            notional_usd: Math.abs(e.sensitivity_usd),
          })),
        }),
      );
    }
  }
  return out;
};

/** Split a trader's orders in one pair into bursts placed close together. */
function clusterOrders(orders: OrderRow[]): OrderRow[][] {
  const sorted = orders.slice().sort((a, b) => a.placed_ms - b.placed_ms);
  const out: OrderRow[][] = [];
  let cur: OrderRow[] = [];
  for (const o of sorted) {
    if (!cur.length || o.placed_ms - cur[cur.length - 1].placed_ms <= CLUSTER_GAP_MS) {
      if (cur.length && cur[0].side !== o.side) {
        out.push(cur);
        cur = [o];
        continue;
      }
      cur.push(o);
    } else {
      out.push(cur);
      cur = [o];
    }
  }
  if (cur.length) out.push(cur);
  return out;
}

function distanceBps(ctx: Parameters<Detector>[0], cluster: OrderRow[]): number {
  let weighted = 0;
  let total = 0;
  for (const o of cluster) {
    const [base, quote] = o.currency_pair.split("/");
    const mid = ctx.market.midRate(base, quote, o.placed_ms);
    const dist = o.side === "buy" ? (mid - o.limit_price) / mid : (o.limit_price - mid) / mid;
    weighted += Math.max(0, dist) * o.size_usd;
    total += o.size_usd;
  }
  return total ? (weighted / total) * 10_000 : 0;
}

/** Size-weighted competitiveness: how close to the touch the orders sit. */
function competitiveness(ctx: Parameters<Detector>[0], cluster: OrderRow[]): number {
  let weighted = 0;
  let total = 0;
  for (const o of cluster) {
    const [base, quote] = o.currency_pair.split("/");
    const mid = ctx.market.midRate(base, quote, o.placed_ms);
    if (!mid || !Number.isFinite(mid)) continue;
    const dist = o.side === "buy" ? (mid - o.limit_price) / mid : (o.limit_price - mid) / mid;
    const c = Math.max(0, Math.min(1, 1 - dist / COMPETITIVE_SCALE));
    weighted += c * o.size_usd;
    total += o.size_usd;
  }
  return total ? weighted / total : 0;
}
