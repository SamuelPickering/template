import type { EquivalentTrade } from "@/lib/types";
import { MS_HOUR } from "@/lib/time";
import { instrumentFor } from "@/lib/models/gmm";
import type { Detector, Instance } from "./types";
import {
  groupBy,
  makeInstance,
  marker,
  minutesStr,
  uniqueTradeIds,
  usd,
  usdCompact,
} from "./util";

/**
 * Insider Trading (§4.4, §7).
 *
 * The only metric that is about exploiting a price move rather than causing
 * one, so the Market Impact Model plays no part. For each event we look at the
 * lookback window before it became public and compare the position the trader
 * actually held against the position a fair trader could have been expected to
 * hold.
 *
 * The expectation is time-weighted: a position established well before the
 * event is ordinary business and counts as expected, while one established in
 * the final hours before the announcement counts barely at all. What is left
 * over is the excess position, and its value at the realised price move is the
 * USD Value.
 *
 *   USD Value = excess position (USD) x realised price move
 */
export const detectInsiderTrading: Detector = (ctx, p) => {
  const lookbackMs = p.lookback_hours * MS_HOUR;
  const minMove = p.min_event_move_pct / 100;
  const halfLifeMs = p.expectation_half_life_hours * MS_HOUR;
  const out: Instance[] = [];

  for (const event of ctx.events) {
    const move = event.move_pct / 100;
    if (Math.abs(move) < minMove) continue;
    const instrument = instrumentFor(event.currency);
    const all = ctx.byInstrument.get(instrument);
    if (!all) continue;

    const from = event.public_ms - lookbackMs;
    const window = all.filter(
      (e) => e.trade.execution_ms >= from && e.trade.execution_ms <= event.public_ms,
    );
    if (!window.length) continue;

    for (const [traderId, eqs] of groupBy(window, (e) => e.trade.trader_id)) {
      if (eqs.length < 2) continue;
      let actual = 0;
      let timeWeighted = 0;
      for (const e of eqs) {
        const dt = event.public_ms - e.trade.execution_ms;
        // Weight of "suspicious recency": 1 right at the announcement, decaying
        // to 0 for trades placed long before it.
        const recency = Math.pow(0.5, dt / halfLifeMs);
        actual += e.sensitivity_usd;
        timeWeighted += e.sensitivity_usd * (1 - recency);
      }
      // A fair trader is also expected to run their usual book on the
      // instrument, so their normal position size counts as expected too.
      const normal = baseline(ctx, instrument, traderId) * Math.sign(actual || 1);
      const expected = timeWeighted + normal;
      const excess = Math.abs(actual) > Math.abs(expected) ? actual - expected : 0;
      // Require the unexplained part to be a real share of the position, not a
      // rounding error on an ordinary book.
      if (!excess || Math.abs(excess) < 0.4 * Math.abs(actual)) continue;
      const usdVal = excess * move;
      if (usdVal < 1) continue;

      const first = eqs[0];
      const closes = closingTrades(ctx, instrument, traderId, event.public_ms, excess);
      const tradeIds = uniqueTradeIds([...eqs, ...closes]);
      const realisedPnl = closes.length ? estimatePnl(ctx, eqs, closes) : null;

      out.push(
        makeInstance({
          ctx,
          metric: "insider_trading",
          instrument,
          traderId,
          traderName: first.trade.trader_name,
          tradeDate: event.trade_date,
          startMs: first.trade.execution_ms,
          endMs: closes.length ? closes[closes.length - 1].trade.execution_ms : event.public_ms,
          usdValue: usdVal,
          headline: `${usdCompact(excess)} ${excess > 0 ? "long" : "short"} into "${event.headline}" (${event.move_pct > 0 ? "+" : ""}${event.move_pct}%)`,
          explanation:
            `${first.trade.trader_name} traded ${instrument} ${eqs.length} times in the ${p.lookback_hours}-hour window ` +
            `before "${event.headline}" became public, ending ${usd(Math.abs(actual))} ` +
            `${actual > 0 ? "long" : "short"}. Weighting each trade by how long before the announcement it was placed, ` +
            `a fair trader would have been expected to hold ${usd(Math.abs(expected))}, leaving an excess of ` +
            `${usd(Math.abs(excess))} concentrated in the hours immediately before the news. ` +
            `The event moved ${instrument} by ${event.move_pct}%, so that excess position was worth ` +
            `${usd(usdVal)} the moment the announcement landed.` +
            (closes.length
              ? ` The position was closed ${minutesStr(closes[0].trade.execution_ms - event.public_ms)} after the news broke.`
              : ` No closing trade was found in the same session.`),
          components: [
            {
              label: "Observed position",
              value: actual,
              unit: "usd",
              help: "Net sensitivity the trader held on the instrument when the event became public.",
            },
            {
              label: "Expected position",
              value: expected,
              unit: "usd",
              help: "Time-weighted position a fair trader could have been expected to hold, given when each trade was placed.",
            },
            {
              label: "Excess position",
              value: excess,
              unit: "usd",
              help: "Observed less expected — the part of the position that only makes sense with foreknowledge.",
            },
            {
              label: "Event move",
              value: event.move_pct,
              unit: "percent",
              help: "Realised price move on the synthetic instrument when the event became public.",
            },
            {
              label: "Event",
              value: `${event.headline} (${event.kind})`,
              unit: "text",
              help: "The event this instance is measured against.",
            },
            {
              label: "Time to announcement",
              value: event.public_ms - eqs[eqs.length - 1].trade.execution_ms,
              unit: "duration",
              help: "Gap between the last position-building trade and the announcement.",
            },
            ...(realisedPnl !== null
              ? [
                  {
                    label: "Realised gain on exit",
                    value: realisedPnl,
                    unit: "usd" as const,
                    help: "Mark-to-market gain between the average entry rate and the exit rate after the news.",
                  },
                ]
              : []),
          ],
          tradeIds,
          markers: [
            ...eqs.map((e) => marker(e, "impacting", "Position built")),
            ...closes.map((e) => marker(e, "benefiting", "Closed after news")),
          ],
        }),
      );
    }
  }
  return out;
};

/**
 * The trader's typical end-of-day net position on the instrument — the size of
 * book they run anyway. Median across sessions, so one large day does not set
 * the baseline.
 */
const baselineCache = new WeakMap<object, Map<string, number>>();

function baseline(
  ctx: Parameters<Detector>[0],
  instrument: string,
  traderId: string,
): number {
  let cache = baselineCache.get(ctx);
  if (!cache) {
    cache = new Map<string, number>();
    const daily = new Map<string, number>();
    for (const e of ctx.eqs) {
      const k = `${e.instrument}|${e.trade.trader_id}|${e.trade.trade_date}`;
      daily.set(k, (daily.get(k) ?? 0) + e.sensitivity_usd);
    }
    const byBook = new Map<string, number[]>();
    for (const [k, v] of daily) {
      const [inst, trader] = k.split("|");
      const key = `${inst}|${trader}`;
      const arr = byBook.get(key);
      if (arr) arr.push(Math.abs(v));
      else byBook.set(key, [Math.abs(v)]);
    }
    for (const [k, arr] of byBook) {
      arr.sort((a, b) => a - b);
      cache.set(k, arr[Math.floor(arr.length / 2)]);
    }
    baselineCache.set(ctx, cache);
  }
  return cache.get(`${instrument}|${traderId}`) ?? 0;
}

/** Trades that unwind the position within a day of the announcement. */
function closingTrades(
  ctx: Parameters<Detector>[0],
  instrument: string,
  traderId: string,
  publicMs: number,
  excess: number,
): EquivalentTrade[] {
  const all = ctx.byInstrument.get(instrument) ?? [];
  const wantDir = excess > 0 ? -1 : 1;
  return all.filter(
    (e) =>
      e.trade.trader_id === traderId &&
      e.direction === wantDir &&
      e.trade.execution_ms > publicMs &&
      e.trade.execution_ms - publicMs <= 8 * MS_HOUR,
  );
}

function estimatePnl(
  ctx: Parameters<Detector>[0],
  opens: EquivalentTrade[],
  closes: EquivalentTrade[],
): number {
  const currency = opens[0].currency;
  const openUsd = opens.reduce((s, e) => s + e.sensitivity_usd, 0);
  if (!openUsd) return 0;
  const wAvgEntry =
    opens.reduce(
      (s, e) => s + ctx.market.usdRate(currency, e.trade.execution_ms) * e.sensitivity_usd,
      0,
    ) / openUsd;
  const closeUsd = closes.reduce((s, e) => s + Math.abs(e.sensitivity_usd), 0);
  const wAvgExit =
    closes.reduce(
      (s, e) => s + ctx.market.usdRate(currency, e.trade.execution_ms) * Math.abs(e.sensitivity_usd),
      0,
    ) / (closeUsd || 1);
  const size = Math.min(Math.abs(openUsd), closeUsd);
  return (size * (wAvgExit - wAvgEntry) * Math.sign(openUsd)) / wAvgEntry;
}

