import type { EquivalentTrade } from "@/lib/types";
import { usdValue } from "@/lib/models/usdvalue";
import { allocate, type AllocationResult } from "@/lib/models/allocation";
import { MS_HOUR } from "@/lib/time";
import type { Component, Detector, Instance } from "./types";
import {
  bpsStr,
  groupBy,
  makeInstance,
  marker,
  minutesStr,
  notionalUsd,
  sumNotional,
  uniqueTradeIds,
  usd,
  usdCompact,
} from "./util";

/**
 * Front Running (§7).
 *
 * A trader who knows a client order is coming opens a proprietary position
 * first, lets the market impact of filling the client order move the price,
 * then exits into it. The signature is a prop exit that lands shortly after
 * client facilitation flow in the same instrument, with a matching prop
 * position opened before that flow began.
 *
 *   EMI = residual modelled impact of the facilitation trades at the moment of
 *         the prop exit (so materiality rises as the gap shrinks)
 *   PTC = size of the prop position exiting into that impact, capped at the
 *         facilitation notional (exhaustion principle)
 */
export const detectFrontRunning: Detector = (ctx, p) =>
  frontRunningCore(ctx, {
    maxLeadMs: p.max_lead_seconds * 1000,
    minPropUsd: p.min_prop_notional_usd,
    sameTraderOnly: p.require_same_trader >= 0.5,
    metric: "front_running",
    minImpact: 0,
  });

export interface CoreOpts {
  maxLeadMs: number;
  minPropUsd: number;
  sameTraderOnly: boolean;
  minImpact: number;
  metric: "front_running" | "internal_front_running";
}

export function frontRunningCore(
  ctx: Parameters<Detector>[0],
  o: CoreOpts,
): Instance[] {
  const out: Instance[] = [];
  const byInstrumentDay = groupBy(ctx.eqs, (e) => `${e.instrument}|${e.trade.trade_date}`);
  // The Allocation Algorithm tells us how much of a trade actually closed an
  // existing position rather than opening a new one — see §4.3.
  const allocations = new Map<string, AllocationResult>();
  const bookAllocation = (eq: EquivalentTrade, eqs: EquivalentTrade[]): AllocationResult => {
    const key = `${eq.trade.trader_id}|${eq.instrument}|${eq.trade.trade_date}`;
    let res = allocations.get(key);
    if (!res) {
      res = allocate(eqs.filter((e) => e.trade.trader_id === eq.trade.trader_id));
      allocations.set(key, res);
    }
    return res;
  };

  for (const eqs of byInstrumentDay.values()) {
    const props = eqs.filter((e) => e.trade.trade_role === "prop");
    if (!props.length) continue;

    for (const exit of props) {
      const exitUsd = notionalUsd(exit);
      if (exitUsd < o.minPropUsd) continue;
      const t = exit.trade.execution_ms;

      // Flow that moved the price in the window before this exit, in the
      // opposite direction to the exit (i.e. the exit sells into buying).
      const impacting = eqs.filter((e) => {
        if (e.direction === exit.direction) return false;
        const dt = t - e.trade.execution_ms;
        if (dt < 0 || dt > o.maxLeadMs) return false;
        if (o.metric === "front_running") {
          if (e.trade.trade_role !== "client_facilitation") return false;
          if (o.sameTraderOnly && e.trade.trader_id !== exit.trade.trader_id) return false;
        } else if (e.trade.trader_id === exit.trade.trader_id) {
          // Internal front running is about flow from someone else's book.
          return false;
        }
        return true;
      });
      if (!impacting.length) continue;

      const emi = Math.abs(ctx.mim.impactFrom(impacting, t));
      if (emi < o.minImpact) continue;

      // The position being exited must have been opened before that flow began.
      const flowStart = impacting[0].trade.execution_ms;
      const opens = eqs.filter(
        (e) =>
          e.trade.trade_role === "prop" &&
          e.trade.trader_id === exit.trade.trader_id &&
          e.direction !== exit.direction &&
          e.trade.execution_ms < flowStart &&
          flowStart - e.trade.execution_ms <= 4 * MS_HOUR,
      );
      const openUsd = sumNotional(opens);
      if (openUsd < 0.25 * exitUsd) continue;

      const impactingUsd = sumNotional(impacting);
      // How much of the exit the Allocation Algorithm ties back to earlier
      // flow in the book, i.e. position closed rather than position opened.
      const alloc = bookAllocation(exit, eqs);
      const allocated = alloc.matchedUsd.get(exit.eq_id) ?? 0;
      const closingUsd = Math.min(exitUsd, Math.max(allocated, 0) || exitUsd, openUsd);
      const parts = usdValue(emi, closingUsd, impactingUsd);
      if (parts.usdValue < 1) continue;

      const gapMs = t - impacting[impacting.length - 1].trade.execution_ms;
      const all = [...opens, ...impacting, exit];
      const tradeIds = uniqueTradeIds(all);
      const startMs = opens[0].trade.execution_ms;
      const internal = o.metric === "internal_front_running";
      const otherTraders = [...new Set(impacting.map((e) => e.trade.trader_name))];

      const components: Component[] = [
        {
          label: "Expected Market Impact (EMI)",
          value: emi * 10_000,
          unit: "bps",
          help: internal
            ? "Residual modelled impact of the other portfolio's flow at the moment of this trade."
            : "Residual modelled impact of the client facilitation trades at the moment of the prop exit.",
        },
        {
          label: "Profit-Taking Component (PTC)",
          value: parts.ptcUsd,
          unit: "usd",
          help: "Prop position exiting into that impact, capped at the impacting notional.",
        },
        {
          label: "Impacting notional",
          value: impactingUsd,
          unit: "usd",
          help: internal
            ? "Notional traded by the other portfolio in the window."
            : "Client facilitation notional executed in the window.",
        },
        {
          label: "Prop position opened",
          value: openUsd,
          unit: "usd",
          help: "Proprietary position established before the impacting flow began.",
        },
        {
          label: "Prop exit notional",
          value: exitUsd,
          unit: "usd",
          help: "Size of the trade that exited the position.",
        },
        {
          label: "Allocated as position closing",
          value: allocated,
          unit: "usd",
          help: "Portion of the exit the Allocation Algorithm matches back to earlier flow in the book, rather than treating as a new position.",
        },
        {
          label: "Lead time",
          value: gapMs,
          unit: "duration",
          help: "Gap between the last impacting trade and the prop exit. Shorter gaps leave more impact intact.",
        },
      ];
      if (internal) {
        components.push({
          label: "Impacting traders",
          value: otherTraders.join(", "),
          unit: "text",
          help: "The other books inside the firm whose flow created the impact.",
        });
      }

      out.push(
        makeInstance({
          ctx,
          metric: o.metric,
          instrument: exit.instrument,
          traderId: exit.trade.trader_id,
          traderName: exit.trade.trader_name,
          counterpartyId: exit.trade.counterparty_id,
          tradeDate: exit.trade.trade_date,
          startMs,
          endMs: t,
          usdValue: parts.usdValue,
          headline: internal
            ? `${usdCompact(parts.ptcUsd)} exited ${minutesStr(gapMs)} after ${usdCompact(
                impactingUsd,
              )} of flow from ${otherTraders.join(", ")}`
            : `${usdCompact(parts.ptcUsd)} prop position exited ${minutesStr(
                gapMs,
              )} after ${usdCompact(impactingUsd)} of client facilitation`,
          explanation:
            `${exit.trade.trader_name} opened ${usd(openUsd)} of ${exit.instrument} sensitivity, ` +
            (internal
              ? `then ${otherTraders.join(" and ")} pushed ${usd(impactingUsd)} through the same instrument in the ` +
                `same direction. `
              : `then filled ${usd(impactingUsd)} of client business in the same instrument and direction. `) +
            `The Market Impact Model puts the residual impact of that flow at ${bpsStr(emi)} when the position was ` +
            `closed ${minutesStr(gapMs)} later. Applying it to the ${usd(parts.ptcUsd)} of position that exited into ` +
            `it gives a USD Value of ${usd(parts.usdValue)}` +
            (parts.ptcRequestedUsd > parts.ptcUsd
              ? `, with the PTC capped at the impacting notional under the exhaustion principle`
              : ``) +
            `.`,
          components,
          tradeIds,
          markers: [
            ...opens.map((e) => marker(e, "context", "Prop position opened")),
            ...impacting.map((e) => marker(e, "impacting", internal ? "Other portfolio" : "Client facilitation")),
            marker(exit, "benefiting", "Prop exit"),
          ],
        }),
      );
    }
  }
  return dedupe(out);
}

/** One instance per prop exit; keep the highest-scoring version of each. */
function dedupe(list: Instance[]): Instance[] {
  const best = new Map<string, Instance>();
  for (const i of list) {
    const key = i.instance_id;
    const cur = best.get(key);
    if (!cur || i.usd_value > cur.usd_value) best.set(key, i);
  }
  return [...best.values()];
}

export const _core = { frontRunningCore };
export type { EquivalentTrade };
