import { usdValue } from "@/lib/models/usdvalue";
import { instrumentFor } from "@/lib/models/gmm";
import type { Detector, Instance } from "./types";
import { impactChart, makeInstance, usd, usdCompact } from "./util";
import { MS_MIN } from "@/lib/time";

/**
 * Off-Market Trading (§7).
 *
 * A trade booked away from where the market actually was moves value between
 * the two sides of it. The check is a direct comparison of the executed rate
 * against the modelled mid for the headline pair at the execution timestamp.
 *
 *   EMI = deviation from the mid
 *   PTC = notional executed at that rate
 */
export const detectOffMarket: Detector = (ctx, p) => {
  const minDeviation = p.deviation_bps / 10_000;
  const out: Instance[] = [];

  for (const t of ctx.trades) {
    if (t.notional_usd < p.min_notional_usd) continue;
    const [base, quote] = t.currency_pair.split("/");
    const mid = ctx.market.midRate(base, quote, t.execution_ms);
    if (!mid || !Number.isFinite(mid)) continue;
    const signed = t.execution_rate / mid - 1;
    const deviation = Math.abs(signed);
    if (deviation < minDeviation) continue;

    const parts = usdValue(deviation, t.notional_usd);
    if (parts.usdValue < 1) continue;

    const currency = base === "USD" ? quote : base;
    const instrument = instrumentFor(currency);
    // Who gained: buying the base below mid, or selling it above, favours the trader.
    const favoursTrader =
      (t.buy_currency === base && signed < 0) || (t.sell_currency === base && signed > 0);

    out.push(
      makeInstance({
        ctx,
        metric: "off_market_trading",
        instrument,
        traderId: t.trader_id,
        traderName: t.trader_name,
        counterpartyId: t.counterparty_id,
        tradeDate: t.trade_date,
        startMs: t.execution_ms,
        endMs: t.execution_ms,
        usdValue: parts.usdValue,
        headline: `${usdCompact(t.notional_usd)} in ${t.currency_pair} printed ${(deviation * 10_000).toFixed(
          1,
        )} bps ${signed > 0 ? "above" : "below"} mid`,
        explanation:
          `${t.trader_name} executed ${usd(t.notional_usd)} of ${t.currency_pair} at ` +
          `${t.execution_rate.toPrecision(6)} against a modelled mid of ${mid.toPrecision(6)} — a deviation of ` +
          `${(deviation * 10_000).toFixed(1)} bps, well beyond ordinary spread. Applied to the notional, the trade ` +
          `moved ${usd(parts.usdValue)} of value ${favoursTrader ? "toward the trader's book" : "toward the counterparty"} ` +
          `relative to executing at the market. The counterparty was ${t.counterparty_id ?? "not recorded"}.`,
        components: [
          {
            label: "Expected Market Impact (EMI)",
            value: deviation * 10_000,
            unit: "bps",
            help: "Distance between the executed rate and the modelled mid.",
          },
          {
            label: "Profit-Taking Component (PTC)",
            value: t.notional_usd,
            unit: "usd",
            help: "Notional executed at the off-market rate.",
          },
          {
            label: "Executed rate",
            value: t.execution_rate,
            unit: "price",
            help: "Rate the trade printed at.",
          },
          {
            label: "Modelled mid",
            value: mid,
            unit: "price",
            help: "Where the market model puts the mid at that instant.",
          },
          {
            label: "Direction of transfer",
            value: favoursTrader ? "Toward the trader's book" : "Toward the counterparty",
            unit: "text",
            help: "Which side of the trade the off-market price favours.",
          },
        ],
        tradeIds: [t.trade_id],
        markers: [
          {
            trade_id: t.trade_id,
            ms: t.execution_ms,
            role: "impacting",
            label: "Off-market execution",
            notional_usd: t.notional_usd,
          },
        ],
      }),
    );
  }
  return out;
};
