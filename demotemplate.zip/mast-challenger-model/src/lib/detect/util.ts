import type { EquivalentTrade } from "@/lib/types";
import type { MetricId } from "@/lib/config/metrics";
import type { Component, DetectionContext, ImpactPoint, Instance, TradeMarker } from "./types";
import { MS_MIN } from "@/lib/time";

export const usd = (v: number) =>
  (v < 0 ? "-" : "") +
  "$" +
  Math.abs(v).toLocaleString("en-US", { maximumFractionDigits: 0 });

export const usdCompact = (v: number) => {
  const a = Math.abs(v);
  const s = v < 0 ? "-" : "";
  if (a >= 1e9) return `${s}$${(a / 1e9).toFixed(2)}bn`;
  if (a >= 1e6) return `${s}$${(a / 1e6).toFixed(1)}m`;
  if (a >= 1e3) return `${s}$${(a / 1e3).toFixed(0)}k`;
  return `${s}$${a.toFixed(0)}`;
};

export const bpsStr = (fraction: number) => `${(fraction * 10_000).toFixed(2)} bps`;

export const minutesStr = (ms: number) => {
  const m = ms / MS_MIN;
  if (m < 1) return `${(ms / 1000).toFixed(1)} seconds`;
  if (m < 90) return `${m.toFixed(1)} minutes`;
  return `${(m / 60).toFixed(1)} hours`;
};

export function groupBy<T>(items: T[], key: (t: T) => string): Map<string, T[]> {
  const m = new Map<string, T[]>();
  for (const it of items) {
    const k = key(it);
    const arr = m.get(k);
    if (arr) arr.push(it);
    else m.set(k, [it]);
  }
  return m;
}

export const notionalUsd = (eq: EquivalentTrade) => Math.abs(eq.sensitivity_usd);

export const sumNotional = (eqs: EquivalentTrade[]) =>
  eqs.reduce((s, e) => s + notionalUsd(e), 0);

export function uniqueTradeIds(eqs: EquivalentTrade[]): string[] {
  return [...new Set(eqs.map((e) => e.trade_id))];
}

export function scenarioTags(ctx: DetectionContext, tradeIds: string[]): string[] {
  const tags = new Set<string>();
  for (const id of tradeIds) {
    const tag = ctx.tradeById.get(id)?.scenario_tag;
    if (tag) tags.add(tag);
  }
  return [...tags];
}

export interface MakeInstanceArgs {
  ctx: DetectionContext;
  metric: MetricId;
  instrument: string;
  traderId: string;
  traderName?: string;
  counterpartyId?: string | null;
  tradeDate: string;
  startMs: number;
  endMs: number;
  usdValue: number;
  headline: string;
  explanation: string;
  components: Component[];
  tradeIds: string[];
  orderIds?: string[];
  markers: TradeMarker[];
}

export function makeInstance(a: MakeInstanceArgs): Instance {
  const trader = a.ctx.traders.get(a.traderId);
  return {
    instance_id: `${a.metric}|${a.traderId}|${a.instrument}|${a.startMs}`,
    metric: a.metric,
    instrument: a.instrument,
    trader_id: a.traderId,
    trader_name: a.traderName ?? trader?.name ?? a.traderId,
    counterparty_id: a.counterpartyId ?? null,
    trade_date: a.tradeDate,
    start_ms: a.startMs,
    end_ms: a.endMs,
    usd_value: a.usdValue,
    headline: a.headline,
    explanation: a.explanation,
    components: a.components,
    trade_ids: a.tradeIds,
    order_ids: a.orderIds,
    markers: a.markers,
    scenario_tags: scenarioTags(a.ctx, a.tradeIds),
  };
}

/**
 * Impact curve around an instance, padded either side for context. Built on
 * demand when an alert is opened rather than stored with every instance — the
 * curves are far bigger than the instances themselves.
 */
export function impactChart(
  ctx: DetectionContext,
  instrument: string,
  startMs: number,
  endMs: number,
  highlight: string[],
): ImpactPoint[] {
  const span = Math.max(endMs - startMs, 10 * MS_MIN);
  const pad = Math.min(90 * MS_MIN, Math.max(10 * MS_MIN, span * 0.4));
  return ctx.mim.curve(instrument, startMs - pad, endMs + pad, new Set(highlight), 90);
}

export function marker(
  eq: EquivalentTrade,
  role: TradeMarker["role"],
  label: string,
): TradeMarker {
  return {
    trade_id: eq.trade_id,
    ms: eq.trade.execution_ms,
    role,
    label,
    notional_usd: notionalUsd(eq),
  };
}

export const dir = (d: number) => (d > 0 ? "bought" : "sold");
export const dirNoun = (d: number) => (d > 0 ? "long" : "short");
