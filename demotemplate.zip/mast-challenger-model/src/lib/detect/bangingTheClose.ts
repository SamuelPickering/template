import type { EquivalentTrade } from "@/lib/types";
import { usdValue } from "@/lib/models/usdvalue";
import { FIX_MIN, MS_MIN, SESSION_START_MIN, atMinute } from "@/lib/time";
import type { Detector, Instance } from "./types";
import {
  bpsStr,
  groupBy,
  makeInstance,
  marker,
  notionalUsd,
  uniqueTradeIds,
  usd,
  usdCompact,
} from "./util";

/**
 * Banging the Close (§7).
 *
 * The simulation publishes a daily fix at 16:00 UTC. A trader with exposure to
 * that fix can concentrate their trading into the final minutes before it,
 * dragging the fix price their way, instead of spreading the same volume across
 * the session.
 *
 *   EMI = modelled fix displacement: the impact their concentrated window
 *         trading leaves standing at the fix, less the impact the same notional
 *         would have left if it had been spread evenly through the session
 *   PTC = their exposure to the fix, capped at the window notional
 */
export const detectBangingTheClose: Detector = (ctx, p) => {
  const windowMs = p.closing_window_minutes * MS_MIN;
  const out: Instance[] = [];

  const byDay = groupBy(ctx.eqs, (e) => `${e.instrument}|${e.trade.trade_date}`);
  for (const [key, eqs] of byDay) {
    const [instrument, date] = key.split("|");
    const fixMs = atMinute(date, FIX_MIN);
    const windowStart = fixMs - windowMs;

    for (const [traderId, traderEqs] of groupBy(eqs, (e) => e.trade.trader_id)) {
      const inWindow = traderEqs.filter(
        (e) => e.trade.execution_ms >= windowStart && e.trade.execution_ms <= fixMs,
      );
      if (inWindow.length < 2) continue;

      const windowNotional = inWindow.reduce((s, e) => s + notionalUsd(e), 0);
      if (windowNotional < p.min_window_notional_usd) continue;
      const dayNotional = traderEqs.reduce((s, e) => s + notionalUsd(e), 0);
      const concentration = windowNotional / dayNotional;
      if (concentration < p.min_concentration) continue;

      // What their window trading actually leaves standing at the fix.
      const actual = ctx.mim.impactFrom(inWindow, fixMs);
      if (Math.abs(actual) < 1e-9) continue;
      // What the same notional would have left if worked evenly through the day.
      const fair = evenlySpreadImpact(ctx, inWindow, date, fixMs);
      const emi = Math.abs(actual) - Math.abs(fair);
      if (emi <= 0) continue;

      // Exposure to the fix: the net position the trader carries into it.
      const exposure = Math.abs(
        traderEqs
          .filter((e) => e.trade.execution_ms <= fixMs)
          .reduce((s, e) => s + e.sensitivity_usd, 0),
      );
      const parts = usdValue(emi, exposure, windowNotional);
      if (parts.usdValue < 1) continue;

      const first = inWindow[0];
      const tradeIds = uniqueTradeIds(traderEqs.filter((e) => e.trade.execution_ms <= fixMs));
      const netDir = inWindow.reduce((s, e) => s + e.sensitivity_usd, 0) > 0 ? "up" : "down";

      out.push(
        makeInstance({
          ctx,
          metric: "banging_the_close",
          instrument,
          traderId,
          traderName: first.trade.trader_name,
          tradeDate: date,
          startMs: inWindow[0].trade.execution_ms,
          endMs: fixMs,
          usdValue: parts.usdValue,
          headline: `${usdCompact(windowNotional)} pushed through the last ${p.closing_window_minutes} minutes before the ${instrument} fix`,
          explanation:
            `${first.trade.trader_name} executed ${inWindow.length} trades worth ${usd(windowNotional)} in the ` +
            `${p.closing_window_minutes} minutes before the 16:00 fix — ${(concentration * 100).toFixed(0)}% of their ` +
            `whole day in ${instrument}. Concentrated like that, the Market Impact Model leaves ${bpsStr(
              Math.abs(actual),
            )} of impact standing at the fix, pushing it ${netDir}; the same notional worked evenly across the session ` +
            `would have left only ${bpsStr(Math.abs(fair))}, since most of it would have decayed. The ` +
            `${bpsStr(emi)} difference is the modelled fix displacement, applied to the ${usd(parts.ptcUsd)} of ` +
            `exposure carried into the fix, giving ${usd(parts.usdValue)}.`,
          components: [
            {
              label: "Expected Market Impact (EMI)",
              value: emi * 10_000,
              unit: "bps",
              help: "Fix displacement: impact standing at the fix from concentrated trading, less what evenly-spread trading would have left.",
            },
            {
              label: "Profit-Taking Component (PTC)",
              value: parts.ptcUsd,
              unit: "usd",
              help: "Exposure carried into the fix, capped at the window notional.",
            },
            {
              label: "Actual fix impact",
              value: Math.abs(actual) * 10_000,
              unit: "bps",
              help: "Modelled impact of the window trades still standing at 16:00.",
            },
            {
              label: "Modelled fair fix impact",
              value: Math.abs(fair) * 10_000,
              unit: "bps",
              help: "What the same notional would have left standing if spread evenly from the open.",
            },
            {
              label: "Window notional",
              value: windowNotional,
              unit: "usd",
              help: "Notional executed inside the closing window.",
            },
            {
              label: "Concentration",
              value: concentration,
              unit: "ratio",
              help: "Share of the trader's day in this instrument that fell inside the window.",
            },
            {
              label: "Trades in window",
              value: inWindow.length,
              unit: "count",
              help: "Number of trades inside the closing window.",
            },
          ],
          tradeIds,
          markers: [
            ...traderEqs
              .filter((e) => e.trade.execution_ms < windowStart)
              .map((e) => marker(e, "context", "Earlier exposure")),
            ...inWindow.map((e) => marker(e, "impacting", "In fixing window")),
          ],
        }),
      );
    }
  }
  return out;
};

/** Impact left at the fix had the same notional been worked evenly from the open. */
function evenlySpreadImpact(
  ctx: Parameters<Detector>[0],
  eqs: EquivalentTrade[],
  date: string,
  fixMs: number,
): number {
  const openMs = atMinute(date, SESSION_START_MIN);
  const span = fixMs - openMs;
  if (span <= 0) return 0;
  const slices = 24;
  const totalSigned = eqs.reduce((s, e) => s + e.sensitivity_usd, 0);
  const perSlice = totalSigned / slices;
  const currency = eqs[0].currency;
  let total = 0;
  for (let i = 0; i < slices; i++) {
    const ms = openMs + (span * (i + 0.5)) / slices;
    const mag = ctx.mim.magnitude(currency, ms, Math.abs(perSlice)) * Math.sign(perSlice);
    total += mag * ctx.mim.decay(fixMs - ms);
  }
  return total;
}
