import { usdValue } from "@/lib/models/usdvalue";
import type { Detector, Instance } from "./types";
import {
  groupBy,
  makeInstance,
  marker,
  notionalUsd,
  uniqueTradeIds,
  usd,
  usdCompact,
} from "./util";

/**
 * Cross Trading (§7).
 *
 * Two books inside the firm taking opposite sides of the same instrument at
 * effectively the same instant. Nothing goes to the street, so whatever price
 * they agree decides how much value moves from one book to the other.
 *
 *   EMI = deviation of the crossed rate from the prevailing market mid
 *   PTC = notional crossed between the books
 */
export const detectCrossTrading: Detector = (ctx, p) => {
  const maxGapMs = p.max_timestamp_gap_seconds * 1000;
  const tol = p.size_match_tolerance_pct / 100;
  const out: Instance[] = [];
  const used = new Set<string>();

  for (const eqs of groupBy(ctx.eqs, (e) => `${e.instrument}|${e.trade.trade_date}`).values()) {
    for (let i = 0; i < eqs.length; i++) {
      const a = eqs[i];
      if (used.has(a.eq_id)) continue;
      for (let j = i + 1; j < eqs.length; j++) {
        const b = eqs[j];
        const gap = b.trade.execution_ms - a.trade.execution_ms;
        if (gap > maxGapMs) break;
        if (used.has(b.eq_id)) continue;
        if (a.direction === b.direction) continue;
        if (a.trade.trader_id === b.trade.trader_id) continue;
        const na = notionalUsd(a);
        const nb = notionalUsd(b);
        if (Math.abs(na - nb) > tol * Math.max(na, nb)) continue;

        // How far the crossed rate sits from where the market actually was.
        const mid = ctx.market.midRate(
          a.trade.currency_pair.split("/")[0],
          a.trade.currency_pair.split("/")[1],
          a.trade.execution_ms,
        );
        const deviation = Math.abs(a.trade.execution_rate / mid - 1);
        const crossed = Math.min(na, nb);
        const parts = usdValue(deviation, crossed);
        if (parts.usdValue < 1) continue;

        used.add(a.eq_id);
        used.add(b.eq_id);
        const tradeIds = uniqueTradeIds([a, b]);
        const bookA = a.trade.trader_name;
        const bookB = b.trade.trader_name;

        out.push(
          makeInstance({
            ctx,
            metric: "cross_trading",
            instrument: a.instrument,
            traderId: a.trade.trader_id,
            traderName: a.trade.trader_name,
            counterpartyId: a.trade.counterparty_id,
            tradeDate: a.trade.trade_date,
            startMs: a.trade.execution_ms,
            endMs: b.trade.execution_ms,
            usdValue: parts.usdValue,
            headline: `${usdCompact(crossed)} crossed between ${bookA} and ${bookB} at ${(deviation * 10_000).toFixed(1)} bps off mid`,
            explanation:
              `${bookA} and ${bookB} took opposite sides of ` +
              `${a.trade.currency_pair} within ${(gap / 1000).toFixed(1)} seconds of each other, for ${usd(na)} and ` +
              `${usd(nb)} respectively. The risk moved between two internal books rather than to the street, and the ` +
              `agreed rate of ${a.trade.execution_rate.toPrecision(6)} sits ${(deviation * 10_000).toFixed(1)} bps ` +
              `away from the modelled mid of ${mid.toPrecision(6)}. Applying that deviation to the ${usd(crossed)} ` +
              `crossed gives ${usd(parts.usdValue)} of value transferred between the two portfolios.`,
            components: [
              {
                label: "Expected Market Impact (EMI)",
                value: deviation * 10_000,
                unit: "bps",
                help: "Deviation of the crossed rate from the prevailing modelled mid.",
              },
              {
                label: "Profit-Taking Component (PTC)",
                value: crossed,
                unit: "usd",
                help: "Notional crossed between the two books.",
              },
              {
                label: "Timestamp gap",
                value: b.trade.execution_ms - a.trade.execution_ms,
                unit: "duration",
                help: "Time between the two sides of the cross.",
              },
              {
                label: "Crossed rate",
                value: a.trade.execution_rate,
                unit: "price",
                help: "Rate the two books agreed.",
              },
              {
                label: "Modelled mid",
                value: mid,
                unit: "price",
                help: "Where the market model puts the mid at that instant.",
              },
              {
                label: "Books",
                value: `${bookA} / ${bookB}`,
                unit: "text",
                help: "The two books on either side of the cross.",
              },
            ],
            tradeIds,
            markers: [marker(a, "impacting", `${bookA} side`), marker(b, "benefiting", `${bookB} side`)],
          }),
        );
        break;
      }
    }
  }
  return out;
};
