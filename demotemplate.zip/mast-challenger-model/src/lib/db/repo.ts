import { getData, resetData, updateData } from "./index";
import type {
  Counterparty,
  Currency,
  MarketDay,
  MarketEvent,
  OrderRow,
  Trade,
  Trader,
} from "@/lib/types";

/* ---------------- writes ---------------- */

export function resetDb() {
  resetData();
}

export function insertTraders(rows: Trader[]) {
  updateData((d) => {
    d.traders = rows;
  });
}

export function insertCounterparties(rows: Counterparty[]) {
  updateData((d) => {
    d.counterparties = rows;
  });
}

export function insertCurrencies(rows: Currency[]) {
  updateData((d) => {
    d.currencies = rows;
  });
}

export function insertMarketDaily(rows: MarketDay[]) {
  updateData((d) => {
    d.market_daily = rows;
  });
}

export function insertEvents(rows: MarketEvent[]) {
  updateData((d) => {
    d.events = rows;
  });
}

export function insertOrders(rows: OrderRow[]) {
  updateData((d) => {
    d.orders = [...d.orders, ...rows].sort((a, b) => a.placed_ms - b.placed_ms);
  });
}

/**
 * Trades are kept per source, so an imported file whose deal references happen
 * to collide with the synthetic population cannot overwrite it.
 */
export function insertTrades(rows: Trade[]) {
  if (!rows.length) return;
  updateData((d) => {
    for (const t of rows) {
      const bucket = (d.trades[t.source] ??= []);
      bucket.push(t);
    }
    for (const bucket of Object.values(d.trades)) {
      bucket.sort((a, b) => a.execution_ms - b.execution_ms);
    }
  });
}

export function deleteTradesBySource(source: string) {
  updateData((d) => {
    d.trades[source] = [];
  });
}

/* ---------------- reads ---------------- */

export const loadTraders = (): Trader[] => getData().traders;

export const loadCounterparties = (): Counterparty[] => getData().counterparties;

export const loadCurrencies = (): Currency[] => getData().currencies;

export const loadMarketDaily = (): MarketDay[] => getData().market_daily;

export const loadTrades = (source: string): Trade[] => getData().trades[source] ?? [];

export const loadOrders = (): OrderRow[] => getData().orders;

export const loadEvents = (): MarketEvent[] => getData().events;

export function countBySource(): Record<string, number> {
  const trades = getData().trades;
  return Object.fromEntries(Object.entries(trades).map(([k, v]) => [k, v.length]));
}
