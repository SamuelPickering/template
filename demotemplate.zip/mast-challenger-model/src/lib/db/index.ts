import fs from "node:fs";
import path from "node:path";
import type {
  Counterparty,
  Currency,
  MarketDay,
  MarketEvent,
  OrderRow,
  Trade,
  Trader,
} from "@/lib/types";

/**
 * Storage.
 *
 * Everything lives in two JSON files under data/: the generated dataset and the
 * admin config. It started out on SQLite, but the native driver has to be
 * compiled from source on machines without C++ build tools, which makes the
 * project awkward to hand to someone else. Plain files need nothing but Node,
 * and the dataset (tens of thousands of trades) loads in well under a second.
 */
export interface DataStore {
  traders: Trader[];
  counterparties: Counterparty[];
  currencies: Currency[];
  market_daily: MarketDay[];
  events: MarketEvent[];
  orders: OrderRow[];
  trades: Record<string, Trade[]>; // keyed by source: synthetic | imported
}

export interface ConfigStore {
  /** metric id -> { param key -> value } */
  config: Record<string, Record<string, number>>;
  settings: Record<string, string>;
}

const EMPTY_DATA: DataStore = {
  traders: [],
  counterparties: [],
  currencies: [],
  market_daily: [],
  events: [],
  orders: [],
  trades: { synthetic: [], imported: [] },
};

export function dataDir(): string {
  return process.env.MAST_DATA_DIR ?? path.join(process.cwd(), "data");
}

const dataFile = () => path.join(dataDir(), "dataset.json");
const configFile = () => path.join(dataDir(), "config.json");

let dataCache: { mtimeMs: number; value: DataStore } | null = null;
let configCache: { mtimeMs: number; value: ConfigStore } | null = null;

function readJson<T>(file: string, fallback: T, cache: { mtimeMs: number; value: T } | null) {
  let stat: fs.Stats | null = null;
  try {
    stat = fs.statSync(file);
  } catch {
    return { value: fallback, cache: null };
  }
  // The seed script writes these files from a separate process, so the mtime is
  // what tells a running server that the data underneath it has changed.
  if (cache && cache.mtimeMs === stat.mtimeMs) return { value: cache.value, cache };
  const parsed = JSON.parse(fs.readFileSync(file, "utf8")) as T;
  return { value: parsed, cache: { mtimeMs: stat.mtimeMs, value: parsed } };
}

function writeJson(file: string, value: unknown) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = `${file}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(value));
  fs.renameSync(tmp, file);
}

export function getData(): DataStore {
  const { value, cache } = readJson<DataStore>(dataFile(), EMPTY_DATA, dataCache);
  dataCache = cache;
  // Older files may predate a source key being used.
  value.trades.synthetic ??= [];
  value.trades.imported ??= [];
  return value;
}

export function saveData(data: DataStore) {
  writeJson(dataFile(), data);
  dataCache = null;
}

/** Read, mutate and write the dataset in one go. */
export function updateData(fn: (data: DataStore) => void) {
  const data = getData();
  fn(data);
  saveData(data);
}

export function getConfigStore(): ConfigStore {
  const { value, cache } = readJson<ConfigStore>(
    configFile(),
    { config: {}, settings: {} },
    configCache,
  );
  configCache = cache;
  value.config ??= {};
  value.settings ??= {};
  return value;
}

export function saveConfigStore(store: ConfigStore) {
  writeJson(configFile(), store);
  configCache = null;
}

/** Wipes the generated dataset. The admin config is left alone. */
export function resetData(): DataStore {
  const fresh: DataStore = structuredClone(EMPTY_DATA);
  saveData(fresh);
  return fresh;
}
