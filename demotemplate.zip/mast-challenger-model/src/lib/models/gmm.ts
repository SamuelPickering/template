import type { EquivalentTrade, Trade } from "@/lib/types";
import type { MarketData } from "./market";

/**
 * General Market Model — synthetic instrument splitting (§4.1).
 *
 * Every FX trade is broken into equivalent trades against USD. A trade between
 * two non-USD currencies produces two equivalent trades, one per leg; a trade
 * that already involves USD produces one. The Sensitivity of each equivalent
 * trade — the signed amount on the synthetic USD-pair instrument — is what
 * every downstream metric consumes, never the raw buy/sell amounts.
 *
 * This is what makes cross-currency abuse visible: a position in JPY built
 * through EUR/JPY and GBP/JPY lands on the single JPY/USD instrument.
 */
export function instrumentFor(currency: string): string {
  return `${currency}/USD`;
}

export function splitTrade(trade: Trade, market: MarketData): EquivalentTrade[] {
  const out: EquivalentTrade[] = [];
  const push = (currency: string, amount: number, dir: 1 | -1, leg: string) => {
    if (currency === "USD" || amount === 0) return;
    const sensitivity = amount * dir;
    out.push({
      eq_id: `${trade.trade_id}:${leg}`,
      trade_id: trade.trade_id,
      instrument: instrumentFor(currency),
      currency,
      sensitivity,
      sensitivity_usd: sensitivity * market.usdRate(currency, trade.execution_ms),
      direction: dir,
      trade,
    });
  };
  push(trade.buy_currency, trade.buy_amount, 1, "B");
  push(trade.sell_currency, trade.sell_amount, -1, "S");
  return out;
}

export function splitAll(trades: Trade[], market: MarketData): EquivalentTrade[] {
  const out: EquivalentTrade[] = [];
  for (const t of trades) out.push(...splitTrade(t, market));
  out.sort((a, b) => a.trade.execution_ms - b.trade.execution_ms);
  return out;
}

/** Equivalent trades grouped by synthetic instrument, each already time-sorted. */
export function groupByInstrument(
  eqs: EquivalentTrade[],
): Map<string, EquivalentTrade[]> {
  const m = new Map<string, EquivalentTrade[]>();
  for (const e of eqs) {
    let arr = m.get(e.instrument);
    if (!arr) {
      arr = [];
      m.set(e.instrument, arr);
    }
    arr.push(e);
  }
  for (const arr of m.values()) {
    arr.sort((a, b) => a.trade.execution_ms - b.trade.execution_ms);
  }
  return m;
}

export function groupBy<T>(items: T[], key: (t: T) => string): Map<string, T[]> {
  const m = new Map<string, T[]>();
  for (const it of items) {
    const k = key(it);
    let arr = m.get(k);
    if (!arr) {
      arr = [];
      m.set(k, arr);
    }
    arr.push(it);
  }
  return m;
}
