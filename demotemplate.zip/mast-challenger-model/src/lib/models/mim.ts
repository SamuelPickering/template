import type { EquivalentTrade } from "@/lib/types";
import type { MarketData } from "./market";
import { dateKey, MS_MIN } from "@/lib/time";
import { groupByInstrument } from "./gmm";

/**
 * Market Impact Model, v1 (§4.2).
 *
 *   instantaneous impact = K x volatility x (notional / ADTV)      [signed]
 *   impact(t)            = instantaneous impact x exp(-lambda x dt)
 *
 * That is: proportional to trade size, proportional to volatility, inversely
 * proportional to average daily traded volume, instantaneous, additive across
 * trades, and decaying exponentially back toward zero. Impact is expressed as
 * a fraction of the instrument's price.
 *
 * K is a calibration constant chosen so that a very large clip in a liquid
 * major (~USD 100m in EUR/USD) moves the modelled price by roughly two basis
 * points — the right order of magnitude for an educational simulation.
 */
export const MIM_DEFAULTS = {
  k: 750,
  halfLifeMinutes: 30,
  /**
   * Sanity cap on a single trade's modelled impact (fraction of price). A
   * linear impact model overstates very large clips in thin instruments, so the
   * cap keeps a single trade from claiming an implausible move.
   */
  maxImpact: 0.0025,
};

export interface MimOptions {
  k?: number;
  halfLifeMinutes?: number;
  maxImpact?: number;
}

export class MarketImpactModel {
  readonly k: number;
  readonly halfLifeMs: number;
  readonly maxImpact: number;
  private lambda: number;
  private byInstrument: Map<string, EquivalentTrade[]>;
  private impactCache = new WeakMap<EquivalentTrade, number>();

  constructor(
    private market: MarketData,
    eqs: EquivalentTrade[],
    opts: MimOptions = {},
  ) {
    this.k = opts.k ?? MIM_DEFAULTS.k;
    this.halfLifeMs = (opts.halfLifeMinutes ?? MIM_DEFAULTS.halfLifeMinutes) * MS_MIN;
    this.maxImpact = opts.maxImpact ?? MIM_DEFAULTS.maxImpact;
    this.lambda = Math.LN2 / this.halfLifeMs;
    this.byInstrument = groupByInstrument(eqs);
  }

  instruments(): string[] {
    return [...this.byInstrument.keys()];
  }

  tradesOn(instrument: string): EquivalentTrade[] {
    return this.byInstrument.get(instrument) ?? [];
  }

  /** Unsigned instantaneous impact of `notionalUsd` traded in `currency`. */
  magnitude(currency: string, ms: number, notionalUsd: number): number {
    const date = dateKey(ms);
    const vol = this.market.volatility(currency, date);
    const adtv = this.market.adtv(currency, date);
    if (!adtv) return 0;
    const raw = this.k * vol * (Math.abs(notionalUsd) / adtv);
    return Math.min(this.maxImpact, raw);
  }

  /** Signed instantaneous impact of one equivalent trade. */
  impactOf(eq: EquivalentTrade): number {
    const cached = this.impactCache.get(eq);
    if (cached !== undefined) return cached;
    const usd = Math.abs(eq.sensitivity_usd);
    const v = this.magnitude(eq.currency, eq.trade.execution_ms, usd) * eq.direction;
    this.impactCache.set(eq, v);
    return v;
  }

  decay(dtMs: number): number {
    if (dtMs <= 0) return dtMs > -1000 ? 1 : 0;
    return Math.exp(-this.lambda * dtMs);
  }

  /** Residual impact of one equivalent trade as observed at `atMs`. */
  residualOf(eq: EquivalentTrade, atMs: number): number {
    const dt = atMs - eq.trade.execution_ms;
    if (dt < 0) return 0;
    return this.impactOf(eq) * this.decay(dt);
  }

  /**
   * Total residual impact on `instrument` at `atMs`, optionally restricted to a
   * subset of the flow (e.g. only one portfolio's trades). Trades older than
   * eight half-lives contribute nothing material and are skipped.
   */
  residual(
    instrument: string,
    atMs: number,
    filter?: (eq: EquivalentTrade) => boolean,
  ): number {
    const arr = this.byInstrument.get(instrument);
    if (!arr) return 0;
    const cutoff = atMs - 8 * this.halfLifeMs;
    let total = 0;
    for (let i = upperBound(arr, atMs) - 1; i >= 0; i--) {
      const eq = arr[i];
      if (eq.trade.execution_ms < cutoff) break;
      if (filter && !filter(eq)) continue;
      total += this.residualOf(eq, atMs);
    }
    return total;
  }

  /** Cumulative impact created by an explicit list of equivalent trades. */
  impactFrom(eqs: EquivalentTrade[], atMs: number): number {
    let total = 0;
    for (const eq of eqs) total += this.residualOf(eq, atMs);
    return total;
  }

  /**
   * Sampled impact curve for charting: modelled impact in basis points across
   * a window, split into the highlighted flow and everything else.
   */
  curve(
    instrument: string,
    fromMs: number,
    toMs: number,
    highlight: Set<string>,
    steps = 80,
  ): { ms: number; total_bps: number; highlight_bps: number; mid: number }[] {
    const out = [];
    const currency = instrument.split("/")[0];
    const step = Math.max(1, (toMs - fromMs) / steps);
    for (let i = 0; i <= steps; i++) {
      const ms = fromMs + i * step;
      const total = this.residual(instrument, ms);
      const hi = this.residual(instrument, ms, (eq) => highlight.has(eq.trade_id));
      out.push({
        ms: Math.round(ms),
        total_bps: total * 10_000,
        highlight_bps: hi * 10_000,
        mid: this.market.usdRate(currency, ms),
      });
    }
    return out;
  }
}

/** First index whose execution time is strictly greater than `ms`. */
function upperBound(arr: EquivalentTrade[], ms: number): number {
  let lo = 0;
  let hi = arr.length;
  while (lo < hi) {
    const mid = (lo + hi) >> 1;
    if (arr[mid].trade.execution_ms <= ms) lo = mid + 1;
    else hi = mid;
  }
  return lo;
}
