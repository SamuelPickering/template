import type { EquivalentTrade } from "@/lib/types";
import { MS_HOUR } from "@/lib/time";

/**
 * Allocation Algorithm (§4.3).
 *
 * Connects buys with sells inside a book so we can tell which trades were
 * executed to facilitate others and which built a proprietary position. The
 * guiding heuristic, per the source material, is that opposite-direction
 * trades are more likely to be matched the closer they are in both timestamp
 * and notional, with client facilitation prioritised. Whatever is left
 * unmatched is proprietary. Partial allocation is supported.
 */
export interface AllocationLink {
  a: string; // eq_id of the earlier leg
  b: string; // eq_id of the later leg
  usd: number;
  score: number;
}

export interface AllocationResult {
  links: AllocationLink[];
  /** eq_id -> USD matched against opposite-direction flow. */
  matchedUsd: Map<string, number>;
  /** eq_id -> USD left unmatched, i.e. proprietary exposure opened. */
  residualUsd: Map<string, number>;
  /** eq_id -> USD matched specifically against client facilitation flow. */
  clientMatchedUsd: Map<string, number>;
}

export interface AllocationOptions {
  /** Time constant of the proximity score. */
  halfLifeMs?: number;
  /** Pairs further apart than this are never matched. */
  maxGapMs?: number;
  /** Multiplier applied when exactly one side is client facilitation. */
  clientBias?: number;
}

const DEFAULTS = {
  halfLifeMs: 45 * 60_000,
  maxGapMs: 6 * MS_HOUR,
  clientBias: 1.6,
};

const isClient = (eq: EquivalentTrade) =>
  eq.trade.trade_role === "client_facilitation";

export function allocate(
  eqs: EquivalentTrade[],
  opts: AllocationOptions = {},
): AllocationResult {
  const halfLife = opts.halfLifeMs ?? DEFAULTS.halfLifeMs;
  const maxGap = opts.maxGapMs ?? DEFAULTS.maxGapMs;
  const clientBias = opts.clientBias ?? DEFAULTS.clientBias;
  const lambda = Math.LN2 / halfLife;

  const items = eqs
    .slice()
    .sort((x, y) => x.trade.execution_ms - y.trade.execution_ms);
  const remaining = new Map<string, number>();
  for (const e of items) remaining.set(e.eq_id, Math.abs(e.sensitivity_usd));

  type Cand = { i: number; j: number; score: number };
  const cands: Cand[] = [];
  for (let i = 0; i < items.length; i++) {
    for (let j = i + 1; j < items.length; j++) {
      const a = items[i];
      const b = items[j];
      const dt = b.trade.execution_ms - a.trade.execution_ms;
      if (dt > maxGap) break;
      if (a.direction === b.direction) continue;
      const sa = Math.abs(a.sensitivity_usd);
      const sb = Math.abs(b.sensitivity_usd);
      if (sa === 0 || sb === 0) continue;
      const sizeAffinity = Math.min(sa, sb) / Math.max(sa, sb);
      const bias = isClient(a) !== isClient(b) ? clientBias : 1;
      const score = Math.exp(-lambda * dt) * sizeAffinity * bias;
      if (score > 1e-4) cands.push({ i, j, score });
    }
  }
  cands.sort((p, q) => q.score - p.score);

  const links: AllocationLink[] = [];
  const matchedUsd = new Map<string, number>();
  const clientMatchedUsd = new Map<string, number>();
  const bump = (m: Map<string, number>, key: string, v: number) =>
    m.set(key, (m.get(key) ?? 0) + v);

  for (const c of cands) {
    const a = items[c.i];
    const b = items[c.j];
    const ra = remaining.get(a.eq_id) ?? 0;
    const rb = remaining.get(b.eq_id) ?? 0;
    if (ra <= 1 || rb <= 1) continue;
    const usd = Math.min(ra, rb);
    remaining.set(a.eq_id, ra - usd);
    remaining.set(b.eq_id, rb - usd);
    links.push({ a: a.eq_id, b: b.eq_id, usd, score: c.score });
    bump(matchedUsd, a.eq_id, usd);
    bump(matchedUsd, b.eq_id, usd);
    if (isClient(b)) bump(clientMatchedUsd, a.eq_id, usd);
    if (isClient(a)) bump(clientMatchedUsd, b.eq_id, usd);
  }

  return { links, matchedUsd, residualUsd: remaining, clientMatchedUsd };
}

/**
 * Share of an equivalent trade that the Allocation Algorithm could not explain
 * as facilitation of nearby opposite flow — i.e. the proprietary portion.
 */
export function propShare(eq: EquivalentTrade, res: AllocationResult): number {
  const total = Math.abs(eq.sensitivity_usd);
  if (!total) return 0;
  return Math.max(0, Math.min(1, (res.residualUsd.get(eq.eq_id) ?? 0) / total));
}

/** Share of an equivalent trade matched against client facilitation flow. */
export function facilitationShare(
  eq: EquivalentTrade,
  res: AllocationResult,
): number {
  const total = Math.abs(eq.sensitivity_usd);
  if (!total) return 0;
  return Math.max(0, Math.min(1, (res.clientMatchedUsd.get(eq.eq_id) ?? 0) / total));
}
