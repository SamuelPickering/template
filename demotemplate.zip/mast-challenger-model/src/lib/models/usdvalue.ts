/**
 * USD Value (§4.5).
 *
 *   USD Value = Expected Market Impact (EMI) x Profit-Taking Component (PTC)
 *
 * EMI is the modelled price impact through time of the abusive action,
 * expressed as a fraction of price. PTC is the size of the position positioned
 * to gain from that impact, in USD. Each metric specialises the two terms.
 *
 * Exhaustion principle: where the PTC is larger than the notional that created
 * the impact, only the portion of the position the impact could actually have
 * benefited counts, so the PTC is capped at the impacting notional.
 */
export interface UsdValueParts {
  emi: number; // fraction of price
  ptcUsd: number; // USD, already capped
  ptcRequestedUsd: number; // USD, before the exhaustion cap
  capUsd: number | null;
  usdValue: number;
}

export function usdValue(
  emi: number,
  ptcUsd: number,
  capUsd: number | null = null,
): UsdValueParts {
  const capped = capUsd === null ? ptcUsd : Math.min(ptcUsd, capUsd);
  return {
    emi,
    ptcUsd: capped,
    ptcRequestedUsd: ptcUsd,
    capUsd,
    usdValue: emi * capped,
  };
}

/**
 * Narrative vs Counter-Narrative scoring, used where the question is not
 * "how much impact did this create" but "is there an innocent explanation".
 * The score is what the abusive reading is worth net of the legitimate one; a
 * non-positive score means the Counter-Narrative dominates and nothing is
 * flagged.
 */
export interface NarrativeParts {
  narrativeUsd: number;
  counterNarrativeUsd: number;
  usdValue: number;
  dominance: number;
}

export function narrativeScore(
  narrativeUsd: number,
  counterNarrativeUsd: number,
): NarrativeParts {
  return {
    narrativeUsd,
    counterNarrativeUsd,
    usdValue: narrativeUsd - counterNarrativeUsd,
    dominance:
      counterNarrativeUsd > 0 ? narrativeUsd / counterNarrativeUsd : Infinity,
  };
}

export const bps = (fraction: number) => fraction * 10_000;
