import type { MarketDay, MarketEvent } from "@/lib/types";
import { gauss, mulberry32 } from "@/lib/gen/rng";
import { MS_DAY, dateKey, dayStartMs } from "@/lib/time";

const MINUTES = 1440;

/**
 * Market reference data, with a deterministic intraday mid path per instrument
 * per day. The path is a Brownian bridge pinned to the day's open and close, so
 * a mid is available at any millisecond without storing minute-level rows.
 */
export class MarketData {
  private byCcy = new Map<string, Map<string, MarketDay>>();
  private dates: string[] = [];
  private pathCache = new Map<string, Float64Array>();

  constructor(rows: MarketDay[]) {
    const dateSet = new Set<string>();
    for (const r of rows) {
      let m = this.byCcy.get(r.currency);
      if (!m) {
        m = new Map();
        this.byCcy.set(r.currency, m);
      }
      m.set(r.trade_date, r);
      dateSet.add(r.trade_date);
    }
    this.dates = [...dateSet].sort();
  }

  get currencies(): string[] {
    return [...this.byCcy.keys()];
  }

  get tradingDates(): string[] {
    return this.dates;
  }

  get firstDate(): string {
    return this.dates[0];
  }

  get lastDate(): string {
    return this.dates[this.dates.length - 1];
  }

  day(currency: string, date: string): MarketDay | undefined {
    return this.byCcy.get(currency)?.get(date);
  }

  /** Nearest available session on or before `date` (covers weekends/holidays). */
  private nearestDay(currency: string, date: string): MarketDay | undefined {
    const m = this.byCcy.get(currency);
    if (!m) return undefined;
    const direct = m.get(date);
    if (direct) return direct;
    let ms = dayStartMs(date);
    for (let i = 0; i < 10; i++) {
      ms -= MS_DAY;
      const hit = m.get(dateKey(ms));
      if (hit) return hit;
    }
    return m.get(this.dates[0]);
  }

  private path(currency: string, date: string): Float64Array | null {
    const key = `${currency}|${date}`;
    const cached = this.pathCache.get(key);
    if (cached) return cached;
    const d = this.nearestDay(currency, date);
    if (!d) return null;
    const rng = mulberry32(d.day_seed);
    const steps = new Float64Array(MINUTES + 1);
    // Intraday wiggle scaled so the realised path roughly matches the daily vol.
    const stepVol = d.volatility / Math.sqrt(MINUTES);
    let acc = 0;
    for (let i = 1; i <= MINUTES; i++) {
      acc += stepVol * gauss(rng);
      steps[i] = acc;
    }
    const end = steps[MINUTES];
    const out = new Float64Array(MINUTES + 1);
    for (let i = 0; i <= MINUTES; i++) {
      const t = i / MINUTES;
      const bridged = steps[i] - t * end; // pin both ends
      const trend = d.mid_open + (d.mid_close - d.mid_open) * t;
      out[i] = trend * (1 + bridged);
    }
    this.pathCache.set(key, out);
    return out;
  }

  /**
   * Event overlay: a step change applied to the instrument's price the instant
   * an event becomes public (see Event Generator, §4.4). Keeping the shock as
   * an overlay rather than baking it into the daily series means the jump lands
   * exactly on the public timestamp, which is what Insider Trading measures
   * against.
   */
  setEvents(events: MarketEvent[]) {
    this.events.clear();
    this.pathCache.clear();
    for (const e of events) {
      const arr = this.events.get(e.currency) ?? [];
      arr.push(e);
      this.events.set(e.currency, arr);
    }
    for (const arr of this.events.values()) arr.sort((a, b) => a.public_ms - b.public_ms);
  }

  private events = new Map<string, MarketEvent[]>();

  eventsFor(currency: string): MarketEvent[] {
    return this.events.get(currency) ?? [];
  }

  /** Cumulative multiplier from every event already public at `ms`. */
  private jumpFactor(currency: string, ms: number): number {
    const arr = this.events.get(currency);
    if (!arr || arr.length === 0) return 1;
    let f = 1;
    for (const e of arr) {
      if (e.public_ms > ms) break;
      f *= 1 + e.move_pct / 100;
    }
    return f;
  }

  /** USD per 1 unit of `currency` at time `ms`. USD itself is always 1. */
  usdRate(currency: string, ms: number): number {
    if (currency === "USD") return 1;
    const date = dateKey(ms);
    const p = this.path(currency, date);
    if (!p) return 1;
    const minute = (ms - dayStartMs(date)) / 60000;
    const i = Math.max(0, Math.min(MINUTES - 1, Math.floor(minute)));
    const frac = Math.max(0, Math.min(1, minute - i));
    const base = p[i] * (1 - frac) + p[i + 1] * frac;
    return base * this.jumpFactor(currency, ms);
  }

  /** Mid rate for `base/quote`, i.e. units of quote per 1 unit of base. */
  midRate(base: string, quote: string, ms: number): number {
    return this.usdRate(base, ms) / this.usdRate(quote, ms);
  }

  /** Daily volatility of the X/USD synthetic instrument, as a fraction. */
  volatility(currency: string, date: string): number {
    if (currency === "USD") return 0;
    return this.nearestDay(currency, date)?.volatility ?? 0.005;
  }

  /** Average daily traded volume of the synthetic instrument, in USD. */
  adtv(currency: string, date: string): number {
    if (currency === "USD") return 5e12;
    return this.nearestDay(currency, date)?.adtv_usd ?? 1e11;
  }

  /** Convert an amount of `currency` into USD at time `ms`. */
  toUsd(amount: number, currency: string, ms: number): number {
    return amount * this.usdRate(currency, ms);
  }
}
