"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import type { CanonicalField } from "@/lib/import/csv";

interface Preview {
  headers: string[];
  sample: string[][];
  rows: number;
  mapping: Record<string, string>;
  fields: CanonicalField[];
}

interface CommitResult {
  imported: number;
  rowsRead: number;
  warnings: string[];
  missingOptional: string[];
  limitations: string[];
  activated: boolean;
  errors?: string[];
}

export function ImportClient({ dataset }: { dataset: "synthetic" | "imported" }) {
  const router = useRouter();
  const [csv, setCsv] = useState<string | null>(null);
  const [fileName, setFileName] = useState("");
  const [preview, setPreview] = useState<Preview | null>(null);
  const [mapping, setMapping] = useState<Record<string, string>>({});
  const [result, setResult] = useState<CommitResult | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function onFile(file: File) {
    setBusy(true);
    setError(null);
    setResult(null);
    const text = await file.text();
    setCsv(text);
    setFileName(file.name);
    const res = await fetch("/api/import", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ action: "preview", csv: text }),
    });
    const json = await res.json();
    setBusy(false);
    if (!res.ok) {
      setError(json.error ?? "Could not read that file.");
      return;
    }
    setPreview(json);
    setMapping(json.mapping);
  }

  async function commit() {
    if (!csv) return;
    setBusy(true);
    setError(null);
    const res = await fetch("/api/import", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ action: "commit", csv, mapping, activate: true }),
    });
    const json = await res.json();
    setBusy(false);
    if (!res.ok) {
      setError((json.errors ?? []).join(" ") || json.error || "Import failed.");
      return;
    }
    setResult(json);
    router.refresh();
  }

  async function post(body: object) {
    setBusy(true);
    await fetch("/api/dataset", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
    });
    setBusy(false);
    router.refresh();
  }

  const required = preview?.fields.filter((f) => f.required) ?? [];
  const optional = preview?.fields.filter((f) => !f.required) ?? [];
  const unmappedRequired = required.filter((f) => !mapping[f.key]);

  return (
    <>
      <fieldset>
        <legend>Active dataset: {dataset}</legend>
        <p className="note small">
          When imported data is active the synthetic trade population is ignored entirely. The
          synthetic market reference data (mid rates, volatility, ADTV) is still used, since the
          impact model needs it and a plain execution file does not carry it.
        </p>
        <button disabled={busy} onClick={() => post({ dataset: "synthetic" })}>
          Use synthetic data
        </button>{" "}
        <button disabled={busy} onClick={() => post({ dataset: "imported" })}>
          Use imported data
        </button>{" "}
        <button
          disabled={busy}
          onClick={() => {
            setResult(null);
            setPreview(null);
            setCsv(null);
            post({ action: "clear_imported" });
          }}
        >
          Clear imported
        </button>
      </fieldset>

      <fieldset>
        <legend>1. Upload a CSV of executions</legend>
        <p className="note small">
          Headers can be anything — you map them to the canonical schema in the next step.
        </p>
        <input
          type="file"
          accept=".csv,text/csv"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) void onFile(f);
          }}
        />{" "}
        {fileName && <span className="note">{fileName}</span>}
        {error && <p className="warn">{error}</p>}
      </fieldset>

      {preview && (
        <fieldset>
          <legend>2. Map your columns</legend>
          <p className="note small">
            {preview.rows.toLocaleString("en-US")} data rows found. Matching headers were mapped
            automatically. * = required.
          </p>
          <table>
            <tbody>
              {[...required, ...optional].map((f) => (
                <tr key={f.key}>
                  <td>
                    {f.label}
                    {f.required ? " *" : ""}
                  </td>
                  <td>
                    <select
                      value={mapping[f.key] ?? ""}
                      onChange={(e) => setMapping({ ...mapping, [f.key]: e.target.value })}
                    >
                      <option value="">(not mapped)</option>
                      {preview.headers.map((h) => (
                        <option key={h} value={h}>
                          {h}
                        </option>
                      ))}
                    </select>
                  </td>
                  <td className="note" style={{ whiteSpace: "normal", maxWidth: 380 }}>
                    {f.help}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          <p className="small">First rows of the file:</p>
          <table>
            <thead>
              <tr>
                {preview.headers.map((h) => (
                  <th key={h}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {preview.sample.map((r, i) => (
                <tr key={i}>
                  {preview.headers.map((_, j) => (
                    <td key={j} className="mono">
                      {r[j]}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>

          <button disabled={busy || unmappedRequired.length > 0} onClick={commit}>
            {busy ? "Importing..." : "Import and activate"}
          </button>{" "}
          {unmappedRequired.length > 0 && (
            <span className="warn small">
              Still to map: {unmappedRequired.map((f) => f.label).join(", ")}
            </span>
          )}
        </fieldset>
      )}

      {result && (
        <fieldset>
          <legend>3. Import complete</legend>
          <p>
            {result.imported.toLocaleString("en-US")} of {result.rowsRead.toLocaleString("en-US")}{" "}
            rows imported{result.activated ? " and made the active dataset" : ""}. The detection
            engine has already re-run against them.
          </p>
          {result.warnings.length > 0 && (
            <>
              <h3>Rows skipped ({result.warnings.length} shown)</h3>
              <ul className="small">
                {result.warnings.map((w, i) => (
                  <li key={i}>{w}</li>
                ))}
              </ul>
            </>
          )}
          {result.missingOptional.length > 0 && (
            <p className="note small">
              Optional fields not supplied: {result.missingOptional.join(", ")}.
            </p>
          )}
          {result.limitations.length > 0 && (
            <>
              <h3>What this limits</h3>
              <ul className="small">
                {result.limitations.map((l, i) => (
                  <li key={i}>{l}</li>
                ))}
              </ul>
            </>
          )}
        </fieldset>
      )}
    </>
  );
}
