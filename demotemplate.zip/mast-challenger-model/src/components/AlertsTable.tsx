import Link from "next/link";
import type { Instance } from "@/lib/detect/types";
import { METRIC_BY_ID } from "@/lib/config/metrics";
import { fmtDateTime, fmtUsd } from "@/lib/format";

export function AlertsTable({
  alerts,
  thresholds,
  showMetric = true,
  emptyHint,
}: {
  alerts: Instance[];
  thresholds: Map<string, number>;
  showMetric?: boolean;
  emptyHint?: string;
}) {
  if (!alerts.length) {
    return (
      <p className="note">
        {emptyHint ?? "Nothing above threshold with the current settings."}
      </p>
    );
  }
  return (
    <table>
      <thead>
        <tr>
          <th className="n">USD Value</th>
          <th className="n">Over threshold</th>
          {showMetric && <th>Metric</th>}
          <th>Trader</th>
          <th>Instrument</th>
          <th>Start</th>
          <th className="n">Trades</th>
          <th>What happened</th>
        </tr>
      </thead>
      <tbody>
        {alerts.map((a) => {
          const th = thresholds.get(a.metric) ?? 0;
          return (
            <tr key={a.instance_id}>
              <td className="n">{fmtUsd(a.usd_value)}</td>
              <td className="n">{fmtUsd(a.usd_value - th)}</td>
              {showMetric && (
                <td>
                  <Link href={`/alerts/${a.metric}`}>{METRIC_BY_ID[a.metric].label}</Link>
                </td>
              )}
              <td>
                <Link href={`/blotter?trader=${a.trader_id}`}>{a.trader_name}</Link>
              </td>
              <td className="mono">{a.instrument}</td>
              <td className="mono">{fmtDateTime(a.start_ms).slice(0, 19)}</td>
              <td className="n">{a.trade_ids.length}</td>
              <td>
                <Link href={`/instance/${encodeURIComponent(a.instance_id)}`}>{a.headline}</Link>
              </td>
            </tr>
          );
        })}
      </tbody>
    </table>
  );
}
