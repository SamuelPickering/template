"use client";

import {
  Area,
  CartesianGrid,
  ComposedChart,
  Line,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import type { ImpactPoint, TradeMarker } from "@/lib/detect/types";
import { fmtTime, fmtRate } from "@/lib/format";

export function ImpactChart({
  data,
  markers,
}: {
  data: ImpactPoint[];
  markers: TradeMarker[];
}) {
  if (!data?.length) return null;
  const rows = data.map((d) => ({ ...d, t: fmtTime(d.ms).slice(0, 8) }));

  return (
    <div style={{ width: "100%", maxWidth: 1000, height: 280 }}>
      <ResponsiveContainer width="100%" height="100%">
        <ComposedChart data={rows} margin={{ top: 8, right: 8, bottom: 4, left: 0 }}>
          <CartesianGrid stroke="#ddd" strokeDasharray="3 3" vertical={false} />
          <XAxis
            dataKey="t"
            tick={{ fill: "#555", fontSize: 11 }}
            stroke="#999"
            minTickGap={40}
          />
          <YAxis
            yAxisId="bps"
            tick={{ fill: "#555", fontSize: 11 }}
            stroke="#999"
            width={54}
            label={{
              value: "impact (bps)",
              angle: -90,
              position: "insideLeft",
              fill: "#555",
              fontSize: 11,
            }}
          />
          <YAxis
            yAxisId="mid"
            orientation="right"
            domain={["auto", "auto"]}
            tick={{ fill: "#555", fontSize: 11 }}
            stroke="#999"
            width={70}
            tickFormatter={(v: number) => fmtRate(v)}
          />
          <Tooltip
            contentStyle={{ background: "#fff", border: "1px solid #999", fontSize: 12 }}
            labelStyle={{ color: "#555" }}
            formatter={(value, name) => {
              const v = Number(value);
              return name === "Mid rate" ? fmtRate(v) : `${v.toFixed(3)} bps`;
            }}
          />
          <ReferenceLine yAxisId="bps" y={0} stroke="#999" />
          <Area
            yAxisId="bps"
            type="monotone"
            dataKey="total_bps"
            name="All flow"
            stroke="#888"
            fill="#e8e8e8"
            strokeWidth={1}
            dot={false}
            isAnimationActive={false}
          />
          <Area
            yAxisId="bps"
            type="monotone"
            dataKey="highlight_bps"
            name="This instance"
            stroke="#c00"
            fill="#ffdede"
            strokeWidth={2}
            dot={false}
            isAnimationActive={false}
          />
          <Line
            yAxisId="mid"
            type="monotone"
            dataKey="mid"
            name="Mid rate"
            stroke="#06c"
            strokeWidth={1.5}
            dot={false}
            isAnimationActive={false}
          />
        </ComposedChart>
      </ResponsiveContainer>
      <p className="note small">
        Red = modelled impact of this instance. Grey = impact of all flow on the instrument. Blue =
        synthetic instrument mid. {markers.length} trades in this instance.
      </p>
    </div>
  );
}
