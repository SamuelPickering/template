"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import type { MetricDef } from "@/lib/config/metrics";
import { fmtUsd } from "@/lib/format";

export function MetricConfigCard({
  def,
  values,
  alerts,
  instances,
  topUsd,
}: {
  def: MetricDef;
  values: Record<string, number>;
  alerts: number;
  instances: number;
  topUsd: number;
}) {
  const router = useRouter();
  const [draft, setDraft] = useState(values);
  const [pending, startTransition] = useTransition();
  const [saving, setSaving] = useState(false);

  const dirty = def.params.some((p) => Number(draft[p.key]) !== Number(values[p.key]));
  const isDefault = def.params.every((p) => Number(values[p.key]) === p.default);

  async function send(payload: object) {
    setSaving(true);
    await fetch("/api/config", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(payload),
    });
    setSaving(false);
    startTransition(() => router.refresh());
  }

  return (
    <fieldset>
      <legend>{def.label}</legend>
      <p className="note small">
        {def.short} &nbsp; {alerts} alerts of {instances} instances, largest {fmtUsd(topUsd)}.
        {isDefault ? " Using defaults." : " Modified from defaults."}
        {saving || pending ? " Recomputing..." : ""}
      </p>

      <table>
        <tbody>
          {def.params.map((p) => {
            const v = draft[p.key];
            return (
              <tr key={p.key}>
                <td>{p.label}</td>
                <td>
                  {p.type === "toggle" ? (
                    <input
                      type="checkbox"
                      checked={!!v}
                      onChange={(e) => setDraft({ ...draft, [p.key]: e.target.checked ? 1 : 0 })}
                    />
                  ) : (
                    <>
                      <input
                        type="number"
                        value={v}
                        min={p.min}
                        max={p.max}
                        step={p.step ?? 1}
                        size={10}
                        style={{ width: 110 }}
                        onChange={(e) => setDraft({ ...draft, [p.key]: Number(e.target.value) })}
                      />{" "}
                      <input
                        type="range"
                        min={p.min ?? 0}
                        max={Math.max(p.max ?? 100, v)}
                        step={p.step ?? 1}
                        value={v}
                        onChange={(e) => setDraft({ ...draft, [p.key]: Number(e.target.value) })}
                      />
                    </>
                  )}
                </td>
                <td>{p.unit ?? ""}</td>
                <td className="note" style={{ whiteSpace: "normal", maxWidth: 380 }}>
                  {p.help}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>

      <button
        type="button"
        disabled={!dirty || saving}
        onClick={() => send({ action: "save", metric: def.id, params: draft })}
      >
        Apply
      </button>{" "}
      <button
        type="button"
        disabled={isDefault || saving}
        onClick={() => {
          setDraft(Object.fromEntries(def.params.map((p) => [p.key, p.default])));
          send({ action: "reset", metric: def.id });
        }}
      >
        Reset to default
      </button>
    </fieldset>
  );
}
