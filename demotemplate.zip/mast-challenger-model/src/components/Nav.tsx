import Link from "next/link";

const LINKS: [string, string][] = [
  ["/", "Dashboard"],
  ["/alerts", "Alerts"],
  ["/alerts/ramping", "By Metric"],
  ["/blotter", "Blotter"],
  ["/traders", "Traders"],
  ["/admin", "Admin"],
  ["/import", "Import"],
  ["/methodology", "Methodology"],
];

export function Nav({ dataset }: { dataset: string }) {
  return (
    <div id="nav">
      <b>MAST Challenger Model</b>
      {LINKS.map(([href, label], i) => (
        <span key={href}>
          {i > 0 ? " | " : ""}
          <Link href={href}>{label}</Link>
        </span>
      ))}
      <span className="note"> &nbsp;&nbsp;(data: {dataset})</span>
    </div>
  );
}
