# MAST Challenger Model

An educational simulation of an FX trade-surveillance system. It generates a realistic population
of FX spot trades, models the theoretical market impact of each one, scores potential market abuse
in USD terms and surfaces the results as alerts for review.

> This is an independent educational simulation inspired by publicly-referenced surveillance
> concepts. It approximates market abuse detection logic for illustrative purposes and is not
> affiliated with, and does not reproduce, any specific commercial product. All traders,
> counterparties, trades, orders, market data and events in the app are synthetic.

## Running it

```bash
npm install
npm run seed
npm run dev
```

Then open http://localhost:3000. `npm run seed` rebuilds `data/dataset.json` from scratch —
traders, market reference data, the background trade population, the event calendar, the
scenario-engineered instances and the spoofing order book.

There are no native dependencies, so `npm install` never needs a compiler. Generated data and
admin settings are stored as JSON under `data/`; detection runs are cached in memory, keyed by
the config hash.

| Command | What it does |
|---|---|
| `npm run seed` | Regenerate the whole synthetic dataset |
| `npm run qa` | Run the detection engine and print coverage: per-metric counts, per-scenario recall, background false positives, threshold sweeps |
| `npm run dev` | Start the app |
| `npx tsx scripts/make-sample-csv.ts` | Write `samples/sample-import.csv` for exercising the import flow |

Environment overrides for seeding: `MAST_END_DATE` (default `2026-08-21`), `MAST_DAYS` (65),
`MAST_SEED` (20260101), `MAST_DB` (path to the SQLite file).

## How it fits together

```
trades ──► GMM split ──► equivalent trades on synthetic instruments (CCY/USD)
                              │
                              ├──► Market Impact Model  ─┐
                              ├──► Allocation Algorithm ─┼──► per-metric detector ──► USD Value
                              └──► Event Generator      ─┘                              │
                                                            live threshold ◄────────────┘
```

- **`src/lib/models/`** — the shared underlying models: `gmm.ts` (synthetic instrument splitting),
  `mim.ts` (Market Impact Model v1), `allocation.ts` (matching buys to sells inside a book),
  `market.ts` (mid rates, volatility, ADTV, event overlay), `usdvalue.ts` (EMI x PTC and the
  Narrative / Counter-Narrative scoring).
- **`src/lib/detect/`** — one module per metric, plus `engine.ts`, which runs them all against the
  live config and caches the result by a hash of that config.
- **`src/lib/gen/`** — synthetic data generation: universe, market series, background flow, the
  event calendar and the engineered scenarios.
- **`src/lib/config/`** — the metric registry (thresholds and secondary sensitivities, with
  defaults) and its file-backed store.
- **`src/lib/db/`** — the JSON file store and the read/write helpers built on it.
- **`src/app/`** — the Next.js App Router pages.

Detection is **live, not snapshotted**: the run key is `data fingerprint + config hash`, so editing
a threshold or a sensitivity on the Admin page produces a new key and the whole pipeline re-runs
against the current dataset.

## Metrics implemented

Insider Trading · Front Running · Internal Front Running · Ramping · Banging the Close ·
Wash Trading (single-counterparty, cross-currency, multi-counterparty) · Cross Trading ·
Off-Market Trading · Layering / Spoofing (including a cross-currency variant).

Out of scope: NAV Manipulation (buy-side/reporting behaviour), Restricted List (a trivial rule
match) and Quote Stuffing (exchange-tape microstructure, which does not map onto OTC FX spot
executions).

## Scenario tags

Engineered trades carry a `scenario_tag` (e.g. `ramping_major`). **No detector reads it.** It exists
only so `npm run qa` can check that each engineered instance was found independently, and to confirm
how much of the alert population comes from ordinary background flow.

## Importing real data

The Import page takes a CSV of executions, maps arbitrary source headers onto the canonical schema,
validates the rows and makes the imported set the active dataset. Missing optional fields are
reported along with what they limit. Imported trades are keyed separately from the synthetic
population, so an import can never overwrite it.
