import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // The app is also reachable on 127.0.0.1; Next blocks cross-origin requests
  // for /_next assets in dev unless the origin is listed.
  allowedDevOrigins: ["127.0.0.1", "localhost"],
};

export default nextConfig;
