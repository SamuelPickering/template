/**
 * QA harness. Runs the detection engine against the live config and reports:
 *   - per-metric instance/alert counts and USD Value totals
 *   - per-scenario-tag recall: did each engineered instance actually surface,
 *     and at what USD Value (the tag is never visible to the detectors)
 *   - how much of the alert population comes from untagged background flow
 *
 *   npm run qa
 */
import { loadTrades } from "@/lib/db/repo";
import { invalidateAnalysis, runAnalysis } from "@/lib/detect/engine";
import { getConfig } from "@/lib/config/store";

const fmt = (v: number) =>
  "$" + Math.round(v).toLocaleString("en-US");

function main() {
  invalidateAnalysis();
  const cfg = getConfig();
  const t0 = Date.now();
  const run = runAnalysis({ config: cfg });
  console.log(
    `dataset=${run.dataset} trades=${run.trades} alerts=${run.alerts.length} in ${Date.now() - t0}ms\n`,
  );

  console.log("metric                    instances  alerts  threshold        total USD");
  for (const s of run.stats) {
    console.log(
      s.metric.padEnd(24),
      String(s.instances).padStart(9),
      String(s.alerts).padStart(7),
      fmt(s.threshold).padStart(10),
      fmt(s.usd_total).padStart(16),
    );
  }

  // ---- scenario coverage ----
  const tagged = loadTrades("synthetic").filter((t) => t.scenario_tag);
  const tagOf = new Map(tagged.map((t) => [t.trade_id, t.scenario_tag!]));
  const byTag = new Map<string, { trades: number; alerts: number[]; instances: number[] }>();
  for (const t of tagged) {
    const e = byTag.get(t.scenario_tag!) ?? { trades: 0, alerts: [], instances: [] };
    e.trades++;
    byTag.set(t.scenario_tag!, e);
  }
  const seenAlert = new Set<string>();
  for (const a of run.alerts) {
    const tags = new Set(a.trade_ids.map((id) => tagOf.get(id)).filter(Boolean) as string[]);
    for (const tag of tags) {
      byTag.get(tag)!.alerts.push(a.usd_value);
      seenAlert.add(`${tag}|${a.instance_id}`);
    }
  }
  for (const i of run.instances) {
    const tags = new Set(i.trade_ids.map((id) => tagOf.get(id)).filter(Boolean) as string[]);
    for (const tag of tags) byTag.get(tag)!.instances.push(i.usd_value);
  }

  console.log("\nscenario tag                trades  instances  alerts   median alert USD   max");
  for (const [tag, v] of [...byTag].sort()) {
    const sorted = v.alerts.slice().sort((a, b) => a - b);
    const med = sorted.length ? sorted[Math.floor(sorted.length / 2)] : 0;
    const max = sorted.length ? sorted[sorted.length - 1] : 0;
    console.log(
      tag.padEnd(26),
      String(v.trades).padStart(6),
      String(v.instances.length).padStart(10),
      String(v.alerts.length).padStart(7),
      fmt(med).padStart(18),
      fmt(max).padStart(14),
    );
  }

  // ---- background noise ----
  console.log("\nalerts with no engineered trade in them (background flow):");
  const counts = new Map<string, number>();
  for (const a of run.alerts) {
    const hasTag = a.trade_ids.some((id) => tagOf.has(id));
    if (!hasTag) counts.set(a.metric, (counts.get(a.metric) ?? 0) + 1);
  }
  for (const s of run.stats) {
    const n = counts.get(s.metric) ?? 0;
    console.log(
      `  ${s.metric.padEnd(24)} ${String(n).padStart(5)} of ${String(s.alerts).padStart(5)} alerts`,
    );
  }

  // ---- live config behaviour ----
  console.log("\nthreshold sweep (alerts at each USD Value threshold):");
  for (const metric of ["ramping", "wash_trading"] as const) {
    const row: string[] = [];
    for (const th of [5_000, 15_000, 50_000, 250_000, 1_000_000]) {
      const cfg2 = structuredClone(cfg);
      cfg2[metric].threshold_usd_value = th;
      const r = runAnalysis({ config: cfg2 });
      row.push(`${fmt(th)}: ${r.stats.find((s) => s.metric === metric)!.alerts}`);
    }
    console.log(`  ${metric.padEnd(14)} ${row.join("   ")}`);
  }

  console.log("\ncross-currency wash trades with 'require instrument match' turned off:");
  const cfg3 = structuredClone(cfg);
  cfg3.wash_trading.require_instrument_match = 0;
  const r3 = runAnalysis({ config: cfg3 });
  const ccAlerts = r3.alerts.filter(
    (a) =>
      a.metric === "wash_trading" &&
      a.trade_ids.some((id) => tagOf.get(id) === "wash_cross_currency"),
  );
  console.log(
    `  wash_trading alerts: ${r3.stats.find((s) => s.metric === "wash_trading")!.alerts}` +
      ` (of which cross-currency scenarios: ${ccAlerts.length}, ` +
      `USD ${ccAlerts.map((a) => fmt(a.usd_value)).join(", ")})`,
  );
}

main();
