/**
 * Regenerates the whole synthetic dataset: desks, traders, counterparties,
 * market reference data, the background trade population, the event calendar,
 * the scenario-engineered trades and the spoofing order book.
 *
 *   npm run seed
 */
import {
  resetDb,
  insertCounterparties,
  insertCurrencies,
  insertEvents,
  insertMarketDaily,
  insertOrders,
  insertTraders,
  insertTrades,
} from "@/lib/db/repo";
import { MarketData } from "@/lib/models/market";
import { generateBackgroundTrades } from "@/lib/gen/background";
import { generateMarketDaily } from "@/lib/gen/market";
import {
  CURRENCIES,
  generateCounterparties,
  generateTraders,
} from "@/lib/gen/universe";
import { resetTradeIds } from "@/lib/gen/trade";
import { businessDays } from "@/lib/time";

const END_DATE = process.env.MAST_END_DATE ?? "2026-08-21";
const N_DAYS = Number(process.env.MAST_DAYS ?? 65);
const SEED = Number(process.env.MAST_SEED ?? 20260101);

async function main() {
  console.log(`Seeding ${N_DAYS} business days ending ${END_DATE} (seed ${SEED})`);
  resetDb();
  resetTradeIds();

  const dates = businessDays(END_DATE, N_DAYS);
  const traders = generateTraders(SEED);
  const counterparties = generateCounterparties();
  const marketRows = generateMarketDaily(dates, SEED);
  const market = new MarketData(marketRows);

  insertTraders(traders);
  insertCounterparties(counterparties);
  insertCurrencies(CURRENCIES);
  insertMarketDaily(marketRows);

  console.log(`  traders: ${traders.length}`);
  console.log(`  market rows: ${marketRows.length} (${CURRENCIES.length} instruments)`);

  // Events are generated before any trade so that every execution prices off a
  // market that already contains the shock overlay.
  const { generateEvents } = await import("@/lib/gen/events");
  const { generateScenarios } = await import("@/lib/gen/scenarios");

  const events = generateEvents({ dates, market, seed: SEED });
  market.setEvents(events);
  insertEvents(events);
  console.log(`  events: ${events.length}`);

  const background = generateBackgroundTrades({
    dates,
    traders,
    counterparties,
    market,
    seed: SEED,
  });
  insertTrades(background);
  console.log(`  background trades: ${background.length}`);

  const scen = generateScenarios({
    dates,
    traders,
    counterparties,
    market,
    events,
    seed: SEED,
    existing: background,
  });
  insertTrades(scen.trades);
  insertOrders(scen.orders);
  console.log(`  scenario trades: ${scen.trades.length}, orders: ${scen.orders.length}`);
  const byTag = new Map<string, number>();
  for (const t of scen.trades) {
    const tag = (t.scenario_tag ?? "untagged").replace(/_\d+$/, "");
    byTag.set(tag, (byTag.get(tag) ?? 0) + 1);
  }
  for (const [tag, n] of [...byTag].sort()) console.log(`    ${tag}: ${n}`);

  console.log("Done.");
}

main();
