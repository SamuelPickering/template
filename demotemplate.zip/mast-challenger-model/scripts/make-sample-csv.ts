/** Writes samples/sample-import.csv: a deliberately awkward export of some
 *  synthetic trades, for exercising the column-mapping import flow. */
import fs from "node:fs";
import { loadTrades } from "@/lib/db/repo";
const rows = loadTrades("synthetic").filter((_, i) => i % 3 === 0).slice(0, 2500);
const header = ["Deal Ref","Dealer","Capacity","Client Acct","CCY Pair","Bought CCY","Sold CCY","Bought Amt","Sold Amt","Deal Rate","Trade Time (UTC)"];
const lines = [header.join(",")];
for (const t of rows) {
  lines.push([
    t.trade_id, `"${t.trader_name}"`,
    t.trade_role === "client_facilitation" ? "Client" : "Principal",
    t.counterparty_id ?? "", t.currency_pair, t.buy_currency, t.sell_currency,
    t.buy_amount.toFixed(2), t.sell_amount.toFixed(2), t.execution_rate.toPrecision(8),
    t.execution_datetime.replace("T"," ").replace("Z",""),
  ].join(","));
}
fs.writeFileSync("samples/sample-import.csv", lines.join("\n"));
console.log("wrote samples/sample-import.csv rows=", rows.length);
