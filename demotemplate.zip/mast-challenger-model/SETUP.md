# Setup — running this on another machine

## What you need first

- **Node.js 20 or newer** (22 LTS is fine, so is 24). Check with `node -v`.
  If it isn't installed: https://nodejs.org — the LTS installer, defaults are fine.
- Nothing else. No database server, no accounts, no API keys, and nothing that has to be
  compiled — every dependency is plain JavaScript, so no C++ build tools are needed. The
  generated data sits in `data/dataset.json`, which the seed step creates.

## Steps

1. Extract the zip somewhere with a short path, e.g. `C:\dev\mast-challenger-model`.
   (Avoid OneDrive-synced folders — the file watcher and OneDrive fight each other.)

2. Open the folder in VS Code: **File → Open Folder…** → pick the extracted folder.

3. Open a terminal in VS Code: **Terminal → New Terminal** (Ctrl + `).

4. Install dependencies — a few minutes the first time:

```bash
npm install
```

5. Generate the synthetic dataset (traders, market data, trades, orders, events,
   scenarios). Takes about 20 seconds and creates `data/dataset.json`:

```bash
npm run seed
```

6. Start the app:

```bash
npm run dev
```

7. Open http://localhost:3000 in a browser. Ctrl+C in the terminal stops it.

## For the demo itself

A route through the app that shows the whole idea in a few minutes:

1. **Dashboard** — total trades vs. total alerts (alerts are well under 1% of trades),
   USD Value by metric, and which traders carry the most risk.
2. **Alerts** — everything above threshold, sorted by USD Value.
3. Open a **Ramping** alert — the plain-English explanation, the intermediate values
   (EMI, PTC), the market impact chart, and the trades involved colour-coded by the part
   they played. "Show these on the blotter" puts them back in context.
4. **Admin** — drop the Ramping threshold from $15,000 to $5,000, hit Apply, then go back
   to Alerts. The list grows immediately; nothing is precomputed. Put it back with
   "Reset to default".
5. **By Metric → Wash Trading** — expand "Below threshold" to show what is being scored
   but not alerted. Then on Admin, turn **off** "Require instrument match" for Wash
   Trading: cross-currency wash trades appear, because the two legs were booked in
   different currency pairs that map to the same synthetic instrument.
6. **Methodology** — the one-page explanation of synthetic instruments, market impact,
   USD Value, allocation and the event generator.

## If something goes wrong

- **`npm install` fails behind a corporate proxy** — the work machine may need a registry
  or proxy setting. `npm config get registry` should return a reachable URL. If IT uses an
  internal mirror, `npm config set registry <their-url>` before retrying.
- **Port 3000 already in use** — run `npm run dev -- -p 3001` and use that port instead.
- **Want to start over from clean data** — delete the `data` folder and run `npm run seed`
  again. That also clears any threshold changes, which live in `data/config.json`.
- **Check the detection engine without the UI** — `npm run qa` prints per-metric alert
  counts, whether each engineered scenario was found, how many alerts come from ordinary
  background flow, and a threshold sweep.

## Running it a bit faster

`npm run dev` is the development server and recompiles pages as they are opened, so the
first visit to each page takes a second or two. For a smoother demo:

```bash
npm run build
npm start
```

Same app at http://localhost:3000, pages render immediately. Re-run `npm run build` after
any code change.
