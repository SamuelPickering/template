import { loadDocuments, loadTraders } from "@/lib/db/repo";
import {
  abuseByTrader,
  alertsByExecution,
  buildContext,
  runAnalysis,
  type RunResult,
} from "@/lib/detect/engine";
import { getConfig, getDataset } from "@/lib/config/store";
import { METRIC_BY_ID, type MetricId } from "@/lib/config/metrics";
import type { ImpactPoint, Instance } from "@/lib/detect/types";
import { impactChart } from "@/lib/detect/util";
import type { Execution, OrderStream, ProductFamily, SourceDocument } from "@/lib/types";

export function currentRun(): RunResult {
  return runAnalysis({ config: getConfig(), dataset: getDataset() });
}

export function context() {
  return buildContext(getDataset());
}

/* ---------------- traders ---------------- */

export interface TraderRow {
  trader_id: string;
  name: string;
  trade_role: string;
  executions: number;
  notional_usd: number;
  alerts: number;
  usd_value: number;
  /** Abuse types this trader currently has alerts for. */
  abuses: { metric: MetricId; label: string; count: number }[];
}

export function traderRows(run: RunResult): TraderRow[] {
  const ctx = context();
  const activity = new Map<string, { n: number; notional: number }>();
  for (const e of ctx.executions) {
    const v = activity.get(e.trader_id) ?? { n: 0, notional: 0 };
    v.n += 1;
    v.notional += e.notional_usd;
    activity.set(e.trader_id, v);
  }
  const counts = new Map<string, Map<MetricId, number>>();
  const totals = new Map<string, { n: number; usd: number }>();
  for (const a of run.alerts) {
    const t = totals.get(a.trader_id) ?? { n: 0, usd: 0 };
    t.n += 1;
    t.usd += a.usd_value;
    totals.set(a.trader_id, t);
    const byMetric = counts.get(a.trader_id) ?? new Map<MetricId, number>();
    byMetric.set(a.metric, (byMetric.get(a.metric) ?? 0) + 1);
    counts.set(a.trader_id, byMetric);
  }

  return loadTraders()
    .map((t) => ({
      trader_id: t.trader_id,
      name: t.name,
      trade_role: t.trade_role,
      executions: activity.get(t.trader_id)?.n ?? 0,
      notional_usd: activity.get(t.trader_id)?.notional ?? 0,
      alerts: totals.get(t.trader_id)?.n ?? 0,
      usd_value: totals.get(t.trader_id)?.usd ?? 0,
      abuses: [...(counts.get(t.trader_id) ?? new Map<MetricId, number>())]
        .map(([metric, count]) => ({ metric, label: METRIC_BY_ID[metric].label, count }))
        .sort((a, b) => b.count - a.count),
    }))
    .sort((a, b) => b.usd_value - a.usd_value || b.executions - a.executions);
}

/* ---------------- blotter ---------------- */

export interface ExecutionFilters {
  trader?: string;
  instrument?: string;
  family?: string;
  product?: string;
  date?: string;
  role?: string;
  search?: string;
  onlyAlerts?: boolean;
  limit?: number;
  offset?: number;
}

export interface BlotterRow {
  execution: Execution;
  /** Alerts this execution appears in — drives the red highlighting. */
  alerts: { metric: MetricId; label: string; instance_id: string; usd_value: number }[];
}

export function queryExecutions(
  run: RunResult,
  f: ExecutionFilters,
): { rows: BlotterRow[]; total: number; alertCount: number } {
  const ctx = context();
  const byExec = alertsByExecution(run);
  const needle = f.search?.toLowerCase();

  const matched = ctx.executions.filter((e) => {
    if (f.trader && e.trader_id !== f.trader) return false;
    if (f.instrument && e.instrument !== f.instrument) return false;
    if (f.family && e.family !== f.family) return false;
    if (f.product && e.product_type !== f.product) return false;
    if (f.date && e.trade_date !== f.date) return false;
    if (f.role && e.trade_role !== f.role) return false;
    if (f.onlyAlerts && !byExec.has(e.exec_id)) return false;
    if (needle) {
      const hay = `${e.trade_id} ${e.trader_name} ${e.counterparty_name ?? ""} ${
        e.instrument
      } ${e.book_name}`.toLowerCase();
      if (!hay.includes(needle)) return false;
    }
    return true;
  });

  const ordered = matched.slice().sort((a, b) => b.event_ms - a.event_ms);
  const offset = f.offset ?? 0;
  const page = ordered.slice(offset, offset + (f.limit ?? 150));

  return {
    rows: page.map((execution) => ({
      execution,
      alerts: (byExec.get(execution.exec_id) ?? []).map((a) => ({
        metric: a.metric,
        label: METRIC_BY_ID[a.metric].label,
        instance_id: a.instance_id,
        usd_value: a.usd_value,
      })),
    })),
    total: ordered.length,
    alertCount: ordered.filter((e) => byExec.has(e.exec_id)).length,
  };
}

/** Abuse types per trader, for marking a trader red in any trader listing. */
export function traderAbuse(run: RunResult) {
  const map = abuseByTrader(run);
  return (traderId: string) =>
    [...(map.get(traderId) ?? [])].map((m) => METRIC_BY_ID[m].label);
}

export function distinctValues(run: RunResult) {
  const ctx = context();
  const instruments = new Map<string, string>();
  const products = new Set<string>();
  const families = new Set<ProductFamily>();
  const dates = new Set<string>();
  for (const e of ctx.executions) {
    instruments.set(e.instrument, e.instrument_label);
    products.add(e.product_type);
    families.add(e.family);
    dates.add(e.trade_date);
  }
  void run;
  return {
    instruments: [...instruments].sort((a, b) => a[0].localeCompare(b[0])),
    products: [...products].sort(),
    families: [...families].sort(),
    dates: [...dates].sort().reverse(),
  };
}

/* ---------------- instances ---------------- */

export function findInstance(run: RunResult, id: string): Instance | undefined {
  return run.instances.find((i) => i.instance_id === id);
}

export function instanceChart(instance: Instance): ImpactPoint[] {
  const ctx = context();
  return impactChart(
    ctx,
    instance.instrument,
    instance.start_ms,
    instance.end_ms,
    [...instance.exec_ids, ...instance.trade_ids],
  );
}

export function executionsByIds(ids: string[]): Execution[] {
  const ctx = context();
  const wanted = new Set(ids);
  return ctx.executions
    .filter((e) => wanted.has(e.exec_id))
    .sort((a, b) => a.event_ms - b.event_ms);
}

export function ordersByIds(ids: string[]): OrderStream[] {
  if (!ids.length) return [];
  const ctx = context();
  const wanted = new Set(ids);
  return ctx.orders.filter((o) => wanted.has(o.order_id)).sort((a, b) => a.start_ms - b.start_ms);
}

export function documentById(docId: string): SourceDocument | undefined {
  return context().docById.get(docId);
}

/* ---------------- datasets ---------------- */

export interface DatasetSummaryRow {
  source: string;
  documents: number;
  byFamily: Record<string, number>;
}

export function datasetSummary(): DatasetSummaryRow[] {
  const out: DatasetSummaryRow[] = [];
  for (const source of ["synthetic", "imported"]) {
    const docs = loadDocuments(source);
    if (!docs.length) continue;
    const byFamily: Record<string, number> = {};
    for (const d of docs) byFamily[d.family] = (byFamily[d.family] ?? 0) + 1;
    out.push({ source, documents: docs.length, byFamily });
  }
  return out;
}
