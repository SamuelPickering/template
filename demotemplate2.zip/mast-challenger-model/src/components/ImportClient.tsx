"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { OVERRIDE_FIELDS, type ImportAnalysis } from "@/lib/import/json";
import type { ImportOverrides } from "@/lib/types";

const FAMILIES: { value: string; label: string }[] = [
  { value: "auto", label: "detect from each document" },
  { value: "credit", label: "Credit (Credit.CDS)" },
  { value: "rates", label: "Rates (IR.Swaption / IR.CapFloor / IR.FRA)" },
  { value: "fenics", label: "Fenics order streams (FixedIncome.Bond)" },
  { value: "fx", label: "FX (FX.Spot)" },
];

interface PreviewResponse {
  format: string;
  fileErrors: string[];
  analysis: ImportAnalysis;
}

export function ImportClient({ dataset }: { dataset: "synthetic" | "imported" }) {
  const router = useRouter();
  const [text, setText] = useState<string | null>(null);
  const [fileName, setFileName] = useState("");
  const [family, setFamily] = useState("auto");
  const [overrides, setOverrides] = useState<Record<string, string>>({});
  const [preview, setPreview] = useState<PreviewResponse | null>(null);
  const [committed, setCommitted] = useState<{ imported: number } | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function buildOverrides(): ImportOverrides {
    const o: ImportOverrides = {};
    for (const f of OVERRIDE_FIELDS) {
      const raw = overrides[f.key]?.trim();
      if (!raw) continue;
      if (f.kind === "patterns") {
        (o as Record<string, unknown>)[f.key] = raw
          .split(",")
          .map((s) => s.trim())
          .filter(Boolean);
      } else {
        (o as Record<string, unknown>)[f.key] = raw;
      }
    }
    return o;
  }

  async function send(action: "preview" | "commit", content: string) {
    setBusy(true);
    setError(null);
    const res = await fetch("/api/import", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ action, text: content, family, overrides: buildOverrides() }),
    });
    const json = await res.json();
    setBusy(false);
    if (!res.ok) {
      setError(json.error ?? "Import failed.");
      return null;
    }
    return json;
  }

  async function onFile(file: File) {
    const content = await file.text();
    setText(content);
    setFileName(file.name);
    setCommitted(null);
    const json = await send("preview", content);
    if (json) setPreview(json);
  }

  async function reanalyse() {
    if (!text) return;
    const json = await send("preview", text);
    if (json) setPreview(json);
  }

  async function commit() {
    if (!text) return;
    const json = await send("commit", text);
    if (json) {
      setCommitted({ imported: json.imported });
      setPreview({ ...(preview as PreviewResponse), analysis: json.analysis });
      router.refresh();
    }
  }

  async function post(body: object) {
    setBusy(true);
    await fetch("/api/dataset", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
    });
    setBusy(false);
    router.refresh();
  }

  const a = preview?.analysis;

  return (
    <>
      <fieldset>
        <legend>Active dataset: {dataset}</legend>
        <p className="note small">
          When imported data is active the synthetic population is ignored entirely. The synthetic
          market reference data (levels, volatility, ADTV) and the event calendar are still used,
          because the impact model needs them and a trade extract does not carry them.
        </p>
        <button disabled={busy} onClick={() => post({ dataset: "synthetic" })}>
          Use synthetic data
        </button>{" "}
        <button disabled={busy} onClick={() => post({ dataset: "imported" })}>
          Use imported data
        </button>{" "}
        <button
          disabled={busy}
          onClick={() => {
            setPreview(null);
            setText(null);
            setCommitted(null);
            post({ action: "clear_imported" });
          }}
        >
          Clear imported
        </button>
      </fieldset>

      <fieldset>
        <legend>1. What are you importing?</legend>
        <label className="f">
          Product type{" "}
          <select value={family} onChange={(e) => setFamily(e.target.value)}>
            {FAMILIES.map((f) => (
              <option key={f.value} value={f.value}>
                {f.label}
              </option>
            ))}
          </select>
        </label>
        <p className="note small">
          Detection reads Execution.Economics.Type, Execution.Type and Unit.BusinessUnit. Choose the
          product explicitly if the extract has been stripped of those.
        </p>
      </fieldset>

      <fieldset>
        <legend>2. Upload the extract</legend>
        <p className="note small">
          A JSON array of Master.Transaction documents, a single document, a wrapper object with the
          array inside it, or newline-delimited JSON. Nothing leaves this machine.
        </p>
        <input
          type="file"
          accept=".json,.ndjson,.txt,application/json"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) void onFile(f);
          }}
        />{" "}
        {fileName && <span className="note">{fileName}</span>}
        {busy && <span className="note"> working...</span>}
        {error && <p className="warn">{error}</p>}
      </fieldset>

      {a && (
        <>
          <fieldset>
            <legend>3. Fields the schema may not carry</legend>
            <p className="note small">
              The sanitized schemas have no side field, and both client and dealer counterparties
              arrive as Counterparty.Professional. Point these at your own fields and re-check —
              several metrics depend on them.
            </p>
            <table>
              <tbody>
                {OVERRIDE_FIELDS.map((f) => (
                  <tr key={f.key}>
                    <td>{f.label}</td>
                    <td>
                      <input
                        value={overrides[f.key] ?? ""}
                        placeholder={f.kind === "patterns" ? "CP-CL, PENSION, FUND" : "Execution.Side"}
                        size={26}
                        onChange={(e) =>
                          setOverrides({ ...overrides, [f.key]: e.target.value })
                        }
                      />
                    </td>
                    <td className="note" style={{ whiteSpace: "normal", maxWidth: 420 }}>
                      {f.help}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <button disabled={busy} onClick={reanalyse}>
              Re-check with these settings
            </button>
          </fieldset>

          <fieldset>
            <legend>4. What the adapters made of it</legend>
            <p className="stats">
              <span>
                <b>Documents:</b> {a.documentCount.toLocaleString("en-US")}
              </span>
              <span>
                <b>Executions:</b> {a.executions.toLocaleString("en-US")}
              </span>
              <span>
                <b>Order streams:</b> {a.orders.toLocaleString("en-US")}
              </span>
              <span>
                <b>Rejected:</b> {a.rejected.length}
              </span>
              {a.dateRange && (
                <span>
                  <b>Range:</b> {a.dateRange[0]} to {a.dateRange[1]}
                </span>
              )}
            </p>
            <p className="stats">
              <span>
                <b>By family:</b>{" "}
                {Object.entries(a.byFamily)
                  .map(([k, v]) => `${k} ${v.toLocaleString("en-US")}`)
                  .join(", ") || "none"}
              </span>
            </p>
            <p className="stats">
              <span>
                <b>Direction known:</b>{" "}
                <span className={a.directionKnownShare > 0.9 ? "ok" : "limited"}>
                  {(a.directionKnownShare * 100).toFixed(0)}%
                </span>
              </span>
              <span>
                <b>Counterparty classified:</b>{" "}
                <span className={a.counterpartyKnownShare > 0.9 ? "ok" : "limited"}>
                  {(a.counterpartyKnownShare * 100).toFixed(0)}%
                </span>
              </span>
              <span>
                <b>Client-facing:</b> {a.clientExecutions.toLocaleString("en-US")}
              </span>
              <span>
                <b>Own risk:</b> {a.propExecutions.toLocaleString("en-US")}
              </span>
              <span>
                <b>With a comparable price:</b> {a.pricedExecutions.toLocaleString("en-US")}
              </span>
            </p>

            {a.rejected.length > 0 && (
              <>
                <h3>Rejected documents</h3>
                <ul className="small">
                  {a.rejected.slice(0, 8).map((r) => (
                    <li key={r.doc}>
                      Document {r.doc}: {r.reason}
                    </li>
                  ))}
                </ul>
              </>
            )}

            {a.problems.length > 0 && (
              <>
                <h3>Notes on individual documents ({a.problems.length} shown)</h3>
                <ul className="small">
                  {a.problems.slice(0, 8).map((p, i) => (
                    <li key={i}>{p}</li>
                  ))}
                </ul>
              </>
            )}

            <h3>What each metric can do with this data</h3>
            <table>
              <thead>
                <tr>
                  <th>Metric</th>
                  <th>Status</th>
                  <th>Why</th>
                </tr>
              </thead>
              <tbody>
                {a.coverage.map((c) => (
                  <tr key={c.metric}>
                    <td>{c.label}</td>
                    <td className={c.status === "ok" ? "ok" : c.status === "limited" ? "limited" : "warn"}>
                      {c.status}
                    </td>
                    <td className="note" style={{ whiteSpace: "normal", maxWidth: 560 }}>
                      {c.note}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            {a.sampleExecutions.length > 0 && (
              <>
                <h3>Sample of the normalised executions</h3>
                <table>
                  <thead>
                    <tr>
                      <th>Trade</th>
                      <th>Trader</th>
                      <th>Instrument</th>
                      <th>Product</th>
                      <th>Side</th>
                      <th className="n">Notional</th>
                      <th className="n">USD</th>
                      <th>Counterparty</th>
                      <th>Role</th>
                    </tr>
                  </thead>
                  <tbody>
                    {a.sampleExecutions.map((e) => (
                      <tr key={e.exec_id}>
                        <td className="mono">{e.trade_id}</td>
                        <td>{e.trader_name}</td>
                        <td className="mono">{e.instrument_label}</td>
                        <td>{e.product_type}</td>
                        <td>
                          {e.direction > 0 ? "+" : "-"}
                          {e.direction_known ? "" : "?"}
                        </td>
                        <td className="n">
                          {Math.round(e.notional).toLocaleString("en-US")} {e.currency}
                        </td>
                        <td className="n">${Math.round(e.notional_usd).toLocaleString("en-US")}</td>
                        <td>{e.counterparty_name ?? "-"}</td>
                        <td>{e.trade_role === "prop" ? "own risk" : "client"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </>
            )}

            <button disabled={busy || !a.documentCount} onClick={commit}>
              {busy ? "Importing..." : "Import and make active"}
            </button>
            {committed && (
              <p className="ok">
                {committed.imported.toLocaleString("en-US")} documents imported and made the active
                dataset. The detection engine has re-run against them.
              </p>
            )}
          </fieldset>
        </>
      )}
    </>
  );
}
