import Link from "next/link";
import { runValidation, formatComponentValue } from "@/lib/testing/run";
import { METRIC_BY_ID } from "@/lib/config/metrics";
import { fmtUsd } from "@/lib/format";

export const dynamic = "force-dynamic";

export default function ValidationPage() {
  const report = runValidation();
  const allPassed = report.summary.failed === 0;

  return (
    <>
      <h1>Test Cases</h1>
      <p className="note">
        One case per behaviour the tool claims to detect. Each plants a known scenario in the data
        and checks that the expected metric found it, with the alert it produced shown underneath.
      </p>

      <div className="box">
        <b style={{ color: allPassed ? "#060" : "#a00" }}>
          {report.summary.passed} of {report.summary.total} test cases passed
        </b>
        <div className="note" style={{ marginTop: 3 }}>
          Dataset: {report.dataset} · {report.documents.toLocaleString("en-US")} source documents ·{" "}
          {report.executions.toLocaleString("en-US")} executions ·{" "}
          {report.orders.toLocaleString("en-US")} order streams ·{" "}
          {report.total_alerts.toLocaleString("en-US")} alerts at the current thresholds · run{" "}
          {report.generated_at.slice(0, 19).replace("T", " ")}Z
        </div>
        <div style={{ marginTop: 6 }}>
          <a href="/api/validation?format=md" download>
            Download report (Markdown)
          </a>
          {" | "}
          <a href="/api/validation?format=json" download>
            Download report (JSON)
          </a>
          <span className="note">
            {" "}
            — or <span className="mono">npm run report</span> to write it to{" "}
            <span className="mono">reports/</span>
          </span>
        </div>
      </div>

      <p className="note small">
        Cases are matched to results through a scenario tag carried on the planted documents.{" "}
        <b>No detection engine reads that tag</b> — it exists only so this page can be written — so
        a pass means the behaviour was found from trade and order data alone. Thresholds are
        whatever is currently set on the <Link href="/admin">admin page</Link>, so this report
        reflects the live configuration rather than a fixed one.
      </p>

      <h2>Coverage by metric</h2>
      <table>
        <thead>
          <tr>
            <th>Metric</th>
            <th className="n">Cases</th>
            <th className="n">Passed</th>
            <th className="n">Threshold</th>
            <th className="n">Instances scored</th>
            <th className="n">Alerts</th>
          </tr>
        </thead>
        <tbody>
          {report.metrics.map((m) => (
            <tr key={m.metric}>
              <td>
                <Link href={`/alerts/${m.metric}`}>{m.label}</Link>
              </td>
              <td className="n">{m.cases}</td>
              <td className="n" style={{ color: m.casesPassed === m.cases ? "#060" : "#a00" }}>
                {m.casesPassed}
              </td>
              <td className="n">{fmtUsd(m.threshold)}</td>
              <td className="n">{m.instances}</td>
              <td className="n">{m.alerts}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <h2>Severity tiers</h2>
      <p className="note">
        Where a behaviour is planted at three sizes, the scores have to come out in order. This is
        what makes the threshold meaningful rather than decorative.
      </p>
      <table>
        <thead>
          <tr>
            <th>Metric</th>
            <th className="n">Barely</th>
            <th className="n">Significant</th>
            <th className="n">Major</th>
            <th>In order</th>
          </tr>
        </thead>
        <tbody>
          {report.tierChecks.map((t) => {
            const get = (tier: string) => t.tiers.find((x) => x.tier === tier)?.median ?? 0;
            return (
              <tr key={t.metric}>
                <td>{t.label}</td>
                <td className="n">{fmtUsd(get("barely"))}</td>
                <td className="n">{fmtUsd(get("significant"))}</td>
                <td className="n">{fmtUsd(get("major"))}</td>
                <td style={{ color: t.ordered ? "#060" : "#a00" }}>{t.ordered ? "yes" : "NO"}</td>
              </tr>
            );
          })}
        </tbody>
      </table>

      <h2>Threshold sensitivity</h2>
      <p className="note">
        Alert counts as each threshold is moved, with the data held constant — proof that the
        setting changes the answer.
      </p>
      <table>
        <thead>
          <tr>
            <th>Metric</th>
            {report.thresholdSweeps[0]?.points.map((p) => (
              <th className="n" key={p.threshold}>
                {fmtUsd(p.threshold)}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {report.thresholdSweeps.map((s) => (
            <tr key={s.metric}>
              <td>{s.label}</td>
              {s.points.map((p) => (
                <td className="n" key={p.threshold}>
                  {p.alerts}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>

      <h2>Alerts from ordinary business</h2>
      <p className="note">
        Alerts containing none of the planted documents. These come from the background population —
        activity that structurally resembles abuse, such as a large order worked in clips and closed
        out later in the session. They are not failures; they are the reason scoring in dollars
        matters rather than pattern-matching.
      </p>
      <table>
        <thead>
          <tr>
            <th>Metric</th>
            <th className="n">From ordinary flow</th>
            <th className="n">Total alerts</th>
          </tr>
        </thead>
        <tbody>
          {report.backgroundAlerts.map((b) => (
            <tr key={b.metric}>
              <td>{b.label}</td>
              <td className="n">{b.background}</td>
              <td className="n">{b.total}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <h2>The cases</h2>
      <table>
        <thead>
          <tr>
            <th>Case</th>
            <th>Behaviour</th>
            <th>Metric</th>
            <th>Products</th>
            <th className="n">Planted</th>
            <th className="n">Alerts</th>
            <th className="n">Median USD</th>
            <th>Result</th>
          </tr>
        </thead>
        <tbody>
          {report.results.map((r) => (
            <tr key={r.testCase.id} className={r.status === "pass" ? "" : "alerted"}>
              <td className="mono">{r.testCase.id}</td>
              <td>{r.testCase.title}</td>
              <td>{METRIC_BY_ID[r.testCase.metric].label}</td>
              <td className="note">{r.testCase.families.join(", ")}</td>
              <td className="n">{r.documents}</td>
              <td className="n">{r.alerts}</td>
              <td className="n">{r.alerts ? fmtUsd(r.medianUsd) : "-"}</td>
              <td style={{ color: r.status === "pass" ? "#060" : "#a00", fontWeight: "bold" }}>
                {r.status === "pass" ? "PASS" : "FAIL"}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <h2>Case detail</h2>
      {report.results.map((r) => (
        <details key={r.testCase.id}>
          <summary>
            <span className="mono">{r.testCase.id}</span> — {r.testCase.title} —{" "}
            <b style={{ color: r.status === "pass" ? "#060" : "#a00" }}>
              {r.status === "pass" ? "PASS" : "FAIL"}
            </b>
            {r.alerts > 0 && (
              <span className="note">
                {" "}
                ({r.alerts} alert{r.alerts === 1 ? "" : "s"}, median {fmtUsd(r.medianUsd)})
              </span>
            )}
          </summary>

          <h3>What is being tested</h3>
          <p>{r.testCase.tests}</p>
          <h3>Scenario</h3>
          <p>{r.testCase.scenario}</p>
          <h3>Expected</h3>
          <p>{r.testCase.expected}</p>
          <h3>Evidence the alert must show</h3>
          <p>{r.testCase.evidence}</p>

          <h3>Result</h3>
          <p className="stats">
            <span>
              <b>Documents planted:</b> {r.documents}
            </span>
            <span>
              <b>Alerts raised:</b> {r.alerts}
            </span>
            {r.alerts > 0 && (
              <>
                <span>
                  <b>USD Value range:</b> {fmtUsd(r.minUsd)} to {fmtUsd(r.maxUsd)}
                </span>
                <span>
                  <b>Threshold:</b> {fmtUsd(r.threshold)}
                </span>
              </>
            )}
            {r.alsoFlaggedBy.length > 0 && (
              <span>
                <b>Also flagged by:</b> {r.alsoFlaggedBy.join(", ")}
              </span>
            )}
          </p>

          {r.example ? (
            <>
              <h3>What actually triggered</h3>
              <p>
                <b>{r.example.headline}</b>
              </p>
              <p>{r.example.explanation}</p>
              <p className="note">
                {r.example.trader_name} · {r.example.instrument_label} · {r.example.trade_date} ·{" "}
                <Link href={`/instance/${encodeURIComponent(r.example.instance_id)}`}>
                  open this alert
                </Link>
              </p>
              <table>
                <thead>
                  <tr>
                    <th>Computed value</th>
                    <th className="n">Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {r.example.components.map((c) => (
                    <tr key={c.label}>
                      <td>{c.label}</td>
                      <td className="n">{formatComponentValue(c.value, c.unit)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </>
          ) : (
            <p className="warn">{r.reason}</p>
          )}
        </details>
      ))}
    </>
  );
}
