/**
 * Writes the UAT results.
 *
 *   npm run uat:report                  -> reports/UAT-results-<date>.md
 *                                          reports/UAT-trades-<date>.csv
 *                                          reports/UAT-case-results-<date>.csv
 *   npm run uat:report -- --json        -> the full report as JSON instead
 *   npm run uat:report -- --out <path>  -> the markdown written where you ask,
 *                                          with the two CSVs beside it
 *
 * Reads whatever is in the imported synthetic bucket, so import the pack
 * first — on the Import page, or with `npm run uat:load`.
 */
import fs from "node:fs";
import path from "node:path";
import { METRIC_BY_ID } from "@/lib/config/metrics";
import { renderUatMarkdown, runUat, type UatReport } from "@/lib/testing/uatRun";

const asJson = process.argv.includes("--json");
const report = runUat();

if (!report.available) {
  console.error(
    "The UAT pack is not loaded. Import uat/mast-uat-synthetic-trades.json on the Import page\n" +
      "as synthetic test data, or run `npm run uat:load` to load it from the command line.",
  );
  process.exit(1);
}

const stamp = report.generated_at.slice(0, 10);
const outArg = process.argv.indexOf("--out");
const file =
  outArg >= 0 && process.argv[outArg + 1]
    ? process.argv[outArg + 1]
    : path.join("reports", `UAT-results-${stamp}.${asJson ? "json" : "md"}`);
const dir = path.dirname(file);
fs.mkdirSync(dir, { recursive: true });
fs.writeFileSync(file, asJson ? JSON.stringify(report, null, 2) : renderUatMarkdown(report));

/* ------------------------------------------------------------------ */
/* Flat files                                                          */
/* ------------------------------------------------------------------ */

/** One field, escaped the way every spreadsheet expects. */
const cell = (v: string | number | null | undefined): string => {
  if (v === null || v === undefined) return "";
  const s = String(v);
  return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};

const csv = (rows: (string | number | null)[][]): string =>
  rows.map((r) => r.map(cell).join(",")).join("\r\n") + "\r\n";

/** Every trade in the pack, against the case it belongs to. */
function tradesCsv(r: UatReport): string {
  const rows: (string | number | null)[][] = [
    [
      "Test Case",
      "Record",
      "Reference",
      "Date/Time (UTC)",
      "Trader ID",
      "Trader",
      "Instrument",
      "Product",
      "Side",
      "Amount (USD)",
      "Price",
      "Counterparty",
      "Capacity",
      "Outcome",
      "Price Levels",
      "Displayed %",
      "Order Life (s)",
    ],
  ];
  for (const c of r.results) {
    for (const t of c.trades) {
      rows.push([
        c.testCase.id,
        t.kind === "order" ? "Order" : "Fill",
        t.id,
        t.time,
        t.trader_id,
        t.trader_name,
        t.instrument,
        t.product,
        t.side,
        Math.round(t.notional_usd),
        t.price ?? "",
        t.counterparty ?? "",
        t.kind === "order" ? "" : t.role === "own risk" ? "Own risk" : "Client",
        t.outcome ?? "",
        t.levels ?? "",
        t.display_share === null ? "" : Math.round(t.display_share * 100),
        t.life_seconds === null ? "" : Math.round(t.life_seconds),
      ]);
    }
  }
  return csv(rows);
}

/** One row per case: what was tested, what was expected, what happened. */
function resultsCsv(r: UatReport): string {
  const rows: (string | number | null)[][] = [
    [
      "Test Case",
      "Scenario under test",
      "Monitored for",
      "Expected",
      "Result",
      "Documents",
      "Alerts Raised",
      "USD Value",
    ],
  ];
  for (const c of r.results) {
    const top = c.alerts.find((a) => a.metric === c.testCase.metric) ?? c.alerts[0];
    rows.push([
      c.testCase.id,
      c.testCase.condition || c.testCase.title,
      METRIC_BY_ID[c.testCase.metric].label,
      c.testCase.expect === "alert" ? "Alert" : "No alert",
      c.status === "pass" ? "PASS" : "FAIL",
      c.documents,
      c.alerts.length,
      top ? Math.round(top.usd_value) : "",
    ]);
  }
  return csv(rows);
}

const base = asJson ? null : path.basename(file).replace(/\.md$/, "");
const tradesFile = path.join(
  dir,
  base && base !== "UAT-results" ? `${base.replace("results", "trades")}.csv` : "UAT-trades.csv",
);
const resultsFile = path.join(
  dir,
  base && base !== "UAT-results"
    ? `${base.replace("results", "case-results")}.csv`
    : "UAT-case-results.csv",
);
fs.writeFileSync(tradesFile, tradesCsv(report));
fs.writeFileSync(resultsFile, resultsCsv(report));

const s = report.summary;
console.log(
  `${s.passed} of ${s.total} UAT cases passed — ` +
    `${s.positivePassed}/${s.positive} that must alert, ${s.negativePassed}/${s.negative} that must not.`,
);
for (const r of report.results.filter((x) => x.status === "fail")) {
  console.log(`  FAIL ${r.testCase.id} ${r.testCase.title} — ${r.verdict}`);
}
console.log(`written to ${file}`);
console.log(`         ${tradesFile}`);
console.log(`         ${resultsFile}`);
