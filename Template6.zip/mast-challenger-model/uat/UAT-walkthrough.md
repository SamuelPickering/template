# Walking the UAT results through with your manager

A script for a 20-minute session. The audience knows what market abuse is and wants to know whether
this thing works; they do not want the model explained from first principles.

The argument you are making has three steps, and everything below serves them:

1. The tool finds the abuse we said it would find.
2. It stays quiet on the business that merely looks like abuse — and that half is bigger.
3. You can check both for yourself, and add your own test if you do not believe us.

Stage directions are in brackets. Everything in quotes is something you can say as written; the
numbers in it are from the committed results file, so they will match the screen as long as the
thresholds are at their defaults.

---

## Before they arrive

- `npm run build` then `npm start` — the production build, so pages open instantly.
- Import the pack: **Import** → *Synthetic test data* → `uat/mast-uat-synthetic-trades.json`.
  (Or `npm run uat:load` from the terminal.) The header should read **Imported synthetic only
  (104)**.
- Open **UAT Pack** and check the banner says **30 of 30**.
- Have `uat/UAT-results.md` open in a second window or printed. It is the thing they will want to
  take away.
- If anyone has been moving thresholds, reset them on the **Admin** page first.

---

## 1. What you are about to show them (1 minute)

[Start on the UAT Pack page, nothing clicked.]

> "This is the acceptance test for the challenger model. Thirty test cases. Thirteen of them plant
> a market abuse in the data and the tool has to find it. The other seventeen plant something that
> looks like abuse and is not, and the tool has to stay quiet. Thirty of thirty pass.
>
> I want to spend most of the time on the second half, because that is the half that decides
> whether anyone can live with the alerts this thing produces."

[Point at the banner: *30 of 30 test cases passed — 13 of 13 cases that must raise an alert, 17 of
17 cases that must not.*]

---

## 2. A case that must alert (4 minutes)

[Scroll to **Best execution** and open **UAT-BESTEX-01**.]

Best execution is the right one to open first with a business audience: no market microstructure to
explain, and the harm is to a client rather than to the firm.

> "At half past nine the firm buys eight million of a bond from a dealer at 99.80. Ninety seconds
> later it buys twenty-five million of the same bond from a client at 99.50. The client sold thirty
> basis points behind the price the firm itself had just achieved, on the same bond, in the same
> feed, a minute and a half earlier.
>
> The tool values that at seventy-five thousand dollars of detriment to the client."

[Point at the three blocks on screen, in order.]

- **The trades analysed** — four rows, two orders and two fills. The last column marks which ones
  the alert was actually built from.
- **The alert** — the headline, then the sentence explaining it, then the arithmetic: client price,
  reference price, which print the reference came from, how long before, and the gap in basis
  points and in dollars.
- **Why these trades** — the design note. Say this one out loud, because it answers the obvious
  objection before it is raised:

> "The dealer trade is deliberately the smaller of the two, so nobody can argue the client got a
> worse price for being bigger."

If they want a second one, open **UAT-FRONT-01** ($32,149): a trader buys twenty million for the
firm's own book, fills sixty million of client business in the same bond, then sells two minutes
later into the lift that business created.

---

## 3. The seventeen cases that must stay quiet (7 minutes)

This is the part of the session that matters. Take three.

[Open **UAT-NEG-WASH-03** — *Market making: bought from one client, sold to another*.]

> "Same bond, same size, eight minutes apart, position flat at the end. On a summary screen that is
> a wash trade. It is a market maker quoting both sides, and the firm earned the spread for taking
> the risk twice.
>
> Nothing fires. Not 'it scored low' — nothing was scored at all, because the legitimate reading of
> those two trades is worth more than the abusive one."

[Open **UAT-NEG-FRONT-01** — *Own-account trade six hours after the client business*.]

> "This is the same sequence as the front running case you just saw: own position first, client
> business second, trader closes third. The only difference is the gap. Here the trader closes
> nearly six hours after the client business instead of two minutes after it.
>
> Nothing fires. If this flagged, we would be flagging every position a trader ever closed on a day
> they also served a client."

[Open **UAT-NEG-SPOOF-02** — *The large order actually traded*.]

> "A fifty-million order, fully visible, and the trader does sell twenty million the other way while
> it is working — which is the pattern. But the order filled. In full. A spoof is an order you never
> intend to trade, and this one traded, so the trader carried exactly the risk they were showing."

Then scroll up to **What it would take to make the silent cases fire**, and let the table do the
work:

> "This is the bit I would push back on if I were you: how do I know it is quiet for the right
> reason, and not quiet by accident?
>
> So every one of those cases names the single check that is supposed to stop it, and the tool
> re-runs the whole pack with that check opened up. Relax the cancel-ratio rule and the ladder case
> alerts at thirty-one thousand. Drop the materiality floor from twenty-five basis points to ten
> and the best-execution case alerts at thirty-seven thousand. Stretch the front-running window from
> fifteen minutes to seven hours and that six-hour trade gets priced at nine dollars — because the
> price impact it could have exploited has decayed away almost completely by then.
>
> Each one is quiet for the reason stated on the case, and the model agrees with the reason."

---

## 4. The threshold is doing real work (3 minutes)

> "Each behaviour is planted at two or three sizes, and one of them is deliberately just over the
> line — layering at thirteen thousand three hundred against a twelve thousand threshold, best
> execution at fifteen thousand six hundred against fifteen thousand. Those are the cases that stop
> alerting first if we raise a threshold, which is exactly what you want to be able to predict."

[Go to **Admin**, drop the Layering threshold, come back to **UAT Pack**.]

> "Nothing is precomputed. Change a threshold and the whole catalogue is re-scored against it."

[Put it back.]

If they ask who decides the thresholds: they do. That is the point of the admin page, and it is why
every number in the report is a dollar amount rather than a score out of ten.

---

## 5. What they take away (2 minutes)

[Click **Download results (Markdown)**, or hand over the printed copy.]

> "Everything on screen is in this file: every case, what it tests, the trades it was judged on,
> the alert text with its arithmetic, and the relaxation table. It regenerates in about a second,
> so it is never out of date with the settings."

These files live in `uat/` and they are the evidence pack:

| File | What it answers |
|---|---|
| `UAT-case-results.csv` | One row per case: what was tested, what was expected, what happened |
| `UAT-trades.csv` | Every trade that was tested, against the case it belongs to |
| `UAT-results.md` | The same, in full: the trades, the alerts and the arithmetic behind each one |
| `UAT-test-cases.md` | What each case tests and why those particular trades |
| `UAT-trade-design.md` | Every trade in the file with the reasoning behind its shape |

The two CSVs are the ones to attach to an email: they open in Excel and carry no commentary.

---

## 6. "Could it test for …?" (3 minutes)

Only if the question comes up — but it usually does, and this is the best answer you can give.

[**UAT Pack → Edit the test cases**.]

> "A test case here is two halves. The description and the pass rule are a form — what is being
> tested, the scenario, whether it must alert or must stay silent. The trades are data, tagged with
> the case id.
>
> So if you want a case we have not thought of, we add it here, download the starter trades,
> edit them into the behaviour you have in mind, import them, and it is scored with the other
> thirty. It takes a couple of minutes and it does not involve a developer."

Add one live if they name something specific. If they do not, move on — do not demonstrate the
editor for its own sake.

---

## Closing

> "Thirty of thirty, with the harder half being the seventeen that have to stay quiet. The
> evidence is a file you can read without the app in front of you, and the catalogue is yours to add
> to. What I would like from you is a view on whether the thresholds are where you want them, and
> which behaviours you want added before this goes any further."

---

## Questions you should expect

**"Is this real data?"**
No. Every trade in the pack is engineered, and no instrument, trader or counterparty in it is real.
That is deliberate: real data cannot tell you whether the tool finds abuse, because nobody has
labelled it. The import path is the same one production data goes through — the pack is imported,
not generated in place, precisely so that path is tested too.

**"How do I know the tool isn't just reading the answers?"**
Each document carries a marker naming its case, and no detection engine reads that marker — it
exists so the report can be written. The detectors see trades and orders. That claim is checkable:
the marker is read in one function, at import, and never again.

**"What about the abuse you haven't thought of?"**
This catalogue proves the eleven metrics behave as specified. It says nothing about a twelfth
behaviour nobody has written a metric for. That is a real limit and worth saying before they say it.

**"Why does one case show two alerts?"**
Some behaviours genuinely are two things at once — a front running pattern with enough build trades
also reads as ramping. Where that happens the report names the second metric rather than hiding it.

**"What happens when you point it at our actual feed?"**
It runs. The coverage table on the import page says, per metric, what the file can and cannot
support — order-level metrics need order data, pricing metrics need a traded price, and a CDS
carries upfront points rather than a traded spread. Instruments not in the reference universe get
their level from the file itself, and the import page lists every one of those so the assumption is
visible.

**"How long does a run take?"**
Under a second for the pack; a couple of seconds for the full seeded population of twelve and a
half thousand documents. Nothing is precomputed or cached overnight.

**"Is there a test suite for the simulation as well?"**
Yes — the **Test Cases** page, 27 cases planted in the generated population, covering all eleven
metrics with severity tiers and threshold sweeps. Same idea, different data. Show it only if asked;
it competes with the message of this session.
