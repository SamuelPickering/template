# UAT pack — the trades, and why they are shaped this way

Generated 2026-10-23T15:53:26.887Z by `npm run uat:pack`. 102 Master.Transaction documents across 30 test cases, in the Credit, Rates and Fenics product schemas.

This document exists so that nothing in the pack has to be taken on trust. For every case it lists the trades that were built, exactly as they appear in the file, and the reasoning behind them — why those sizes, why those timestamps, why those counterparties. Where a case is supposed to produce silence, the reasoning is about what was deliberately left out or set just inside a limit.

## How the pack is laid out

- **2026-10-13** — the cases that must raise an alert.
- **2026-10-14** — the cases that must not.
- **2026-10-15** — a day of ordinary business, which must produce nothing at all.

One instrument per case, because the reference level for an instrument the tool has never seen is derived from the prices in the file — sharing an instrument between two cases would let one case move the other's market level. Trades are kept clear of the 16:00 close so Banging the Close has nothing to say about them, and no trader holds five or more executions in one instrument on one day unless the case is about ramping, which is where that detector starts looking.

## Traders

| Trader | Name | Used for |
|---|---|---|
| UAT-T01 | N. Okafor | layering cases |
| UAT-T02 | P. Lindqvist | spoofing cases |
| UAT-T03 | G. Mbeki | wash trading cases |
| UAT-T04 | T. Varga | front running cases |
| UAT-T05 | I. Solberg | best execution cases |
| UAT-T06 | R. Duarte | wash and front running cases that must not fire |
| UAT-T07 | Y. Tanaka | spoofing and layering cases that must not fire |
| UAT-T08 | O. Brandt | ordinary business |
| UAT-T09 | M. Lindgren | ordinary business |

## Counterparties

The product schemas have no field that separates a client from a dealer, and Front Running and Best Execution both turn on that distinction. The pack therefore follows a convention and declares it in the file's own envelope: clients match `CLT-`, dealers match `DLR-`, and an internal book is recognised from its `INT` prefix without needing to be told. On a real extract the same job is done by the counterparty registry, or by typing patterns into the import page.

| Code | Name | Treated as |
|---|---|---|
| CLT-ALPHA | Alpha Pension Trust | client |
| CLT-BETA | Beta Family Office | client |
| CLT-GAMMA | Gamma Mutual Insurance | client |
| DLR-ONE | Onebrook Securities | dealer |
| DLR-TWO | Twyford Markets | dealer |
| INT-DESK | Internal Book Transfer | internal |

## Layering

### UAT-LAYER-01 — Five-rung bid ladder pulled unfilled while the trader sells

**Scenario under test.** Trader places a run of orders on one side at successive prices, cancels them all without trading, and deals the opposite way while they stand

6 documents. Expected: a Layering alert.

**The scenario.** One trader places five bids on the same bond within about a minute, at five successive prices from the touch downwards, $12m each and fully displayed. Two are amended to walk the price in. All five are cancelled 20 to 40 seconds after being placed, with no fills. While the ladder stands, the same trader sells $20m of the same bond to a dealer.

**Why these trades.** Five rungs is the smallest ladder that is unambiguously a ladder — it clears the four-level floor with one to spare, so the case does not pass on a rounding accident. $12m a rung matters as much as the total: each individual order is too small to score as a spoof on its own, so the only way this becomes an alert is if the engine assembles the five orders into one ladder. The sell is what gives the ladder a purpose; without it there is nothing the ladder could have benefited.

| Document | Timestamp | What it is | Instrument | Side | Amount | Price | Counterparty |
|---|---|---|---|---|---:|---:|---|
| UAT-LAYER-01-O1 | 2026-10-13 09:15:00 | order, fully displayed, no fills, cancelled, 2 events | XS2601000011 | bid | 12,000,000 | 99.5 |  |
| UAT-LAYER-01-O2 | 2026-10-13 09:15:12 | order, fully displayed, no fills, cancelled, 3 events | XS2601000011 | bid | 12,000,000 | 99.49 |  |
| UAT-LAYER-01-O3 | 2026-10-13 09:15:24 | order, fully displayed, no fills, cancelled, 2 events | XS2601000011 | bid | 12,000,000 | 99.48 |  |
| UAT-LAYER-01-O4 | 2026-10-13 09:15:36 | order, fully displayed, no fills, cancelled, 3 events | XS2601000011 | bid | 12,000,000 | 99.47 |  |
| UAT-LAYER-01-O5 | 2026-10-13 09:15:48 | order, fully displayed, no fills, cancelled, 2 events | XS2601000011 | bid | 12,000,000 | 99.46 |  |
| UAT-LAYER-01-O6 | 2026-10-13 09:15:33 | order, fully displayed, 1 fill, 2 events | XS2601000011 | offer | 20,000,000 | 99.51 | DLR-ONE |

### UAT-LAYER-02 — Four-rung ladder, just over the threshold

**Scenario under test.** The same pattern at the fewest price levels the firm counts as a ladder

5 documents. Expected: a Layering alert.

**The scenario.** Four bids at four prices, $6m each, placed over 30 seconds and all cancelled within 25 seconds, against a $20m sell on the other side. Deliberately sized to land just above the threshold, which is what shows the threshold is doing real work rather than letting everything through.

**Why these trades.** The four-level floor is the single most important setting on this metric, because it is what separates a ladder from a trader legitimately working one order at a couple of prices. This case sits exactly on that floor, so if the floor is ever raised to five this case is the one that stops alerting — which is the behaviour an analyst should be able to predict from the admin page.

| Document | Timestamp | What it is | Instrument | Side | Amount | Price | Counterparty |
|---|---|---|---|---|---:|---:|---|
| UAT-LAYER-02-O7 | 2026-10-13 09:40:00 | order, fully displayed, no fills, cancelled, 2 events | XS2601000022 | bid | 6,000,000 | 99.6 |  |
| UAT-LAYER-02-O8 | 2026-10-13 09:40:10 | order, fully displayed, no fills, cancelled, 2 events | XS2601000022 | bid | 6,000,000 | 99.59 |  |
| UAT-LAYER-02-O9 | 2026-10-13 09:40:20 | order, fully displayed, no fills, cancelled, 2 events | XS2601000022 | bid | 6,000,000 | 99.58 |  |
| UAT-LAYER-02-O10 | 2026-10-13 09:40:30 | order, fully displayed, no fills, cancelled, 2 events | XS2601000022 | bid | 6,000,000 | 99.57 |  |
| UAT-LAYER-02-O11 | 2026-10-13 09:40:26 | order, fully displayed, 1 fill, 2 events | XS2601000022 | offer | 20,000,000 | 99.61 | DLR-TWO |

## Spoofing

### UAT-SPOOF-01 — $50m bid pulled after 18 seconds, $20m sold the other way

**Scenario under test.** Trader places one large fully visible order at the current price, cancels it within seconds, and deals the opposite way while it stands

2 documents. Expected: a Spoofing alert.

**The scenario.** A trader places one $50m bid on a bond at the prevailing level, all of it displayed, and cancels it 18 seconds later with nothing filled. Nine seconds into its life, the same trader sells $20m of the same bond to a dealer.

**Why these trades.** Every element is there because a gate depends on it: the size and the display make the order worth seeing, sitting at the touch makes it competitive, the 18-second life makes it implausible as genuine liquidity, the nil fill makes it a decoy rather than a trade, and the sale on the other side is what the decoy was for. Remove any one of them and this should stop being an alert — which is exactly what the spoofing negative cases do, one gate at a time.

| Document | Timestamp | What it is | Instrument | Side | Amount | Price | Counterparty |
|---|---|---|---|---|---:|---:|---|
| UAT-SPOOF-01-O12 | 2026-10-13 09:50:00 | order, fully displayed, no fills, cancelled, 2 events | XS2602000011 | bid | 50,000,000 | 99.7 |  |
| UAT-SPOOF-01-O13 | 2026-10-13 09:50:07 | order, fully displayed, 1 fill, 2 events | XS2602000011 | offer | 20,000,000 | 99.7 | DLR-ONE |

### UAT-SPOOF-02 — $32m offer pulled after 25 seconds, just over the threshold

**Scenario under test.** The same pattern with the order left in the market longer before it is cancelled

2 documents. Expected: a Spoofing alert.

**The scenario.** A $32m offer at the touch, fully displayed, cancelled after 25 seconds, with $16m bought on the other side while it rested. Deliberately sized to land just above the threshold, which is what shows the threshold is doing real work rather than letting everything through.

**Why these trades.** The Counter-Narrative — what it would have cost the trader if the decoy had actually been filled — grows with both the size of the order and how long it rested. At 25 seconds this case carries noticeably more of that cost than the 18-second case, so it tests that the model nets the two readings off against each other rather than just counting the pattern.

| Document | Timestamp | What it is | Instrument | Side | Amount | Price | Counterparty |
|---|---|---|---|---|---:|---:|---|
| UAT-SPOOF-02-O14 | 2026-10-13 10:05:00 | order, fully displayed, no fills, cancelled, 2 events | XS2602000022 | offer | 32,000,000 | 100.2 |  |
| UAT-SPOOF-02-O15 | 2026-10-13 10:05:12 | order, fully displayed, 1 fill, 2 events | XS2602000022 | bid | 16,000,000 | 100.2 | DLR-TWO |

## Wash trading

### UAT-WASH-01 — $30m bought and sold back to the same internal account in six minutes

**Scenario under test.** Trader buys and sells the same security in the same size against the same internal account minutes apart

2 documents. Expected: a Wash Trading alert.

**The scenario.** A trader buys $30m of a bond from an internal book at 10:02 and sells the same $30m back to that internal book at 10:08, at the same price.

**Why these trades.** This is the textbook case, and it is in the pack as the control for the three disguised variants that follow: same instrument, same size, same account, minutes apart. The six-minute gap is the point — it is long enough to look like two separate decisions on a blotter and far too short for any real risk to have been run, which is what the Counter-Narrative measures.

| Document | Timestamp | What it is | Instrument | Side | Amount | Price | Counterparty |
|---|---|---|---|---|---:|---:|---|
| UAT-WASH-01-O16 | 2026-10-13 10:01:58 | order, fully displayed, 1 fill, 2 events | XS2603000011 | bid | 30,000,000 | 100 | INT-DESK |
| UAT-WASH-01-O17 | 2026-10-13 10:07:58 | order, fully displayed, 1 fill, 2 events | XS2603000011 | offer | 30,000,000 | 100 | INT-DESK |

### UAT-WASH-02 — Round trip disguised as two different CDS tenors

**Scenario under test.** Trader offsets a position within minutes using a contract booked at a different stated maturity

2 documents. Expected: a Wash Trading alert.

**The scenario.** $40m of protection bought on a reference entity with the tenor stated as 58M, and $40m sold on the same entity four minutes later with the tenor stated as 61M, both against an internal book. Sized far above the threshold, so it stays an alert even if the threshold is raised several times over.

**Why these trades.** On any blotter these are two different contracts and the round trip is invisible. They are only the same position after the tenor strings have been bucketed onto a standard curve point, which happens in the adapter, before any detector runs. That is the whole argument for normalising first and detecting second, and this case is what proves it happens.

| Document | Timestamp | What it is | Instrument | Side | Amount | Price | Counterparty |
|---|---|---|---|---|---:|---:|---|
| UAT-WASH-02-C18 | 2026-10-13T11:00:00 | Credit.CDS | UATPLC SNRFOR 58M | buy protection | 40,000,000 | 0 | INT-DESK |
| UAT-WASH-02-C19 | 2026-10-13T11:04:00 | Credit.CDS | UATPLC SNRFOR 61M | sell protection | 40,000,000 | 0 | INT-DESK |

### UAT-WASH-03 — $24m round trip, just over the threshold

**Scenario under test.** The same round trip in a smaller size

2 documents. Expected: a Wash Trading alert.

**The scenario.** The same shape as UAT-WASH-01 at $24m, nine minutes apart. Deliberately sized to land just above the threshold, which is what shows the threshold is doing real work rather than letting everything through.

**Why these trades.** Scored on impact rather than on the pattern, a $24m round trip has to come out materially lower than a $30m one — the two together show the score is a function of size and are what make the threshold meaningful. This is also the case to watch when someone asks what the threshold should be: it is the one that disappears first.

| Document | Timestamp | What it is | Instrument | Side | Amount | Price | Counterparty |
|---|---|---|---|---|---:|---:|---|
| UAT-WASH-03-O20 | 2026-10-13 11:29:58 | order, fully displayed, 1 fill, 2 events | XS2603000033 | bid | 24,000,000 | 98.75 | INT-DESK |
| UAT-WASH-03-O21 | 2026-10-13 11:38:58 | order, fully displayed, 1 fill, 2 events | XS2603000033 | offer | 24,000,000 | 98.75 | INT-DESK |

## Front running

### UAT-FRONT-01 — $20m bought ahead of $60m of client business, sold two minutes after it

**Scenario under test.** Trader takes a position for the firm's own book, fills client orders in the same security and direction, then closes out minutes later

3 documents. Expected: a Front Running alert.

**The scenario.** At 09:58 a trader buys $20m of a bond from a dealer, for the firm's own book. Between 10:12 and 10:18 the same trader buys $60m of the same bond from two clients. At 10:20, two minutes after the last client fill, the trader sells the $20m back to a dealer.

**Why these trades.** The order of events is the evidence, so the data is built to make the order unambiguous: the own-account position exists before the client flow begins, the client flow is large enough to move the instrument, and the exit comes two minutes after it — close enough that most of the modelled impact is still there. Only two client fills are used, which keeps the trader under five executions on the day and stops this from also reading as ramping; that keeps the case about one thing.

| Document | Timestamp | What it is | Instrument | Side | Amount | Price | Counterparty |
|---|---|---|---|---|---:|---:|---|
| UAT-FRONT-01-O22 | 2026-10-13 09:57:58 | order, fully displayed, 1 fill, 2 events | XS2604000011 | bid | 20,000,000 | 99.9 | DLR-ONE |
| UAT-FRONT-01-O23 | 2026-10-13 10:10:00 | order, fully displayed, 2 fills, 3 events | XS2604000011 | bid | 60,000,000 | 99.94 | CLT-ALPHA, CLT-BETA |
| UAT-FRONT-01-O24 | 2026-10-13 10:19:58 | order, fully displayed, 1 fill, 2 events | XS2604000011 | offer | 20,000,000 | 99.98 | DLR-TWO |

### UAT-FRONT-02 — The same pattern in swaptions, not bonds

**Scenario under test.** The same sequence in a product with no order book and no traded price

4 documents. Expected: a Front Running alert.

**The scenario.** A trader pays fixed on $200m of a 5Y swaption against a dealer, then executes $600m of client business paying fixed on the same curve point, then receives fixed on $200m eight minutes later. Sized far above the threshold, so it stays an alert even if the threshold is raised several times over.

**Why these trades.** A swaption carries a strike rather than a price, settles against a curve point rather than an ISIN, and arrives in a different Economics shape with its direction in PayOrReceive instead of the sign of the notional. If the detector works here without being told any of that, it is working on the normalised model rather than on the Fenics feed it was first written against. The rates notionals are larger because a swap curve absorbs far more size than a single bond before it moves.

| Document | Timestamp | What it is | Instrument | Side | Amount | Price | Counterparty |
|---|---|---|---|---|---:|---:|---|
| UAT-FRONT-02-R25 | 2026-10-13T09:30:00 | IR.Swaption | UATSOFR 2026-11-12→2031-11-13 | Pay | 200,000,000 | 3.95 | DLR-ONE |
| UAT-FRONT-02-R26 | 2026-10-13T09:40:00 | IR.Swaption | UATSOFR 2026-11-12→2031-11-13 | Pay | 300,000,000 | 3.96 | CLT-ALPHA |
| UAT-FRONT-02-R27 | 2026-10-13T09:44:00 | IR.Swaption | UATSOFR 2026-11-12→2031-11-13 | Pay | 300,000,000 | 3.96 | CLT-GAMMA |
| UAT-FRONT-02-R28 | 2026-10-13T09:46:00 | IR.Swaption | UATSOFR 2026-11-12→2031-11-13 | Receive | 160,000,000 | 3.97 | DLR-TWO |

### UAT-FRONT-03 — $25m exited after $30m of client business, just over the threshold

**Scenario under test.** The same sequence against a single, smaller client order

3 documents. Expected: a Front Running alert.

**The scenario.** A $25m own-account position opened at 11:05, a single $30m client fill at 11:20, and the exit at 11:22. Deliberately sized to land just above the threshold, which is what shows the threshold is doing real work rather than letting everything through.

**Why these trades.** Front running is priced on the impact the client business left standing, so one $30m fill creates far less of it than three $20m fills would. This case is the lower bound of what the metric reports at the default threshold, and it is the one to re-run after any change to the impact model.

| Document | Timestamp | What it is | Instrument | Side | Amount | Price | Counterparty |
|---|---|---|---|---|---:|---:|---|
| UAT-FRONT-03-O29 | 2026-10-13 11:04:58 | order, fully displayed, 1 fill, 2 events | XS2604000033 | bid | 25,000,000 | 100.1 | DLR-ONE |
| UAT-FRONT-03-O30 | 2026-10-13 11:19:00 | order, fully displayed, 1 fill, 2 events | XS2604000033 | bid | 30,000,000 | 100.12 | CLT-ALPHA |
| UAT-FRONT-03-O31 | 2026-10-13 11:21:58 | order, fully displayed, 1 fill, 2 events | XS2604000033 | offer | 25,000,000 | 100.12 | DLR-TWO |

## Best execution

### UAT-BESTEX-01 — Client filled 30 bps behind the firm's own print 90 seconds earlier

**Scenario under test.** Client is filled at a worse price than the firm itself obtained on the same security minutes earlier

2 documents. Expected: a Best Execution alert.

**The scenario.** At 09:30 the firm buys $8m of a bond from a dealer at 99.80. At 09:31:30 it buys $25m of the same bond from a client at 99.50 — the client sold 30 bps lower than the dealer did, 90 seconds apart.

**Why these trades.** The strongest evidence available for this metric is the firm's own contemporaneous print on the same instrument, because there is no argument about what was reachable: the firm reached it itself, a minute and a half earlier, in the same feed. The dealer print is deliberately smaller than the client fill, so no one can argue the client got a worse price for being bigger. The gap is 30 bps against a 25 bps floor, comfortably material but nowhere near the 60 bps that would make this an off-market trade instead.

| Document | Timestamp | What it is | Instrument | Side | Amount | Price | Counterparty |
|---|---|---|---|---|---:|---:|---|
| UAT-BESTEX-01-O32 | 2026-10-13 09:29:58 | order, fully displayed, 1 fill, 2 events | XS2605000011 | bid | 8,000,000 | 99.8 | DLR-ONE |
| UAT-BESTEX-01-O33 | 2026-10-13 09:31:28 | order, fully displayed, 1 fill, 2 events | XS2605000011 | bid | 25,000,000 | 99.5 | CLT-ALPHA |

### UAT-BESTEX-02 — $6m client fill, 26 bps behind, just over the threshold

**Scenario under test.** Client is filled just beyond the firm's limit for an acceptable difference in price

2 documents. Expected: a Best Execution alert.

**The scenario.** A $4m dealer print at 99.76, then a $6m client fill at 99.56 — 26 bps worse, inside the five-minute reference window. Deliberately sized to land just above the threshold, which is what shows the threshold is doing real work rather than letting everything through.

**Why these trades.** This case sits one basis point above the 25 bps materiality floor and only a little above the USD threshold, so it exercises both limits at once. It is the companion to UAT-NEG-BESTEX-02, which is the same shape at 15 bps and must not fire: between them they show exactly where the line is.

| Document | Timestamp | What it is | Instrument | Side | Amount | Price | Counterparty |
|---|---|---|---|---|---:|---:|---|
| UAT-BESTEX-02-O34 | 2026-10-13 09:59:58 | order, fully displayed, 1 fill, 2 events | XS2605000022 | bid | 4,000,000 | 99.76 | DLR-ONE |
| UAT-BESTEX-02-O35 | 2026-10-13 10:01:18 | order, fully displayed, 1 fill, 2 events | XS2605000022 | bid | 6,000,000 | 99.5 | CLT-BETA |

### UAT-BESTEX-03 — $40m client fill, 45 bps behind the firm's own print

**Scenario under test.** A large client order is filled well behind the price the firm itself obtained on the same security

2 documents. Expected: a Best Execution alert.

**The scenario.** A $10m dealer print at 100.05, then a $40m client fill at 99.60 — 45 bps worse, two minutes later. Sized far above the threshold, so it stays an alert even if the threshold is raised several times over.

**Why these trades.** Best Execution is the one metric here that measures harm to the client rather than gain to the trader, so what matters most is that the score tracks the size of the harm. Put next to UAT-BESTEX-02 it shows an order of magnitude between a $6m fill 26 bps behind and a $40m fill 45 bps behind, which is the right ordering for a review queue.

| Document | Timestamp | What it is | Instrument | Side | Amount | Price | Counterparty |
|---|---|---|---|---|---:|---:|---|
| UAT-BESTEX-03-O36 | 2026-10-13 12:59:58 | order, fully displayed, 1 fill, 2 events | XS2605000033 | bid | 10,000,000 | 100.05 | DLR-TWO |
| UAT-BESTEX-03-O37 | 2026-10-13 13:01:58 | order, fully displayed, 1 fill, 2 events | XS2605000033 | bid | 40,000,000 | 99.6 | CLT-GAMMA |

## Wash trading — must not fire

### UAT-NEG-WASH-01 — Two completely different bonds, bought and sold at the same moment

**Scenario under test.** Trader buys one security and sells a different security at the same moment, in the same size, against the same account

2 documents. Expected: no alert from any metric.

**The scenario.** A trader buys $30m of one bond at 10:00:05 and sells $30m of a different bond at 10:00:12, both against the same internal book.

**Why these trades.** This is the most obvious way to produce a false positive: the sizes match, the accounts match, the timestamps are seconds apart, and on a summary screen it looks exactly like a wash. The only thing that makes it legitimate is that the two trades are in different instruments, so no position was closed. If the detector were matching on size and time rather than on a normalised instrument, this is the case that would expose it.

**The check that should stop it.** Offsetting legs are only ever looked for within one trader, one instrument and one day. Two instruments are never compared against each other.

| Document | Timestamp | What it is | Instrument | Side | Amount | Price | Counterparty |
|---|---|---|---|---|---:|---:|---|
| UAT-NEG-WASH-01-O38 | 2026-10-14 10:00:03 | order, fully displayed, 1 fill, 2 events | XS2606000011 | bid | 30,000,000 | 99.7 | INT-DESK |
| UAT-NEG-WASH-01-O39 | 2026-10-14 10:00:10 | order, fully displayed, 1 fill, 2 events | XS2606000012 | offer | 30,000,000 | 101.2 | INT-DESK |

### UAT-NEG-WASH-02 — Position opened in the morning, closed in the afternoon

**Scenario under test.** Trader opens a position in the morning and closes the same size in the afternoon

2 documents. Expected: no alert from any metric.

**The scenario.** A trader buys $30m of a bond from a dealer at 09:15 and sells the same $30m to another dealer at 14:55, five hours and 40 minutes later.

**Why these trades.** Taking a position and closing it later in the day is the ordinary business of a trading book, and the sizes offsetting exactly is normal rather than suspicious — that is what closing a position means. What separates it from a wash is that real market risk was carried for most of a session. The engine's own limit on the gap between legs is what has to catch this, and at five hours and 40 minutes it is nowhere near it.

**The check that should stop it.** The maximum gap between offsetting legs, 30 minutes by default. Beyond it the two trades are never considered as a pair.

| Document | Timestamp | What it is | Instrument | Side | Amount | Price | Counterparty |
|---|---|---|---|---|---:|---:|---|
| UAT-NEG-WASH-02-O40 | 2026-10-14 09:14:58 | order, fully displayed, 1 fill, 2 events | XS2606000022 | bid | 30,000,000 | 99.5 | DLR-ONE |
| UAT-NEG-WASH-02-O41 | 2026-10-14 14:54:58 | order, fully displayed, 1 fill, 2 events | XS2606000022 | offer | 30,000,000 | 99.85 | DLR-TWO |

### UAT-NEG-WASH-03 — Market making: bought from one client, sold to another

**Scenario under test.** Trader buys a security from one client and sells it to a different client minutes later

2 documents. Expected: no alert from any metric.

**The scenario.** A trader buys $25m of a bond from one client at 10:00 and sells $25m of the same bond to a different client at 10:08, four basis points higher.

**Why these trades.** This is the single most dangerous false positive in the whole metric, because it is what a market maker does all day: the instrument is the same, the size is the same, the gap is minutes, and the position nets to flat. The difference is that risk genuinely changed hands twice, with two unrelated clients, and the firm earned the spread for it. The engine has to reach that conclusion on its own from the counterparties and the client-facing role, and say so — rather than being told to ignore it.

**The check that should stop it.** Relatedness and the Counter-Narrative. Two unrelated external clients score far below an internal account, and the client-facilitation explanation cancels what is left.

| Document | Timestamp | What it is | Instrument | Side | Amount | Price | Counterparty |
|---|---|---|---|---|---:|---:|---|
| UAT-NEG-WASH-03-O42 | 2026-10-14 09:59:58 | order, fully displayed, 1 fill, 2 events | XS2606000033 | bid | 25,000,000 | 99.3 | CLT-ALPHA |
| UAT-NEG-WASH-03-O43 | 2026-10-14 10:07:58 | order, fully displayed, 1 fill, 2 events | XS2606000033 | offer | 25,000,000 | 99.34 | CLT-BETA |

### UAT-NEG-WASH-04 — Partial hedge against an internal book

**Scenario under test.** Trader offsets part of a position against an internal account and leaves the rest open

2 documents. Expected: no alert from any metric.

**The scenario.** A trader buys $30m of a bond from an internal book at 11:00 and sells $9m of it back five minutes later — 30% of the position, leaving $21m of exposure.

**Why these trades.** Everything that makes UAT-WASH-01 an alert is present here except that the legs do not offset: same instrument, same internal account, five minutes apart. What is missing is the round trip, because 70% of the position is still live and still carrying risk. Without a size-match requirement this case would be indistinguishable from the real thing, which is why the tolerance exists and why it is on the admin page.

**The check that should stop it.** The size match tolerance, 15% by default. $9m against $30m is nowhere near offsetting.

| Document | Timestamp | What it is | Instrument | Side | Amount | Price | Counterparty |
|---|---|---|---|---|---:|---:|---|
| UAT-NEG-WASH-04-O44 | 2026-10-14 10:59:58 | order, fully displayed, 1 fill, 2 events | XS2606000044 | bid | 30,000,000 | 100 | INT-DESK |
| UAT-NEG-WASH-04-O45 | 2026-10-14 11:04:58 | order, fully displayed, 1 fill, 2 events | XS2606000044 | offer | 9,000,000 | 100 | INT-DESK |

## Front running — must not fire

### UAT-NEG-FRONT-01 — Own-account trade six hours after the client business

**Scenario under test.** Trader deals in the same security as a client, hours after the client order was filled

3 documents. Expected: no alert from any metric.

**The scenario.** A trader holds a $20m own-account position from 09:00, fills $60m of client business between 09:25 and 09:35, and sells the $20m at 15:30 — nearly six hours after the last client fill.

**Why these trades.** This is the case the request asked for by name, and it matters because the sequence is identical to UAT-FRONT-01 — position, client flow, exit, all in the right order. The only difference is the gap. Front running is priced on the impact the client business left standing at the moment of the exit, and six hours later there is none: the modelled impact has decayed through roughly twelve half-lives. A tool that flagged this would flag every position a trader ever closed on a day they also served a client.

**The check that should stop it.** The maximum lead time, 15 minutes by default. Client business older than that is not considered as the impacting flow at all.

| Document | Timestamp | What it is | Instrument | Side | Amount | Price | Counterparty |
|---|---|---|---|---|---:|---:|---|
| UAT-NEG-FRONT-01-O46 | 2026-10-14 08:59:58 | order, fully displayed, 1 fill, 2 events | XS2607000011 | bid | 20,000,000 | 99.6 | DLR-ONE |
| UAT-NEG-FRONT-01-O47 | 2026-10-14 09:22:00 | order, fully displayed, 2 fills, 3 events | XS2607000011 | bid | 60,000,000 | 99.62 | CLT-ALPHA, CLT-BETA |
| UAT-NEG-FRONT-01-O48 | 2026-10-14 15:29:58 | order, fully displayed, 1 fill, 2 events | XS2607000011 | offer | 20,000,000 | 99.7 | DLR-TWO |

### UAT-NEG-FRONT-02 — Client business on the other side of the market

**Scenario under test.** Trader holds a position and the client orders in that security are on the opposite side

3 documents. Expected: no alert from any metric.

**The scenario.** A trader buys $20m of a bond for the firm's own book at 10:00, then sells $60m of the same bond to clients between 10:05 and 10:09, then sells $28m for the firm's own book at 10:12.

**Why these trades.** The timing here is tighter than in the real case — three minutes rather than two — so timing alone cannot be what saves it. Selling to clients pushes the instrument down, which is the wrong way for someone holding a long position to profit; the trader's own sale is into a market their client business just moved against them. Direction is the substance of this metric, not an incidental field, and this case is what proves it is being read.

**The check that should stop it.** The impacting flow must be in the opposite direction to the exit — in other words, the same direction as the position being held.

| Document | Timestamp | What it is | Instrument | Side | Amount | Price | Counterparty |
|---|---|---|---|---|---:|---:|---|
| UAT-NEG-FRONT-02-O49 | 2026-10-14 09:59:58 | order, fully displayed, 1 fill, 2 events | XS2607000022 | bid | 20,000,000 | 100 | DLR-ONE |
| UAT-NEG-FRONT-02-O50 | 2026-10-14 10:03:00 | order, fully displayed, 2 fills, 3 events | XS2607000022 | offer | 60,000,000 | 99.98 | CLT-ALPHA, CLT-BETA |
| UAT-NEG-FRONT-02-O51 | 2026-10-14 10:11:58 | order, fully displayed, 1 fill, 2 events | XS2607000022 | offer | 28,000,000 | 99.96 | DLR-TWO |

### UAT-NEG-FRONT-03 — No position held before the client business

**Scenario under test.** Trader deals minutes after client orders in the same security, holding no position beforehand

2 documents. Expected: no alert from any metric.

**The scenario.** A trader fills $60m of client business between 10:00 and 10:06 holding no position of their own, then sells $20m for the firm's own book at 10:08, two minutes later.

**Why these trades.** Front running requires foreknowledge turned into a position, and a trader who was flat when the client business arrived had nothing in place to benefit. Selling afterwards may be any number of things — hedging the inventory the client business just created, most likely — but it cannot be front running, because there was no earlier position to exit. The two-minute gap is identical to UAT-FRONT-01, so the only difference between an alert and silence here is whether the position existed first.

**The check that should stop it.** The position being exited must have been opened before the client flow began, and must be at least a quarter of the size of the exit.

| Document | Timestamp | What it is | Instrument | Side | Amount | Price | Counterparty |
|---|---|---|---|---|---:|---:|---|
| UAT-NEG-FRONT-03-O52 | 2026-10-14 09:58:00 | order, fully displayed, 2 fills, 3 events | XS2607000033 | bid | 60,000,000 | 99.5 | CLT-ALPHA, CLT-BETA |
| UAT-NEG-FRONT-03-O53 | 2026-10-14 10:07:58 | order, fully displayed, 1 fill, 2 events | XS2607000033 | offer | 20,000,000 | 99.52 | DLR-TWO |

## Spoofing — must not fire

### UAT-NEG-SPOOF-01 — Large bid pulled, nothing executed the other way

**Scenario under test.** Trader places and cancels a large visible order and deals in nothing else in that security

1 document. Expected: no alert from any metric.

**The scenario.** A $50m bid at the touch, fully displayed, cancelled 20 seconds later with no fills. The trader executes nothing else in that bond all day.

**Why these trades.** Pulling a large order quickly is ordinary: the market moves, a client cancels, a risk limit changes, the price is no longer wanted. What makes it spoofing is that the trader was doing something on the other side that the order's visible weight helped. With nothing on the other side there is no benefit to measure and no reason to suspect anything, and this case is identical to UAT-SPOOF-01 in every other respect.

**The check that should stop it.** There must be an execution in the opposite direction while the order rested, worth at least 15% of the order.

| Document | Timestamp | What it is | Instrument | Side | Amount | Price | Counterparty |
|---|---|---|---|---|---:|---:|---|
| UAT-NEG-SPOOF-01-O54 | 2026-10-14 09:50:00 | order, fully displayed, no fills, cancelled, 2 events | XS2608000011 | bid | 50,000,000 | 99.4 |  |

### UAT-NEG-SPOOF-02 — The large order actually traded

**Scenario under test.** Trader's large visible order is filled in full

2 documents. Expected: no alert from any metric.

**The scenario.** A $50m bid at the touch, fully displayed, which fills completely in two clips over 40 seconds. The trader also sells $20m of the same bond while it is working.

**Why these trades.** A spoof is an order placed with no intention of trading, so an order that traded in full is the clearest possible refutation — the trader took the risk they were displaying. The $20m sale is left in deliberately, so that the opposite-side execution the metric looks for is present and the only thing standing between this case and an alert is the fill.

**The check that should stop it.** The order must have been cancelled with effectively nothing filled. A filled order is never a candidate.

| Document | Timestamp | What it is | Instrument | Side | Amount | Price | Counterparty |
|---|---|---|---|---|---:|---:|---|
| UAT-NEG-SPOOF-02-O55 | 2026-10-14 09:55:00 | order, fully displayed, 2 fills, 3 events | XS2608000022 | bid | 50,000,000 | 99.45 | DLR-ONE |
| UAT-NEG-SPOOF-02-O56 | 2026-10-14 09:55:18 | order, fully displayed, 1 fill, 2 events | XS2608000022 | offer | 20,000,000 | 99.45 | DLR-TWO |

### UAT-NEG-SPOOF-03 — The order rested for eleven minutes

**Scenario under test.** Trader leaves a large visible order in the market for several minutes before cancelling it

2 documents. Expected: no alert from any metric.

**The scenario.** A $50m bid at the touch, fully displayed, cancelled unfilled after 11 minutes. $20m is sold the other way while it rests.

**Why these trades.** Time is the cleanest evidence of intent available in order data. A decoy has to be withdrawn before anyone can trade against it; an order that sits at the touch for eleven minutes was genuinely exposed to being filled for eleven minutes, and the trader carried that risk. Everything else here is identical to UAT-SPOOF-01, including the sale on the other side, so the order's life is doing all the work.

**The check that should stop it.** The maximum order life, 60 seconds by default. Anything resting longer is treated as real liquidity.

| Document | Timestamp | What it is | Instrument | Side | Amount | Price | Counterparty |
|---|---|---|---|---|---:|---:|---|
| UAT-NEG-SPOOF-03-O57 | 2026-10-14 10:10:00 | order, fully displayed, no fills, cancelled, 2 events | XS2608000033 | bid | 50,000,000 | 99.55 |  |
| UAT-NEG-SPOOF-03-O58 | 2026-10-14 10:14:58 | order, fully displayed, 1 fill, 2 events | XS2608000033 | offer | 20,000,000 | 99.55 | DLR-TWO |

## Layering — must not fire

### UAT-NEG-LAYER-01 — One order re-posted five times at the same price

**Scenario under test.** Trader places several orders on one side at a single price and cancels them

6 documents. Expected: no alert from any metric.

**The scenario.** Five bids of $12m on the same bond, all at exactly the same price, each resting about 90 seconds before being cancelled, with $20m sold the other way.

**Why these trades.** A trader working one order re-posts it as the book changes around them, which produces several orders on one side of the market in quick succession — the same raw shape as a ladder. What a ladder adds is depth: rungs at successive prices, so the book appears to have weight behind it at several levels. Counting orders would flag this; counting distinct price levels does not. The 90-second lives also keep it clear of the spoofing test, so nothing fires.

**The check that should stop it.** The minimum number of distinct price levels, four by default. Five orders at one price is one level — and the floor cannot be set below two, because a single price can never be a ladder, so no configuration makes this case fire.

| Document | Timestamp | What it is | Instrument | Side | Amount | Price | Counterparty |
|---|---|---|---|---|---:|---:|---|
| UAT-NEG-LAYER-01-O59 | 2026-10-14 10:40:00 | order, fully displayed, no fills, cancelled, 2 events | XS2609000011 | bid | 12,000,000 | 99.75 |  |
| UAT-NEG-LAYER-01-O60 | 2026-10-14 10:40:20 | order, fully displayed, no fills, cancelled, 2 events | XS2609000011 | bid | 12,000,000 | 99.75 |  |
| UAT-NEG-LAYER-01-O61 | 2026-10-14 10:40:40 | order, fully displayed, no fills, cancelled, 2 events | XS2609000011 | bid | 12,000,000 | 99.75 |  |
| UAT-NEG-LAYER-01-O62 | 2026-10-14 10:41:00 | order, fully displayed, no fills, cancelled, 2 events | XS2609000011 | bid | 12,000,000 | 99.75 |  |
| UAT-NEG-LAYER-01-O63 | 2026-10-14 10:41:20 | order, fully displayed, no fills, cancelled, 2 events | XS2609000011 | bid | 12,000,000 | 99.75 |  |
| UAT-NEG-LAYER-01-O64 | 2026-10-14 10:40:58 | order, fully displayed, 1 fill, 2 events | XS2609000011 | offer | 20,000,000 | 99.75 | DLR-TWO |

### UAT-NEG-LAYER-02 — A ladder that mostly traded

**Scenario under test.** Trader works an order through several price levels and most of it trades

6 documents. Expected: no alert from any metric.

**The scenario.** Five bids at five prices, $12m each. Three fill in full, two are cancelled — 40% of the notional cancelled. $20m is sold the other way.

**Why these trades.** Working an order down through several price levels and getting most of it done is a normal way to buy a bond, and it leaves exactly the same footprint as a ladder in everything except the outcome. Layering is characterised by the orders being withdrawn: the appearance of depth is the point, and filling it would defeat the purpose. The cancel ratio is what distinguishes the two, and at 40% this case is well under the 80% the engine requires.

**The check that should stop it.** The cancel ratio threshold, 80% of the ladder's notional by default. This ladder cancelled 40%.

| Document | Timestamp | What it is | Instrument | Side | Amount | Price | Counterparty |
|---|---|---|---|---|---:|---:|---|
| UAT-NEG-LAYER-02-O65 | 2026-10-14 11:00:00 | order, fully displayed, 1 fill, 2 events | XS2609000022 | bid | 12,000,000 | 99.85 | DLR-ONE |
| UAT-NEG-LAYER-02-O66 | 2026-10-14 11:00:20 | order, fully displayed, 1 fill, 2 events | XS2609000022 | bid | 12,000,000 | 99.84 | DLR-ONE |
| UAT-NEG-LAYER-02-O67 | 2026-10-14 11:00:40 | order, fully displayed, 1 fill, 2 events | XS2609000022 | bid | 12,000,000 | 99.83 | DLR-ONE |
| UAT-NEG-LAYER-02-O68 | 2026-10-14 11:01:00 | order, fully displayed, no fills, cancelled, 2 events | XS2609000022 | bid | 12,000,000 | 99.82 |  |
| UAT-NEG-LAYER-02-O69 | 2026-10-14 11:01:20 | order, fully displayed, no fills, cancelled, 2 events | XS2609000022 | bid | 12,000,000 | 99.81 |  |
| UAT-NEG-LAYER-02-O70 | 2026-10-14 11:01:28 | order, fully displayed, 1 fill, 2 events | XS2609000022 | offer | 20,000,000 | 99.85 | DLR-TWO |

### UAT-NEG-LAYER-03 — A ladder standing well away from the touch

**Scenario under test.** Trader leaves orders at several price levels away from where the security is trading

12 documents. Expected: no alert from any metric.

**The scenario.** Five bids at five prices, $12m each, all cancelled within 30 seconds — but placed six to ten basis points below where the bond was trading, which the same file establishes through a morning of ordinary two-way prints. $20m is sold the other way.

**Why these trades.** Resting orders away from the touch is how traders leave standing interest in the market without being hit: they are visible, they are cancelled constantly, and they are not pretending anything. An order only shifts the apparent balance of the book if it is near the price people are actually trading at. This is the one gate in the metric that depends on knowing where the market was, which is why the pack includes the ordinary prints that establish it.

**The check that should stop it.** The minimum competitiveness, 0.35 by default — a size-weighted measure of how close to the touch the ladder sat.

| Document | Timestamp | What it is | Instrument | Side | Amount | Price | Counterparty |
|---|---|---|---|---|---:|---:|---|
| UAT-NEG-LAYER-03-O71 | 2026-10-14 13:00:00 | order, fully displayed, no fills, cancelled, 2 events | XS2609000033 | bid | 12,000,000 | 99.44 |  |
| UAT-NEG-LAYER-03-O72 | 2026-10-14 13:00:15 | order, fully displayed, no fills, cancelled, 2 events | XS2609000033 | bid | 12,000,000 | 99.43 |  |
| UAT-NEG-LAYER-03-O73 | 2026-10-14 13:00:30 | order, fully displayed, no fills, cancelled, 2 events | XS2609000033 | bid | 12,000,000 | 99.42 |  |
| UAT-NEG-LAYER-03-O74 | 2026-10-14 13:00:45 | order, fully displayed, no fills, cancelled, 2 events | XS2609000033 | bid | 12,000,000 | 99.41 |  |
| UAT-NEG-LAYER-03-O75 | 2026-10-14 13:01:00 | order, fully displayed, no fills, cancelled, 2 events | XS2609000033 | bid | 12,000,000 | 99.4 |  |
| UAT-NEG-LAYER-03-O76 | 2026-10-14 13:00:38 | order, fully displayed, 1 fill, 2 events | XS2609000033 | offer | 20,000,000 | 99.5 | DLR-TWO |
| UAT-NEG-LAYER-03-O77 | 2026-10-14 08:39:58 | order, fully displayed, 1 fill, 2 events | XS2609000033 | bid | 2,000,000 | 99.5 | DLR-ONE |
| UAT-NEG-LAYER-03-O78 | 2026-10-14 09:24:58 | order, fully displayed, 1 fill, 2 events | XS2609000033 | offer | 2,000,000 | 99.51 | DLR-TWO |
| UAT-NEG-LAYER-03-O79 | 2026-10-14 10:09:58 | order, fully displayed, 1 fill, 2 events | XS2609000033 | bid | 2,000,000 | 99.5 | DLR-ONE |
| UAT-NEG-LAYER-03-O80 | 2026-10-14 11:04:58 | order, fully displayed, 1 fill, 2 events | XS2609000033 | offer | 2,000,000 | 99.51 | DLR-TWO |
| UAT-NEG-LAYER-03-O81 | 2026-10-14 11:49:58 | order, fully displayed, 1 fill, 2 events | XS2609000033 | bid | 2,000,000 | 99.51 | DLR-TWO |
| UAT-NEG-LAYER-03-O82 | 2026-10-14 12:34:58 | order, fully displayed, 1 fill, 2 events | XS2609000033 | offer | 2,000,000 | 99.5 | DLR-ONE |

## Best execution — must not fire

### UAT-NEG-BESTEX-01 — The client got the better price

**Scenario under test.** Client is filled at a better price than the firm itself obtained on the same security minutes earlier

2 documents. Expected: no alert from any metric.

**The scenario.** The firm buys $8m of a bond from a dealer at 99.50, then buys $25m from a client at 99.70 — the client sold 20 bps higher than the dealer did.

**Why these trades.** This is the mirror image of UAT-BESTEX-01 and it tests the one thing that is easy to get wrong in both directions: which side of the comparison the client is on. A client who sold wanted the highest price available; a client who bought wanted the lowest. Comparing the two prices without reference to the client's side would flag this case exactly as hard as the real one, which is why it is in the pack.

**The check that should stop it.** Detriment is measured on the client's side of the market and must be positive.

| Document | Timestamp | What it is | Instrument | Side | Amount | Price | Counterparty |
|---|---|---|---|---|---:|---:|---|
| UAT-NEG-BESTEX-01-O83 | 2026-10-14 09:19:58 | order, fully displayed, 1 fill, 2 events | XS2610000011 | bid | 8,000,000 | 99.5 | DLR-ONE |
| UAT-NEG-BESTEX-01-O84 | 2026-10-14 09:21:28 | order, fully displayed, 1 fill, 2 events | XS2610000011 | bid | 25,000,000 | 99.7 | CLT-ALPHA |

### UAT-NEG-BESTEX-02 — Fifteen basis points behind — inside the materiality floor

**Scenario under test.** Client is filled behind the firm's own price but within the firm's limit for an acceptable difference

2 documents. Expected: no alert from any metric.

**The scenario.** A $5m dealer print at 99.65, then a $25m client fill at 99.50 — 15 bps worse, 80 seconds later.

**Why these trades.** Two prices on the same bond minutes apart are almost never identical, and the gap between them is usually just the spread, the size difference and the market moving. If every such gap were an alert the metric would be unusable. The floor is where the firm says what counts as material, and this case sits deliberately below it while UAT-BESTEX-02 sits one basis point above — the pair is what demonstrates where the line is.

**The check that should stop it.** The minimum client detriment, 25 bps by default. This fill was 15 bps behind.

| Document | Timestamp | What it is | Instrument | Side | Amount | Price | Counterparty |
|---|---|---|---|---|---:|---:|---|
| UAT-NEG-BESTEX-02-O85 | 2026-10-14 09:39:58 | order, fully displayed, 1 fill, 2 events | XS2610000022 | bid | 5,000,000 | 99.65 | DLR-ONE |
| UAT-NEG-BESTEX-02-O86 | 2026-10-14 09:41:18 | order, fully displayed, 1 fill, 2 events | XS2610000022 | bid | 25,000,000 | 99.5 | CLT-BETA |

### UAT-NEG-BESTEX-03 — A $200k client fill, well behind the print

**Scenario under test.** A client order below the firm's size limit for review is filled behind the firm's own price

2 documents. Expected: no alert from any metric.

**The scenario.** An $8m dealer print at 99.80, then a $200k client fill at 99.20 — 60 bps worse, inside the reference window.

**Why these trades.** Small tickets are priced differently and always will be: a $200k fill does not get the price an $8m fill gets, and the difference is the cost of doing a small trade rather than a failure of execution. The size floor is what keeps the review queue pointed at the fills where the money is, and this case checks that the floor is applied before the price comparison rather than after, so a large percentage on a tiny notional cannot climb the queue.

**The check that should stop it.** The minimum client notional, $250,000 by default.

| Document | Timestamp | What it is | Instrument | Side | Amount | Price | Counterparty |
|---|---|---|---|---|---:|---:|---|
| UAT-NEG-BESTEX-03-O87 | 2026-10-14 10:49:58 | order, fully displayed, 1 fill, 2 events | XS2610000033 | bid | 8,000,000 | 99.8 | DLR-ONE |
| UAT-NEG-BESTEX-03-O88 | 2026-10-14 10:50:58 | order, fully displayed, 1 fill, 2 events | XS2610000033 | bid | 200,000 | 99.2 | CLT-GAMMA |

## Ordinary business

### UAT-CLEAN-01 — A day of ordinary two-way business across three product families

**Scenario under test.** A day of ordinary client and dealer business with nothing offsetting, cancelled or concentrated

14 documents. Expected: no alert from any metric.

**The scenario.** Fourteen trades on one day across three traders and three product families: bonds bought and sold with clients and dealers an hour or more apart, a CDS position taken and left on, two swaptions at different curve points, and two bond orders that filled normally.

**Why these trades.** Every other case in this pack is engineered, which means they say nothing on their own about what happens to normal business. This case is the control: ordinary sizes, ordinary spacing, two-way flow, real counterparties on both sides, nothing offsetting inside half an hour, nothing cancelled, nothing concentrated into the close. If anything fires here, the false positive rate on real data is not acceptable, and no amount of passing on the engineered cases would make up for it.

**The check that should stop it.** None in particular — the whole engine. This case passes only if every metric stays quiet on ordinary flow.

| Document | Timestamp | What it is | Instrument | Side | Amount | Price | Counterparty |
|---|---|---|---|---|---:|---:|---|
| UAT-CLEAN-01-O89 | 2026-10-15 08:29:58 | order, fully displayed, 1 fill, 2 events | XS2611000011 | bid | 5,000,000 | 99.9 | CLT-GAMMA |
| UAT-CLEAN-01-O90 | 2026-10-15 10:44:58 | order, fully displayed, 1 fill, 2 events | XS2611000011 | offer | 4,000,000 | 99.95 | DLR-ONE |
| UAT-CLEAN-01-O91 | 2026-10-15 13:29:58 | order, fully displayed, 1 fill, 2 events | XS2611000011 | bid | 6,000,000 | 99.92 | DLR-TWO |
| UAT-CLEAN-01-O92 | 2026-10-15 09:09:58 | order, fully displayed, 1 fill, 2 events | XS2611000022 | offer | 7,000,000 | 100.4 | CLT-ALPHA |
| UAT-CLEAN-01-O93 | 2026-10-15 12:19:58 | order, fully displayed, 1 fill, 2 events | XS2611000022 | bid | 7,000,000 | 100.35 | DLR-ONE |
| UAT-CLEAN-01-O94 | 2026-10-15 14:29:58 | order, fully displayed, 1 fill, 2 events | XS2611000022 | bid | 2,000,000 | 100.38 | DLR-TWO |
| UAT-CLEAN-01-O95 | 2026-10-15 09:59:58 | order, fully displayed, 1 fill, 2 events | XS2611000033 | bid | 3,000,000 | 100.1 | DLR-ONE |
| UAT-CLEAN-01-O96 | 2026-10-15 14:59:58 | order, fully displayed, 1 fill, 2 events | XS2611000033 | bid | 3,000,000 | 100.1 | CLT-ALPHA |
| UAT-CLEAN-01-C97 | 2026-10-15T11:00:00 | Credit.CDS | UATGRP SNRFOR 60M | buy protection | 25,000,000 | 0 | CLT-BETA |
| UAT-CLEAN-01-C98 | 2026-10-15T14:00:00 | Credit.CDS | UATGRP SNRFOR 60M | buy protection | 15,000,000 | 0 | DLR-ONE |
| UAT-CLEAN-01-C99 | 2026-10-15T11:30:00 | Credit.CDS | UATGRP SNRFOR 120M | sell protection | 20,000,000 | 0 | DLR-TWO |
| UAT-CLEAN-01-R100 | 2026-10-15T09:50:00 | IR.Swaption | UATESTR 2026-11-14→2031-11-15 | Pay | 150,000,000 | 2.8 | CLT-GAMMA |
| UAT-CLEAN-01-R101 | 2026-10-15T13:10:00 | IR.Swaption | UATESTR 2026-11-14→2028-11-14 | Receive | 120,000,000 | 2.6 | DLR-TWO |
| UAT-CLEAN-01-R102 | 2026-10-15T14:50:00 | IR.Swaption | UATESTR 2026-11-15→2031-11-15 | Receive | 60,000,000 | 2.8 | DLR-ONE |
