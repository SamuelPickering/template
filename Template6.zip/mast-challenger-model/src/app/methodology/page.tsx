import Link from "next/link";
import { METRICS } from "@/lib/config/metrics";
import { MIM_DEFAULTS } from "@/lib/models/mim";
import { IMPACT_K } from "@/lib/gen/universe";

export const dynamic = "force-dynamic";

export default function MethodologyPage() {
  return (
    <>
      <h1>Methodology</h1>

      <h2>1. Source documents in, normalised executions out</h2>
      <p>
        Data arrives as Master.Transaction documents in one of four product schemas: Credit
        (Credit.CDS), Rates (IR.Swaption, IR.CapFloor, IR.FRA), Fenics order streams
        (FixedIncome.Bond) and FX (FX.Spot). The documents are stored exactly as they arrive. A set
        of adapters then normalises each one into executions — and, for Fenics, into order streams —
        and everything downstream works on those.
      </p>
      <p>
        That is the whole reason the same detectors work across asset classes: by the time a metric
        sees a record it is a direction, a notional in USD, an instrument and a timestamp, whether
        it started life as a credit default swap or a currency trade.
      </p>
      <pre className="small">
        {`Credit.CDS        -> CDS:TICKER/TIER/TENOR   (spread, bps)
IR.Swaption       -> IR:USD SOFR/5Y          (rate, %)
IR.CapFloor       -> IR:EUR ESTR/10Y         (rate, %)
IR.FRA            -> IR:SEK FRA/3M           (rate, %)
FixedIncome.Bond  -> BOND:ISIN               (clean price)
FX.Spot           -> FX:EUR/USD + FX:JPY/USD (rate, USD per unit)`}
      </pre>
      <p>
        Two normalisation steps matter more than the rest. Tenors are bucketed onto standard curve
        points, so a CDS written at 58 months and one at 61 months meet on the same five-year
        instrument. And an FX trade is split into one execution per non-USD leg, so a position
        built through several pairs lands in one place.
      </p>

      <h2>2. One direction convention</h2>
      <p>
        Every execution gets a direction, and the convention is the same everywhere:{" "}
        <b>+1 means pressure that pushes the instrument&apos;s quoted level up</b>. Buying a bond
        raises its price, paying fixed raises the rate, buying protection widens the spread, buying
        a currency raises it against the dollar. Every metric that reasons about &quot;same
        direction&quot; or &quot;offsetting&quot; runs off that one rule.
      </p>
      <p>
        Swaptions carry PayOrReceive, caps and floors carry TradeType, and an FX trade names both
        currencies. Credit, FRAs and the Fenics order streams carry no side field, and for those
        the sign of the amount is the side: <b>a negative amount is a sell, a positive amount is a
        buy</b>. An import can still point at a dedicated side field where a feed has one.
      </p>

      <h2>3. The Market Impact Model</h2>
      <p>Buying pushes a level up, selling pushes it down. The model estimates by how much:</p>
      <pre className="small">
        {`level impact = K x volatility x (notional / ADTV)
impact(t)    = level impact x exp(-lambda x t)
value impact = level impact x valueFactor(instrument)`}
      </pre>
      <ul>
        <li>proportional to trade size</li>
        <li>proportional to the volatility of the instrument</li>
        <li>inversely proportional to average daily traded volume</li>
        <li>instantaneous, and additive across nearby trades</li>
        <li>
          decaying exponentially back toward zero — half-life {MIM_DEFAULTS.halfLifeMinutes} minutes
          here
        </li>
      </ul>
      <p>
        K is calibrated per asset class, because the same share of a day&apos;s volume moves a thin
        corporate bond far more than it moves a major currency: FX {IMPACT_K.fx}, credit{" "}
        {IMPACT_K.credit}, rates {IMPACT_K.rates}, bonds {IMPACT_K.fenics}.
      </p>
      <p>
        <b>The value conversion is what makes asset classes comparable.</b> For a bond price or an
        FX rate, a move in the level is a move in value. For a credit spread or an interest rate it
        is not: one basis point is worth a basis point of notional for every year of risk, so the
        level move is multiplied through by duration before it means anything in dollars. Without
        that step a 5% move on a 150bp spread and a 5% move on a bond price would score the same,
        and they are nothing like each other.
      </p>

      <h2>4. USD Value</h2>
      <p>
        Every metric ends in the same place: a dollar figure estimating what the trader was trying
        to gain — or, for Best Execution, what the client lost.
      </p>
      <pre className="small">USD Value = EMI x PTC</pre>
      <ul>
        <li>
          <b>EMI</b> — Expected Market Impact: the value impact through time of the action being
          scored.
        </li>
        <li>
          <b>PTC</b> — Profit-Taking Component: the position positioned to benefit from it.
        </li>
      </ul>
      <p>
        <b>The exhaustion principle:</b> where the benefiting position is larger than the trades
        that created the impact, only the portion the impact could plausibly have benefited counts,
        so the PTC is capped at the impacting notional.
      </p>
      <p>
        Wash Trading, Spoofing and Layering are scored differently, because the question is not how
        much impact was created but whether an innocent explanation exists. Those weigh a{" "}
        <b>Narrative</b> (what the abusive reading is worth) against a <b>Counter-Narrative</b>{" "}
        (genuine market risk run, real client business, the cost of actually being filled), and
        alert only where the Narrative dominates.
      </p>

      <h2>5. What each product can and cannot evidence</h2>
      <p>
        Not every metric can run on every schema, and the tool says so rather than inventing a
        number.
      </p>
      <table>
        <thead>
          <tr>
            <th>Limitation</th>
            <th>Consequence</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>CDS records carry upfront points, not a traded spread</td>
            <td>
              Off-Market Trading, Cross Trading and Best Execution skip credit. Everything that
              works off notional and direction — wash trading, ramping, front running, insider —
              runs on it normally.
            </td>
          </tr>
          <tr>
            <td>Swaption and cap strikes are negotiated contract terms, not prints against a mid</td>
            <td>The same three pricing metrics skip rates products.</td>
          </tr>
          <tr>
            <td>Only Fenics carries order-level data</td>
            <td>
              Spoofing and Layering run on bonds alone. An execution-only extract produces nothing
              for either, which the import page reports up front.
            </td>
          </tr>
          <tr>
            <td>Client and dealer counterparties both arrive as Counterparty.Professional</td>
            <td>
              Front Running and Best Execution need to know which business was a client&apos;s. The
              counterparty registry resolves it for generated data; an import can supply code or
              name patterns.
            </td>
          </tr>
          <tr>
            <td>Some source records arrive with incomplete Economics</td>
            <td>Those documents are counted and skipped rather than scored on a partial record.</td>
          </tr>
        </tbody>
      </table>

      <h2>6. The Allocation Algorithm</h2>
      <p>
        To know whether an execution built a position or simply filled a client order, you have to
        connect buys with sells. The allocation algorithm matches opposite-direction executions
        inside a book, on the heuristic that two are more likely to be a pair the closer they are in
        both timestamp and notional, with client facilitation prioritised. Matching is partial, and
        whatever cannot be explained as facilitation is treated as the firm&apos;s own risk — which
        is what Front Running and Ramping care about.
      </p>

      <h2>7. The Event Generator</h2>
      <p>
        Insider Trading needs something to be insider to. The simulation generates rating actions
        and profit warnings on credit names, rate decisions and inflation prints on the curves,
        issuer news on bonds and macro surprises on currencies — each with the instrument it moves,
        a signed move and the timestamp at which it became public. The move is applied as a step
        change at exactly that timestamp, so a position held into the announcement is worth
        precisely what the model says.
      </p>
      <p>
        The comparison is between the position a trader actually held and the position a fair trader
        could have been expected to hold. Position built well before the event is ordinary business;
        position built in the final hours is not, and it is that excess — valued at the move, in
        value terms — that scores.
      </p>

      <h2>8. The data behind all of this</h2>
      <p>
        Every trader, counterparty, instrument, level and event in the synthetic dataset is
        generated, and emitted in the production schemas rather than in a shape of its own. The
        overwhelming majority of it is ordinary business, including activity that structurally
        resembles abuse — a trader working a large order in clips and closing out later, an order
        placed and pulled because the market moved. That is the point: a pattern match alone
        produces noise, which is why everything is scored in dollars and compared against a
        threshold.
      </p>
      <p>
        A set of instances per metric is deliberately engineered, with three severity tiers for
        Ramping, Wash Trading, Front Running, Best Execution, Spoofing and Layering, plus disguised
        wash variants that hide the offset behind a different tenor, product, counterparty or
        currency pair. Those documents carry an internal tag used only to check coverage when
        testing — <b>no detection engine reads it</b>.
      </p>

      <h2>9. Proving it works, and proving it stays quiet</h2>
      <p>
        There are two test catalogues, and they ask different questions. The{" "}
        <Link href="/validation">Test Cases</Link> page checks that each behaviour engineered into
        the seeded population was found: one case per metric per severity tier, with the alert it
        actually produced. The <Link href="/uat">UAT Pack</Link> page runs a separate file of
        engineered trades that is imported rather than seeded, so the import path is exercised too,
        and most of its cases exist to prove the opposite point — that data which merely resembles
        abuse produces nothing.
      </p>
      <p>
        That second half matters more than the first. Thirteen of its cases require an alert;
        seventeen require silence. Two different instruments bought and sold at the same moment is
        not a wash trade. A position closed five hours later is not a wash trade. Buying from one
        client and selling to another is market making. A trade six hours after client business is
        not front running, because the modelled impact of that business has decayed through a dozen
        half-lives. An order that filled, or that rested at the touch for eleven minutes, is not a
        decoy. Each of those names the single check that should stop it, and the
        report re-scores the pack with that check relaxed, so that a case passing on silence can be
        shown to be silent for the stated reason rather than by accident.
      </p>

      <h2>The metrics</h2>
      {METRICS.map((m) => (
        <div key={m.id}>
          <h3>
            <Link href={`/alerts/${m.id}`}>{m.label}</Link>
          </h3>
          <p>{m.about}</p>
          <p className="note">Scoring: {m.usdValue}</p>
          <p className="note">Needs: {m.needs}</p>
        </div>
      ))}
    </>
  );
}
