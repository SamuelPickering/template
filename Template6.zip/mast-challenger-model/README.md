# MAST Challenger Model

A multi-asset trade-surveillance challenger model. It ingests trade and order data in the
production product schemas, normalises it, models the theoretical market impact of each execution,
and scores eleven kinds of market abuse in USD terms.

## Running it

```bash
npm install
npm run seed
npm run dev
```

Then open http://localhost:3000. `npm run seed` rebuilds `data/dataset.json` from scratch. There
are no native dependencies, so `npm install` never needs a compiler, and nothing is stored outside
`data/`.

| Command | What it does |
|---|---|
| `npm run seed` | Regenerate the whole synthetic dataset |
| `npm run qa` | Run the engine and print coverage: adapter notes, per-metric counts, per-scenario recall, background false positives, threshold sweeps |
| `npm run dev` | Start the app |
| `npx tsx scripts/make-sample-json.ts` | Write sample extracts to `samples/`, one per product family, for exercising the import |
| `npx tsx scripts/explain-detection.ts samples/sample-fenics.json` | Walk a JSON extract through the Spoofing, Layering and Best Execution logic, printing every gate and every intermediate number |
| `npm run report` | Run the test catalogue and write the report to `reports/` (add `-- --json` for JSON) |
| `npm run uat:pack` | Rebuild the UAT pack in `uat/`: the importable file of engineered trades and the two documents describing it |
| `npm run uat:load` | Import that pack from the command line, without opening the app |
| `npm run uat:report` | Run the UAT cases and write the results to `reports/` (`-- --json`, or `-- --out <path>`) |

Seeding env overrides: `MAST_END_DATE` (default `2026-10-09`), `MAST_DAYS` (65), `MAST_SEED`
(20260101), `MAST_DATA_DIR`.

## Product schemas

Data arrives as `Master.Transaction` documents in one of four schemas. The documents are stored
exactly as they arrive; adapters normalise them into executions and order streams, and every
detector works on those.

| Family | Product types | Instrument key | Notes |
|---|---|---|---|
| Credit | `Credit.CDS` | `CDS:TICKER/TIER/TENOR` | `Identifier.Ticker` optional (absent → `NOTICKER`); `Tenor` is a string, bucketed onto standard curve points; `Economics.Price` is upfront points, not a spread |
| Rates | `IR.Swaption`, `IR.CapFloor`, `IR.FRA` | `IR:INDEX/TENOR` | Polymorphic `Economics`; incomplete records are counted and skipped; FRAs carry no fixing index and map to their own short-dated points |
| Fenics | `FixedIncome.Bond` | `BOND:ISIN` | `Execution.OrderStream` with an `Events` array (OpenLimitOrder, Amendment, Fill, Close); numbers are strings, timestamps are microsecond and zone-less; each Fill becomes an execution |
| FX | `FX.Spot` | `FX:CCY/USD` | Split into one execution per non-USD leg, so a position built across pairs lands on one instrument |

**Direction convention:** `+1` means pressure that pushes the instrument's quoted level up —
buying a bond, paying fixed, buying protection, buying a currency. Swaptions (`PayOrReceive`),
caps and floors (`TradeType`) and FX carry an explicit side. Credit, FRAs and Fenics orders do
not, and for those the sign of the amount is the side: **negative sells, positive buys**.

**Value conversion:** a move in a level is not a move in value. Bond prices and FX rates convert
1:1; credit spreads and interest rates are multiplied through by duration first. Without that step
asset classes are not comparable in dollars.

## Metrics

Insider Trading · Front Running · Internal Front Running · Ramping · Banging the Close ·
Wash Trading (plain, cross-tenor, cross-product, multi-counterparty, cross-currency) ·
Cross Trading · Off-Market Trading · **Spoofing** · **Layering** · **Best Execution**

Spoofing and Layering are separate metrics with separate thresholds: spoofing scores one
conspicuous order pulled unfilled, layering scores a ladder across several price levels. Both need
order-level data, so they run on Fenics only.

Not every metric can run on every schema, and the tool says so rather than inventing a number:

- Off-Market Trading, Cross Trading and Best Execution need a real execution price, which rules
  out CDS (upfront points) and rates (negotiated strikes).
- Spoofing and Layering need order data; an execution-only extract produces nothing.
- Front Running and Best Execution need to know which business was a client's. Both client and
  dealer counterparties arrive as `Counterparty.Professional`, so an import can supply code or
  name patterns.

## How it fits together

```
source documents (4 schemas)
        │  adapters
        ▼
executions + order streams on canonical instruments
        │
        ├──► Market Impact Model (per-asset-class K, value conversion) ─┐
        ├──► Allocation Algorithm ───────────────────────────────────────┼──► detector ──► USD Value
        └──► Event Generator ───────────────────────────────────────────┘        │
                                             live threshold ◄───────────────────┘
```

- **`src/lib/schema/`** — the product registry (instrument keys, tenor buckets, direction rules)
  and the adapters that normalise each schema.
- **`src/lib/models/`** — Market Impact Model, Allocation Algorithm, market reference data, USD
  Value.
- **`src/lib/detect/`** — one module per metric, plus `engine.ts`.
- **`src/lib/gen/`** — synthetic generation: universe, market series, documents in each schema,
  background flow, engineered scenarios.
- **`src/lib/import/`** — import parsing, analysis and metric coverage reporting.

Detection is live, not snapshotted: the run key is `data fingerprint + config hash`, so editing a
threshold re-runs the whole pipeline.

## Test cases

Every behaviour the tool claims to detect has a test case: what is being tested, the scenario
planted in the data, what should trigger, and what the resulting alert has to show an
investigator. The **Test Cases** page runs the whole catalogue against the live configuration and
shows the alert each case actually produced, with a downloadable report in Markdown or JSON.
`npm run report` writes the same report from the command line.

Cases are matched to results through the `scenario_tag` on the planted documents. **No detection
engine reads that tag**, so a pass means the behaviour was found from trade and order data alone.
The report also carries the evidence that the thresholds matter: severity tiers coming out in
order, alert counts as each threshold moves, and how many alerts came from ordinary business
rather than planted scenarios.

## The UAT pack

The test cases above are planted in the seeded data. The **UAT pack** is the same idea done through
the front door: a file of engineered trades in `uat/mast-uat-synthetic-trades.json` that is
*imported* rather than seeded, so importing is itself part of what gets tested. The **UAT Pack**
page reports on it, and `npm run uat:report` writes the same thing to a file.

30 cases, and the split is the point:

- **13 cases must raise an alert** — layering, spoofing, wash trading, front running and best
  execution, each at two or three sizes so that one of them sits just above the threshold.
- **17 cases must raise nothing**, because a tool that alerts on everything is as useless as one
  that alerts on nothing. Two different bonds bought and sold at the same moment is not a wash. A
  position closed five hours later is not a wash. Buying from one client and selling to another is
  not a wash. A trade six hours after client business is not front running. An order that filled,
  or rested for eleven minutes, is not a spoof. Five orders at one price are
  not a ladder. A client who got the *better* price has suffered no detriment.

Each negative case names the single check that should stop it, and the report then re-scores the
pack with that check relaxed — so "no alert" becomes "no alert, for the stated reason". Relaxing
the cancel-ratio floor makes the ladder case alert at $31,010; relaxing the materiality floor makes
the best-execution case alert at $37,632; stretching the front-running lead time to seven hours
prices the six-hour-later trade at $9, because the modelled impact has decayed through twelve
half-lives.

`uat/` holds the pack, what each case tests and why those particular trades were built
(`UAT-test-cases.md`, `UAT-trade-design.md`), and a recorded results run (`UAT-results.md`).

### Changing the test cases

A case is two halves, and they are edited in different places:

- **The description and the verdict rule** — what is being tested, the scenario, why those trades,
  and whether the metric must alert or must stay silent. Edited in the app at **UAT Pack → Edit the
  test cases**: add, edit, switch off, restore, reset. Changes are written to
  `uat/uat-cases.custom.json`, a plain file you can read, commit or delete; the cases that ship stay
  in `src/lib/testing/uatCases.ts`, so an update never silently drops yours. No file means no local
  changes.
- **The trades** — matched to a case by a `QA.TestCase` marker on each document. Any file works, as
  long as the marker is on it and it is imported as *synthetic test data* with "add to what is
  already in this bucket" ticked. The editor hands out a starter file already carrying the new
  case's marker, which imports as a passing wash trade so you can confirm the plumbing before
  editing it into whatever you actually want to test.

Trades carrying a marker no case claims are listed on both pages as *trades with no case written
for them*, with a button to describe them — which is the usual order of events: import first,
describe second.

Editing the built-in trades instead means editing `src/lib/testing/uatPack.ts` and re-running
`npm run uat:pack`.

## Working with imported data

A dataset switch sits in the header on every page, with four views over three storage buckets:

| View | What is in scope |
|---|---|
| Synthetic (seeded) | the seeded simulation only |
| Synthetic + imported | the seeded simulation plus an imported synthetic pack, scored together |
| Imported synthetic only | an imported pack on its own — no seeded trades |
| Production import only | imported production data on its own |

Importing asks which kind of file it is, and that answer is a statement by whoever is importing
rather than something sniffed from the file. Production data lands in its own bucket and is never
mixed with anything synthetic; there is no view that combines them. Synthetic test data may carry a
`QA.TestCase` marker naming the case it belongs to, which is read only on a synthetic import and
never by a detector.

Everything in the active dataset is browsable whether or not it alerts. The blotter has two views,
**Executions** and **Orders**, both filterable by trader, family, product, instrument, date and
role, and searchable by ID, trader, counterparty, ISIN or book. Orders matter on an order-driven
feed: an order that was placed and pulled never becomes an execution, but it is exactly what
Layering and Spoofing are about. The traders page is built from the data itself, so an imported
extract lists its own trader IDs and nothing else.

**Instruments not in the reference universe** — which is most of them in a real extract — have
reference data derived from the file: the level is what the data was printing, while volatility and
traded volume are asset-class defaults. Without that step a perfectly ordinary bond fill at 99.23
would be compared against a level of 1 and flagged as thousands of basis points off-market. The
import preview lists every derived instrument so the assumption is visible.

## Reading the detection logic

`scripts/explain-detection.ts` is a self-contained walkthrough: give it a JSON extract and it
normalises the documents, derives a market level, then runs the Spoofing, Layering and Best
Execution checks, printing each gate with its numbers and the arithmetic behind the score. Point it
at a Credit or Rates extract and it explains why those three cannot be evidenced from
execution-only data. It mirrors `src/lib/detect/{spoofing,layering,bestExecution}.ts`, with the
instrument reference data replaced by stated assumptions so it can run on its own.

## Importing production data

The Import page takes a JSON extract (array, single document, wrapper object or newline-delimited),
lets you state the product type or detect it per document, and reports what the adapters made of it
— documents by family, executions, order streams, how much of the direction and counterparty
classification is known rather than assumed, rejected records with reasons, and a per-metric
coverage table. Nothing is committed until you have seen that.

Generated and imported data travel the same adapters, so anything that works on the synthetic
dataset works on a real extract of the same shape.

## Scenario tags

Engineered documents carry a `scenario_tag` (e.g. `layering_major`, or a UAT case id). **No
detector reads it.** It exists so `npm run qa` can check that each engineered instance was found
independently, and to show how much of the alert population comes from ordinary background flow.
Ramping, Wash Trading, Front Running, Best Execution, Spoofing and Layering each have three
severity tiers.

The field mappings an import was committed with — which counterparty codes are clients, where the
side or the trader name lives — are stored against the bucket and re-applied when the detectors
run, not just in the preview. Typing client patterns and then finding Front Running silent because
detection re-read the file without them would be worse than useless.
