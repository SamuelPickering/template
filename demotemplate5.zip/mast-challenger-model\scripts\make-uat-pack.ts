import fs from "node:fs";
import path from "node:path";
import {
  UAT_CLIENT_PATTERNS,
  UAT_COUNTERPARTIES,
  UAT_DAYS,
  UAT_DEALER_PATTERNS,
  UAT_PACK_NAME,
  UAT_PACK_VERSION,
  UAT_TRADERS,
  uatDocumentsByCase,
  uatPackFile,
} from "@/lib/testing/uatPack";
import { UAT_CASES, UAT_GROUPS } from "@/lib/testing/uatCases";
import { METRIC_BY_ID } from "@/lib/config/metrics";

/**
 * Writes the UAT pack and the two documents that go with it:
 *
 *   mast-uat-synthetic-trades.json   the importable file
 *   UAT-test-cases.md                what each case tests and why
 *   UAT-trade-design.md              every trade in the file, by case, and the
 *                                    reason it is shaped the way it is
 *
 * The results are not written here — they come from running the detectors,
 * which is `npm run uat:report` or the UAT page in the app.
 */
const OUT = path.join(process.cwd(), "uat");
fs.mkdirSync(OUT, { recursive: true });

const generated = new Date().toISOString();
const pack = uatPackFile(generated);
const byCase = uatDocumentsByCase();

/* ---------------- the file ---------------- */

const jsonPath = path.join(OUT, "mast-uat-synthetic-trades.json");
fs.writeFileSync(jsonPath, JSON.stringify(pack, null, 2) + "\n");

/* ---------------- what each case tests ---------------- */

const cases: string[] = [];
cases.push("# UAT test cases");
cases.push("");
cases.push(
  "Every behaviour this tool claims to detect, and — just as important — the patterns that resemble those " +
    "behaviours and must not be flagged. The trades for all of them are in " +
    "`mast-uat-synthetic-trades.json`, which is imported on the Import page as synthetic test data.",
);
cases.push("");
cases.push(
  `${UAT_CASES.filter((c) => c.expect === "alert").length} cases must raise an alert. ` +
    `${UAT_CASES.filter((c) => c.expect === "no_alert").length} cases must not. ` +
    `${byCase.size} groups of trades, ${pack.Transactions.length} documents in total.`,
);
cases.push("");
cases.push(
  "A tool that alerts on everything is as useless as one that alerts on nothing, so each negative case is " +
    "built to sit one step away from a real pattern and names the single check that should stop it. " +
    "Results — pass or fail, with the trades that were analysed and the alert text where one was raised — " +
    "come from the UAT page in the app, or from `npm run uat:report`.",
);
cases.push("");

cases.push("## The cases");
cases.push("");
cases.push("| Case | Behaviour | Metric | Expected |");
cases.push("|---|---|---|---|");
for (const c of UAT_CASES) {
  cases.push(
    `| ${c.id} | ${c.title} | ${METRIC_BY_ID[c.metric].label} | ${
      c.expect === "alert" ? "**alert**" : "no alert" }  |`,
  );
}
cases.push("");

for (const g of UAT_GROUPS) {
  const inGroup = UAT_CASES.filter((c) => c.group === g.name);
  if (!inGroup.length) continue;
  cases.push(`## ${g.name}`);
  cases.push("");
  cases.push(g.blurb);
  cases.push("");
  for (const c of inGroup) {
    cases.push(`### ${c.id} — ${c.title}`);
    cases.push("");
    cases.push(
      `**Expected result:** ${
        c.expect === "alert" ? `a ${METRIC_BY_ID[c.metric].label} alert` : "no alert from any metric"
      }. **Products:** ${c.families.join(", ")}.${c.tier ? ` **Size:** ${c.tier}.` : ""}`,
    );
    cases.push("");
    cases.push(`**What is being tested.** ${c.tests}`);
    cases.push("");
    cases.push(`**Scenario.** ${c.scenario}`);
    cases.push("");
    cases.push(`**Why these trades.** ${c.rationale}`);
    cases.push("");
    cases.push(`**Expected.** ${c.expected}`);
    cases.push("");
    if (c.gate) {
      cases.push(`**The check that should stop it.** ${c.gate}`);
      cases.push("");
    }
  }
}

fs.writeFileSync(path.join(OUT, "UAT-test-cases.md"), cases.join("\n"));

/* ---------------- the trades, and why ---------------- */

const fmt = (v: unknown) =>
  typeof v === "number"
    ? Math.abs(v) >= 1000
      ? Math.round(v).toLocaleString("en-US")
      : String(v)
    : String(v ?? "-");

interface Row {
  id: string;
  time: string;
  what: string;
  instrument: string;
  side: string;
  amount: string;
  price: string;
  counterparty: string;
}

/** Reads the document back, so the design note describes the file itself. */
function describe(payload: Record<string, unknown>): Row {
  const exec = payload.Execution as Record<string, unknown>;
  const econ = (exec.Economics ?? {}) as Record<string, unknown>;
  const cp = (exec.Counterparty ?? {}) as Record<string, unknown>;
  const type = String(econ.Type ?? exec.Type ?? "");

  if (exec.Type === "Execution.OrderStream") {
    const events = (exec.Events ?? []) as Record<string, unknown>[];
    const open = events.find((e) => e.Type === "OrderEvent.OpenLimitOrder") ?? {};
    const fills = events.filter((e) => e.Type === "OrderEvent.Fill");
    const closed = events.some((e) => e.Type === "OrderEvent.Close");
    const total = Number(open.TotalAmount ?? 0);
    const display = Number(open.DisplayAmount ?? total);
    const ident = (econ.Identifier ?? {}) as Record<string, unknown>;
    return {
      id: String(exec.OrderMessageID ?? ""),
      time: String(open.EventDateTime ?? exec.OrderStartDate ?? "").slice(0, 19),
      what:
        `order, ${display === total ? "fully displayed" : `${fmt(Math.abs(display))} of ${fmt(Math.abs(total))} displayed`}` +
        `, ${fills.length ? `${fills.length} fill${fills.length > 1 ? "s" : ""}` : "no fills"}` +
        `${closed ? ", cancelled" : ""}` +
        `, ${events.length} events`,
      instrument: String(ident.ISINCode ?? ""),
      side: Number(total) < 0 ? "offer" : "bid",
      amount: fmt(Math.abs(Number(total))),
      price: open.LimitPrice === undefined ? "-" : String(Number(open.LimitPrice)),
      counterparty: [
        ...new Set(
          fills.map((f) =>
            String(((f.Counterparty ?? {}) as Record<string, unknown>).CounterpartyCode ?? "-"),
          ),
        ),
      ].join(", "),
    };
  }

  const ident = (econ.Identifier ?? {}) as Record<string, unknown>;
  const notional = Number(econ.Notional ?? 0);
  return {
    id: String(exec.TradeID ?? ""),
    time: String(exec.TradeDate ?? "").slice(0, 19),
    what: type,
    instrument:
      type === "Credit.CDS"
        ? `${ident.Ticker ?? "?"} ${ident.Tier ?? ""} ${ident.Tenor ?? ""}`
        : `${((econ.FixingIndex ?? {}) as Record<string, unknown>).FixingIndex ?? ""} ${String(
            econ.SwapStartDate ?? "",
          ).slice(0, 10)}→${String(econ.SwapEndDate ?? "").slice(0, 10)}`,
    side:
      type === "Credit.CDS"
        ? notional < 0
          ? "sell protection"
          : "buy protection"
        : String(econ.PayOrReceive ?? (notional < 0 ? "sell" : "buy")),
    amount: fmt(Math.abs(notional)),
    price: String(econ.SwaptionStrike ?? econ.Strike ?? econ.FixedRate ?? econ.Price ?? "-"),
    counterparty: String(cp.CounterpartyCode ?? "-"),
  };
}

const design: string[] = [];
design.push("# UAT pack — the trades, and why they are shaped this way");
design.push("");
design.push(
  `Generated ${generated} by \`npm run uat:pack\`. ${pack.Transactions.length} Master.Transaction documents ` +
    `across ${byCase.size} test cases, in the Credit, Rates and Fenics product schemas.`,
);
design.push("");
design.push(
  "This document exists so that nothing in the pack has to be taken on trust. For every case it lists the " +
    "trades that were built, exactly as they appear in the file, and the reasoning behind them — why those " +
    "sizes, why those timestamps, why those counterparties. Where a case is supposed to produce silence, the " +
    "reasoning is about what was deliberately left out or set just inside a limit.",
);
design.push("");

design.push("## How the pack is laid out");
design.push("");
design.push(
  `- **${UAT_DAYS.positive}** — the cases that must raise an alert.\n` +
    `- **${UAT_DAYS.negative}** — the cases that must not.\n` +
    `- **${UAT_DAYS.clean}** — a day of ordinary business, which must produce nothing at all.`,
);
design.push("");
design.push(
  "One instrument per case, because the reference level for an instrument the tool has never seen is derived " +
    "from the prices in the file — sharing an instrument between two cases would let one case move the other's " +
    "market level. Trades are kept clear of the 16:00 close so Banging the Close has nothing to say about them, " +
    "and no trader holds five or more executions in one instrument on one day unless the case is about ramping, " +
    "which is where that detector starts looking.",
);
design.push("");

design.push("## Traders");
design.push("");
design.push("| Trader | Name | Used for |");
design.push("|---|---|---|");
for (const t of UAT_TRADERS) design.push(`| ${t.trader_id} | ${t.name} | ${t.note} |`);
design.push("");
design.push("## Counterparties");
design.push("");
design.push(
  "The product schemas have no field that separates a client from a dealer, and Front Running and Best " +
    "Execution both turn on that distinction. The pack therefore follows a convention and declares it in the " +
    "file's own envelope: " +
    `clients match ${UAT_CLIENT_PATTERNS.map((p) => `\`${p}\``).join(", ")}, dealers match ` +
    `${UAT_DEALER_PATTERNS.map((p) => `\`${p}\``).join(", ")}, and an internal book is recognised from its ` +
    "`INT` prefix without needing to be told. On a real extract the same job is done by the counterparty " +
    "registry, or by typing patterns into the import page.",
);
design.push("");
design.push("| Code | Name | Treated as |");
design.push("|---|---|---|");
for (const c of UAT_COUNTERPARTIES) {
  design.push(`| ${c.counterparty_code} | ${c.name} | ${c.kind} |`);
}
design.push("");

for (const g of UAT_GROUPS) {
  const inGroup = UAT_CASES.filter((c) => c.group === g.name);
  if (!inGroup.length) continue;
  design.push(`## ${g.name}`);
  design.push("");
  for (const c of inGroup) {
    const docs = byCase.get(c.id) ?? [];
    design.push(`### ${c.id} — ${c.title}`);
    design.push("");
    design.push(
      `${docs.length} document${docs.length === 1 ? "" : "s"}. Expected: ${
        c.expect === "alert" ? `a ${METRIC_BY_ID[c.metric].label} alert` : "no alert from any metric"
      }.`,
    );
    design.push("");
    design.push(`**The scenario.** ${c.scenario}`);
    design.push("");
    design.push(`**Why these trades.** ${c.rationale}`);
    design.push("");
    if (c.gate) {
      design.push(`**The check that should stop it.** ${c.gate}`);
      design.push("");
    }
    design.push("| Document | Timestamp | What it is | Instrument | Side | Amount | Price | Counterparty |");
    design.push("|---|---|---|---|---|---:|---:|---|");
    for (const d of docs) {
      const r = describe(d.payload as Record<string, unknown>);
      design.push(
        `| ${r.id} | ${r.time} | ${r.what} | ${r.instrument} | ${r.side} | ${r.amount} | ${r.price} | ${r.counterparty} |`,
      );
    }
    design.push("");
  }
}

fs.writeFileSync(path.join(OUT, "UAT-trade-design.md"), design.join("\n"));

const tagged = pack.Transactions.filter(
  (t) => (t.QA as Record<string, unknown> | undefined)?.TestCase,
).length;

console.log(`${UAT_PACK_NAME} v${UAT_PACK_VERSION}`);
console.log(`  ${jsonPath}`);
console.log(`    ${pack.Transactions.length} documents, ${tagged} carrying a QA.TestCase marker`);
console.log(`    ${byCase.size} cases of ${UAT_CASES.length} catalogued`);
console.log(`  ${path.join(OUT, "UAT-test-cases.md")}`);
console.log(`  ${path.join(OUT, "UAT-trade-design.md")}`);

const missing = UAT_CASES.filter((c) => !byCase.has(c.id)).map((c) => c.id);
if (missing.length) {
  console.error(`\nNo trades were built for: ${missing.join(", ")}`);
  process.exit(1);
}
