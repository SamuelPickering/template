import { loadDocuments } from "@/lib/db/repo";
import { runAnalysis } from "@/lib/detect/engine";
import { getConfig } from "@/lib/config/store";
import type { Dataset } from "@/lib/datasets";
import { METRICS, METRIC_BY_ID, type MetricId } from "@/lib/config/metrics";
import type { Instance } from "@/lib/detect/types";
import { TEST_CASES, type TestCase } from "./cases";

/**
 * The validation run.
 *
 * Executes the whole detection pipeline against the synthetic dataset and
 * checks each catalogued behaviour against what actually came out. A case
 * passes when the expected metric raised an alert containing the documents
 * that scenario planted — and the detectors cannot see which documents those
 * are, so a pass is evidence the behaviour was found from the data.
 */
export interface CaseResult {
  testCase: TestCase;
  status: "pass" | "fail";
  /** Engineered documents carrying this scenario tag. */
  documents: number;
  /** Alerts of the expected metric built from those documents. */
  alerts: number;
  usdValues: number[];
  minUsd: number;
  maxUsd: number;
  medianUsd: number;
  threshold: number;
  /** Other metrics that also fired on the same documents. */
  alsoFlaggedBy: string[];
  example?: {
    instance_id: string;
    usd_value: number;
    headline: string;
    explanation: string;
    trader_name: string;
    instrument_label: string;
    trade_date: string;
    components: { label: string; value: string | number; unit: string }[];
  };
  reason?: string;
}

export interface TierCheck {
  metric: MetricId;
  label: string;
  ordered: boolean;
  tiers: { tier: string; median: number }[];
}

export interface ThresholdPoint {
  threshold: number;
  alerts: number;
}

export interface ValidationReport {
  generated_at: string;
  dataset: string;
  documents: number;
  executions: number;
  orders: number;
  total_alerts: number;
  results: CaseResult[];
  summary: { total: number; passed: number; failed: number };
  metrics: {
    metric: MetricId;
    label: string;
    threshold: number;
    instances: number;
    alerts: number;
    cases: number;
    casesPassed: number;
  }[];
  tierChecks: TierCheck[];
  /** Alerts containing no engineered document — ordinary flow that scored. */
  backgroundAlerts: { metric: MetricId; label: string; background: number; total: number }[];
  thresholdSweeps: { metric: MetricId; label: string; points: ThresholdPoint[] }[];
}

const docIdOfExec = (execId: string) => execId.split(":")[0];

function median(xs: number[]): number {
  if (!xs.length) return 0;
  const s = xs.slice().sort((a, b) => a - b);
  return s[Math.floor(s.length / 2)];
}

/** Tags attached to the documents an alert was built from. */
function tagsOf(alert: Instance, tagOfDoc: Map<string, string>): Set<string> {
  const tags = new Set<string>();
  for (const id of alert.exec_ids) {
    const t = tagOfDoc.get(docIdOfExec(id));
    if (t) tags.add(t);
  }
  for (const id of alert.order_ids) {
    const t = tagOfDoc.get(id);
    if (t) tags.add(t);
  }
  return tags;
}

/**
 * These cases describe behaviours engineered into the seeded population, so
 * they are always scored against it rather than against whatever view happens
 * to be on screen. The imported test pack has its own catalogue and its own
 * page; running one against the other would just report that the trades are
 * missing.
 */
const VALIDATION_DATASET: Dataset = "synthetic";

export function runValidation(): ValidationReport {
  const dataset = VALIDATION_DATASET;
  const cfg = getConfig();
  const run = runAnalysis({ config: cfg, dataset });

  // Documents are matched to cases by their scenario tag. Detectors never read
  // it; it exists only so this report can be written.
  const tagged = loadDocuments(dataset).filter((d) => d.scenario_tag);
  const tagOfDoc = new Map(tagged.map((d) => [d.doc_id, d.scenario_tag as string]));
  const docsPerTag = new Map<string, number>();
  for (const d of tagged) {
    docsPerTag.set(d.scenario_tag as string, (docsPerTag.get(d.scenario_tag as string) ?? 0) + 1);
  }

  // Index alerts by the tags they touch.
  const alertsByTag = new Map<string, Instance[]>();
  for (const a of run.alerts) {
    for (const tag of tagsOf(a, tagOfDoc)) {
      const arr = alertsByTag.get(tag) ?? [];
      arr.push(a);
      alertsByTag.set(tag, arr);
    }
  }

  const results: CaseResult[] = TEST_CASES.map((testCase) => {
    const threshold =
      run.stats.find((s) => s.metric === testCase.metric)?.threshold ?? 0;
    const documents = docsPerTag.get(testCase.tag) ?? 0;
    const touching = alertsByTag.get(testCase.tag) ?? [];
    const onMetric = touching
      .filter((a) => a.metric === testCase.metric)
      .sort((a, b) => b.usd_value - a.usd_value);
    const usdValues = onMetric.map((a) => a.usd_value);
    const alsoFlaggedBy = [
      ...new Set(
        touching.filter((a) => a.metric !== testCase.metric).map((a) => METRIC_BY_ID[a.metric].label),
      ),
    ];

    const status: CaseResult["status"] = onMetric.length > 0 ? "pass" : "fail";
    const example = onMetric[0];

    return {
      testCase,
      status,
      documents,
      alerts: onMetric.length,
      usdValues,
      minUsd: usdValues.length ? Math.min(...usdValues) : 0,
      maxUsd: usdValues.length ? Math.max(...usdValues) : 0,
      medianUsd: median(usdValues),
      threshold,
      alsoFlaggedBy,
      example: example
        ? {
            instance_id: example.instance_id,
            usd_value: example.usd_value,
            headline: example.headline,
            explanation: example.explanation,
            trader_name: example.trader_name,
            instrument_label: example.instrument_label,
            trade_date: example.trade_date,
            components: example.components.map((c) => ({
              label: c.label,
              value: c.value,
              unit: c.unit,
            })),
          }
        : undefined,
      reason:
        status === "pass"
          ? undefined
          : documents === 0
            ? "No documents carrying this scenario tag are present in the dataset."
            : `${documents} documents were planted but no ${METRIC_BY_ID[testCase.metric].label} alert was raised from them at the current threshold of ${threshold}.`,
    };
  });

  // Severity tiers should come out in order: barely < significant < major.
  const tierChecks: TierCheck[] = [];
  const tiered = new Map<MetricId, { tier: string; median: number }[]>();
  for (const r of results) {
    if (!r.testCase.tier) continue;
    const arr = tiered.get(r.testCase.metric) ?? [];
    arr.push({ tier: r.testCase.tier, median: r.medianUsd });
    tiered.set(r.testCase.metric, arr);
  }
  for (const [metric, rows] of tiered) {
    const order = ["barely", "significant", "major"];
    const sorted = rows.slice().sort((a, b) => order.indexOf(a.tier) - order.indexOf(b.tier));
    const ordered = sorted.every(
      (row, i) => i === 0 || row.median > sorted[i - 1].median,
    );
    tierChecks.push({ metric, label: METRIC_BY_ID[metric].label, ordered, tiers: sorted });
  }

  // How much of each metric's alert population came from ordinary flow.
  const backgroundAlerts = run.stats.map((s) => {
    const forMetric = run.alerts.filter((a) => a.metric === s.metric);
    const background = forMetric.filter((a) => tagsOf(a, tagOfDoc).size === 0).length;
    return { metric: s.metric, label: s.label, background, total: forMetric.length };
  });

  // Moving a threshold must change what alerts; this is the evidence.
  const sweepMetrics: MetricId[] = [
    "ramping",
    "wash_trading",
    "front_running",
    "spoofing",
    "layering",
    "best_execution",
  ];
  const thresholdSweeps = sweepMetrics.map((metric) => ({
    metric,
    label: METRIC_BY_ID[metric].label,
    points: [5_000, 15_000, 50_000, 250_000, 1_000_000].map((threshold) => {
      const cfg2 = structuredClone(cfg);
      cfg2[metric].threshold_usd_value = threshold;
      const r = runAnalysis({ config: cfg2, dataset });
      return {
        threshold,
        alerts: r.stats.find((s) => s.metric === metric)?.alerts ?? 0,
      };
    }),
  }));

  const passed = results.filter((r) => r.status === "pass").length;

  return {
    generated_at: new Date().toISOString(),
    dataset,
    documents: run.documents,
    executions: run.executions,
    orders: run.orders,
    total_alerts: run.alerts.length,
    results,
    summary: { total: results.length, passed, failed: results.length - passed },
    metrics: METRICS.map((m) => {
      const s = run.stats.find((x) => x.metric === m.id)!;
      const cases = results.filter((r) => r.testCase.metric === m.id);
      return {
        metric: m.id,
        label: m.label,
        threshold: s.threshold,
        instances: s.instances,
        alerts: s.alerts,
        cases: cases.length,
        casesPassed: cases.filter((c) => c.status === "pass").length,
      };
    }),
    tierChecks,
    backgroundAlerts,
    thresholdSweeps,
  };
}

/* ------------------------------------------------------------------ */
/* Report rendering                                                    */
/* ------------------------------------------------------------------ */

const usd = (v: number) => "$" + Math.round(v).toLocaleString("en-US");

/** Renders a component value the way the alert page does. */
export function formatComponentValue(value: string | number, unit: string): string {
  if (typeof value === "string") return value;
  switch (unit) {
    case "usd":
      return usd(value);
    case "bps":
      return `${value.toFixed(2)} bps`;
    case "ratio":
      return `${(value * 100).toFixed(1)}%`;
    case "percent":
      return `${value > 0 ? "+" : ""}${value.toFixed(2)}%`;
    case "duration": {
      const abs = Math.abs(value);
      if (abs < 1000) return `${abs.toFixed(0)} ms`;
      if (abs < 90_000) return `${(abs / 1000).toFixed(1)} s`;
      if (abs < 5_400_000) return `${(abs / 60_000).toFixed(1)} min`;
      return `${(abs / 3_600_000).toFixed(1)} h`;
    }
    case "level":
      return value.toFixed(Math.abs(value) >= 10 ? 3 : 5);
    default:
      return value.toLocaleString("en-US");
  }
}

export function renderMarkdown(report: ValidationReport): string {
  const L: string[] = [];
  L.push("# Market abuse detection — test report");
  L.push("");
  L.push(`Generated: ${report.generated_at}`);
  L.push("");
  L.push(
    `**${report.summary.passed} of ${report.summary.total} test cases passed.** ` +
      `Dataset: ${report.dataset}, ${report.documents.toLocaleString("en-US")} source documents ` +
      `(${report.executions.toLocaleString("en-US")} executions, ${report.orders.toLocaleString("en-US")} order streams), ` +
      `${report.total_alerts} alerts at the current thresholds.`,
  );
  L.push("");
  L.push(
    "Each case plants a known behaviour in the data and checks that the expected metric found it. " +
      "The planted documents carry an internal scenario tag used only to write this report — " +
      "no detection engine reads it, so a pass means the behaviour was found from trade and order data alone.",
  );
  L.push("");

  L.push("## Coverage by metric");
  L.push("");
  L.push("| Metric | Threshold | Cases | Passed | Instances scored | Alerts |");
  L.push("|---|---:|---:|---:|---:|---:|");
  for (const m of report.metrics) {
    L.push(
      `| ${m.label} | ${usd(m.threshold)} | ${m.cases} | ${m.casesPassed} | ${m.instances} | ${m.alerts} |`,
    );
  }
  L.push("");

  L.push("## Test cases");
  L.push("");
  for (const r of report.results) {
    const c = r.testCase;
    L.push(`### ${c.id} — ${c.title}`);
    L.push("");
    L.push(`**Result:** ${r.status === "pass" ? "PASS" : "FAIL"}`);
    L.push("");
    L.push(`- **Metric:** ${METRIC_BY_ID[c.metric].label}`);
    L.push(`- **Products:** ${c.families.join(", ")}`);
    L.push(`- **Documents planted:** ${r.documents}`);
    L.push(
      `- **Alerts raised:** ${r.alerts}` +
        (r.alerts
          ? ` (USD Value ${usd(r.minUsd)} to ${usd(r.maxUsd)}, median ${usd(r.medianUsd)}, threshold ${usd(r.threshold)})`
          : ""),
    );
    if (r.alsoFlaggedBy.length) {
      L.push(`- **Also flagged by:** ${r.alsoFlaggedBy.join(", ")}`);
    }
    L.push("");
    L.push(`**What is being tested.** ${c.tests}`);
    L.push("");
    L.push(`**Scenario.** ${c.scenario}`);
    L.push("");
    L.push(`**Expected.** ${c.expected}`);
    L.push("");
    L.push(`**Evidence the alert must show.** ${c.evidence}`);
    L.push("");
    if (r.example) {
      L.push(`**What actually triggered.** ${r.example.headline}`);
      L.push("");
      L.push(`> ${r.example.explanation}`);
      L.push("");
      L.push(
        `Trader ${r.example.trader_name}, ${r.example.instrument_label}, ${r.example.trade_date}, ` +
          `USD Value ${usd(r.example.usd_value)}.`,
      );
      L.push("");
      L.push("| Computed value | Amount |");
      L.push("|---|---:|");
      for (const comp of r.example.components) {
        L.push(`| ${comp.label} | ${formatComponentValue(comp.value, comp.unit)} |`);
      }
      L.push("");
    } else if (r.reason) {
      L.push(`**Why it failed.** ${r.reason}`);
      L.push("");
    }
  }

  L.push("## Severity tiers");
  L.push("");
  L.push(
    "Where a behaviour is planted at three sizes, the scores must come out in order. This is what makes the threshold meaningful rather than decorative.",
  );
  L.push("");
  L.push("| Metric | Barely | Significant | Major | In order |");
  L.push("|---|---:|---:|---:|---|");
  for (const t of report.tierChecks) {
    const get = (tier: string) => t.tiers.find((x) => x.tier === tier)?.median ?? 0;
    L.push(
      `| ${t.label} | ${usd(get("barely"))} | ${usd(get("significant"))} | ${usd(get("major"))} | ${t.ordered ? "yes" : "NO"} |`,
    );
  }
  L.push("");

  L.push("## Threshold sensitivity");
  L.push("");
  L.push("Alert counts as each metric's threshold is moved, with the data held constant.");
  L.push("");
  const cols = report.thresholdSweeps[0]?.points.map((p) => usd(p.threshold)) ?? [];
  L.push(`| Metric | ${cols.join(" | ")} |`);
  L.push(`|---|${cols.map(() => "---:").join("|")}|`);
  for (const s of report.thresholdSweeps) {
    L.push(`| ${s.label} | ${s.points.map((p) => p.alerts).join(" | ")} |`);
  }
  L.push("");

  L.push("## Alerts from ordinary business");
  L.push("");
  L.push(
    "Alerts containing none of the planted documents. These come from the background population — " +
      "activity that is structurally similar to abuse, such as a large order worked in clips and closed later. " +
      "They are not failures; they are the reason scoring in dollars matters.",
  );
  L.push("");
  L.push("| Metric | From ordinary flow | Total alerts |");
  L.push("|---|---:|---:|");
  for (const b of report.backgroundAlerts) {
    L.push(`| ${b.label} | ${b.background} | ${b.total} |`);
  }
  L.push("");

  return L.join("\n");
}
