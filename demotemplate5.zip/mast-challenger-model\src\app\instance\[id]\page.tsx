import Link from "next/link";
import { notFound } from "next/navigation";
import { ImpactChart } from "@/components/ImpactChart";
import { METRIC_BY_ID } from "@/lib/config/metrics";
import {
  currentRun,
  documentById,
  executionsByIds,
  findInstance,
  instanceChart,
  ordersByIds,
} from "@/lib/queries";
import { fmtAmount, fmtComponent, fmtDateTime, fmtLevel, fmtUsd } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function InstanceDetail({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const instanceId = decodeURIComponent(id);
  const run = currentRun();
  const instance = findInstance(run, instanceId);
  if (!instance) notFound();

  const def = METRIC_BY_ID[instance.metric];
  const stats = run.stats.find((s) => s.metric === instance.metric)!;
  const isAlert = instance.usd_value > stats.threshold;
  const executions = executionsByIds(instance.exec_ids);
  const orders = ordersByIds(instance.order_ids);
  const chart = instanceChart(instance);
  const roleOf = new Map(instance.markers.map((m) => [m.exec_id ?? m.trade_id, m]));

  // One raw source document, so the shape the data arrived in is visible.
  const sampleDocId = executions[0]?.doc_id ?? orders[0]?.doc_id;
  const sampleDoc = sampleDocId ? documentById(sampleDocId) : undefined;

  return (
    <>
      <h1>
        {def.label}: {fmtUsd(instance.usd_value)}
      </h1>
      <p className="note">
        {instance.headline} — {isAlert ? "above" : "below"} the {fmtUsd(stats.threshold)} threshold.{" "}
        <Link href={`/alerts/${instance.metric}`}>Back to {def.label}</Link>
      </p>

      <p className="stats">
        <span>
          <b>Trader:</b> {instance.trader_name} ({instance.trader_id})
        </span>
        <span>
          <b>Instrument:</b> {instance.instrument_label}
        </span>
        <span>
          <b>Family:</b> {instance.family}
        </span>
        <span>
          <b>Book:</b> {instance.book_name || "-"}
        </span>
        <span>
          <b>Date:</b> {instance.trade_date}
        </span>
        <span>
          <b>Executions:</b> {executions.length}
          {orders.length ? `, orders: ${orders.length}` : ""}
        </span>
      </p>

      <h2>Why this instance triggered</h2>
      <p>{instance.explanation}</p>

      <h2>Computed values</h2>
      <table>
        <thead>
          <tr>
            <th>Value</th>
            <th className="n">Amount</th>
            <th>What it is</th>
          </tr>
        </thead>
        <tbody>
          {instance.components.map((c) => (
            <tr key={c.label}>
              <td>{c.label}</td>
              <td className="n">{fmtComponent(c.value, c.unit)}</td>
              <td style={{ whiteSpace: "normal", maxWidth: 520 }} className="note">
                {c.help}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {chart.length > 0 && (
        <>
          <h2>Modelled market impact</h2>
          <p className="note small">
            Market Impact Model estimate of how this flow moved the instrument&apos;s quoted level,
            and how that impact decayed afterwards.
          </p>
          <ImpactChart data={chart} markers={instance.markers} />
        </>
      )}

      {orders.length > 0 && (
        <>
          <h2>Order streams in this instance</h2>
          <p className="note small">
            Layering and spoofing are scored from order behaviour, so the whole life of each order
            is shown: placement, amendments, fills and the cancellation.
          </p>
          <table>
            <thead>
              <tr>
                <th>Order</th>
                <th>Instrument</th>
                <th>Side</th>
                <th className="n">Placed</th>
                <th className="n">Displayed</th>
                <th className="n">Filled</th>
                <th className="n">Levels</th>
                <th className="n">Amendments</th>
                <th className="n">Life</th>
                <th>Outcome</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((o) => (
                <tr key={o.order_id}>
                  <td className="mono">{o.order_id}</td>
                  <td className="mono">{o.instrument_label}</td>
                  <td>{o.side > 0 ? "bid" : "offer"}</td>
                  <td className="n">{fmtAmount(o.placed_amount)}</td>
                  <td className="n">{fmtAmount(o.display_amount)}</td>
                  <td className="n">{fmtAmount(o.filled_amount)}</td>
                  <td className="n">{o.price_levels.length}</td>
                  <td className="n">{o.amendments}</td>
                  <td className="n">{((o.end_ms - o.start_ms) / 1000).toFixed(0)}s</td>
                  <td>{o.cancelled_unfilled ? "cancelled unfilled" : "filled"}</td>
                </tr>
              ))}
            </tbody>
          </table>

          <h3>Order events</h3>
          <table>
            <thead>
              <tr>
                <th>Order</th>
                <th>Event</th>
                <th>Time</th>
                <th className="n">Limit</th>
                <th className="n">Total</th>
                <th className="n">Display</th>
                <th className="n">Fill price</th>
                <th className="n">Fill amount</th>
                <th>Counterparty</th>
                <th>Venue</th>
              </tr>
            </thead>
            <tbody>
              {orders.flatMap((o) =>
                o.events.map((ev) => (
                  <tr key={`${o.order_id}-${ev.event_id}`}>
                    <td className="mono">{o.order_id}</td>
                    <td>{ev.type}</td>
                    <td className="mono">{fmtDateTime(ev.ms).slice(11)}</td>
                    <td className="n">{ev.limit_price !== null ? fmtLevel(ev.limit_price) : "-"}</td>
                    <td className="n">{ev.total_amount !== null ? fmtAmount(ev.total_amount) : "-"}</td>
                    <td className="n">{ev.display_amount !== null ? fmtAmount(ev.display_amount) : "-"}</td>
                    <td className="n">{ev.price !== null ? fmtLevel(ev.price) : "-"}</td>
                    <td className="n">{ev.amount !== null ? fmtAmount(ev.amount) : "-"}</td>
                    <td>{ev.counterparty_name ?? "-"}</td>
                    <td>{ev.venue_name ?? "-"}</td>
                  </tr>
                )),
              )}
            </tbody>
          </table>
        </>
      )}

      {executions.length > 0 && (
        <>
          <h2>Executions in this instance</h2>
          <p className="small">
            <Link
              href={`/blotter?trader=${instance.trader_id}&date=${instance.trade_date}&alerts=1`}
            >
              Show this trader&apos;s alerted executions on the blotter
            </Link>
          </p>
          <table>
            <thead>
              <tr>
                <th>Part played</th>
                <th>Trade / event</th>
                <th>Execution time</th>
                <th>Trader</th>
                <th>Product</th>
                <th>Side</th>
                <th className="n">Notional</th>
                <th className="n">USD</th>
                <th className="n">Level</th>
                <th>Counterparty</th>
                <th>Role</th>
              </tr>
            </thead>
            <tbody>
              {executions.map((e) => {
                const m = roleOf.get(e.exec_id);
                return (
                  <tr key={e.exec_id} className={m?.role ?? ""}>
                    <td>{m ? m.label : "Context"}</td>
                    <td className="mono">{e.trade_id}</td>
                    <td className="mono">{fmtDateTime(e.event_ms)}</td>
                    <td>{e.trader_name}</td>
                    <td>{e.product_type}</td>
                    <td>{e.direction > 0 ? "buy" : "sell"}</td>
                    <td className="n">
                      {fmtAmount(e.notional)} {e.currency}
                    </td>
                    <td className="n">{fmtUsd(e.notional_usd)}</td>
                    <td className="n">{e.price ? fmtLevel(e.price) : "-"}</td>
                    <td>{e.counterparty_name ?? "-"}</td>
                    <td>{e.trade_role === "prop" ? "own risk" : "client"}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </>
      )}

      {sampleDoc && (
        <details>
          <summary>Source document ({sampleDoc.family} schema, {sampleDoc.doc_id})</summary>
          <p className="note small">
            The record exactly as it arrives, before normalisation. Everything above is derived
            from documents in this shape.
          </p>
          <pre className="doc">{JSON.stringify(sampleDoc.payload, null, 2)}</pre>
        </details>
      )}

      <h2>What {def.label.toLowerCase()} is, and why it matters</h2>
      <p>{def.about}</p>
      <p className="note">{def.usdValue}</p>
      <p className="note">
        <b>Data it relies on:</b> {def.needs}
      </p>
    </>
  );
}
