import { renderMarkdown, runValidation } from "@/lib/testing/run";

export const maxDuration = 120;

/**
 * The test report as a downloadable file: markdown by default, JSON for
 * anything that wants to consume it.
 */
export async function GET(req: Request) {
  const format = new URL(req.url).searchParams.get("format") ?? "md";
  const report = runValidation();
  const stamp = report.generated_at.slice(0, 10);

  if (format === "json") {
    return new Response(JSON.stringify(report, null, 2), {
      headers: {
        "content-type": "application/json",
        "content-disposition": `attachment; filename="abuse-detection-tests-${stamp}.json"`,
      },
    });
  }

  return new Response(renderMarkdown(report), {
    headers: {
      "content-type": "text/markdown; charset=utf-8",
      "content-disposition": `attachment; filename="abuse-detection-tests-${stamp}.md"`,
    },
  });
}
