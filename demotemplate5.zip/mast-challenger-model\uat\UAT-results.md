# Market abuse detection — UAT results

Generated: 2026-10-19T11:53:56.531Z

**31 of 31 test cases passed** — 13 of 13 cases that must raise an alert, and 18 of 18 cases that must not.

The pack holds 104 documents, which normalise to 83 executions and 92 order streams. 13 alerts were raised across all eleven metrics at the current thresholds.

Each case is matched to its results through a QA marker on the documents it planted. No detection engine reads that marker — it exists only so this report can be written — so a pass on a positive case means the behaviour was found from trade and order data alone, and a pass on a negative case means nothing in the data looked like abuse to the engine.

## Thresholds this run used

| Metric | USD Value threshold |
|---|---:|
| Insider Trading | $50,000 |
| Front Running | $20,000 |
| Internal Front Running | $25,000 |
| Ramping | $15,000 |
| Banging the Close | $20,000 |
| Wash Trading | $15,000 |
| Cross Trading | $15,000 |
| Off-Market Trading | $10,000 |
| Spoofing | $12,000 |
| Layering | $12,000 |
| Best Execution | $15,000 |

## Summary

| Case | Behaviour | Expected | Result | Alerts | USD Value |
|---|---|---|---|---:|---:|
| UAT-LAYER-01 | Five-rung bid ladder pulled unfilled while the trader sells | alert | PASS | 1 | $30,987 |
| UAT-LAYER-02 | Four-rung ladder, just over the threshold | alert | PASS | 1 | $13,334 |
| UAT-SPOOF-01 | $50m bid pulled after 18 seconds, $20m sold the other way | alert | PASS | 1 | $27,600 |
| UAT-SPOOF-02 | $32m offer pulled after 25 seconds, just over the threshold | alert | PASS | 1 | $13,947 |
| UAT-WASH-01 | $30m bought and sold back to the same internal account in six minutes | alert | PASS | 1 | $27,000 |
| UAT-WASH-02 | Round trip disguised as two different CDS tenors | alert | PASS | 1 | $29,808 |
| UAT-WASH-03 | $24m round trip, just over the threshold | alert | PASS | 1 | $17,280 |
| UAT-FRONT-01 | $20m bought ahead of $60m of client business, sold two minutes after it | alert | PASS | 1 | $32,149 |
| UAT-FRONT-02 | The same pattern in swaptions, not bonds | alert | PASS | 1 | $60,720 |
| UAT-FRONT-03 | $25m exited after $30m of client business, just over the threshold | alert | PASS | 1 | $21,484 |
| UAT-BESTEX-01 | Client filled 30 bps behind the firm's own print 90 seconds earlier | alert | PASS | 1 | $75,150 |
| UAT-BESTEX-02 | $6m client fill, 26 bps behind, just over the threshold | alert | PASS | 1 | $15,638 |
| UAT-BESTEX-03 | $40m client fill, 45 bps behind the firm's own print | alert | PASS | 1 | $179,910 |
| UAT-NEG-WASH-01 | Two completely different bonds, bought and sold at the same moment | no alert | PASS | 0 | - |
| UAT-NEG-WASH-02 | Position opened in the morning, closed in the afternoon | no alert | PASS | 0 | - |
| UAT-NEG-WASH-03 | Market making: bought from one client, sold to another | no alert | PASS | 0 | - |
| UAT-NEG-WASH-04 | Partial hedge against an internal book | no alert | PASS | 0 | - |
| UAT-NEG-FRONT-01 | Own-account trade six hours after the client business | no alert | PASS | 0 | - |
| UAT-NEG-FRONT-02 | Client business on the other side of the market | no alert | PASS | 0 | - |
| UAT-NEG-FRONT-03 | No position held before the client business | no alert | PASS | 0 | - |
| UAT-NEG-SPOOF-01 | Large bid pulled, nothing executed the other way | no alert | PASS | 0 | - |
| UAT-NEG-SPOOF-02 | The large order actually traded | no alert | PASS | 0 | - |
| UAT-NEG-SPOOF-03 | The order rested for eleven minutes | no alert | PASS | 0 | - |
| UAT-NEG-SPOOF-04 | The order was hidden, not displayed | no alert | PASS | 0 | - |
| UAT-NEG-LAYER-01 | One order re-posted five times at the same price | no alert | PASS | 0 | - |
| UAT-NEG-LAYER-02 | A ladder that mostly traded | no alert | PASS | 0 | - |
| UAT-NEG-LAYER-03 | A ladder standing well away from the touch | no alert | PASS | 0 | - |
| UAT-NEG-BESTEX-01 | The client got the better price | no alert | PASS | 0 | - |
| UAT-NEG-BESTEX-02 | Fifteen basis points behind — inside the materiality floor | no alert | PASS | 0 | - |
| UAT-NEG-BESTEX-03 | A $200k client fill, well behind the print | no alert | PASS | 0 | - |
| UAT-CLEAN-01 | A day of ordinary two-way business across three product families | no alert | PASS | 0 | - |

## What it would take to make the silent cases fire

Each row re-scores the pack with one setting opened up, so that a case passing on silence can be shown to be silent for the stated reason rather than by accident.

| Case | Setting relaxed | From | To | Result |
|---|---|---:|---:|---|
| UAT-NEG-WASH-02 | Max gap between legs | 30 | 7 hours | scored at $12,150, under the $15,000 threshold |
| UAT-NEG-WASH-04 | Size match tolerance | 15 | 80% | scored at $2,430, under the $15,000 threshold |
| UAT-NEG-FRONT-01 | Max lead time | 900 | 7 hours | scored at $9, under the $20,000 threshold |
| UAT-NEG-SPOOF-03 | Max order life | 60 | 15 minutes | still nothing |
| UAT-NEG-SPOOF-04 | Min displayed share | 0.7 | 5% | scored at $1,000, under the $12,000 threshold |
| UAT-NEG-LAYER-02 | Cancel ratio threshold | 0.8 | 20% | alerts at $31,010 |
| UAT-NEG-LAYER-03 | Min competitiveness | 0.35 | no floor | still nothing |
| UAT-NEG-BESTEX-02 | Min client detriment | 25 | 10 bps | alerts at $37,632 |
| UAT-NEG-BESTEX-03 | Min client notional | 250000 | $100,000 | scored at $1,202, under the $15,000 threshold |

## Layering

A ladder of orders across several price levels on one side of the book, pulled together without trading, while the genuine execution goes the other way.

### UAT-LAYER-01 — Five-rung bid ladder pulled unfilled while the trader sells

**PASS** — expected a Layering alert. Layering raised 1 alert from these trades.

- **Metric:** Layering (threshold $12,000)
- **Products:** fenics
- **Trades analysed:** 6 documents — 1 execution, 6 order streams
- **Size:** significant

**What is being tested.** That a ladder of orders across several price levels is detected from order data alone, scored on the depth it appeared to add, and reported separately from spoofing.

**Scenario.** One trader places five bids on the same bond within about a minute, at five successive prices from the touch downwards, $12m each and fully displayed. Two are amended to walk the price in. All five are cancelled 20 to 40 seconds after being placed, with no fills. While the ladder stands, the same trader sells $20m of the same bond to a dealer.

**Why these trades.** Five rungs is the smallest ladder that is unambiguously a ladder — it clears the four-level floor with one to spare, so the case does not pass on a rounding accident. $12m a rung matters as much as the total: each individual order is too small to score as a spoof on its own, so the only way this becomes an alert is if the engine assembles the five orders into one ladder. The sell is what gives the ladder a purpose; without it there is nothing the ladder could have benefited.

**Expected.** A Layering alert naming five orders across five price levels, a 100% cancel ratio, an average life under a minute, and the $20m sell as the execution on the other side. No Spoofing alert, because no single rung is large enough to score.

**The trades analysed.**

| | Id | Time (UTC) | Trader | Instrument | Side | Size | Price | Counterparty | Detail | In alert |
|---|---|---|---|---|---|---:|---:|---|---|---|
| order | UAT-LAYER-01-O1 | 2026-10-13 09:15:00 | N. Okafor | XS2601000011 | bid | 12m | 99.5 | - | cancelled unfilled, 1 level, 100% shown, 20s | yes |
| order | UAT-LAYER-01-O2 | 2026-10-13 09:15:12 | N. Okafor | XS2601000011 | bid | 12m | 99.49 | - | cancelled unfilled, 1 level, 100% shown, 25s | yes |
| order | UAT-LAYER-01-O3 | 2026-10-13 09:15:24 | N. Okafor | XS2601000011 | bid | 12m | 99.48 | - | cancelled unfilled, 1 level, 100% shown, 30s | yes |
| order | UAT-LAYER-01-O6 | 2026-10-13 09:15:33 | N. Okafor | XS2601000011 | offer | 20m | 99.51 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-LAYER-01-O6-F1 | 2026-10-13 09:15:35 | N. Okafor | XS2601000011 | sell | 20m | 99.51 | Onebrook Securities | own risk | yes |
| order | UAT-LAYER-01-O4 | 2026-10-13 09:15:36 | N. Okafor | XS2601000011 | bid | 12m | 99.47 | - | cancelled unfilled, 1 level, 100% shown, 35s | yes |
| order | UAT-LAYER-01-O5 | 2026-10-13 09:15:48 | N. Okafor | XS2601000011 | bid | 12m | 99.46 | - | cancelled unfilled, 1 level, 100% shown, 40s | yes |

**Alert raised — Layering, $30,987** (threshold $12,000)

> 5-order bid ladder across 5 levels on XS2601000011, $20.0m executed the other way

N. Okafor placed 5 bids on XS2601000011 across 5 distinct price levels, $60,000,000 in total, with 2 amendments walking the price in. 100% of that notional was cancelled without filling, after an average life of 30.0 seconds. While the ladder stood, the same trader executed $20,000,000 in the opposite direction. The Narrative — ladder impact of 18.34 bps, weighted for the depth it appeared to add, applied to that execution — is worth $36,687 against a Counter-Narrative of $5,700 for the risk of being filled. Narrative less Counter-Narrative = $30,987.

| Computed value | Amount |
|---|---:|
| Narrative | $36,687 |
| Counter-Narrative | $5,700 |
| Price levels | 5 |
| Orders in ladder | 5 |
| Ladder notional | $60,000,000 |
| Cancel ratio | 100.0% |
| Amendments | 2 |
| Average order life | 30.0 s |
| Competitiveness | 84.9% |
| Executed the other way | $20,000,000 |

### UAT-LAYER-02 — Four-rung ladder, just over the threshold

**PASS** — expected a Layering alert. Layering raised 1 alert from these trades.

- **Metric:** Layering (threshold $12,000)
- **Products:** fenics
- **Trades analysed:** 5 documents — 1 execution, 5 order streams
- **Size:** barely

**What is being tested.** That the minimum shape of a ladder — four price levels, the configured floor — is still caught, and that it scores close to the threshold rather than far above it.

**Scenario.** Four bids at four prices, $6m each, placed over 30 seconds and all cancelled within 25 seconds, against a $20m sell on the other side. Deliberately sized to land just above the threshold, which is what shows the threshold is doing real work rather than letting everything through.

**Why these trades.** The four-level floor is the single most important setting on this metric, because it is what separates a ladder from a trader legitimately working one order at a couple of prices. This case sits exactly on that floor, so if the floor is ever raised to five this case is the one that stops alerting — which is the behaviour an analyst should be able to predict from the admin page.

**Expected.** A Layering alert with four price levels and a USD Value a short way above the Layering threshold.

**The trades analysed.**

| | Id | Time (UTC) | Trader | Instrument | Side | Size | Price | Counterparty | Detail | In alert |
|---|---|---|---|---|---|---:|---:|---|---|---|
| order | UAT-LAYER-02-O7 | 2026-10-13 09:40:00 | N. Okafor | XS2601000022 | bid | 6.0m | 99.6 | - | cancelled unfilled, 1 level, 100% shown, 20s | yes |
| order | UAT-LAYER-02-O8 | 2026-10-13 09:40:10 | N. Okafor | XS2601000022 | bid | 6.0m | 99.59 | - | cancelled unfilled, 1 level, 100% shown, 22s | yes |
| order | UAT-LAYER-02-O9 | 2026-10-13 09:40:20 | N. Okafor | XS2601000022 | bid | 6.0m | 99.58 | - | cancelled unfilled, 1 level, 100% shown, 25s | yes |
| order | UAT-LAYER-02-O11 | 2026-10-13 09:40:26 | N. Okafor | XS2601000022 | offer | 20m | 99.61 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-LAYER-02-O11-F1 | 2026-10-13 09:40:28 | N. Okafor | XS2601000022 | sell | 20m | 99.61 | Twyford Markets | own risk | yes |
| order | UAT-LAYER-02-O10 | 2026-10-13 09:40:30 | N. Okafor | XS2601000022 | bid | 6.0m | 99.57 | - | cancelled unfilled, 1 level, 100% shown, 25s | yes |

**Alert raised — Layering, $13,334** (threshold $12,000)

> 4-order bid ladder across 4 levels on XS2601000022, $20.0m executed the other way

N. Okafor placed 4 bids on XS2601000022 across 4 distinct price levels, $24,000,000 in total. 100% of that notional was cancelled without filling, after an average life of 23.0 seconds. While the ladder stood, the same trader executed $20,000,000 in the opposite direction. The Narrative — ladder impact of 7.04 bps, weighted for the depth it appeared to add, applied to that execution — is worth $14,088 against a Counter-Narrative of $754 for the risk of being filled. Narrative less Counter-Narrative = $13,334.

| Computed value | Amount |
|---|---:|
| Narrative | $14,088 |
| Counter-Narrative | $754 |
| Price levels | 4 |
| Orders in ladder | 4 |
| Ladder notional | $24,000,000 |
| Cancel ratio | 100.0% |
| Amendments | 0 |
| Average order life | 23.0 s |
| Competitiveness | 90.6% |
| Executed the other way | $20,000,000 |

## Spoofing

One large, fully visible order placed at the touch and pulled within seconds, while the trader executes on the opposite side.

### UAT-SPOOF-01 — $50m bid pulled after 18 seconds, $20m sold the other way

**PASS** — expected a Spoofing alert. Spoofing raised 1 alert from these trades.

- **Metric:** Spoofing (threshold $12,000)
- **Products:** fenics
- **Trades analysed:** 2 documents — 1 execution, 2 order streams
- **Size:** significant

**What is being tested.** That a single large, fully displayed order placed at the touch, pulled quickly without trading, while the trader executes in the opposite direction, is detected from order data.

**Scenario.** A trader places one $50m bid on a bond at the prevailing level, all of it displayed, and cancels it 18 seconds later with nothing filled. Nine seconds into its life, the same trader sells $20m of the same bond to a dealer.

**Why these trades.** Every element is there because a gate depends on it: the size and the display make the order worth seeing, sitting at the touch makes it competitive, the 18-second life makes it implausible as genuine liquidity, the nil fill makes it a decoy rather than a trade, and the sale on the other side is what the decoy was for. Remove any one of them and this should stop being an alert — which is exactly what the four spoofing negative cases do, one gate at a time.

**Expected.** A Spoofing alert quoting the order notional, 100% displayed, the order life, nil fills, and the $20m executed the other way, with the Narrative beating the Counter-Narrative comfortably. No Layering alert, because there is only one order.

**The trades analysed.**

| | Id | Time (UTC) | Trader | Instrument | Side | Size | Price | Counterparty | Detail | In alert |
|---|---|---|---|---|---|---:|---:|---|---|---|
| order | UAT-SPOOF-01-O12 | 2026-10-13 09:50:00 | P. Lindqvist | XS2602000011 | bid | 50m | 99.7 | - | cancelled unfilled, 1 level, 100% shown, 18s | yes |
| order | UAT-SPOOF-01-O13 | 2026-10-13 09:50:07 | P. Lindqvist | XS2602000011 | offer | 20m | 99.7 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-SPOOF-01-O13-F1 | 2026-10-13 09:50:09 | P. Lindqvist | XS2602000011 | sell | 20m | 99.7 | Onebrook Securities | own risk | yes |

**Alert raised — Spoofing, $27,600** (threshold $12,000)

> $50.0m bid on XS2602000011 pulled after 18.0 seconds, $20.0m executed the other way

P. Lindqvist placed a single bid for $50,000,000 of XS2602000011 at 99.7000, with 100% of it displayed to the market — competitive enough to shift the visible balance of the book. It was cancelled after 18.0 seconds without filling. While it rested, the same trader executed $20,000,000 in the opposite direction on the same instrument. The Narrative — order impact of 15.00 bps applied to that execution — is worth $30,000. The Counter-Narrative, the cost of unwinding had the order been filled, is $2,400 once scaled by how briefly it was exposed. Narrative less Counter-Narrative = $27,600.

| Computed value | Amount |
|---|---:|
| Narrative | $30,000 |
| Counter-Narrative | $2,400 |
| Order notional | $50,000,000 |
| Displayed share | 100.0% |
| Competitiveness | 100.0% |
| Order life | 18.0 s |
| Executed the other way | $20,000,000 |
| Filled | 0 |
| Side | bid (positive amount) |

### UAT-SPOOF-02 — $32m offer pulled after 25 seconds, just over the threshold

**PASS** — expected a Spoofing alert. Spoofing raised 1 alert from these trades.

- **Metric:** Spoofing (threshold $12,000)
- **Products:** fenics
- **Trades analysed:** 2 documents — 1 execution, 2 order streams
- **Size:** barely

**What is being tested.** That the same pattern at a size where the decoy's own risk of being filled starts to matter still clears the threshold, and only just.

**Scenario.** A $32m offer at the touch, fully displayed, cancelled after 25 seconds, with $16m bought on the other side while it rested. Deliberately sized to land just above the threshold, which is what shows the threshold is doing real work rather than letting everything through.

**Why these trades.** The Counter-Narrative — what it would have cost the trader if the decoy had actually been filled — grows with both the size of the order and how long it rested. At 25 seconds this case carries noticeably more of that cost than the 18-second case, so it tests that the model nets the two readings off against each other rather than just counting the pattern.

**Expected.** A Spoofing alert a short way above the threshold, with a visibly larger Counter-Narrative than UAT-SPOOF-01.

**The trades analysed.**

| | Id | Time (UTC) | Trader | Instrument | Side | Size | Price | Counterparty | Detail | In alert |
|---|---|---|---|---|---|---:|---:|---|---|---|
| order | UAT-SPOOF-02-O14 | 2026-10-13 10:05:00 | P. Lindqvist | XS2602000022 | offer | 32m | 100.2 | - | cancelled unfilled, 1 level, 100% shown, 25s | yes |
| order | UAT-SPOOF-02-O15 | 2026-10-13 10:05:12 | P. Lindqvist | XS2602000022 | bid | 16m | 100.2 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-SPOOF-02-O15-F1 | 2026-10-13 10:05:14 | P. Lindqvist | XS2602000022 | buy | 16m | 100.2 | Twyford Markets | own risk | yes |

**Alert raised — Spoofing, $13,947** (threshold $12,000)

> $32.0m offer on XS2602000022 pulled after 25.0 seconds, $16.0m executed the other way

P. Lindqvist placed a single offer for $32,000,000 of XS2602000022 at 100.2000, with 100% of it displayed to the market — competitive enough to shift the visible balance of the book. It was cancelled after 25.0 seconds without filling. While it rested, the same trader executed $16,000,000 in the opposite direction on the same instrument. The Narrative — order impact of 9.60 bps applied to that execution — is worth $15,360. The Counter-Narrative, the cost of unwinding had the order been filled, is $1,413 once scaled by how briefly it was exposed. Narrative less Counter-Narrative = $13,947.

| Computed value | Amount |
|---|---:|
| Narrative | $15,360 |
| Counter-Narrative | $1,413 |
| Order notional | $32,000,000 |
| Displayed share | 100.0% |
| Competitiveness | 100.0% |
| Order life | 25.0 s |
| Executed the other way | $16,000,000 |
| Filled | 0 |
| Side | offer (negative amount) |

## Wash trading

Offsetting legs that leave no genuine market risk, including the versions disguised behind a different tenor or a different account.

### UAT-WASH-01 — $30m bought and sold back to the same internal account in six minutes

**PASS** — expected a Wash Trading alert. Wash Trading raised 1 alert from these trades.

- **Metric:** Wash Trading (threshold $15,000)
- **Products:** fenics
- **Trades analysed:** 2 documents — 2 executions, 2 order streams
- **Size:** significant

**What is being tested.** That a round trip against a related account, with no genuine risk taken in between, is identified and priced on the activity it manufactured.

**Scenario.** A trader buys $30m of a bond from an internal book at 10:02 and sells the same $30m back to that internal book at 10:08, at the same price.

**Why these trades.** This is the textbook case, and it is in the pack as the control for the three disguised variants that follow: same instrument, same size, same account, minutes apart. The six-minute gap is the point — it is long enough to look like two separate decisions on a blotter and far too short for any real risk to have been run, which is what the Counter-Narrative measures.

**Expected.** A Wash Trading alert with a relatedness of 1.00 because both legs face an internal account, the full $30m matched, and a Counter-Narrative of almost nothing because the instrument did not move between the legs.

**The trades analysed.**

| | Id | Time (UTC) | Trader | Instrument | Side | Size | Price | Counterparty | Detail | In alert |
|---|---|---|---|---|---|---:|---:|---|---|---|
| order | UAT-WASH-01-O16 | 2026-10-13 10:01:58 | G. Mbeki | XS2603000011 | bid | 30m | 100 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-WASH-01-O16-F1 | 2026-10-13 10:02:00 | G. Mbeki | XS2603000011 | buy | 30m | 100 | Internal Book Transfer | own risk | yes |
| order | UAT-WASH-01-O17 | 2026-10-13 10:07:58 | G. Mbeki | XS2603000011 | offer | 30m | 100 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-WASH-01-O17-F1 | 2026-10-13 10:08:00 | G. Mbeki | XS2603000011 | sell | 30m | 100 | Internal Book Transfer | own risk | yes |

**Alert raised — Wash Trading, $27,000** (threshold $15,000)

> $30.0m wash on XS2603000011, offset in 6.0 minutes

G. Mbeki bought $30,000,000 of XS2603000011 and reversed it with 1 offsetting leg totalling $30,000,000 6.0 minutes later. Both legs were booked against Internal Book Transfer, so no risk left the firm. The manufactured activity carries a modelled impact of 9.00 bps in value terms, giving a Narrative of $27,000. Against that, the instrument moved only 0.00 bps of value while the position was open, so the genuine market risk run between the legs is worth $0. Narrative less Counter-Narrative = $27,000.

| Computed value | Amount |
|---|---:|
| Narrative | $27,000 |
| Counter-Narrative | $0 |
| Matched notional | $30,000,000 |
| Modelled impact | 9.00 bps |
| Gap between legs | 6.0 min |
| Value move over the gap | 0.00 bps |
| Relatedness | 100.0% |
| Variant | wash |
| Products involved | FixedIncome.Bond |

### UAT-WASH-02 — Round trip disguised as two different CDS tenors

**PASS** — expected a Wash Trading alert. Wash Trading raised 1 alert from these trades.

- **Metric:** Wash Trading (threshold $15,000)
- **Products:** credit
- **Trades analysed:** 2 documents — 2 executions, 0 order streams
- **Size:** major

**What is being tested.** That tenor normalisation defeats the simplest disguise available in the credit schema — booking the two legs as different contracts on the same curve point.

**Scenario.** $40m of protection bought on a reference entity with the tenor stated as 58M, and $40m sold on the same entity four minutes later with the tenor stated as 61M, both against an internal book. Sized far above the threshold, so it stays an alert even if the threshold is raised several times over.

**Why these trades.** On any blotter these are two different contracts and the round trip is invisible. They are only the same position after the tenor strings have been bucketed onto a standard curve point, which happens in the adapter, before any detector runs. That is the whole argument for normalising first and detecting second, and this case is what proves it happens.

**Expected.** A Wash Trading alert on the bucketed 5Y instrument, with both legs listed against one instrument and the full $40m matched.

**The trades analysed.**

| | Id | Time (UTC) | Trader | Instrument | Side | Size | Price | Counterparty | Detail | In alert |
|---|---|---|---|---|---|---:|---:|---|---|---|
| fill | UAT-WASH-02-C18 | 2026-10-13 11:00:00 | G. Mbeki | UATPLC SNRFOR 5Y CDS | buy | 40m | - | Internal Book Transfer | own risk | yes |
| fill | UAT-WASH-02-C19 | 2026-10-13 11:04:00 | G. Mbeki | UATPLC SNRFOR 5Y CDS | sell | 40m | - | Internal Book Transfer | own risk | yes |

**Alert raised — Wash Trading, $29,808** (threshold $15,000)

> $40.0m wash on UATPLC SNRFOR 5Y CDS, offset in 4.0 minutes

G. Mbeki bought protection on $40,000,000 of UATPLC SNRFOR 5Y CDS and reversed it with 1 offsetting leg totalling $40,000,000 4.0 minutes later. Both legs were booked against Internal Book Transfer, so no risk left the firm. The manufactured activity carries a modelled impact of 7.45 bps in value terms, giving a Narrative of $29,808. Against that, the instrument moved only 0.00 bps of value while the position was open, so the genuine market risk run between the legs is worth $0. Narrative less Counter-Narrative = $29,808.

| Computed value | Amount |
|---|---:|
| Narrative | $29,808 |
| Counter-Narrative | $0 |
| Matched notional | $40,000,000 |
| Modelled impact | 7.45 bps |
| Gap between legs | 4.0 min |
| Value move over the gap | 0.00 bps |
| Relatedness | 100.0% |
| Variant | wash |
| Products involved | Credit.CDS |

### UAT-WASH-03 — $24m round trip, just over the threshold

**PASS** — expected a Wash Trading alert. Wash Trading raised 1 alert from these trades.

- **Metric:** Wash Trading (threshold $15,000)
- **Products:** fenics
- **Trades analysed:** 2 documents — 2 executions, 2 order streams
- **Size:** barely

**What is being tested.** That the metric scales with size rather than firing on the pattern alone, and that a smaller round trip lands just above the threshold.

**Scenario.** The same shape as UAT-WASH-01 at $24m, nine minutes apart. Deliberately sized to land just above the threshold, which is what shows the threshold is doing real work rather than letting everything through.

**Why these trades.** Scored on impact rather than on the pattern, a $24m round trip has to come out materially lower than a $30m one — the two together show the score is a function of size and are what make the threshold meaningful. This is also the case to watch when someone asks what the threshold should be: it is the one that disappears first.

**Expected.** A Wash Trading alert at well under half the USD Value of UAT-WASH-01, still above the threshold.

**The trades analysed.**

| | Id | Time (UTC) | Trader | Instrument | Side | Size | Price | Counterparty | Detail | In alert |
|---|---|---|---|---|---|---:|---:|---|---|---|
| order | UAT-WASH-03-O20 | 2026-10-13 11:29:58 | G. Mbeki | XS2603000033 | bid | 24m | 98.75 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-WASH-03-O20-F1 | 2026-10-13 11:30:00 | G. Mbeki | XS2603000033 | buy | 24m | 98.75 | Internal Book Transfer | own risk | yes |
| order | UAT-WASH-03-O21 | 2026-10-13 11:38:58 | G. Mbeki | XS2603000033 | offer | 24m | 98.75 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-WASH-03-O21-F1 | 2026-10-13 11:39:00 | G. Mbeki | XS2603000033 | sell | 24m | 98.75 | Internal Book Transfer | own risk | yes |

**Alert raised — Wash Trading, $17,280** (threshold $15,000)

> $24.0m wash on XS2603000033, offset in 9.0 minutes

G. Mbeki bought $24,000,000 of XS2603000033 and reversed it with 1 offsetting leg totalling $24,000,000 9.0 minutes later. Both legs were booked against Internal Book Transfer, so no risk left the firm. The manufactured activity carries a modelled impact of 7.20 bps in value terms, giving a Narrative of $17,280. Against that, the instrument moved only 0.00 bps of value while the position was open, so the genuine market risk run between the legs is worth $0. Narrative less Counter-Narrative = $17,280.

| Computed value | Amount |
|---|---:|
| Narrative | $17,280 |
| Counter-Narrative | $0 |
| Matched notional | $24,000,000 |
| Modelled impact | 7.20 bps |
| Gap between legs | 9.0 min |
| Value move over the gap | 0.00 bps |
| Relatedness | 100.0% |
| Variant | wash |
| Products involved | FixedIncome.Bond |

## Front running

A position opened on the firm's own book ahead of the firm's own client business, and exited into the price impact that business creates.

### UAT-FRONT-01 — $20m bought ahead of $60m of client business, sold two minutes after it

**PASS** — expected a Front Running alert. Front Running raised 1 alert from these trades.

- **Metric:** Front Running (threshold $20,000)
- **Products:** fenics
- **Trades analysed:** 3 documents — 4 executions, 3 order streams
- **Size:** significant

**What is being tested.** That a position opened on the firm's own book before the firm's own client flow, and closed into the impact of that flow, is detected and priced on the impact still standing at the exit.

**Scenario.** At 09:58 a trader buys $20m of a bond from a dealer, for the firm's own book. Between 10:12 and 10:18 the same trader buys $60m of the same bond from two clients. At 10:20, two minutes after the last client fill, the trader sells the $20m back to a dealer.

**Why these trades.** The order of events is the evidence, so the data is built to make the order unambiguous: the own-account position exists before the client flow begins, the client flow is large enough to move the instrument, and the exit comes two minutes after it — close enough that most of the modelled impact is still there. Only two client fills are used, which keeps the trader under five executions on the day and stops this from also reading as ramping; that keeps the case about one thing.

**Expected.** A Front Running alert with the position opened before the flow, the two client fills as the impacting business, a two-minute lead time, and a PTC capped at the exit notional.

**The trades analysed.**

| | Id | Time (UTC) | Trader | Instrument | Side | Size | Price | Counterparty | Detail | In alert |
|---|---|---|---|---|---|---:|---:|---|---|---|
| order | UAT-FRONT-01-O22 | 2026-10-13 09:57:58 | T. Varga | XS2604000011 | bid | 20m | 99.9 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-FRONT-01-O22-F1 | 2026-10-13 09:58:00 | T. Varga | XS2604000011 | buy | 20m | 99.9 | Onebrook Securities | own risk | yes |
| order | UAT-FRONT-01-O23 | 2026-10-13 10:10:00 | T. Varga | XS2604000011 | bid | 60m | 99.94 | - | filled, 1 level, 100% shown, 480s | - |
| fill | UAT-FRONT-01-O23-F1 | 2026-10-13 10:12:00 | T. Varga | XS2604000011 | buy | 30m | 99.94 | Alpha Pension Trust | client | yes |
| fill | UAT-FRONT-01-O23-F2 | 2026-10-13 10:18:00 | T. Varga | XS2604000011 | buy | 30m | 99.94 | Beta Family Office | client | yes |
| order | UAT-FRONT-01-O24 | 2026-10-13 10:19:58 | T. Varga | XS2604000011 | offer | 20m | 99.98 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-FRONT-01-O24-F1 | 2026-10-13 10:20:00 | T. Varga | XS2604000011 | sell | 20m | 99.98 | Twyford Markets | own risk | yes |

**Alert raised — Front Running, $32,149** (threshold $20,000)

> $20.0m position exited 2.0 minutes after $60.0m of client business in XS2604000011

T. Varga bought $20,000,000 of XS2604000011, then filled $60,000,000 of client business in the same instrument and direction. The residual impact of that flow was 16.07 bps in value terms when the position was closed 2.0 minutes later. Applied to the $20,000,000 that exited into it, USD Value = $32,149.

| Computed value | Amount |
|---|---:|
| Expected Market Impact (EMI) | 16.07 bps |
| Level impact | 16.07 bps |
| Profit-Taking Component (PTC) | $20,000,000 |
| Impacting notional | $60,000,000 |
| Position opened | $20,000,000 |
| Exit notional | $20,000,000 |
| Allocated as position closing | $20,000,000 |
| Lead time | 2.0 min |
| Product | FixedIncome.Bond |

### UAT-FRONT-02 — The same pattern in swaptions, not bonds

**PASS** — expected a Front Running alert. Front Running raised 1 alert from these trades.

- **Metric:** Front Running (threshold $20,000)
- **Products:** rates
- **Trades analysed:** 4 documents — 4 executions, 0 order streams
- **Size:** major

**What is being tested.** That front running is detected identically in a product with no traded price, no order book and a different schema — which is the test of whether normalising first actually works.

**Scenario.** A trader pays fixed on $200m of a 5Y swaption against a dealer, then executes $600m of client business paying fixed on the same curve point, then receives fixed on $200m eight minutes later. Sized far above the threshold, so it stays an alert even if the threshold is raised several times over.

**Why these trades.** A swaption carries a strike rather than a price, settles against a curve point rather than an ISIN, and arrives in a different Economics shape with its direction in PayOrReceive instead of the sign of the notional. If the detector works here without being told any of that, it is working on the normalised model rather than on the Fenics feed it was first written against. The rates notionals are larger because a swap curve absorbs far more size than a single bond before it moves.

**Expected.** A Front Running alert on the bucketed 5Y curve point, with the impact converted into value terms through duration rather than being read off the rate.

**The trades analysed.**

| | Id | Time (UTC) | Trader | Instrument | Side | Size | Price | Counterparty | Detail | In alert |
|---|---|---|---|---|---|---:|---:|---|---|---|
| fill | UAT-FRONT-02-R25 | 2026-10-13 09:30:00 | T. Varga | UATSOFR 5Y | buy | 200m | 3.95 | Onebrook Securities | own risk | yes |
| fill | UAT-FRONT-02-R26 | 2026-10-13 09:40:00 | T. Varga | UATSOFR 5Y | buy | 300m | 3.96 | Alpha Pension Trust | client | yes |
| fill | UAT-FRONT-02-R27 | 2026-10-13 09:44:00 | T. Varga | UATSOFR 5Y | buy | 300m | 3.96 | Gamma Mutual Insurance | client | yes |
| fill | UAT-FRONT-02-R28 | 2026-10-13 09:46:00 | T. Varga | UATSOFR 5Y | sell | 160m | 3.97 | Twyford Markets | own risk | yes |

**Alert raised — Front Running, $60,720** (threshold $20,000)

> $160.0m position exited 2.0 minutes after $600.0m of client business in UATSOFR 5Y

T. Varga paid fixed on $200,000,000 of UATSOFR 5Y, then filled $600,000,000 of client business in the same instrument and direction. The residual impact of that flow was 3.79 bps in value terms when the position was closed 2.0 minutes later. Applied to the $160,000,000 that exited into it, USD Value = $60,720.

| Computed value | Amount |
|---|---:|
| Expected Market Impact (EMI) | 3.79 bps |
| Level impact | 19.17 bps |
| Profit-Taking Component (PTC) | $160,000,000 |
| Impacting notional | $600,000,000 |
| Position opened | $200,000,000 |
| Exit notional | $160,000,000 |
| Allocated as position closing | $160,000,000 |
| Lead time | 2.0 min |
| Product | IR.Swaption |

### UAT-FRONT-03 — $25m exited after $30m of client business, just over the threshold

**PASS** — expected a Front Running alert. Front Running raised 1 alert from these trades.

- **Metric:** Front Running (threshold $20,000)
- **Products:** fenics
- **Trades analysed:** 3 documents — 3 executions, 3 order streams
- **Size:** barely

**What is being tested.** That a smaller position exiting into smaller client flow still clears the threshold, and only just.

**Scenario.** A $25m own-account position opened at 11:05, a single $30m client fill at 11:20, and the exit at 11:22. Deliberately sized to land just above the threshold, which is what shows the threshold is doing real work rather than letting everything through.

**Why these trades.** Front running is priced on the impact the client business left standing, so one $30m fill creates far less of it than three $20m fills would. This case is the lower bound of what the metric reports at the default threshold, and it is the one to re-run after any change to the impact model.

**Expected.** A Front Running alert a short way above the threshold, with a single client fill as the impacting business.

**The trades analysed.**

| | Id | Time (UTC) | Trader | Instrument | Side | Size | Price | Counterparty | Detail | In alert |
|---|---|---|---|---|---|---:|---:|---|---|---|
| order | UAT-FRONT-03-O29 | 2026-10-13 11:04:58 | T. Varga | XS2604000033 | bid | 25m | 100.1 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-FRONT-03-O29-F1 | 2026-10-13 11:05:00 | T. Varga | XS2604000033 | buy | 25m | 100.1 | Onebrook Securities | own risk | yes |
| order | UAT-FRONT-03-O30 | 2026-10-13 11:19:00 | T. Varga | XS2604000033 | bid | 30m | 100.12 | - | filled, 1 level, 100% shown, 60s | - |
| fill | UAT-FRONT-03-O30-F1 | 2026-10-13 11:20:00 | T. Varga | XS2604000033 | buy | 30m | 100.12 | Alpha Pension Trust | client | yes |
| order | UAT-FRONT-03-O31 | 2026-10-13 11:21:58 | T. Varga | XS2604000033 | offer | 25m | 100.12 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-FRONT-03-O31-F1 | 2026-10-13 11:22:00 | T. Varga | XS2604000033 | sell | 25m | 100.12 | Twyford Markets | own risk | yes |

**Alert raised — Front Running, $21,484** (threshold $20,000)

> $25.0m position exited 2.0 minutes after $30.0m of client business in XS2604000033

T. Varga bought $25,000,000 of XS2604000033, then filled $30,000,000 of client business in the same instrument and direction. The residual impact of that flow was 8.59 bps in value terms when the position was closed 2.0 minutes later. Applied to the $25,000,000 that exited into it, USD Value = $21,484.

| Computed value | Amount |
|---|---:|
| Expected Market Impact (EMI) | 8.59 bps |
| Level impact | 8.59 bps |
| Profit-Taking Component (PTC) | $25,000,000 |
| Impacting notional | $30,000,000 |
| Position opened | $25,000,000 |
| Exit notional | $25,000,000 |
| Allocated as position closing | $25,000,000 |
| Lead time | 2.0 min |
| Product | FixedIncome.Bond |

## Best execution

A client filled on worse terms than the firm itself was demonstrably achieving moments earlier on the same instrument.

### UAT-BESTEX-01 — Client filled 30 bps behind the firm's own print 90 seconds earlier

**PASS** — expected a Best Execution alert. Best Execution raised 1 alert from these trades.

- **Metric:** Best Execution (threshold $15,000)
- **Products:** fenics
- **Trades analysed:** 2 documents — 2 executions, 2 order streams
- **Size:** significant

**What is being tested.** That a client filled worse than the firm itself was demonstrably achieving is identified, measured against the firm's own print rather than against a model, and quantified as detriment to the client.

**Scenario.** At 09:30 the firm buys $8m of a bond from a dealer at 99.80. At 09:31:30 it buys $25m of the same bond from a client at 99.50 — the client sold 30 bps lower than the dealer did, 90 seconds apart.

**Why these trades.** The strongest evidence available for this metric is the firm's own contemporaneous print on the same instrument, because there is no argument about what was reachable: the firm reached it itself, a minute and a half earlier, in the same feed. The dealer print is deliberately smaller than the client fill, so no one can argue the client got a worse price for being bigger. The gap is 30 bps against a 25 bps floor, comfortably material but nowhere near the 60 bps that would make this an off-market trade instead.

**Expected.** A Best Execution alert quoting both prices, the 90-second gap, the reference basis as the firm's own print, and a USD Value equal to the detriment applied to the client's $25m.

**The trades analysed.**

| | Id | Time (UTC) | Trader | Instrument | Side | Size | Price | Counterparty | Detail | In alert |
|---|---|---|---|---|---|---:|---:|---|---|---|
| order | UAT-BESTEX-01-O32 | 2026-10-13 09:29:58 | I. Solberg | XS2605000011 | bid | 8.0m | 99.8 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-BESTEX-01-O32-F1 | 2026-10-13 09:30:00 | I. Solberg | XS2605000011 | buy | 8.0m | 99.8 | Onebrook Securities | own risk | yes |
| order | UAT-BESTEX-01-O33 | 2026-10-13 09:31:28 | I. Solberg | XS2605000011 | bid | 25m | 99.5 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-BESTEX-01-O33-F1 | 2026-10-13 09:31:30 | I. Solberg | XS2605000011 | buy | 25m | 99.5 | Alpha Pension Trust | client | yes |

**Alert raised — Best Execution, $75,150** (threshold $15,000)

> Alpha Pension Trust filled $25.0m of XS2605000011 30.1 bps worse than the firm's own print

Alpha Pension Trust was filled $25,000,000 of XS2605000011 at 99.5000, having sold to the firm. Measured against the firm's own print on the same instrument of 99.8000, printed 1.5 minutes earlier with Onebrook Securities, the client was 30.1 bps worse off — 30.1 bps in value terms. Applied to the client notional, $75,150 of value moved away from the client relative to the terms the firm could demonstrably have achieved.

| Computed value | Amount |
|---|---:|
| Client detriment (EMI) | 30.06 bps |
| Level difference | 30.06 bps |
| Client notional (PTC) | $25,000,000 |
| Client price | 99.500 |
| Reference price | 99.800 |
| Reference basis | Firm's own contemporaneous print |
| Gap to reference print | 1.5 min |
| Counterparty | Alpha Pension Trust (client) |
| Venue | Fenics UST |

### UAT-BESTEX-02 — $6m client fill, 26 bps behind, just over the threshold

**PASS** — expected a Best Execution alert. Best Execution raised 1 alert from these trades.

- **Metric:** Best Execution (threshold $15,000)
- **Products:** fenics
- **Trades analysed:** 2 documents — 2 executions, 2 order streams
- **Size:** barely

**What is being tested.** That a fill one basis point over the materiality floor on a modest notional still reports, and lands just above the threshold.

**Scenario.** A $4m dealer print at 99.76, then a $6m client fill at 99.56 — 26 bps worse, inside the five-minute reference window. Deliberately sized to land just above the threshold, which is what shows the threshold is doing real work rather than letting everything through.

**Why these trades.** This case sits one basis point above the 25 bps materiality floor and only a little above the USD threshold, so it exercises both limits at once. It is the companion to UAT-NEG-BESTEX-02, which is the same shape at 15 bps and must not fire: between them they show exactly where the line is.

**Expected.** A Best Execution alert a short way above the threshold, with a level difference just over 25 bps.

**The trades analysed.**

| | Id | Time (UTC) | Trader | Instrument | Side | Size | Price | Counterparty | Detail | In alert |
|---|---|---|---|---|---|---:|---:|---|---|---|
| order | UAT-BESTEX-02-O34 | 2026-10-13 09:59:58 | I. Solberg | XS2605000022 | bid | 4.0m | 99.76 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-BESTEX-02-O34-F1 | 2026-10-13 10:00:00 | I. Solberg | XS2605000022 | buy | 4.0m | 99.76 | Onebrook Securities | own risk | yes |
| order | UAT-BESTEX-02-O35 | 2026-10-13 10:01:18 | I. Solberg | XS2605000022 | bid | 6.0m | 99.5 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-BESTEX-02-O35-F1 | 2026-10-13 10:01:20 | I. Solberg | XS2605000022 | buy | 6.0m | 99.5 | Beta Family Office | client | yes |

**Alert raised — Best Execution, $15,638** (threshold $15,000)

> Beta Family Office filled $6.0m of XS2605000022 26.1 bps worse than the firm's own print

Beta Family Office was filled $6,000,000 of XS2605000022 at 99.5000, having sold to the firm. Measured against the firm's own print on the same instrument of 99.7600, printed 1.3 minutes earlier with Onebrook Securities, the client was 26.1 bps worse off — 26.1 bps in value terms. Applied to the client notional, $15,638 of value moved away from the client relative to the terms the firm could demonstrably have achieved.

| Computed value | Amount |
|---|---:|
| Client detriment (EMI) | 26.06 bps |
| Level difference | 26.06 bps |
| Client notional (PTC) | $6,000,000 |
| Client price | 99.500 |
| Reference price | 99.760 |
| Reference basis | Firm's own contemporaneous print |
| Gap to reference print | 80.0 s |
| Counterparty | Beta Family Office (client) |
| Venue | Fenics UST |

### UAT-BESTEX-03 — $40m client fill, 45 bps behind the firm's own print

**PASS** — expected a Best Execution alert. Best Execution raised 1 alert from these trades.

- **Metric:** Best Execution (threshold $15,000)
- **Products:** fenics
- **Trades analysed:** 2 documents — 2 executions, 2 order streams
- **Size:** major

**What is being tested.** That detriment scales with the client's notional, so the largest client loses the most and sorts to the top of the queue.

**Scenario.** A $10m dealer print at 100.05, then a $40m client fill at 99.60 — 45 bps worse, two minutes later. Sized far above the threshold, so it stays an alert even if the threshold is raised several times over.

**Why these trades.** Best Execution is the one metric here that measures harm to the client rather than gain to the trader, so what matters most is that the score tracks the size of the harm. Put next to UAT-BESTEX-02 it shows an order of magnitude between a $6m fill 26 bps behind and a $40m fill 45 bps behind, which is the right ordering for a review queue.

**Expected.** A Best Execution alert an order of magnitude above UAT-BESTEX-02, and the largest best execution score in the pack.

**The trades analysed.**

| | Id | Time (UTC) | Trader | Instrument | Side | Size | Price | Counterparty | Detail | In alert |
|---|---|---|---|---|---|---:|---:|---|---|---|
| order | UAT-BESTEX-03-O36 | 2026-10-13 12:59:58 | I. Solberg | XS2605000033 | bid | 10m | 100.05 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-BESTEX-03-O36-F1 | 2026-10-13 13:00:00 | I. Solberg | XS2605000033 | buy | 10m | 100.05 | Twyford Markets | own risk | yes |
| order | UAT-BESTEX-03-O37 | 2026-10-13 13:01:58 | I. Solberg | XS2605000033 | bid | 40m | 99.6 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-BESTEX-03-O37-F1 | 2026-10-13 13:02:00 | I. Solberg | XS2605000033 | buy | 40m | 99.6 | Gamma Mutual Insurance | client | yes |

**Alert raised — Best Execution, $179,910** (threshold $15,000)

> Gamma Mutual Insurance filled $40.0m of XS2605000033 45.0 bps worse than the firm's own print

Gamma Mutual Insurance was filled $40,000,000 of XS2605000033 at 99.6000, having sold to the firm. Measured against the firm's own print on the same instrument of 100.0500, printed 2.0 minutes earlier with Twyford Markets, the client was 45.0 bps worse off — 45.0 bps in value terms. Applied to the client notional, $179,910 of value moved away from the client relative to the terms the firm could demonstrably have achieved.

| Computed value | Amount |
|---|---:|
| Client detriment (EMI) | 44.98 bps |
| Level difference | 44.98 bps |
| Client notional (PTC) | $40,000,000 |
| Client price | 99.600 |
| Reference price | 100.050 |
| Reference basis | Firm's own contemporaneous print |
| Gap to reference print | 2.0 min |
| Counterparty | Gamma Mutual Insurance (client) |
| Venue | Fenics UST |

## Wash trading — must not fire

Four patterns that resemble a round trip and are not one. Each is stopped by a different check.

### UAT-NEG-WASH-01 — Two completely different bonds, bought and sold at the same moment

**PASS** — expected no alert. No alert from any metric, and nothing was scored — the data never passed the gates.

- **Metric:** Wash Trading (threshold $15,000)
- **Products:** fenics
- **Trades analysed:** 2 documents — 2 executions, 2 order streams
- **Check that should stop it:** Offsetting legs are only ever looked for within one trader, one instrument and one day. Two instruments are never compared against each other.

**What is being tested.** That a buy and a sell of the same size at the same moment are not treated as a round trip when they are in different instruments.

**Scenario.** A trader buys $30m of one bond at 10:00:05 and sells $30m of a different bond at 10:00:12, both against the same internal book.

**Why these trades.** This is the most obvious way to produce a false positive: the sizes match, the accounts match, the timestamps are seconds apart, and on a summary screen it looks exactly like a wash. The only thing that makes it legitimate is that the two trades are in different instruments, so no position was closed. If the detector were matching on size and time rather than on a normalised instrument, this is the case that would expose it.

**Expected.** No alert of any kind on either trade.

**The trades analysed.**

| | Id | Time (UTC) | Trader | Instrument | Side | Size | Price | Counterparty | Detail | In alert |
|---|---|---|---|---|---|---:|---:|---|---|---|
| order | UAT-NEG-WASH-01-O38 | 2026-10-14 10:00:03 | R. Duarte | XS2606000011 | bid | 30m | 99.7 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-NEG-WASH-01-O38-F1 | 2026-10-14 10:00:05 | R. Duarte | XS2606000011 | buy | 30m | 99.7 | Internal Book Transfer | own risk | - |
| order | UAT-NEG-WASH-01-O39 | 2026-10-14 10:00:10 | R. Duarte | XS2606000012 | offer | 30m | 101.2 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-NEG-WASH-01-O39-F1 | 2026-10-14 10:00:12 | R. Duarte | XS2606000012 | sell | 30m | 101.2 | Internal Book Transfer | own risk | - |

**No alert, and nothing scored.** The trades were read and normalised but never priced — a gate stopped them first, which is the intended behaviour for this case.

**No setting to relax.** This check is structural rather than configurable, so there is no version of the settings under which these trades become this behaviour.

### UAT-NEG-WASH-02 — Position opened in the morning, closed in the afternoon

**PASS** — expected no alert. No alert from any metric, and nothing was scored — the data never passed the gates.

- **Metric:** Wash Trading (threshold $15,000)
- **Products:** fenics
- **Trades analysed:** 2 documents — 2 executions, 2 order streams
- **Check that should stop it:** The maximum gap between offsetting legs, 30 minutes by default. Beyond it the two trades are never considered as a pair.

**What is being tested.** That a genuine position held for most of the session and then closed is not a round trip, however exactly the sizes offset.

**Scenario.** A trader buys $30m of a bond from a dealer at 09:15 and sells the same $30m to another dealer at 14:55, five hours and 40 minutes later.

**Why these trades.** Taking a position and closing it later in the day is the ordinary business of a trading book, and the sizes offsetting exactly is normal rather than suspicious — that is what closing a position means. What separates it from a wash is that real market risk was carried for most of a session. The engine's own limit on the gap between legs is what has to catch this, and at five hours and 40 minutes it is nowhere near it.

**Expected.** No alert of any kind.

**The trades analysed.**

| | Id | Time (UTC) | Trader | Instrument | Side | Size | Price | Counterparty | Detail | In alert |
|---|---|---|---|---|---|---:|---:|---|---|---|
| order | UAT-NEG-WASH-02-O40 | 2026-10-14 09:14:58 | R. Duarte | XS2606000022 | bid | 30m | 99.5 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-NEG-WASH-02-O40-F1 | 2026-10-14 09:15:00 | R. Duarte | XS2606000022 | buy | 30m | 99.5 | Onebrook Securities | own risk | - |
| order | UAT-NEG-WASH-02-O41 | 2026-10-14 14:54:58 | R. Duarte | XS2606000022 | offer | 30m | 99.85 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-NEG-WASH-02-O41-F1 | 2026-10-14 14:55:00 | R. Duarte | XS2606000022 | sell | 30m | 99.85 | Twyford Markets | own risk | - |

**No alert, and nothing scored.** The trades were read and normalised but never priced — a gate stopped them first, which is the intended behaviour for this case.

**Proof the check is what stopped it.** With **Max gap between legs** moved from 30 to 7 hours and the pack scored again: Wash Trading scores these trades at $12,150 against a $15,000 threshold, below the threshold. The trades are now priced but stay under the threshold, so the check and the scoring agree about them.

### UAT-NEG-WASH-03 — Market making: bought from one client, sold to another

**PASS** — expected no alert. No alert from any metric, and nothing was scored — the data never passed the gates.

- **Metric:** Wash Trading (threshold $15,000)
- **Products:** fenics
- **Trades analysed:** 2 documents — 2 executions, 2 order streams
- **Check that should stop it:** Relatedness and the Counter-Narrative. Two unrelated external clients score far below an internal account, and the client-facilitation explanation cancels what is left.

**What is being tested.** That quoting both sides to clients — buying from one and selling to another within minutes — is not read as a wash, even though the legs offset.

**Scenario.** A trader buys $25m of a bond from one client at 10:00 and sells $25m of the same bond to a different client at 10:08, four basis points higher.

**Why these trades.** This is the single most dangerous false positive in the whole metric, because it is what a market maker does all day: the instrument is the same, the size is the same, the gap is minutes, and the position nets to flat. The difference is that risk genuinely changed hands twice, with two unrelated clients, and the firm earned the spread for it. The engine has to reach that conclusion on its own from the counterparties and the client-facing role, and say so — rather than being told to ignore it.

**Expected.** No alert. The legitimate reading has to come out at least as large as the abusive one, so nothing is even scored.

**The trades analysed.**

| | Id | Time (UTC) | Trader | Instrument | Side | Size | Price | Counterparty | Detail | In alert |
|---|---|---|---|---|---|---:|---:|---|---|---|
| order | UAT-NEG-WASH-03-O42 | 2026-10-14 09:59:58 | R. Duarte | XS2606000033 | bid | 25m | 99.3 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-NEG-WASH-03-O42-F1 | 2026-10-14 10:00:00 | R. Duarte | XS2606000033 | buy | 25m | 99.3 | Alpha Pension Trust | client | - |
| order | UAT-NEG-WASH-03-O43 | 2026-10-14 10:07:58 | R. Duarte | XS2606000033 | offer | 25m | 99.34 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-NEG-WASH-03-O43-F1 | 2026-10-14 10:08:00 | R. Duarte | XS2606000033 | sell | 25m | 99.34 | Beta Family Office | client | - |

**No alert, and nothing scored.** The trades were read and normalised but never priced — a gate stopped them first, which is the intended behaviour for this case.

**No setting to relax.** This check is structural rather than configurable, so there is no version of the settings under which these trades become this behaviour.

### UAT-NEG-WASH-04 — Partial hedge against an internal book

**PASS** — expected no alert. No alert from any metric, and nothing was scored — the data never passed the gates.

- **Metric:** Wash Trading (threshold $15,000)
- **Products:** fenics
- **Trades analysed:** 2 documents — 2 executions, 2 order streams
- **Check that should stop it:** The size match tolerance, 15% by default. $9m against $30m is nowhere near offsetting.

**What is being tested.** That a partial offset is not reported as a round trip just because both sides face the same internal account.

**Scenario.** A trader buys $30m of a bond from an internal book at 11:00 and sells $9m of it back five minutes later — 30% of the position, leaving $21m of exposure.

**Why these trades.** Everything that makes UAT-WASH-01 an alert is present here except that the legs do not offset: same instrument, same internal account, five minutes apart. What is missing is the round trip, because 70% of the position is still live and still carrying risk. Without a size-match requirement this case would be indistinguishable from the real thing, which is why the tolerance exists and why it is on the admin page.

**Expected.** No alert of any kind.

**The trades analysed.**

| | Id | Time (UTC) | Trader | Instrument | Side | Size | Price | Counterparty | Detail | In alert |
|---|---|---|---|---|---|---:|---:|---|---|---|
| order | UAT-NEG-WASH-04-O44 | 2026-10-14 10:59:58 | R. Duarte | XS2606000044 | bid | 30m | 100 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-NEG-WASH-04-O44-F1 | 2026-10-14 11:00:00 | R. Duarte | XS2606000044 | buy | 30m | 100 | Internal Book Transfer | own risk | - |
| order | UAT-NEG-WASH-04-O45 | 2026-10-14 11:04:58 | R. Duarte | XS2606000044 | offer | 9.0m | 100 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-NEG-WASH-04-O45-F1 | 2026-10-14 11:05:00 | R. Duarte | XS2606000044 | sell | 9.0m | 100 | Internal Book Transfer | own risk | - |

**No alert, and nothing scored.** The trades were read and normalised but never priced — a gate stopped them first, which is the intended behaviour for this case.

**Proof the check is what stopped it.** With **Size match tolerance** moved from 15 to 80% and the pack scored again: Wash Trading scores these trades at $2,430 against a $15,000 threshold, below the threshold. The trades are now priced but stay under the threshold, so the check and the scoring agree about them.

## Front running — must not fire

Three patterns involving both client business and the firm's own risk, none of which is front running.

### UAT-NEG-FRONT-01 — Own-account trade six hours after the client business

**PASS** — expected no alert. No alert from any metric, and nothing was scored — the data never passed the gates.

- **Metric:** Front Running (threshold $20,000)
- **Products:** fenics
- **Trades analysed:** 3 documents — 4 executions, 3 order streams
- **Check that should stop it:** The maximum lead time, 15 minutes by default. Client business older than that is not considered as the impacting flow at all.

**What is being tested.** That a trade in the same instrument and the same direction as earlier client business is not front running when it happens hours later.

**Scenario.** A trader holds a $20m own-account position from 09:00, fills $60m of client business between 09:25 and 09:35, and sells the $20m at 15:30 — nearly six hours after the last client fill.

**Why these trades.** This is the case the request asked for by name, and it matters because the sequence is identical to UAT-FRONT-01 — position, client flow, exit, all in the right order. The only difference is the gap. Front running is priced on the impact the client business left standing at the moment of the exit, and six hours later there is none: the modelled impact has decayed through roughly twelve half-lives. A tool that flagged this would flag every position a trader ever closed on a day they also served a client.

**Expected.** No alert of any kind.

**The trades analysed.**

| | Id | Time (UTC) | Trader | Instrument | Side | Size | Price | Counterparty | Detail | In alert |
|---|---|---|---|---|---|---:|---:|---|---|---|
| order | UAT-NEG-FRONT-01-O46 | 2026-10-14 08:59:58 | R. Duarte | XS2607000011 | bid | 20m | 99.6 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-NEG-FRONT-01-O46-F1 | 2026-10-14 09:00:00 | R. Duarte | XS2607000011 | buy | 20m | 99.6 | Onebrook Securities | own risk | - |
| order | UAT-NEG-FRONT-01-O47 | 2026-10-14 09:22:00 | R. Duarte | XS2607000011 | bid | 60m | 99.62 | - | filled, 1 level, 100% shown, 780s | - |
| fill | UAT-NEG-FRONT-01-O47-F1 | 2026-10-14 09:25:00 | R. Duarte | XS2607000011 | buy | 30m | 99.62 | Alpha Pension Trust | client | - |
| fill | UAT-NEG-FRONT-01-O47-F2 | 2026-10-14 09:35:00 | R. Duarte | XS2607000011 | buy | 30m | 99.62 | Beta Family Office | client | - |
| order | UAT-NEG-FRONT-01-O48 | 2026-10-14 15:29:58 | R. Duarte | XS2607000011 | offer | 20m | 99.7 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-NEG-FRONT-01-O48-F1 | 2026-10-14 15:30:00 | R. Duarte | XS2607000011 | sell | 20m | 99.7 | Twyford Markets | own risk | - |

**No alert, and nothing scored.** The trades were read and normalised but never priced — a gate stopped them first, which is the intended behaviour for this case.

**Proof the check is what stopped it.** With **Max lead time** moved from 900 to 7 hours and the pack scored again: Front Running scores these trades at $9 against a $20,000 threshold, below the threshold. The trades are now priced but stay under the threshold, so the check and the scoring agree about them.

### UAT-NEG-FRONT-02 — Client business on the other side of the market

**PASS** — expected no alert. No alert from any metric, and nothing was scored — the data never passed the gates.

- **Metric:** Front Running (threshold $20,000)
- **Products:** fenics
- **Trades analysed:** 3 documents — 4 executions, 3 order streams
- **Check that should stop it:** The impacting flow must be in the opposite direction to the exit — in other words, the same direction as the position being held.

**What is being tested.** That client business in the opposite direction to the trader's own position cannot be the impacting flow, however close in time.

**Scenario.** A trader buys $20m of a bond for the firm's own book at 10:00, then sells $60m of the same bond to clients between 10:05 and 10:09, then sells $28m for the firm's own book at 10:12.

**Why these trades.** The timing here is tighter than in the real case — three minutes rather than two — so timing alone cannot be what saves it. Selling to clients pushes the instrument down, which is the wrong way for someone holding a long position to profit; the trader's own sale is into a market their client business just moved against them. Direction is the substance of this metric, not an incidental field, and this case is what proves it is being read.

**Expected.** No alert of any kind.

**The trades analysed.**

| | Id | Time (UTC) | Trader | Instrument | Side | Size | Price | Counterparty | Detail | In alert |
|---|---|---|---|---|---|---:|---:|---|---|---|
| order | UAT-NEG-FRONT-02-O49 | 2026-10-14 09:59:58 | R. Duarte | XS2607000022 | bid | 20m | 100 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-NEG-FRONT-02-O49-F1 | 2026-10-14 10:00:00 | R. Duarte | XS2607000022 | buy | 20m | 100 | Onebrook Securities | own risk | - |
| order | UAT-NEG-FRONT-02-O50 | 2026-10-14 10:03:00 | R. Duarte | XS2607000022 | offer | 60m | 99.98 | - | filled, 1 level, 100% shown, 360s | - |
| fill | UAT-NEG-FRONT-02-O50-F1 | 2026-10-14 10:05:00 | R. Duarte | XS2607000022 | sell | 30m | 99.98 | Alpha Pension Trust | client | - |
| fill | UAT-NEG-FRONT-02-O50-F2 | 2026-10-14 10:09:00 | R. Duarte | XS2607000022 | sell | 30m | 99.98 | Beta Family Office | client | - |
| order | UAT-NEG-FRONT-02-O51 | 2026-10-14 10:11:58 | R. Duarte | XS2607000022 | offer | 28m | 99.96 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-NEG-FRONT-02-O51-F1 | 2026-10-14 10:12:00 | R. Duarte | XS2607000022 | sell | 28m | 99.96 | Twyford Markets | own risk | - |

**No alert, and nothing scored.** The trades were read and normalised but never priced — a gate stopped them first, which is the intended behaviour for this case.

**No setting to relax.** This check is structural rather than configurable, so there is no version of the settings under which these trades become this behaviour.

### UAT-NEG-FRONT-03 — No position held before the client business

**PASS** — expected no alert. No alert from any metric, and nothing was scored — the data never passed the gates.

- **Metric:** Front Running (threshold $20,000)
- **Products:** fenics
- **Trades analysed:** 2 documents — 3 executions, 2 order streams
- **Check that should stop it:** The position being exited must have been opened before the client flow began, and must be at least a quarter of the size of the exit.

**What is being tested.** That trading after client business is not front running when the trader was flat beforehand — the position has to pre-date the flow.

**Scenario.** A trader fills $60m of client business between 10:00 and 10:06 holding no position of their own, then sells $20m for the firm's own book at 10:08, two minutes later.

**Why these trades.** Front running requires foreknowledge turned into a position, and a trader who was flat when the client business arrived had nothing in place to benefit. Selling afterwards may be any number of things — hedging the inventory the client business just created, most likely — but it cannot be front running, because there was no earlier position to exit. The two-minute gap is identical to UAT-FRONT-01, so the only difference between an alert and silence here is whether the position existed first.

**Expected.** No alert of any kind.

**The trades analysed.**

| | Id | Time (UTC) | Trader | Instrument | Side | Size | Price | Counterparty | Detail | In alert |
|---|---|---|---|---|---|---:|---:|---|---|---|
| order | UAT-NEG-FRONT-03-O52 | 2026-10-14 09:58:00 | R. Duarte | XS2607000033 | bid | 60m | 99.5 | - | filled, 1 level, 100% shown, 480s | - |
| fill | UAT-NEG-FRONT-03-O52-F1 | 2026-10-14 10:00:00 | R. Duarte | XS2607000033 | buy | 30m | 99.5 | Alpha Pension Trust | client | - |
| fill | UAT-NEG-FRONT-03-O52-F2 | 2026-10-14 10:06:00 | R. Duarte | XS2607000033 | buy | 30m | 99.5 | Beta Family Office | client | - |
| order | UAT-NEG-FRONT-03-O53 | 2026-10-14 10:07:58 | R. Duarte | XS2607000033 | offer | 20m | 99.52 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-NEG-FRONT-03-O53-F1 | 2026-10-14 10:08:00 | R. Duarte | XS2607000033 | sell | 20m | 99.52 | Twyford Markets | own risk | - |

**No alert, and nothing scored.** The trades were read and normalised but never priced — a gate stopped them first, which is the intended behaviour for this case.

**No setting to relax.** This check is structural rather than configurable, so there is no version of the settings under which these trades become this behaviour.

## Spoofing — must not fire

Four large orders that were pulled, none of which is a decoy. The gates are the order's life, how much of it was visible, whether it traded, and whether anything was executed the other way.

### UAT-NEG-SPOOF-01 — Large bid pulled, nothing executed the other way

**PASS** — expected no alert. No alert from any metric, and nothing was scored — the data never passed the gates.

- **Metric:** Spoofing (threshold $12,000)
- **Products:** fenics
- **Trades analysed:** 1 document — 0 executions, 1 order stream
- **Check that should stop it:** There must be an execution in the opposite direction while the order rested, worth at least 15% of the order.

**What is being tested.** That a large order placed and cancelled is not spoofing on its own, with no trade on the opposite side for it to have benefited.

**Scenario.** A $50m bid at the touch, fully displayed, cancelled 20 seconds later with no fills. The trader executes nothing else in that bond all day.

**Why these trades.** Pulling a large order quickly is ordinary: the market moves, a client cancels, a risk limit changes, the price is no longer wanted. What makes it spoofing is that the trader was doing something on the other side that the order's visible weight helped. With nothing on the other side there is no benefit to measure and no reason to suspect anything, and this case is identical to UAT-SPOOF-01 in every other respect.

**Expected.** No alert of any kind.

**The trades analysed.**

| | Id | Time (UTC) | Trader | Instrument | Side | Size | Price | Counterparty | Detail | In alert |
|---|---|---|---|---|---|---:|---:|---|---|---|
| order | UAT-NEG-SPOOF-01-O54 | 2026-10-14 09:50:00 | Y. Tanaka | XS2608000011 | bid | 50m | 99.4 | - | cancelled unfilled, 1 level, 100% shown, 20s | - |

**No alert, and nothing scored.** The trades were read and normalised but never priced — a gate stopped them first, which is the intended behaviour for this case.

**No setting to relax.** This check is structural rather than configurable, so there is no version of the settings under which these trades become this behaviour.

### UAT-NEG-SPOOF-02 — The large order actually traded

**PASS** — expected no alert. No alert from any metric, and nothing was scored — the data never passed the gates.

- **Metric:** Spoofing (threshold $12,000)
- **Products:** fenics
- **Trades analysed:** 2 documents — 3 executions, 2 order streams
- **Check that should stop it:** The order must have been cancelled with effectively nothing filled. A filled order is never a candidate.

**What is being tested.** That an order that filled is genuine liquidity, whatever else the trader was doing at the time.

**Scenario.** A $50m bid at the touch, fully displayed, which fills completely in two clips over 40 seconds. The trader also sells $20m of the same bond while it is working.

**Why these trades.** A spoof is an order placed with no intention of trading, so an order that traded in full is the clearest possible refutation — the trader took the risk they were displaying. The $20m sale is left in deliberately, so that the opposite-side execution the metric looks for is present and the only thing standing between this case and an alert is the fill.

**Expected.** No alert of any kind.

**The trades analysed.**

| | Id | Time (UTC) | Trader | Instrument | Side | Size | Price | Counterparty | Detail | In alert |
|---|---|---|---|---|---|---:|---:|---|---|---|
| order | UAT-NEG-SPOOF-02-O55 | 2026-10-14 09:55:00 | Y. Tanaka | XS2608000022 | bid | 50m | 99.45 | - | filled, 1 level, 100% shown, 40s | - |
| fill | UAT-NEG-SPOOF-02-O55-F1 | 2026-10-14 09:55:10 | Y. Tanaka | XS2608000022 | buy | 25m | 99.45 | Onebrook Securities | own risk | - |
| order | UAT-NEG-SPOOF-02-O56 | 2026-10-14 09:55:18 | Y. Tanaka | XS2608000022 | offer | 20m | 99.45 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-NEG-SPOOF-02-O56-F1 | 2026-10-14 09:55:20 | Y. Tanaka | XS2608000022 | sell | 20m | 99.45 | Twyford Markets | own risk | - |
| fill | UAT-NEG-SPOOF-02-O55-F2 | 2026-10-14 09:55:40 | Y. Tanaka | XS2608000022 | buy | 25m | 99.45 | Onebrook Securities | own risk | - |

**No alert, and nothing scored.** The trades were read and normalised but never priced — a gate stopped them first, which is the intended behaviour for this case.

**No setting to relax.** This check is structural rather than configurable, so there is no version of the settings under which these trades become this behaviour.

### UAT-NEG-SPOOF-03 — The order rested for eleven minutes

**PASS** — expected no alert. No alert from any metric, and nothing was scored — the data never passed the gates.

- **Metric:** Spoofing (threshold $12,000)
- **Products:** fenics
- **Trades analysed:** 2 documents — 1 execution, 2 order streams
- **Check that should stop it:** The maximum order life, 60 seconds by default. Anything resting longer is treated as real liquidity.

**What is being tested.** That an order left in the market long enough to be hit is treated as genuine liquidity even if it is eventually pulled unfilled.

**Scenario.** A $50m bid at the touch, fully displayed, cancelled unfilled after 11 minutes. $20m is sold the other way while it rests.

**Why these trades.** Time is the cleanest evidence of intent available in order data. A decoy has to be withdrawn before anyone can trade against it; an order that sits at the touch for eleven minutes was genuinely exposed to being filled for eleven minutes, and the trader carried that risk. Everything else here is identical to UAT-SPOOF-01, including the sale on the other side, so the order's life is doing all the work.

**Expected.** No alert of any kind.

**The trades analysed.**

| | Id | Time (UTC) | Trader | Instrument | Side | Size | Price | Counterparty | Detail | In alert |
|---|---|---|---|---|---|---:|---:|---|---|---|
| order | UAT-NEG-SPOOF-03-O57 | 2026-10-14 10:10:00 | Y. Tanaka | XS2608000033 | bid | 50m | 99.55 | - | cancelled unfilled, 1 level, 100% shown, 660s | - |
| order | UAT-NEG-SPOOF-03-O58 | 2026-10-14 10:14:58 | Y. Tanaka | XS2608000033 | offer | 20m | 99.55 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-NEG-SPOOF-03-O58-F1 | 2026-10-14 10:15:00 | Y. Tanaka | XS2608000033 | sell | 20m | 99.55 | Twyford Markets | own risk | - |

**No alert, and nothing scored.** The trades were read and normalised but never priced — a gate stopped them first, which is the intended behaviour for this case.

**Proof the check is what stopped it.** With **Max order life** moved from 60 to 15 minutes and the pack scored again: still nothing. Opening this check is not enough on its own — the model still does not price these trades as the behaviour once it is allowed to look at them.

### UAT-NEG-SPOOF-04 — The order was hidden, not displayed

**PASS** — expected no alert. No alert from any metric, and nothing was scored — the data never passed the gates.

- **Metric:** Spoofing (threshold $12,000)
- **Products:** fenics
- **Trades analysed:** 2 documents — 1 execution, 2 order streams
- **Check that should stop it:** The minimum displayed share, 70% by default. An order showing 10% of its size is not a candidate.

**What is being tested.** That an order the market could not see is not a decoy, because nothing can be misled by it.

**Scenario.** A $50m bid with only $5m displayed — the rest held back — cancelled after 15 seconds, with $20m sold the other way.

**Why these trades.** Spoofing works by being seen. An iceberg showing $5m of $50m is the opposite technique: a trader who wants to buy without moving the price against themselves, which is a legitimate and common way to work a large order. The displayed share is the field that separates the two intentions, and this case is identical to UAT-SPOOF-01 apart from that one number.

**Expected.** No alert of any kind.

**The trades analysed.**

| | Id | Time (UTC) | Trader | Instrument | Side | Size | Price | Counterparty | Detail | In alert |
|---|---|---|---|---|---|---:|---:|---|---|---|
| order | UAT-NEG-SPOOF-04-O59 | 2026-10-14 10:30:00 | Y. Tanaka | XS2608000044 | bid | 50m | 99.65 | - | cancelled unfilled, 1 level, 10% shown, 15s | - |
| order | UAT-NEG-SPOOF-04-O60 | 2026-10-14 10:30:06 | Y. Tanaka | XS2608000044 | offer | 20m | 99.65 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-NEG-SPOOF-04-O60-F1 | 2026-10-14 10:30:08 | Y. Tanaka | XS2608000044 | sell | 20m | 99.65 | Twyford Markets | own risk | - |

**No alert, and nothing scored.** The trades were read and normalised but never priced — a gate stopped them first, which is the intended behaviour for this case.

**Proof the check is what stopped it.** With **Min displayed share** moved from 0.7 to 5% and the pack scored again: Spoofing scores these trades at $1,000 against a $12,000 threshold, below the threshold. The trades are now priced but stay under the threshold, so the check and the scoring agree about them.

## Layering — must not fire

Three sets of orders on one side of the book that are not ladders built to mislead.

### UAT-NEG-LAYER-01 — One order re-posted five times at the same price

**PASS** — expected no alert. No alert from any metric, and nothing was scored — the data never passed the gates.

- **Metric:** Layering (threshold $12,000)
- **Products:** fenics
- **Trades analysed:** 6 documents — 1 execution, 6 order streams
- **Check that should stop it:** The minimum number of distinct price levels, four by default. Five orders at one price is one level — and the floor cannot be set below two, because a single price can never be a ladder, so no configuration makes this case fire.

**What is being tested.** That repeatedly posting at a single price is not a ladder, however many orders it takes.

**Scenario.** Five bids of $12m on the same bond, all at exactly the same price, each resting about 90 seconds before being cancelled, with $20m sold the other way.

**Why these trades.** A trader working one order re-posts it as the book changes around them, which produces several orders on one side of the market in quick succession — the same raw shape as a ladder. What a ladder adds is depth: rungs at successive prices, so the book appears to have weight behind it at several levels. Counting orders would flag this; counting distinct price levels does not. The 90-second lives also keep it clear of the spoofing test, so nothing fires.

**Expected.** No alert of any kind.

**The trades analysed.**

| | Id | Time (UTC) | Trader | Instrument | Side | Size | Price | Counterparty | Detail | In alert |
|---|---|---|---|---|---|---:|---:|---|---|---|
| order | UAT-NEG-LAYER-01-O61 | 2026-10-14 10:40:00 | Y. Tanaka | XS2609000011 | bid | 12m | 99.75 | - | cancelled unfilled, 1 level, 100% shown, 90s | - |
| order | UAT-NEG-LAYER-01-O62 | 2026-10-14 10:40:20 | Y. Tanaka | XS2609000011 | bid | 12m | 99.75 | - | cancelled unfilled, 1 level, 100% shown, 90s | - |
| order | UAT-NEG-LAYER-01-O63 | 2026-10-14 10:40:40 | Y. Tanaka | XS2609000011 | bid | 12m | 99.75 | - | cancelled unfilled, 1 level, 100% shown, 90s | - |
| order | UAT-NEG-LAYER-01-O66 | 2026-10-14 10:40:58 | Y. Tanaka | XS2609000011 | offer | 20m | 99.75 | - | filled, 1 level, 100% shown, 2s | - |
| order | UAT-NEG-LAYER-01-O64 | 2026-10-14 10:41:00 | Y. Tanaka | XS2609000011 | bid | 12m | 99.75 | - | cancelled unfilled, 1 level, 100% shown, 90s | - |
| fill | UAT-NEG-LAYER-01-O66-F1 | 2026-10-14 10:41:00 | Y. Tanaka | XS2609000011 | sell | 20m | 99.75 | Twyford Markets | own risk | - |
| order | UAT-NEG-LAYER-01-O65 | 2026-10-14 10:41:20 | Y. Tanaka | XS2609000011 | bid | 12m | 99.75 | - | cancelled unfilled, 1 level, 100% shown, 90s | - |

**No alert, and nothing scored.** The trades were read and normalised but never priced — a gate stopped them first, which is the intended behaviour for this case.

**No setting to relax.** This check is structural rather than configurable, so there is no version of the settings under which these trades become this behaviour.

### UAT-NEG-LAYER-02 — A ladder that mostly traded

**PASS** — expected no alert. No alert from any metric. Spoofing scored these trades at 2,962, under its 12,000 threshold.

- **Metric:** Layering (threshold $12,000)
- **Products:** fenics
- **Trades analysed:** 6 documents — 4 executions, 6 order streams
- **Check that should stop it:** The cancel ratio threshold, 80% of the ladder's notional by default. This ladder cancelled 40%.

**What is being tested.** That orders at several price levels are not layering when most of that size actually filled.

**Scenario.** Five bids at five prices, $12m each. Three fill in full, two are cancelled — 40% of the notional cancelled. $20m is sold the other way.

**Why these trades.** Working an order down through several price levels and getting most of it done is a normal way to buy a bond, and it leaves exactly the same footprint as a ladder in everything except the outcome. Layering is characterised by the orders being withdrawn: the appearance of depth is the point, and filling it would defeat the purpose. The cancel ratio is what distinguishes the two, and at 40% this case is well under the 80% the engine requires.

**Expected.** No alert of any kind.

**The trades analysed.**

| | Id | Time (UTC) | Trader | Instrument | Side | Size | Price | Counterparty | Detail | In alert |
|---|---|---|---|---|---|---:|---:|---|---|---|
| order | UAT-NEG-LAYER-02-O67 | 2026-10-14 11:00:00 | Y. Tanaka | XS2609000022 | bid | 12m | 99.85 | - | filled, 1 level, 100% shown, 30s | - |
| order | UAT-NEG-LAYER-02-O68 | 2026-10-14 11:00:20 | Y. Tanaka | XS2609000022 | bid | 12m | 99.84 | - | filled, 1 level, 100% shown, 30s | - |
| fill | UAT-NEG-LAYER-02-O67-F1 | 2026-10-14 11:00:30 | Y. Tanaka | XS2609000022 | buy | 12m | 99.85 | Onebrook Securities | own risk | - |
| order | UAT-NEG-LAYER-02-O69 | 2026-10-14 11:00:40 | Y. Tanaka | XS2609000022 | bid | 12m | 99.83 | - | filled, 1 level, 100% shown, 30s | - |
| fill | UAT-NEG-LAYER-02-O68-F1 | 2026-10-14 11:00:50 | Y. Tanaka | XS2609000022 | buy | 12m | 99.84 | Onebrook Securities | own risk | - |
| order | UAT-NEG-LAYER-02-O70 | 2026-10-14 11:01:00 | Y. Tanaka | XS2609000022 | bid | 12m | 99.82 | - | cancelled unfilled, 1 level, 100% shown, 30s | - |
| fill | UAT-NEG-LAYER-02-O69-F1 | 2026-10-14 11:01:10 | Y. Tanaka | XS2609000022 | buy | 12m | 99.83 | Onebrook Securities | own risk | - |
| order | UAT-NEG-LAYER-02-O71 | 2026-10-14 11:01:20 | Y. Tanaka | XS2609000022 | bid | 12m | 99.81 | - | cancelled unfilled, 1 level, 100% shown, 30s | - |
| order | UAT-NEG-LAYER-02-O72 | 2026-10-14 11:01:28 | Y. Tanaka | XS2609000022 | offer | 20m | 99.85 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-NEG-LAYER-02-O72-F1 | 2026-10-14 11:01:30 | Y. Tanaka | XS2609000022 | sell | 20m | 99.85 | Twyford Markets | own risk | - |

**No alert.** The highest score the engine produced on these trades was Spoofing at $2,962, below its threshold: $12.0m bid on XS2609000022 pulled after 30.0 seconds, $20.0m executed the other way

**Proof the check is what stopped it.** With **Cancel ratio threshold** moved from 0.8 to 20% and the pack scored again: Layering scores these trades at $31,010 against a $12,000 threshold — an alert. The alert appears. This check, and nothing else, is what kept the case quiet.

### UAT-NEG-LAYER-03 — A ladder standing well away from the touch

**PASS** — expected no alert. No alert from any metric, and nothing was scored — the data never passed the gates.

- **Metric:** Layering (threshold $12,000)
- **Products:** fenics
- **Trades analysed:** 12 documents — 7 executions, 12 order streams
- **Check that should stop it:** The minimum competitiveness, 0.35 by default — a size-weighted measure of how close to the touch the ladder sat.

**What is being tested.** That orders parked away from the market are not layering, because they are not close enough to influence the price.

**Scenario.** Five bids at five prices, $12m each, all cancelled within 30 seconds — but placed six to ten basis points below where the bond was trading, which the same file establishes through a morning of ordinary two-way prints. $20m is sold the other way.

**Why these trades.** Resting orders away from the touch is how traders leave standing interest in the market without being hit: they are visible, they are cancelled constantly, and they are not pretending anything. An order only shifts the apparent balance of the book if it is near the price people are actually trading at. This is the one gate in the metric that depends on knowing where the market was, which is why the pack includes the ordinary prints that establish it.

**Expected.** No alert of any kind.

**The trades analysed.**

| | Id | Time (UTC) | Trader | Instrument | Side | Size | Price | Counterparty | Detail | In alert |
|---|---|---|---|---|---|---:|---:|---|---|---|
| order | UAT-NEG-LAYER-03-O79 | 2026-10-14 08:39:58 | O. Brandt | XS2609000033 | bid | 2.0m | 99.5 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-NEG-LAYER-03-O79-F1 | 2026-10-14 08:40:00 | O. Brandt | XS2609000033 | buy | 2.0m | 99.5 | Onebrook Securities | own risk | - |
| order | UAT-NEG-LAYER-03-O80 | 2026-10-14 09:24:58 | O. Brandt | XS2609000033 | offer | 2.0m | 99.51 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-NEG-LAYER-03-O80-F1 | 2026-10-14 09:25:00 | O. Brandt | XS2609000033 | sell | 2.0m | 99.51 | Twyford Markets | own risk | - |
| order | UAT-NEG-LAYER-03-O81 | 2026-10-14 10:09:58 | M. Lindgren | XS2609000033 | bid | 2.0m | 99.5 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-NEG-LAYER-03-O81-F1 | 2026-10-14 10:10:00 | M. Lindgren | XS2609000033 | buy | 2.0m | 99.5 | Onebrook Securities | own risk | - |
| order | UAT-NEG-LAYER-03-O82 | 2026-10-14 11:04:58 | M. Lindgren | XS2609000033 | offer | 2.0m | 99.51 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-NEG-LAYER-03-O82-F1 | 2026-10-14 11:05:00 | M. Lindgren | XS2609000033 | sell | 2.0m | 99.51 | Twyford Markets | own risk | - |
| order | UAT-NEG-LAYER-03-O83 | 2026-10-14 11:49:58 | O. Brandt | XS2609000033 | bid | 2.0m | 99.51 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-NEG-LAYER-03-O83-F1 | 2026-10-14 11:50:00 | O. Brandt | XS2609000033 | buy | 2.0m | 99.51 | Twyford Markets | own risk | - |
| order | UAT-NEG-LAYER-03-O84 | 2026-10-14 12:34:58 | M. Lindgren | XS2609000033 | offer | 2.0m | 99.5 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-NEG-LAYER-03-O84-F1 | 2026-10-14 12:35:00 | M. Lindgren | XS2609000033 | sell | 2.0m | 99.5 | Onebrook Securities | own risk | - |
| order | UAT-NEG-LAYER-03-O73 | 2026-10-14 13:00:00 | Y. Tanaka | XS2609000033 | bid | 12m | 99.44 | - | cancelled unfilled, 1 level, 100% shown, 30s | - |
| order | UAT-NEG-LAYER-03-O74 | 2026-10-14 13:00:15 | Y. Tanaka | XS2609000033 | bid | 12m | 99.43 | - | cancelled unfilled, 1 level, 100% shown, 30s | - |
| order | UAT-NEG-LAYER-03-O75 | 2026-10-14 13:00:30 | Y. Tanaka | XS2609000033 | bid | 12m | 99.42 | - | cancelled unfilled, 1 level, 100% shown, 30s | - |
| order | UAT-NEG-LAYER-03-O78 | 2026-10-14 13:00:38 | Y. Tanaka | XS2609000033 | offer | 20m | 99.5 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-NEG-LAYER-03-O78-F1 | 2026-10-14 13:00:40 | Y. Tanaka | XS2609000033 | sell | 20m | 99.5 | Twyford Markets | own risk | - |
| order | UAT-NEG-LAYER-03-O76 | 2026-10-14 13:00:45 | Y. Tanaka | XS2609000033 | bid | 12m | 99.41 | - | cancelled unfilled, 1 level, 100% shown, 30s | - |
| order | UAT-NEG-LAYER-03-O77 | 2026-10-14 13:01:00 | Y. Tanaka | XS2609000033 | bid | 12m | 99.4 | - | cancelled unfilled, 1 level, 100% shown, 30s | - |

**No alert, and nothing scored.** The trades were read and normalised but never priced — a gate stopped them first, which is the intended behaviour for this case.

**Proof the check is what stopped it.** With **Min competitiveness** moved from 0.35 to no floor and the pack scored again: still nothing. Opening this check is not enough on its own — the model still does not price these trades as the behaviour once it is allowed to look at them.

## Best execution — must not fire

Three client fills that are not detriment: one better than the reference, one inside the materiality floor, one below the size floor.

### UAT-NEG-BESTEX-01 — The client got the better price

**PASS** — expected no alert. No alert from any metric, and nothing was scored — the data never passed the gates.

- **Metric:** Best Execution (threshold $15,000)
- **Products:** fenics
- **Trades analysed:** 2 documents — 2 executions, 2 order streams
- **Check that should stop it:** Detriment is measured on the client's side of the market and must be positive.

**What is being tested.** That a client filled better than the firm's own contemporaneous print is not detriment, and that the comparison is signed correctly.

**Scenario.** The firm buys $8m of a bond from a dealer at 99.50, then buys $25m from a client at 99.70 — the client sold 20 bps higher than the dealer did.

**Why these trades.** This is the mirror image of UAT-BESTEX-01 and it tests the one thing that is easy to get wrong in both directions: which side of the comparison the client is on. A client who sold wanted the highest price available; a client who bought wanted the lowest. Comparing the two prices without reference to the client's side would flag this case exactly as hard as the real one, which is why it is in the pack.

**Expected.** No alert of any kind. The client was better off, so there is no detriment to measure.

**The trades analysed.**

| | Id | Time (UTC) | Trader | Instrument | Side | Size | Price | Counterparty | Detail | In alert |
|---|---|---|---|---|---|---:|---:|---|---|---|
| order | UAT-NEG-BESTEX-01-O85 | 2026-10-14 09:19:58 | I. Solberg | XS2610000011 | bid | 8.0m | 99.5 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-NEG-BESTEX-01-O85-F1 | 2026-10-14 09:20:00 | I. Solberg | XS2610000011 | buy | 8.0m | 99.5 | Onebrook Securities | own risk | - |
| order | UAT-NEG-BESTEX-01-O86 | 2026-10-14 09:21:28 | I. Solberg | XS2610000011 | bid | 25m | 99.7 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-NEG-BESTEX-01-O86-F1 | 2026-10-14 09:21:30 | I. Solberg | XS2610000011 | buy | 25m | 99.7 | Alpha Pension Trust | client | - |

**No alert, and nothing scored.** The trades were read and normalised but never priced — a gate stopped them first, which is the intended behaviour for this case.

**No setting to relax.** This check is structural rather than configurable, so there is no version of the settings under which these trades become this behaviour.

### UAT-NEG-BESTEX-02 — Fifteen basis points behind — inside the materiality floor

**PASS** — expected no alert. No alert from any metric, and nothing was scored — the data never passed the gates.

- **Metric:** Best Execution (threshold $15,000)
- **Products:** fenics
- **Trades analysed:** 2 documents — 2 executions, 2 order streams
- **Check that should stop it:** The minimum client detriment, 25 bps by default. This fill was 15 bps behind.

**What is being tested.** That a small difference between a client fill and an earlier print is not reported, so the queue is not filled with ordinary spread.

**Scenario.** A $5m dealer print at 99.65, then a $25m client fill at 99.50 — 15 bps worse, 80 seconds later.

**Why these trades.** Two prices on the same bond minutes apart are almost never identical, and the gap between them is usually just the spread, the size difference and the market moving. If every such gap were an alert the metric would be unusable. The floor is where the firm says what counts as material, and this case sits deliberately below it while UAT-BESTEX-02 sits one basis point above — the pair is what demonstrates where the line is.

**Expected.** No alert of any kind.

**The trades analysed.**

| | Id | Time (UTC) | Trader | Instrument | Side | Size | Price | Counterparty | Detail | In alert |
|---|---|---|---|---|---|---:|---:|---|---|---|
| order | UAT-NEG-BESTEX-02-O87 | 2026-10-14 09:39:58 | I. Solberg | XS2610000022 | bid | 5.0m | 99.65 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-NEG-BESTEX-02-O87-F1 | 2026-10-14 09:40:00 | I. Solberg | XS2610000022 | buy | 5.0m | 99.65 | Onebrook Securities | own risk | - |
| order | UAT-NEG-BESTEX-02-O88 | 2026-10-14 09:41:18 | I. Solberg | XS2610000022 | bid | 25m | 99.5 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-NEG-BESTEX-02-O88-F1 | 2026-10-14 09:41:20 | I. Solberg | XS2610000022 | buy | 25m | 99.5 | Beta Family Office | client | - |

**No alert, and nothing scored.** The trades were read and normalised but never priced — a gate stopped them first, which is the intended behaviour for this case.

**Proof the check is what stopped it.** With **Min client detriment** moved from 25 to 10 bps and the pack scored again: Best Execution scores these trades at $37,632 against a $15,000 threshold — an alert. The alert appears. This check, and nothing else, is what kept the case quiet.

### UAT-NEG-BESTEX-03 — A $200k client fill, well behind the print

**PASS** — expected no alert. No alert from any metric, and nothing was scored — the data never passed the gates.

- **Metric:** Best Execution (threshold $15,000)
- **Products:** fenics
- **Trades analysed:** 2 documents — 2 executions, 2 order streams
- **Check that should stop it:** The minimum client notional, $250,000 by default.

**What is being tested.** That a client fill below the size floor is not reported even when the price difference is large.

**Scenario.** An $8m dealer print at 99.80, then a $200k client fill at 99.20 — 60 bps worse, inside the reference window.

**Why these trades.** Small tickets are priced differently and always will be: a $200k fill does not get the price an $8m fill gets, and the difference is the cost of doing a small trade rather than a failure of execution. The size floor is what keeps the review queue pointed at the fills where the money is, and this case checks that the floor is applied before the price comparison rather than after, so a large percentage on a tiny notional cannot climb the queue.

**Expected.** No alert of any kind, from this metric or from Off-Market Trading, which has the same floor.

**The trades analysed.**

| | Id | Time (UTC) | Trader | Instrument | Side | Size | Price | Counterparty | Detail | In alert |
|---|---|---|---|---|---|---:|---:|---|---|---|
| order | UAT-NEG-BESTEX-03-O89 | 2026-10-14 10:49:58 | I. Solberg | XS2610000033 | bid | 8.0m | 99.8 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-NEG-BESTEX-03-O89-F1 | 2026-10-14 10:50:00 | I. Solberg | XS2610000033 | buy | 8.0m | 99.8 | Onebrook Securities | own risk | - |
| order | UAT-NEG-BESTEX-03-O90 | 2026-10-14 10:50:58 | I. Solberg | XS2610000033 | bid | 200k | 99.2 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-NEG-BESTEX-03-O90-F1 | 2026-10-14 10:51:00 | I. Solberg | XS2610000033 | buy | 200k | 99.2 | Gamma Mutual Insurance | client | - |

**No alert, and nothing scored.** The trades were read and normalised but never priced — a gate stopped them first, which is the intended behaviour for this case.

**Proof the check is what stopped it.** With **Min client notional** moved from 250000 to $100,000 and the pack scored again: Best Execution scores these trades at $1,202 against a $15,000 threshold, below the threshold. The trades are now priced but stay under the threshold, so the check and the scoring agree about them.

## Ordinary business

A day of unremarkable two-way trading. Nothing in it should produce an alert of any kind.

### UAT-CLEAN-01 — A day of ordinary two-way business across three product families

**PASS** — expected no alert. No alert from any metric, and nothing was scored — the data never passed the gates.

- **Metric:** Wash Trading (threshold $15,000)
- **Products:** fenics, credit, rates
- **Trades analysed:** 14 documents — 14 executions, 8 order streams
- **Check that should stop it:** None in particular — the whole engine. This case passes only if every metric stays quiet on ordinary flow.

**What is being tested.** That an unremarkable trading day produces no alerts at all — the base case for every other number in this report.

**Scenario.** Fourteen trades on one day across three traders and three product families: bonds bought and sold with clients and dealers an hour or more apart, a CDS position taken and left on, two swaptions at different curve points, and two bond orders that filled normally.

**Why these trades.** Every other case in this pack is engineered, which means they say nothing on their own about what happens to normal business. This case is the control: ordinary sizes, ordinary spacing, two-way flow, real counterparties on both sides, nothing offsetting inside half an hour, nothing cancelled, nothing concentrated into the close. If anything fires here, the false positive rate on real data is not acceptable, and no amount of passing on the engineered cases would make up for it.

**Expected.** No alert from any of the eleven metrics on any of these trades.

**The trades analysed.**

| | Id | Time (UTC) | Trader | Instrument | Side | Size | Price | Counterparty | Detail | In alert |
|---|---|---|---|---|---|---:|---:|---|---|---|
| order | UAT-CLEAN-01-O91 | 2026-10-15 08:29:58 | O. Brandt | XS2611000011 | bid | 5.0m | 99.9 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-CLEAN-01-O91-F1 | 2026-10-15 08:30:00 | O. Brandt | XS2611000011 | buy | 5.0m | 99.9 | Gamma Mutual Insurance | client | - |
| order | UAT-CLEAN-01-O94 | 2026-10-15 09:09:58 | M. Lindgren | XS2611000022 | offer | 7.0m | 100.4 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-CLEAN-01-O94-F1 | 2026-10-15 09:10:00 | M. Lindgren | XS2611000022 | sell | 7.0m | 100.4 | Alpha Pension Trust | client | - |
| fill | UAT-CLEAN-01-R102 | 2026-10-15 09:50:00 | M. Lindgren | UATESTR 5Y | buy | 150m | 2.8 | Gamma Mutual Insurance | client | - |
| order | UAT-CLEAN-01-O97 | 2026-10-15 09:59:58 | O. Brandt | XS2611000033 | bid | 3.0m | 100.1 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-CLEAN-01-O97-F1 | 2026-10-15 10:00:00 | O. Brandt | XS2611000033 | buy | 3.0m | 100.1 | Onebrook Securities | own risk | - |
| order | UAT-CLEAN-01-O92 | 2026-10-15 10:44:58 | O. Brandt | XS2611000011 | offer | 4.0m | 99.95 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-CLEAN-01-O92-F1 | 2026-10-15 10:45:00 | O. Brandt | XS2611000011 | sell | 4.0m | 99.95 | Onebrook Securities | own risk | - |
| fill | UAT-CLEAN-01-C99 | 2026-10-15 11:00:00 | O. Brandt | UATGRP SNRFOR 5Y CDS | buy | 25m | - | Beta Family Office | client | - |
| fill | UAT-CLEAN-01-C101 | 2026-10-15 11:30:00 | O. Brandt | UATGRP SNRFOR 10Y CDS | sell | 20m | - | Twyford Markets | own risk | - |
| order | UAT-CLEAN-01-O95 | 2026-10-15 12:19:58 | M. Lindgren | XS2611000022 | bid | 7.0m | 100.35 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-CLEAN-01-O95-F1 | 2026-10-15 12:20:00 | M. Lindgren | XS2611000022 | buy | 7.0m | 100.35 | Onebrook Securities | own risk | - |
| fill | UAT-CLEAN-01-R103 | 2026-10-15 13:10:00 | M. Lindgren | UATESTR 2Y | sell | 120m | 2.6 | Twyford Markets | own risk | - |
| order | UAT-CLEAN-01-O93 | 2026-10-15 13:29:58 | O. Brandt | XS2611000011 | bid | 6.0m | 99.92 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-CLEAN-01-O93-F1 | 2026-10-15 13:30:00 | O. Brandt | XS2611000011 | buy | 6.0m | 99.92 | Twyford Markets | own risk | - |
| fill | UAT-CLEAN-01-C100 | 2026-10-15 14:00:00 | O. Brandt | UATGRP SNRFOR 5Y CDS | buy | 15m | - | Onebrook Securities | own risk | - |
| order | UAT-CLEAN-01-O96 | 2026-10-15 14:29:58 | M. Lindgren | XS2611000022 | bid | 2.0m | 100.38 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-CLEAN-01-O96-F1 | 2026-10-15 14:30:00 | M. Lindgren | XS2611000022 | buy | 2.0m | 100.38 | Twyford Markets | own risk | - |
| fill | UAT-CLEAN-01-R104 | 2026-10-15 14:50:00 | M. Lindgren | UATESTR 5Y | sell | 60m | 2.8 | Onebrook Securities | own risk | - |
| order | UAT-CLEAN-01-O98 | 2026-10-15 14:59:58 | O. Brandt | XS2611000033 | bid | 3.0m | 100.1 | - | filled, 1 level, 100% shown, 2s | - |
| fill | UAT-CLEAN-01-O98-F1 | 2026-10-15 15:00:00 | O. Brandt | XS2611000033 | buy | 3.0m | 100.1 | Alpha Pension Trust | client | - |

**No alert, and nothing scored.** The trades were read and normalised but never priced — a gate stopped them first, which is the intended behaviour for this case.

**No setting to relax.** This check is structural rather than configurable, so there is no version of the settings under which these trades become this behaviour.
