import type { PriceType, ProductFamily, ProductType } from "@/lib/types";

/**
 * Product registry and the conventions that let one set of detectors work
 * across Credit, Rates, Fenics bonds and FX.
 *
 * The unifying convention is the sign of `direction`:
 *
 *   direction = +1  means pressure that pushes the instrument's quoted level UP
 *   direction = -1  means pressure that pushes it DOWN
 *
 * So buying a bond (+1) raises its price, paying fixed on a swaption (+1)
 * raises the rate, buying CDS protection (+1) widens the spread, and buying a
 * currency (+1) raises that currency against USD. Every metric that reasons
 * about "same direction" or "offsetting" works off that one convention.
 */

export const FAMILY_OF: Record<ProductType, ProductFamily> = {
  "Credit.CDS": "credit",
  "IR.Swaption": "rates",
  "IR.CapFloor": "rates",
  "IR.FRA": "rates",
  "FixedIncome.Bond": "fenics",
  "FX.Spot": "fx",
};

export const FAMILY_LABEL: Record<ProductFamily, string> = {
  credit: "Credit",
  rates: "Rates",
  fenics: "Fenics (Fixed Income)",
  fx: "FX",
};

export const PRICE_TYPE_OF: Record<ProductType, PriceType> = {
  "Credit.CDS": "Spread",
  "IR.Swaption": "Rate",
  "IR.CapFloor": "Rate",
  "IR.FRA": "Rate",
  "FixedIncome.Bond": "Price",
  "FX.Spot": "FXRate",
};

/**
 * Whether an execution of this product carries a usable traded level.
 *
 * Credit.CDS is the exception: its `Economics.Price` is an upfront points
 * figure (0 on most records, small positive or negative on the rest), not a
 * traded spread, so there is nothing to compare against a market level. The
 * metrics that need a traded price — Off-Market Trading and Best Execution —
 * skip CDS and say so rather than inventing a number.
 */
export const HAS_TRADED_LEVEL: Record<ProductType, boolean> = {
  "Credit.CDS": false,
  "IR.Swaption": true,
  "IR.CapFloor": true,
  "IR.FRA": true,
  "FixedIncome.Bond": true,
  "FX.Spot": true,
};

/**
 * Whether the product's `price` is a true execution price that can be compared
 * against a market level.
 *
 * A bond fill and an FX rate are. A swaption strike or a cap strike is a
 * negotiated parameter of the contract, not a print against a mid, and a CDS
 * carries upfront points rather than a traded spread. Off-Market Trading,
 * Cross Trading and Best Execution therefore only score bonds and FX, and say
 * so rather than inventing a comparison.
 */
export const HAS_EXECUTION_PRICE: Record<ProductType, boolean> = {
  "Credit.CDS": false,
  "IR.Swaption": false,
  "IR.CapFloor": false,
  "IR.FRA": false,
  "FixedIncome.Bond": true,
  "FX.Spot": true,
};

export const UNIT_TYPE_OF: Record<ProductFamily, string> = {
  credit: "Unit.Desk",
  rates: "Unit.Desk",
  fenics: "Unit.Book",
  fx: "Unit.Desk",
};

export const BUSINESS_UNIT_OF: Record<ProductFamily, string> = {
  credit: "Credit",
  rates: "Rates",
  fenics: "Rates",
  fx: "FX",
};

/* ------------------------------------------------------------------ */
/* Tenors                                                              */
/* ------------------------------------------------------------------ */

/** "60M" -> 60. Tenors are strings in the source schemas, never numbers. */
export function tenorMonths(tenor: string | null | undefined): number | null {
  if (!tenor) return null;
  const m = /^(\d+(?:\.\d+)?)\s*([MY])$/i.exec(tenor.trim());
  if (!m) return null;
  const n = Number(m[1]);
  return m[2].toUpperCase() === "Y" ? n * 12 : n;
}

const BUCKETS: [number, string][] = [
  [3, "3M"],
  [6, "6M"],
  [12, "1Y"],
  [24, "2Y"],
  [36, "3Y"],
  [60, "5Y"],
  [84, "7Y"],
  [120, "10Y"],
  [360, "30Y"],
];

/**
 * Collapse a tenor onto a standard curve point. Positions are built across
 * nearby tenors, so 61M and 60M have to land on the same instrument or a
 * cross-tenor wash trade would be invisible.
 */
export function tenorBucket(tenor: string | null | undefined): string {
  const months = tenorMonths(tenor);
  if (months === null) return "UNSPEC";
  let best = BUCKETS[0];
  let bestGap = Infinity;
  for (const b of BUCKETS) {
    const gap = Math.abs(b[0] - months);
    if (gap < bestGap) {
      bestGap = gap;
      best = b;
    }
  }
  return best[1];
}

export function bucketFromDates(startMs: number, endMs: number): string {
  const months = (endMs - startMs) / (1000 * 60 * 60 * 24 * 30.44);
  return tenorBucket(`${Math.max(1, Math.round(months))}M`);
}

/* ------------------------------------------------------------------ */
/* Instrument keys                                                     */
/* ------------------------------------------------------------------ */

export function creditInstrument(
  ticker: string | null | undefined,
  tier: string,
  tenor: string | null | undefined,
): string {
  const ref = ticker && ticker.trim() ? ticker.trim().toUpperCase() : "NOTICKER";
  return `CDS:${ref}/${(tier || "SNRFOR").toUpperCase()}/${tenorBucket(tenor)}`;
}

export function ratesInstrument(
  fixingIndex: string | null | undefined,
  currency: string,
  tenorBucketed: string,
): string {
  const idx = (fixingIndex ?? `${currency} CURVE`).trim().toUpperCase();
  return `IR:${idx}/${tenorBucketed}`;
}

export function bondInstrument(isin: string): string {
  return `BOND:${isin.trim().toUpperCase()}`;
}

export function fxInstrument(currency: string): string {
  return `FX:${currency.trim().toUpperCase()}/USD`;
}

export function instrumentFamily(instrument: string): ProductFamily {
  if (instrument.startsWith("CDS:")) return "credit";
  if (instrument.startsWith("IR:")) return "rates";
  if (instrument.startsWith("BOND:")) return "fenics";
  return "fx";
}

export function instrumentLabel(instrument: string): string {
  if (instrument.startsWith("CDS:")) {
    const [ref, tier, tenor] = instrument.slice(4).split("/");
    return `${ref} ${tier} ${tenor} CDS`;
  }
  if (instrument.startsWith("IR:")) {
    const [idx, tenor] = instrument.slice(3).split("/");
    return `${idx} ${tenor}`;
  }
  if (instrument.startsWith("BOND:")) return instrument.slice(5);
  return instrument.replace("FX:", "");
}

/* ------------------------------------------------------------------ */
/* Direction                                                           */
/* ------------------------------------------------------------------ */

export interface DirectionResult {
  direction: 1 | -1;
  known: boolean;
  /** How it was determined, for display on an alert. */
  basis: string;
}

/**
 * Work out which way an execution pushes its instrument.
 *
 * Swaptions have PayOrReceive, caps and floors have TradeType, and FX has the
 * buy and sell currencies. Credit, FRAs and the Fenics order streams carry no
 * side field, and for those the sign of the amount is the side: negative is a
 * sell, positive is a buy.
 */
export function directionFor(
  productType: ProductType,
  econ: Record<string, unknown>,
  explicitSide?: string | number | null,
): DirectionResult {
  if (explicitSide !== undefined && explicitSide !== null && explicitSide !== "") {
    const s = String(explicitSide).trim().toLowerCase();
    if (["buy", "b", "bid", "pay", "long", "1", "+1", "buyer"].includes(s)) {
      return { direction: 1, known: true, basis: "explicit side field" };
    }
    if (["sell", "s", "offer", "ask", "receive", "short", "-1", "seller"].includes(s)) {
      return { direction: -1, known: true, basis: "explicit side field" };
    }
    const n = Number(s);
    if (Number.isFinite(n) && n !== 0) {
      return { direction: n > 0 ? 1 : -1, known: true, basis: "explicit side field" };
    }
  }

  const num = (k: string): number | null => {
    const v = econ[k];
    const n = typeof v === "string" ? Number(v) : typeof v === "number" ? v : NaN;
    return Number.isFinite(n) ? n : null;
  };

  switch (productType) {
    case "IR.Swaption": {
      const por = String(econ.PayOrReceive ?? "").toLowerCase();
      if (por.startsWith("pay")) {
        return { direction: 1, known: true, basis: "PayOrReceive = Pay (pays fixed, long rates)" };
      }
      if (por.startsWith("rec")) {
        return { direction: -1, known: true, basis: "PayOrReceive = Receive (receives fixed, short rates)" };
      }
      break;
    }
    case "IR.CapFloor": {
      const tt = String(econ.TradeType ?? "").toLowerCase();
      const asset = String(econ.AssetType ?? "").toLowerCase();
      // A bought cap is long rates; a bought floor is short rates.
      const isFloor = asset.includes("floor");
      if (tt.startsWith("buy")) {
        return {
          direction: isFloor ? -1 : 1,
          known: true,
          basis: `TradeType = Buy on a ${isFloor ? "floor" : "cap"}`,
        };
      }
      if (tt.startsWith("sell")) {
        return {
          direction: isFloor ? 1 : -1,
          known: true,
          basis: `TradeType = Sell on a ${isFloor ? "floor" : "cap"}`,
        };
      }
      break;
    }
    default:
      break;
  }

  // The feeds use signed amounts: negative is a sell, positive is a buy. That
  // is the convention, not an inference, so it is reported as known.
  const notional = num("Notional") ?? num("PrincipalAmount") ?? num("TotalAmount");
  if (notional !== null && notional < 0) {
    return { direction: -1, known: true, basis: "negative amount (sell)" };
  }
  if (notional !== null && notional > 0) {
    return { direction: 1, known: true, basis: "positive amount (buy)" };
  }
  return { direction: 1, known: false, basis: "no amount on the record" };
}

/** Read a dotted path out of a nested object. */
export function getPath(obj: unknown, path: string): unknown {
  if (!path) return undefined;
  let cur: unknown = obj;
  for (const part of path.split(".")) {
    if (cur === null || typeof cur !== "object") return undefined;
    cur = (cur as Record<string, unknown>)[part];
  }
  return cur;
}

export const numOf = (v: unknown): number => {
  if (typeof v === "number") return v;
  if (typeof v === "string") {
    const n = Number(v.replace(/,/g, "").trim());
    return Number.isFinite(n) ? n : NaN;
  }
  return NaN;
};

export const strOf = (v: unknown): string | null =>
  typeof v === "string" && v.trim() !== "" ? v.trim() : null;

/**
 * Source timestamps come in two shapes: ISO with a Z (Credit, Rates, FX) and
 * "YYYY-MM-DD HH:MM:SS.ffffff" with no zone (Fenics). Both are read as UTC.
 */
export function parseTimestamp(v: unknown): number {
  const s = strOf(v);
  if (!s) return NaN;
  const direct = Date.parse(s);
  if (Number.isFinite(direct) && /[Zz]|[+-]\d{2}:?\d{2}$/.test(s)) return direct;
  const m = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2}):(\d{2})(?:\.(\d{1,6}))?$/.exec(s);
  if (m) {
    const micros = m[7] ? m[7].padEnd(6, "0") : "000000";
    return Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +m[6], Math.round(+micros / 1000));
  }
  const dateOnly = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
  if (dateOnly) return Date.UTC(+dateOnly[1], +dateOnly[2] - 1, +dateOnly[3]);
  return Number.isFinite(direct) ? direct : NaN;
}
