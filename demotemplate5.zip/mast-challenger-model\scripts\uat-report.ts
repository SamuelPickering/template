/**
 * Writes the UAT results to a file.
 *
 *   npm run uat:report                     -> reports/UAT-results-<date>.md
 *   npm run uat:report -- --json           -> the same content as JSON
 *   npm run uat:report -- --out <path>     -> written where you ask
 *
 * Reads whatever is in the imported synthetic bucket, so import the pack
 * first — on the Import page, or by running this after `npm run uat:load`.
 */
import fs from "node:fs";
import path from "node:path";
import { renderUatMarkdown, runUat } from "@/lib/testing/uatRun";

const asJson = process.argv.includes("--json");
const report = runUat();

if (!report.available) {
  console.error(
    "The UAT pack is not loaded. Import uat/mast-uat-synthetic-trades.json on the Import page\n" +
      "as synthetic test data, or run `npm run uat:load` to load it from the command line.",
  );
  process.exit(1);
}

const stamp = report.generated_at.slice(0, 10);
const outArg = process.argv.indexOf("--out");
const file =
  outArg >= 0 && process.argv[outArg + 1]
    ? process.argv[outArg + 1]
    : path.join("reports", `UAT-results-${stamp}.${asJson ? "json" : "md"}`);
fs.mkdirSync(path.dirname(file), { recursive: true });
fs.writeFileSync(file, asJson ? JSON.stringify(report, null, 2) : renderUatMarkdown(report));

const s = report.summary;
console.log(
  `${s.passed} of ${s.total} UAT cases passed — ` +
    `${s.positivePassed}/${s.positive} that must alert, ${s.negativePassed}/${s.negative} that must not.`,
);
for (const r of report.results.filter((x) => x.status === "fail")) {
  console.log(`  FAIL ${r.testCase.id} ${r.testCase.title} — ${r.verdict}`);
}
console.log(`written to ${file}`);
