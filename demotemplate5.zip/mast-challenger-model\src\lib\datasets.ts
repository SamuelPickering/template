import type { DataSource } from "./types";

/**
 * Data sources and the views over them.
 *
 * Documents live in one of three buckets:
 *
 *   synthetic            the population the seed script generates
 *   imported_synthetic   a test pack imported from a file — fake trades, built
 *                        to exercise the detectors and to be shown to someone
 *   imported_production  a real extract imported from a file
 *
 * Keeping the two kinds of import apart matters: a UAT run has to be able to
 * say "these are engineered trades and here is what they were engineered to
 * prove", and a production run has to be able to say "nothing here was made
 * up". Mixing them in one bucket makes both statements impossible.
 *
 * A dataset is a named view over those buckets. Everything downstream — the
 * detection engine, the blotter, the reports — takes a dataset and never
 * touches the buckets directly.
 */
export type Dataset =
  | "synthetic"
  | "synthetic_plus"
  | "imported_synthetic"
  | "imported_production";

export const DATA_SOURCES: DataSource[] = [
  "synthetic",
  "imported_synthetic",
  "imported_production",
];

export const DATASETS: Dataset[] = [
  "synthetic",
  "synthetic_plus",
  "imported_synthetic",
  "imported_production",
];

export const DATASET_BUCKETS: Record<Dataset, DataSource[]> = {
  synthetic: ["synthetic"],
  synthetic_plus: ["synthetic", "imported_synthetic"],
  imported_synthetic: ["imported_synthetic"],
  imported_production: ["imported_production"],
};

/** Short label for the switch in the header. */
export const DATASET_LABEL: Record<Dataset, string> = {
  synthetic: "Synthetic (seeded)",
  synthetic_plus: "Synthetic + imported",
  imported_synthetic: "Imported synthetic only",
  imported_production: "Production import only",
};

export const DATASET_NOTE: Record<Dataset, string> = {
  synthetic: "the seeded simulation only — nothing imported is in scope",
  synthetic_plus:
    "the seeded simulation plus the imported synthetic pack, scored together",
  imported_synthetic:
    "the imported synthetic pack on its own — no seeded trades, no production data",
  imported_production:
    "imported production data only — no synthetic traders or trades",
};

export const SOURCE_LABEL: Record<DataSource, string> = {
  synthetic: "synthetic (seeded)",
  imported_synthetic: "imported synthetic",
  imported_production: "imported production",
};

/** True where the view contains nothing but engineered data. */
export const IS_SYNTHETIC_VIEW: Record<Dataset, boolean> = {
  synthetic: true,
  synthetic_plus: true,
  imported_synthetic: true,
  imported_production: false,
};

export function isDataset(v: unknown): v is Dataset {
  return typeof v === "string" && (DATASETS as string[]).includes(v);
}

export function isDataSource(v: unknown): v is DataSource {
  return typeof v === "string" && (DATA_SOURCES as string[]).includes(v);
}

/**
 * The buckets a key covers. Accepts a dataset view or a bucket name, so a
 * caller that already holds a bucket does not have to special-case it.
 */
export function bucketsOf(key: Dataset | DataSource | string): DataSource[] {
  if (isDataset(key)) return DATASET_BUCKETS[key];
  if (isDataSource(key)) return [key];
  return [];
}
