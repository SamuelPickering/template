import { NextResponse } from "next/server";
import { METRICS } from "@/lib/config/metrics";
import { UAT_CASE_BY_ID } from "@/lib/testing/uatCases";
import {
  casesFile,
  deleteCase,
  deletedCaseIds,
  loadUatCases,
  loadUatGroups,
  originOf,
  resetCases,
  restoreCase,
  saveCase,
} from "@/lib/testing/uatStore";
import { starterTrades } from "@/lib/testing/uatTemplate";
import { invalidateAnalysis } from "@/lib/detect/engine";

/**
 * The test catalogue as data: read it, change it, put it back.
 *
 * Editing a case does not touch any trade, and the engine is not re-run by
 * saving — a case is a description and a verdict rule, and the data it is
 * judged on is whatever has been imported.
 */
function payload() {
  return {
    file: casesFile(),
    cases: loadUatCases().map((c) => ({ ...c, origin: originOf(c.id) })),
    groups: loadUatGroups().map((g) => g.name),
    switchedOff: deletedCaseIds().map((id) => ({
      id,
      title: UAT_CASE_BY_ID[id]?.title ?? id,
    })),
    metrics: METRICS.map((m) => ({
      id: m.id,
      label: m.label,
      params: m.params
        .filter((p) => p.key !== "threshold_usd_value")
        .map((p) => ({ key: p.key, label: p.label, default: p.default, unit: p.unit ?? "" })),
    })),
  };
}

export async function GET(req: Request) {
  const template = new URL(req.url).searchParams.get("template");
  if (template) {
    return new Response(starterTrades(template), {
      headers: {
        "content-type": "application/json",
        "content-disposition": `attachment; filename="${template}-trades.json"`,
      },
    });
  }
  return NextResponse.json(payload());
}

export async function POST(req: Request) {
  const body = (await req.json()) as {
    action?: "save" | "delete" | "restore" | "reset";
    id?: string;
    case?: Record<string, unknown>;
  };

  switch (body.action) {
    case "save": {
      const result = saveCase(body.case ?? {});
      if (!result.ok) return NextResponse.json({ errors: result.errors }, { status: 400 });
      invalidateAnalysis();
      return NextResponse.json({ saved: result.case?.id, ...payload() });
    }
    case "delete": {
      if (!body.id) return NextResponse.json({ errors: ["No case named."] }, { status: 400 });
      const r = deleteCase(body.id);
      if (!r.ok) return NextResponse.json({ errors: ["No such case."] }, { status: 404 });
      invalidateAnalysis();
      return NextResponse.json({ deleted: body.id, restorable: r.restorable, ...payload() });
    }
    case "restore": {
      if (!body.id || !restoreCase(body.id)) {
        return NextResponse.json(
          { errors: ["Only a case that ships with the tool can be restored."] },
          { status: 400 },
        );
      }
      invalidateAnalysis();
      return NextResponse.json({ restored: body.id, ...payload() });
    }
    case "reset": {
      resetCases();
      invalidateAnalysis();
      return NextResponse.json({ reset: true, ...payload() });
    }
    default:
      return NextResponse.json({ errors: ["Unknown action."] }, { status: 400 });
  }
}
