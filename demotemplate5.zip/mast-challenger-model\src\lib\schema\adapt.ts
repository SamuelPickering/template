import type {
  Counterparty,
  CounterpartyKind,
  Execution,
  ExecutionClass,
  ImportOverrides,
  OrderEvent,
  OrderStream,
  ProductFamily,
  ProductType,
  SourceDocument,
  Trader,
} from "@/lib/types";
import {
  BUSINESS_UNIT_OF,
  bondInstrument,
  bucketFromDates,
  creditInstrument,
  directionFor,
  fxInstrument,
  getPath,
  instrumentLabel,
  numOf,
  parseTimestamp,
  PRICE_TYPE_OF,
  ratesInstrument,
  strOf,
  tenorBucket,
} from "./products";
import { dateKey, isoMs } from "@/lib/time";

/**
 * Adapters: Master.Transaction documents in their source product schema, in;
 * normalised executions and order streams, out.
 *
 * Generated data and imported production data travel the same path, so
 * anything that works on the synthetic dataset works on a real extract with
 * the same shape.
 */
export interface AdaptContext {
  /** USD per 1 unit of a currency at a point in time. */
  usdRate: (currency: string, ms: number) => number;
  traders: Map<string, Trader>;
  /** Known counterparties, used to tell a client from a dealer. */
  counterparties?: Map<string, Counterparty>;
  overrides?: ImportOverrides;
}

/**
 * Client, dealer or internal?
 *
 * The product schemas only distinguish Counterparty.Professional from an
 * internal trade, but Front Running and Best Execution both turn on whether
 * the business was a client's. The counterparty registry answers it where the
 * code is known; an import can supply patterns for its own codes; otherwise
 * the split is marked unknown and the metrics that depend on it report that.
 */
function classifyCounterparty(
  code: string | null,
  name: string | null,
  type: string | null,
  execClass: ExecutionClass,
  ctx: AdaptContext,
): { kind: CounterpartyKind; known: boolean } {
  const hay = `${code ?? ""} ${name ?? ""}`.toLowerCase();
  if (
    execClass === "internalTrade" ||
    (type ?? "").toLowerCase().includes("internal") ||
    (code ?? "").toUpperCase().startsWith("INT") ||
    hay.includes("internal") ||
    hay.includes("affiliate")
  ) {
    return { kind: "internal", known: true };
  }
  const known = code ? ctx.counterparties?.get(code) : undefined;
  if (known) return { kind: known.kind, known: true };
  const o = ctx.overrides ?? {};
  if ((o.client_patterns ?? []).some((pat) => hay.includes(pat.toLowerCase()))) {
    return { kind: "client", known: true };
  }
  if ((o.dealer_patterns ?? []).some((pat) => hay.includes(pat.toLowerCase()))) {
    return { kind: "dealer", known: true };
  }
  return { kind: "unknown", known: false };
}

export interface AdaptResult {
  executions: Execution[];
  orders: OrderStream[];
  /** Why a document produced nothing usable. */
  problems: string[];
}

export function detectFamily(payload: Record<string, unknown>): ProductFamily | null {
  const execType = strOf(getPath(payload, "Execution.Type"));
  if (execType === "Execution.OrderStream") return "fenics";
  const econType = strOf(getPath(payload, "Execution.Economics.Type"));
  if (econType) {
    if (econType.startsWith("Credit.")) return "credit";
    if (econType.startsWith("IR.")) return "rates";
    if (econType.startsWith("FX.")) return "fx";
    if (econType.startsWith("FixedIncome.")) return "fenics";
  }
  const bu = strOf(getPath(payload, "Unit.BusinessUnit"));
  if (bu === "Credit") return "credit";
  if (bu === "Rates") return "rates";
  if (bu === "FX") return "fx";
  return null;
}

export function adaptDocument(doc: SourceDocument, ctx: AdaptContext): AdaptResult {
  const family = doc.family ?? detectFamily(doc.payload);
  switch (family) {
    case "credit":
      return adaptCredit(doc, ctx);
    case "rates":
      return adaptRates(doc, ctx);
    case "fenics":
      return adaptFenics(doc, ctx);
    case "fx":
      return adaptFx(doc, ctx);
    default:
      return { executions: [], orders: [], problems: ["unrecognised product family"] };
  }
}

export function adaptAll(docs: SourceDocument[], ctx: AdaptContext) {
  const executions: Execution[] = [];
  const orders: OrderStream[] = [];
  const problems: string[] = [];
  for (const doc of docs) {
    const r = adaptDocument(doc, ctx);
    executions.push(...r.executions);
    orders.push(...r.orders);
    for (const p of r.problems) {
      if (problems.length < 50) problems.push(`${doc.doc_id}: ${p}`);
    }
  }
  executions.sort((a, b) => a.event_ms - b.event_ms);
  orders.sort((a, b) => a.start_ms - b.start_ms);
  return { executions, orders, problems };
}

/* ------------------------------------------------------------------ */
/* shared pieces                                                       */
/* ------------------------------------------------------------------ */

interface Common {
  trader_id: string;
  trader_name: string;
  trade_role: Trader["trade_role"];
  book_name: string;
  business_unit: string;
  region: string;
  execution_class: ExecutionClass;
  counterparty_name: string | null;
  counterparty_code: string | null;
  counterparty_kind: CounterpartyKind;
  counterparty_kind_known: boolean;
}

function commonFields(
  payload: Record<string, unknown>,
  family: ProductFamily,
  ctx: AdaptContext,
): Common {
  const o = ctx.overrides ?? {};
  const traderId =
    strOf(getPath(payload, "Execution.TraderID")) ??
    strOf(o.trader_name_path ? getPath(payload, o.trader_name_path) : null) ??
    "UNKNOWN";
  const trader = ctx.traders.get(traderId);
  const nameOverride = o.trader_name_path ? strOf(getPath(payload, o.trader_name_path)) : null;
  const execClass = (strOf(getPath(payload, "Execution.Type")) ??
    "withClientTrade") as ExecutionClass;

  const cpName = strOf(getPath(payload, "Execution.Counterparty.CounterpartyName"));
  const cpCode = strOf(getPath(payload, "Execution.Counterparty.CounterpartyCode"));
  const cpType = strOf(getPath(payload, "Execution.Counterparty.Type"));
  const cls = classifyCounterparty(cpCode, cpName, cpType, execClass, ctx);

  return {
    trader_id: traderId,
    trader_name: nameOverride ?? trader?.name ?? traderId,
    // Facing a client is facilitation; facing another dealer or an internal
    // book is the firm running its own risk. Where the counterparty cannot be
    // classified, the trader's own book role is the fallback - an import can
    // supply client and dealer patterns to replace the guess.
    trade_role:
      cls.kind === "client"
        ? "client_facilitation"
        : cls.kind === "unknown"
          ? (trader?.trade_role ?? "client_facilitation")
          : "prop",
    book_name:
      strOf(o.book_path ? getPath(payload, o.book_path) : null) ??
      strOf(getPath(payload, "Unit.BookName")) ??
      "UNKNOWN",
    business_unit: strOf(getPath(payload, "Unit.BusinessUnit")) ?? BUSINESS_UNIT_OF[family],
    region: strOf(getPath(payload, "Unit.Region")) ?? "UNSPEC",
    execution_class: execClass,
    counterparty_name: cpName,
    counterparty_code: cpCode,
    counterparty_kind: cls.kind,
    counterparty_kind_known: cls.known,
  };
}

function sideOverride(payload: Record<string, unknown>, ctx: AdaptContext) {
  const path = ctx.overrides?.side_path;
  if (!path) return null;
  const v = getPath(payload, path);
  return typeof v === "string" || typeof v === "number" ? v : null;
}

function usdOf(ctx: AdaptContext, amount: number, currency: string, ms: number): number {
  if (!Number.isFinite(amount)) return 0;
  return Math.abs(amount) * ctx.usdRate(currency, ms);
}

/* ------------------------------------------------------------------ */
/* Credit.CDS                                                          */
/* ------------------------------------------------------------------ */

function adaptCredit(doc: SourceDocument, ctx: AdaptContext): AdaptResult {
  const p = doc.payload;
  const econ = (getPath(p, "Execution.Economics") ?? {}) as Record<string, unknown>;
  const problems: string[] = [];
  const ms = parseTimestamp(getPath(p, "Execution.TradeDate"));
  if (!Number.isFinite(ms)) return { executions: [], orders: [], problems: ["unparseable TradeDate"] };

  const notional = Math.abs(numOf(econ.Notional));
  if (!Number.isFinite(notional) || notional <= 0) {
    return { executions: [], orders: [], problems: ["missing or non-numeric Notional"] };
  }

  const currency = strOf(getPath(econ, "Currency.ISOCode")) ?? "USD";
  const tier = strOf(getPath(econ, "Identifier.Tier")) ?? "SNRFOR";
  const tenorRaw = strOf(getPath(econ, "Identifier.Tenor"));
  const ticker = strOf(getPath(econ, "Identifier.Ticker"));
  if (!ticker) problems.push("Identifier.Ticker absent — grouped under NOTICKER");
  const instrument = creditInstrument(ticker, tier, tenorRaw);
  const dir = directionFor("Credit.CDS", econ, sideOverride(p, ctx));
  const c = commonFields(p, "credit", ctx);

  return {
    orders: [],
    problems,
    executions: [
      {
        exec_id: `${doc.doc_id}:X`,
        doc_id: doc.doc_id,
        trade_id: strOf(getPath(p, "Execution.TradeID")) ?? doc.doc_id,
        order_id: null,
        event_id: null,
        product_type: "Credit.CDS",
        family: "credit",
        execution_class: c.execution_class,
        trader_id: c.trader_id,
        trader_name: c.trader_name,
        counterparty_name: c.counterparty_name,
        counterparty_code: c.counterparty_code,
        counterparty_kind: c.counterparty_kind,
        counterparty_kind_known: c.counterparty_kind_known,
        venue_code: null,
        venue_name: null,
        book_name: c.book_name,
        business_unit: c.business_unit,
        region: c.region,
        instrument,
        instrument_label: instrumentLabel(instrument),
        currency,
        direction: dir.direction,
        direction_known: dir.known,
        notional,
        notional_usd: usdOf(ctx, notional, currency, ms),
        // Economics.Price on a CDS is upfront points, not a traded spread.
        price: numOf(econ.Price) || 0,
        price_type: PRICE_TYPE_OF["Credit.CDS"],
        event_ms: ms,
        event_datetime: isoMs(ms),
        trade_date: dateKey(ms),
        tenor: tenorRaw ? tenorBucket(tenorRaw) : null,
        maturity_ms: parseTimestamp(econ.Maturity) || null,
        trade_role: c.trade_role,
        source: doc.source,
        scenario_tag: doc.scenario_tag,
      },
    ],
  };
}

/* ------------------------------------------------------------------ */
/* Rates: IR.Swaption | IR.CapFloor | IR.FRA                           */
/* ------------------------------------------------------------------ */

function adaptRates(doc: SourceDocument, ctx: AdaptContext): AdaptResult {
  const p = doc.payload;
  const econ = (getPath(p, "Execution.Economics") ?? {}) as Record<string, unknown>;
  const productType = strOf(econ.Type) as ProductType | null;
  if (!productType || !["IR.Swaption", "IR.CapFloor", "IR.FRA"].includes(productType)) {
    return { executions: [], orders: [], problems: ["Economics.Type missing or not a rates product"] };
  }
  const ms = parseTimestamp(getPath(p, "Execution.TradeDate"));
  if (!Number.isFinite(ms)) return { executions: [], orders: [], problems: ["unparseable TradeDate"] };

  const notional = Math.abs(numOf(econ.Notional));
  if (!Number.isFinite(notional) || notional <= 0) {
    // The source does contain transactions with incomplete Economics.
    return { executions: [], orders: [], problems: ["incomplete Economics — no usable Notional"] };
  }
  const currency = strOf(getPath(econ, "Currency.ISOCode")) ?? "USD";
  const problems: string[] = [];

  let startMs = NaN;
  let endMs = NaN;
  let level = NaN;
  if (productType === "IR.Swaption") {
    startMs = parseTimestamp(econ.SwapStartDate);
    endMs = parseTimestamp(econ.SwapEndDate);
    level = numOf(econ.SwaptionStrike);
    if (!Number.isFinite(level)) problems.push("SwaptionStrike absent — no traded level for pricing checks");
  } else if (productType === "IR.CapFloor") {
    startMs = parseTimestamp(econ.StartDate);
    endMs = parseTimestamp(econ.MaturityDate);
    level = numOf(econ.Strike);
  } else {
    startMs = parseTimestamp(econ.StartDate);
    endMs = parseTimestamp(econ.MaturityDate);
    level = numOf(econ.FixedRate);
  }

  const bucket =
    Number.isFinite(startMs) && Number.isFinite(endMs)
      ? bucketFromDates(startMs, endMs)
      : tenorBucket(strOf(getPath(econ, "FixingIndex.FixingTenor")));
  const instrument = ratesInstrument(
    strOf(getPath(econ, "FixingIndex.FixingIndex")) ?? `${currency} FRA`,
    currency,
    bucket,
  );
  const dir = directionFor(productType, econ, sideOverride(p, ctx));
  const c = commonFields(p, "rates", ctx);

  return {
    orders: [],
    problems,
    executions: [
      {
        exec_id: `${doc.doc_id}:X`,
        doc_id: doc.doc_id,
        trade_id: strOf(getPath(p, "Execution.TradeID")) ?? doc.doc_id,
        order_id: null,
        event_id: null,
        product_type: productType,
        family: "rates",
        execution_class: c.execution_class,
        trader_id: c.trader_id,
        trader_name: c.trader_name,
        counterparty_name: c.counterparty_name,
        counterparty_code: c.counterparty_code,
        counterparty_kind: c.counterparty_kind,
        counterparty_kind_known: c.counterparty_kind_known,
        venue_code: null,
        venue_name: null,
        book_name: c.book_name,
        business_unit: c.business_unit,
        region: c.region,
        instrument,
        instrument_label: instrumentLabel(instrument),
        currency,
        direction: dir.direction,
        direction_known: dir.known,
        notional,
        notional_usd: usdOf(ctx, notional, currency, ms),
        price: Number.isFinite(level) ? level : 0,
        price_type: PRICE_TYPE_OF[productType],
        event_ms: ms,
        event_datetime: isoMs(ms),
        trade_date: dateKey(ms),
        tenor: bucket,
        maturity_ms: Number.isFinite(endMs) ? endMs : null,
        trade_role: c.trade_role,
        source: doc.source,
        scenario_tag: doc.scenario_tag,
      },
    ],
  };
}

/* ------------------------------------------------------------------ */
/* Fenics order streams (FixedIncome.Bond)                             */
/* ------------------------------------------------------------------ */

function adaptFenics(doc: SourceDocument, ctx: AdaptContext): AdaptResult {
  const p = doc.payload;
  const exec = (getPath(p, "Execution") ?? {}) as Record<string, unknown>;
  const econ = (getPath(exec, "Economics") ?? {}) as Record<string, unknown>;
  const isin = strOf(getPath(econ, "Identifier.ISINCode"));
  if (!isin) return { executions: [], orders: [], problems: ["no ISIN on the order stream"] };

  const currency = strOf(getPath(econ, "PriceCurrency.ISOCode")) ?? "USD";
  const instrument = bondInstrument(isin);
  const startMs = parseTimestamp(exec.OrderStartDate);
  const endMs = parseTimestamp(exec.OrderEndDate);
  if (!Number.isFinite(startMs)) {
    return { executions: [], orders: [], problems: ["unparseable OrderStartDate"] };
  }
  const c = commonFields(p, "fenics", ctx);
  const problems: string[] = [];

  const rawEvents = Array.isArray(exec.Events) ? (exec.Events as Record<string, unknown>[]) : [];
  const events: OrderEvent[] = [];
  for (const e of rawEvents) {
    const type = (strOf(e.Type) ?? "").replace(/^OrderEvent\./, "") as OrderEvent["type"];
    const ems = parseTimestamp(e.EventDateTime);
    if (!Number.isFinite(ems)) continue;
    events.push({
      type: type || "Amendment",
      event_id: strOf(e.EventID) ?? `${doc.doc_id}:E${events.length}`,
      ms: ems,
      datetime: isoMs(ems),
      limit_price: Number.isFinite(numOf(e.LimitPrice)) ? numOf(e.LimitPrice) : null,
      total_amount: Number.isFinite(numOf(e.TotalAmount)) ? numOf(e.TotalAmount) : null,
      display_amount: Number.isFinite(numOf(e.DisplayAmount)) ? numOf(e.DisplayAmount) : null,
      price: Number.isFinite(numOf(e.Price)) ? numOf(e.Price) : null,
      amount: Number.isFinite(numOf(e.Amount)) ? numOf(e.Amount) : null,
      counterparty_name: strOf(getPath(e, "Counterparty.CounterpartyName")),
      counterparty_code: strOf(getPath(e, "Counterparty.CounterpartyCode")),
      venue_code: strOf(getPath(e, "Venue.VenueCode")),
      venue_name: strOf(getPath(e, "Venue.VenueName")),
    });
  }
  events.sort((a, b) => a.ms - b.ms);
  if (!events.length) problems.push("order stream carried no usable events");

  const open = events.find((e) => e.type === "OpenLimitOrder");
  const fills = events.filter((e) => e.type === "Fill");
  const closes = events.filter((e) => e.type === "Close" || e.type === "Cancel");
  const amendments = events.filter((e) => e.type === "Amendment");

  // Side: the Fenics structure carries no explicit buy/sell field, so the sign
  // of the amount is the side — negative sells, positive buys.
  const signedCandidates = [
    numOf(econ.PrincipalAmount),
    open?.total_amount ?? NaN,
    ...fills.map((f) => f.amount ?? NaN),
  ].filter((n) => Number.isFinite(n) && n !== 0);
  const explicit = sideOverride(p, ctx);
  let side: 1 | -1 = 1;
  let sideKnown = false;
  if (explicit !== null) {
    const d = directionFor("FixedIncome.Bond", {}, explicit);
    side = d.direction;
    sideKnown = d.known;
  } else if (signedCandidates.some((n) => n < 0)) {
    side = -1;
    sideKnown = true;
  } else if (signedCandidates.length) {
    side = 1;
    sideKnown = true;
  }

  const placed = Math.abs(open?.total_amount ?? 0);
  const display = Math.abs(open?.display_amount ?? placed);
  const filled = fills.reduce((s, f) => s + Math.abs(f.amount ?? 0), 0);
  const priceLevels = [
    ...new Set(
      events
        .map((e) => e.limit_price)
        .filter((v): v is number => v !== null && Number.isFinite(v))
        .map((v) => Number(v.toFixed(6))),
    ),
  ];
  const lastMs = events.length ? events[events.length - 1].ms : startMs;
  const streamEnd = Number.isFinite(endMs) ? endMs : lastMs;

  const order: OrderStream = {
    order_id: strOf(exec.OrderMessageID) ?? doc.doc_id,
    doc_id: doc.doc_id,
    trader_id: c.trader_id,
    trader_name: c.trader_name,
    instrument,
    instrument_label: instrumentLabel(instrument),
    currency,
    product_type: "FixedIncome.Bond",
    family: "fenics",
    book_name: c.book_name,
    business_unit: c.business_unit,
    region: c.region,
    side,
    side_known: sideKnown,
    start_ms: startMs,
    end_ms: streamEnd,
    events,
    placed_amount: placed,
    display_amount: display,
    filled_amount: filled,
    cancelled_unfilled: closes.length > 0 && filled < placed * 0.1,
    amendments: amendments.length,
    price_levels: priceLevels,
    notional_usd: usdOf(ctx, placed, currency, startMs),
    source: doc.source,
    scenario_tag: doc.scenario_tag,
  };

  // Every fill is an execution in its own right.
  const executions: Execution[] = fills.map((f, i) => {
    const amt = Math.abs(f.amount ?? 0);
    const cls = classifyCounterparty(
      f.counterparty_code,
      f.counterparty_name,
      null,
      "Execution.OrderStream",
      ctx,
    );
    return {
      exec_id: `${doc.doc_id}:F${i}`,
      doc_id: doc.doc_id,
      trade_id: f.event_id,
      order_id: order.order_id,
      event_id: f.event_id,
      product_type: "FixedIncome.Bond",
      family: "fenics",
      execution_class: "Execution.OrderStream",
      trader_id: c.trader_id,
      trader_name: c.trader_name,
      counterparty_name: f.counterparty_name,
      counterparty_code: f.counterparty_code,
      counterparty_kind: cls.kind,
      counterparty_kind_known: cls.known,
      venue_code: f.venue_code,
      venue_name: f.venue_name,
      book_name: c.book_name,
      business_unit: c.business_unit,
      region: c.region,
      instrument,
      instrument_label: instrumentLabel(instrument),
      currency,
      direction: side,
      direction_known: sideKnown,
      notional: amt,
      notional_usd: usdOf(ctx, amt, currency, f.ms),
      price: f.price ?? numOf(econ.Price) ?? 0,
      price_type: "Price",
      event_ms: f.ms,
      event_datetime: f.datetime,
      trade_date: dateKey(f.ms),
      tenor: null,
      maturity_ms: null,
      // A fill facing a client is facilitation; facing a dealer it is the
      // firm's own risk.
      trade_role:
        cls.kind === "client"
          ? "client_facilitation"
          : cls.kind === "unknown"
            ? (ctx.traders.get(c.trader_id)?.trade_role ?? "client_facilitation")
            : "prop",
      source: doc.source,
      scenario_tag: doc.scenario_tag,
    };
  });

  return { executions, orders: [order], problems };
}

/* ------------------------------------------------------------------ */
/* FX.Spot — split into legs against USD (General Market Model)         */
/* ------------------------------------------------------------------ */

function adaptFx(doc: SourceDocument, ctx: AdaptContext): AdaptResult {
  const p = doc.payload;
  const econ = (getPath(p, "Execution.Economics") ?? {}) as Record<string, unknown>;
  const ms = parseTimestamp(getPath(p, "Execution.TradeDate"));
  if (!Number.isFinite(ms)) return { executions: [], orders: [], problems: ["unparseable TradeDate"] };

  const buyCcy = strOf(getPath(econ, "BuyCurrency.ISOCode"))?.toUpperCase();
  const sellCcy = strOf(getPath(econ, "SellCurrency.ISOCode"))?.toUpperCase();
  const buyAmt = Math.abs(numOf(econ.BuyAmount));
  const sellAmt = Math.abs(numOf(econ.SellAmount));
  if (!buyCcy || !sellCcy || !Number.isFinite(buyAmt) || !Number.isFinite(sellAmt)) {
    return { executions: [], orders: [], problems: ["FX legs incomplete"] };
  }
  const c = commonFields(p, "fx", ctx);
  const pair = strOf(econ.CurrencyPair) ?? `${buyCcy}/${sellCcy}`;
  const tradeId = strOf(getPath(p, "Execution.TradeID")) ?? doc.doc_id;

  // One equivalent trade per non-USD leg: buying a currency pushes it up
  // against USD, selling pushes it down. A trade between two non-USD
  // currencies therefore lands on two instruments at once, which is what makes
  // a position built across several pairs visible in one place.
  const legs: { currency: string; amount: number; direction: 1 | -1 }[] = [];
  if (buyCcy !== "USD") legs.push({ currency: buyCcy, amount: buyAmt, direction: 1 });
  if (sellCcy !== "USD") legs.push({ currency: sellCcy, amount: sellAmt, direction: -1 });
  if (!legs.length) return { executions: [], orders: [], problems: ["USD/USD trade"] };

  const executions = legs.map((leg, i) => {
    const instrument = fxInstrument(leg.currency);
    // The headline rate is quoted in the pair's terms, which says nothing
    // about this leg's own instrument. Imply the leg's level - USD per unit of
    // the leg currency - from the other side of the trade, triangulating
    // through USD where the trade is a cross.
    const counterCcy = leg.currency === buyCcy ? sellCcy : buyCcy;
    const counterAmt = leg.currency === buyCcy ? sellAmt : buyAmt;
    const impliedLevel =
      leg.amount > 0 && counterAmt > 0
        ? (counterAmt * ctx.usdRate(counterCcy, ms)) / leg.amount
        : ctx.usdRate(leg.currency, ms);
    return {
      exec_id: `${doc.doc_id}:L${i}`,
      doc_id: doc.doc_id,
      trade_id: tradeId,
      order_id: strOf(getPath(p, "Execution.OrderID")),
      event_id: null,
      product_type: "FX.Spot" as ProductType,
      family: "fx" as ProductFamily,
      execution_class: c.execution_class,
      trader_id: c.trader_id,
      trader_name: c.trader_name,
      counterparty_name: c.counterparty_name,
      counterparty_code: c.counterparty_code,
      counterparty_kind: c.counterparty_kind,
      counterparty_kind_known: c.counterparty_kind_known,
      venue_code: null,
      venue_name: null,
      book_name: c.book_name,
      business_unit: c.business_unit,
      region: c.region,
      instrument,
      instrument_label: instrumentLabel(instrument),
      currency: leg.currency,
      direction: leg.direction,
      direction_known: true,
      notional: leg.amount,
      notional_usd: usdOf(ctx, leg.amount, leg.currency, ms),
      price: Number.isFinite(impliedLevel) && impliedLevel > 0 ? impliedLevel : 0,
      price_type: "FXRate" as const,
      event_ms: ms,
      event_datetime: isoMs(ms),
      trade_date: dateKey(ms),
      tenor: null,
      maturity_ms: null,
      trade_role: c.trade_role,
      source: doc.source,
      scenario_tag: doc.scenario_tag,
      /** Kept for display: the headline pair the trade was booked in. */
      headline_pair: pair,
    } as Execution & { headline_pair: string };
  });

  return { executions, orders: [], problems: [] };
}

/** The headline currency pair, where the execution came from an FX trade. */
export function headlinePair(e: Execution): string | null {
  return (e as Execution & { headline_pair?: string }).headline_pair ?? null;
}
