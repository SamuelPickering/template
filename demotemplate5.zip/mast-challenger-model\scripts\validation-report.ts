/**
 * Writes the test report to a file.
 *
 *   npm run report            -> reports/abuse-detection-tests-<date>.md
 *   npm run report -- --json  -> the same content as JSON
 */
import fs from "node:fs";
import path from "node:path";
import { renderMarkdown, runValidation } from "@/lib/testing/run";

const asJson = process.argv.includes("--json");
const report = runValidation();
const stamp = report.generated_at.slice(0, 10);
const dir = "reports";
fs.mkdirSync(dir, { recursive: true });
const file = path.join(dir, `abuse-detection-tests-${stamp}.${asJson ? "json" : "md"}`);
fs.writeFileSync(file, asJson ? JSON.stringify(report, null, 2) : renderMarkdown(report));

console.log(
  `${report.summary.passed} of ${report.summary.total} test cases passed ` +
    `(${report.total_alerts} alerts across ${report.documents.toLocaleString("en-US")} documents)`,
);
for (const r of report.results.filter((x) => x.status === "fail")) {
  console.log(`  FAIL ${r.testCase.id} ${r.testCase.title} — ${r.reason}`);
}
console.log(`written to ${file}`);
