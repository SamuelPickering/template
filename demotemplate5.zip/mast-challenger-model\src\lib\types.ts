/**
 * Canonical data model.
 *
 * Source data arrives as Master.Transaction documents in one of several
 * product schemas (Credit, Rates, Fenics order streams, FX). Those documents
 * are stored as-is; everything downstream works on the normalised `Execution`
 * and `OrderStream` records the adapters produce from them, so the detection
 * logic does not care which product family a record came from.
 */

export type ProductFamily = "credit" | "rates" | "fenics" | "fx";

export type ProductType =
  | "Credit.CDS"
  | "IR.Swaption"
  | "IR.CapFloor"
  | "IR.FRA"
  | "FixedIncome.Bond"
  | "FX.Spot";

/** How the source classified the execution. */
export type ExecutionClass =
  | "withClientTrade"
  | "internalTrade"
  | "Execution.OrderStream";

/** What the `price` field on an execution actually means for this product. */
export type PriceType = "Price" | "Spread" | "Rate" | "FXRate";

/**
 * Which bucket a document came from: the seeded simulation, an imported test
 * pack of engineered trades, or an imported production extract. See
 * `src/lib/datasets.ts` for the views built over these.
 */
export type DataSource = "synthetic" | "imported_synthetic" | "imported_production";

export type CounterpartyKind = "client" | "dealer" | "internal" | "unknown";

export interface Trader {
  trader_id: string;
  name: string;
  /** Dominant activity: facing clients, or running the firm's own risk. */
  trade_role: "client_facilitation" | "prop";
}

export interface Counterparty {
  counterparty_code: string;
  name: string;
  /**
   * Client = external customer whose business the firm facilitates;
   * Dealer = another bank or broker, where the firm trades its own risk;
   * Internal = the firm's own books and affiliates.
   */
  kind: CounterpartyKind;
}

/**
 * An instrument in the surveillance universe. One per thing a position can be
 * built in — a CDS reference entity at a tenor, a bond ISIN, a rates curve
 * point, a currency against USD.
 */
export interface Instrument {
  instrument: string; // canonical key, e.g. "CDS:ARDNT/SNRFOR/5Y"
  label: string; // human readable
  family: ProductFamily;
  currency: string;
  /** What the quoted level means: clean price, spread in bps, rate in %, FX rate. */
  price_type: PriceType;
  /** Starting level of the quoted metric. */
  base_level: number;
  /** Annualised volatility of the quoted metric, as a fraction of level. */
  ann_vol: number;
  /** Average daily traded volume, USD. */
  adtv_usd: number;
  /**
   * Market Impact Model calibration constant for this instrument. Set per
   * asset class, because a 1% share of a day's volume moves a thin corporate
   * bond far more than it moves EUR/USD.
   */
  impact_k: number;
  /** Years of risk, used to turn a level move into a value move. */
  duration_years: number;
  /** FX only: the non-USD currency this synthetic instrument represents. */
  currency_code?: string;
  /** Credit/rates: tenor bucket. */
  tenor?: string;
  /**
   * True when the instrument was not in the reference universe and had to be
   * derived from the imported data. Its level is what the file was printing;
   * its volatility and ADTV are asset-class defaults, not observations.
   */
  derived?: boolean;
}

export interface MarketDay {
  instrument: string;
  trade_date: string;
  open: number;
  close: number;
  volatility: number; // daily vol, fraction of level
  adtv_usd: number;
  day_seed: number;
}

export interface MarketEvent {
  event_id: string;
  headline: string;
  description: string;
  /** Instrument the shock lands on. */
  instrument: string;
  kind: "scheduled" | "surprise";
  move_pct: number; // signed move in the quoted level
  public_ms: number;
  public_datetime: string;
  trade_date: string;
}

/** A stored source document, kept in its original product schema. */
export interface SourceDocument {
  doc_id: string;
  family: ProductFamily;
  source: DataSource;
  /** QA only — detectors never read this. */
  scenario_tag: string | null;
  /** The Master.Transaction object exactly as it would arrive. */
  payload: Record<string, unknown>;
}

/**
 * A normalised execution. Produced from a source document by the adapters;
 * this is what every detector consumes.
 */
export interface Execution {
  exec_id: string;
  doc_id: string;
  trade_id: string;
  order_id: string | null;
  event_id: string | null;

  product_type: ProductType;
  family: ProductFamily;
  execution_class: ExecutionClass;

  trader_id: string;
  trader_name: string;
  counterparty_name: string | null;
  counterparty_code: string | null;
  counterparty_kind: CounterpartyKind;
  /** False when the client/dealer split had to be assumed. */
  counterparty_kind_known: boolean;
  venue_code: string | null;
  venue_name: string | null;

  book_name: string;
  business_unit: string;
  region: string;

  instrument: string;
  instrument_label: string;
  currency: string;

  /** +1 = acquiring risk (buy / receive / long), -1 = shedding it. */
  direction: 1 | -1;
  /**
   * False when the source schema carried no side field and the direction was
   * inferred. Metrics that depend on direction report this.
   */
  direction_known: boolean;

  notional: number; // in instrument currency, absolute
  notional_usd: number; // absolute
  price: number;
  price_type: PriceType;

  event_ms: number;
  event_datetime: string;
  trade_date: string;

  tenor: string | null;
  maturity_ms: number | null;

  /** Client-facing flow is what Front Running and Best Execution key off. */
  trade_role: Trader["trade_role"];

  source: DataSource;
  scenario_tag: string | null;
}

export type OrderEventType =
  | "OpenLimitOrder"
  | "Amendment"
  | "Fill"
  | "Close"
  | "Cancel";

export interface OrderEvent {
  type: OrderEventType;
  event_id: string;
  ms: number;
  datetime: string;
  limit_price: number | null;
  total_amount: number | null;
  display_amount: number | null;
  price: number | null;
  amount: number | null;
  counterparty_name: string | null;
  counterparty_code: string | null;
  venue_code: string | null;
  venue_name: string | null;
}

/**
 * A Fenics-style order stream: one order's whole life, from placement through
 * amendments and fills to close. Layering, Spoofing and Best Execution are all
 * driven by these rather than by executions.
 */
export interface OrderStream {
  order_id: string;
  doc_id: string;
  trader_id: string;
  trader_name: string;
  instrument: string;
  instrument_label: string;
  currency: string;
  product_type: ProductType;
  family: ProductFamily;
  book_name: string;
  business_unit: string;
  region: string;
  /** +1 = bid (buying), -1 = offer (selling). */
  side: 1 | -1;
  side_known: boolean;
  start_ms: number;
  end_ms: number;
  events: OrderEvent[];
  /** Totals derived from the events. */
  placed_amount: number;
  display_amount: number;
  filled_amount: number;
  cancelled_unfilled: boolean;
  amendments: number;
  /** Distinct limit price levels the order visited. */
  price_levels: number[];
  notional_usd: number;
  source: DataSource;
  scenario_tag: string | null;
}

/** Mapping overrides supplied at import time for fields a schema may not carry. */
export interface ImportOverrides {
  /** Counterparty codes or name fragments that identify clients. */
  client_patterns?: string[];
  /** Counterparty codes or name fragments that identify dealers/brokers. */
  dealer_patterns?: string[];
  /** JSON path to a side / buy-sell field, e.g. "Execution.Side". */
  side_path?: string;
  /** JSON path to a trader display name. */
  trader_name_path?: string;
  /** JSON path to a book name. */
  book_path?: string;
  /** Treat positive notional as this direction when no side field exists. */
  default_direction?: 1 | -1;
}
