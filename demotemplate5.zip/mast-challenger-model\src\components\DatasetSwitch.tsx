"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { DATASETS, DATASET_LABEL, DATASET_NOTE, type Dataset } from "@/lib/datasets";

/**
 * The dataset switch, in the header so it is always visible and it is always
 * obvious which data is on screen.
 *
 * Four views over three buckets: the seeded simulation, the seeded simulation
 * with an imported synthetic test pack added to it, that pack on its own, and
 * imported production data on its own. Production data is never mixed with
 * anything synthetic — there is no view that combines them.
 */
export function DatasetSwitch({
  dataset,
  counts,
}: {
  dataset: Dataset;
  counts: Record<Dataset, number>;
}) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [pending, startTransition] = useTransition();

  async function choose(next: Dataset) {
    if (next === dataset) return;
    setBusy(true);
    await fetch("/api/dataset", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ dataset: next }),
    });
    setBusy(false);
    startTransition(() => router.refresh());
  }

  return (
    <span>
      <b>Data source:</b>{" "}
      {DATASETS.map((view) => {
        const n = counts[view] ?? 0;
        const active = dataset === view;
        const empty = n === 0;
        return (
          <button
            key={view}
            type="button"
            onClick={() => choose(view)}
            disabled={busy || empty}
            title={
              empty
                ? "Nothing loaded for this view yet"
                : `${n.toLocaleString("en-US")} documents — ${DATASET_NOTE[view]}`
            }
            style={{
              fontWeight: active ? "bold" : "normal",
              border: active ? "2px solid #a00" : "1px solid #999",
              background: active ? "#ffecec" : empty ? "#eee" : "#fff",
              color: empty ? "#888" : "#000",
              padding: "1px 6px",
              marginRight: 4,
              cursor: empty ? "default" : "pointer",
            }}
          >
            {DATASET_LABEL[view]} ({n.toLocaleString("en-US")})
          </button>
        );
      })}
      {(busy || pending) && <span className="note"> switching...</span>}
      <span className="note"> showing {DATASET_NOTE[dataset]}</span>
    </span>
  );
}
