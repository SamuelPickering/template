/**
 * Loads the UAT pack into the imported synthetic bucket from the command line,
 * through the same parse and adapt path the Import page uses.
 *
 *   npm run uat:load
 *
 * Useful for a clean-machine check: seed, load, report, without opening the app.
 */
import fs from "node:fs";
import path from "node:path";
import { parseImport, toSourceDocuments } from "@/lib/import/json";
import { loadDocuments, replaceDocuments } from "@/lib/db/repo";
import { setDataset, setImportOverrides } from "@/lib/config/store";
import { invalidateAnalysis } from "@/lib/detect/engine";

const file = path.join(process.cwd(), "uat", "mast-uat-synthetic-trades.json");
if (!fs.existsSync(file)) {
  console.error(`${file} does not exist — run \`npm run uat:pack\` first.`);
  process.exit(1);
}

const parsed = parseImport(fs.readFileSync(file, "utf8"));
const { documents, rejected } = toSourceDocuments(parsed, "auto", "synthetic");
if (!documents.length) {
  console.error("No documents could be matched to a product schema.");
  process.exit(1);
}

replaceDocuments("imported_synthetic", documents);
setImportOverrides("imported_synthetic", parsed.pack?.overrides ?? undefined);
invalidateAnalysis();

const activate = !process.argv.includes("--no-activate");
if (activate) setDataset("imported_synthetic");

console.log(
  `${parsed.pack?.name ?? "pack"}: ${documents.length} documents loaded into the imported ` +
    `synthetic bucket${rejected.length ? `, ${rejected.length} rejected` : ""}.`,
);
console.log(
  `  ${documents.filter((d) => d.scenario_tag).length} carry a QA.TestCase marker` +
    (parsed.pack?.overrides?.client_patterns?.length
      ? `; client patterns ${parsed.pack.overrides.client_patterns.join(", ")} applied`
      : ""),
);
console.log(
  `  bucket now holds ${loadDocuments("imported_synthetic").length} documents` +
    (activate ? "; the active view is now Imported synthetic only" : ""),
);
