import fs from "node:fs";
import path from "node:path";
import { METRIC_BY_ID, METRIC_IDS, type MetricId } from "@/lib/config/metrics";
import type { ProductFamily } from "@/lib/types";
import {
  UAT_CASES,
  UAT_CASE_BY_ID,
  UAT_GROUPS,
  type Expectation,
  type UatCase,
  type UatGroup,
} from "./uatCases";

/**
 * The editable test catalogue.
 *
 * The cases that ship with the project are in `uatCases.ts`, where they can be
 * read alongside the code. Everything anyone changes afterwards — a new case,
 * a reworded scenario, a case switched off — is written to a plain JSON file
 * next to the pack, and merged over the built-in list at read time.
 *
 * Keeping edits in a separate file rather than rewriting the source means an
 * upgrade never silently drops someone's test case, and the diff between "what
 * shipped" and "what this firm actually tests" is a single file you can read.
 *
 * A case here is only the description and the verdict rule. The trades it is
 * judged on come from the imported pack, matched on the QA.TestCase marker —
 * so adding a case means writing a description here and importing documents
 * carrying that id.
 */
export interface UatCaseStore {
  version: number;
  updated: string;
  /** Added cases, and edited copies of built-in ones, keyed by nothing but id. */
  cases: UatCase[];
  /** Built-in cases switched off. */
  deleted: string[];
}

export type CaseOrigin = "built-in" | "edited" | "custom";

/**
 * A factory, not a constant: the arrays inside a shared empty object get
 * pushed into by the first save, which quietly turns "empty" into "whatever
 * was added first".
 */
const emptyStore = (): UatCaseStore => ({ version: 1, updated: "", cases: [], deleted: [] });

/**
 * Always a file inside `uat/`. Kept statically scoped to that folder so the
 * build can see where the reads go — an unscoped path makes Next trace the
 * whole project into its output.
 */
export function casesFile(): string {
  const name = process.env.MAST_UAT_CASES_FILE ?? "uat-cases.custom.json";
  return path.join(process.cwd(), "uat", path.basename(name));
}

function readStore(): UatCaseStore {
  try {
    const raw = fs.readFileSync(casesFile(), "utf8");
    const parsed = JSON.parse(raw) as Partial<UatCaseStore>;
    return {
      version: parsed.version ?? 1,
      updated: parsed.updated ?? "",
      cases: Array.isArray(parsed.cases) ? parsed.cases : [],
      deleted: Array.isArray(parsed.deleted) ? parsed.deleted : [],
    };
  } catch {
    return emptyStore();
  }
}

function writeStore(store: UatCaseStore) {
  const file = casesFile();
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const payload: UatCaseStore = { ...store, version: 1, updated: new Date().toISOString() };
  // Written formatted, because this file is meant to be read and committed.
  fs.writeFileSync(file, JSON.stringify(payload, null, 2) + "\n");
}

/* ------------------------------------------------------------------ */
/* Reading                                                             */
/* ------------------------------------------------------------------ */

/** The catalogue as it stands: built-ins, with edits, deletions and additions. */
export function loadUatCases(): UatCase[] {
  const store = readStore();
  const deleted = new Set(store.deleted);
  const edits = new Map(store.cases.map((c) => [c.id, c]));
  const out: UatCase[] = [];
  for (const c of UAT_CASES) {
    if (deleted.has(c.id)) continue;
    out.push(edits.get(c.id) ?? c);
  }
  for (const c of store.cases) {
    if (!UAT_CASE_BY_ID[c.id]) out.push(c);
  }
  return out;
}

export function originOf(id: string): CaseOrigin {
  const store = readStore();
  if (store.cases.some((c) => c.id === id)) {
    return UAT_CASE_BY_ID[id] ? "edited" : "custom";
  }
  return "built-in";
}

/** Built-in cases currently switched off. */
export function deletedCaseIds(): string[] {
  return readStore().deleted.filter((id) => !!UAT_CASE_BY_ID[id]);
}

/**
 * Groups, in the order they should appear: the ones that ship first, then any
 * a custom case invented, so a new group does not disappear off the page.
 */
export function loadUatGroups(): UatGroup[] {
  const cases = loadUatCases();
  const used = new Set(cases.map((c) => c.group));
  const out: UatGroup[] = UAT_GROUPS.filter((g) => used.has(g.name));
  const known = new Set(out.map((g) => g.name));
  for (const c of cases) {
    if (known.has(c.group)) continue;
    known.add(c.group);
    out.push({ name: c.group, blurb: "" });
  }
  return out;
}

/* ------------------------------------------------------------------ */
/* Writing                                                             */
/* ------------------------------------------------------------------ */

export interface SaveResult {
  ok: boolean;
  errors: string[];
  case?: UatCase;
}

const ID_RE = /^[A-Za-z0-9][A-Za-z0-9_.-]{1,39}$/;
const FAMILIES: ProductFamily[] = ["credit", "rates", "fenics", "fx"];
const TIERS = ["barely", "significant", "major"];

const text = (v: unknown) => (typeof v === "string" ? v.trim() : "");

/**
 * Validates a case coming in from the editor or from a hand-edited file.
 *
 * Deliberately strict about the id, the metric and the expectation, because
 * those three decide what the case means, and forgiving about the prose: an
 * empty rationale is a worse test case but not a broken one.
 */
export function validateCase(input: Record<string, unknown>): SaveResult {
  const errors: string[] = [];
  const id = text(input.id);
  if (!ID_RE.test(id)) {
    errors.push(
      "The id must be 2 to 40 characters, start with a letter or digit, and use only letters, digits, dot, dash or underscore. It is what ties the case to its trades.",
    );
  }
  const metric = text(input.metric) as MetricId;
  if (!METRIC_IDS.includes(metric)) {
    errors.push(`"${metric}" is not one of the eleven metrics.`);
  }
  const expect = text(input.expect) as Expectation;
  if (expect !== "alert" && expect !== "no_alert") {
    errors.push("Expectation must be either alert or no_alert.");
  }
  const title = text(input.title);
  if (!title) errors.push("A case needs a title — one line naming the behaviour.");

  const group = text(input.group) || "Uncategorised";
  const tierRaw = text(input.tier);
  const tier = TIERS.includes(tierRaw) ? (tierRaw as UatCase["tier"]) : undefined;
  const families = Array.isArray(input.families)
    ? (input.families.filter((f) => FAMILIES.includes(f as ProductFamily)) as ProductFamily[])
    : [];

  let relax: UatCase["relax"];
  const r = input.relax as Record<string, unknown> | undefined;
  if (r && text(r.param)) {
    const param = text(r.param);
    const def = METRIC_IDS.includes(metric)
      ? METRIC_BY_ID[metric].params.find((p) => p.key === param)
      : undefined;
    const value = Number(r.value);
    if (!def) {
      errors.push(
        `"${param}" is not a setting on ${METRIC_IDS.includes(metric) ? METRIC_BY_ID[metric].label : "that metric"}. Leave the relaxation blank if the check is structural.`,
      );
    } else if (!Number.isFinite(value)) {
      errors.push("The relaxed value has to be a number.");
    } else {
      relax = {
        param,
        label: text(r.label) || def.label,
        value,
        shown: text(r.shown) || String(value),
      };
    }
  }

  if (errors.length) return { ok: false, errors };

  return {
    ok: true,
    errors: [],
    case: {
      id,
      group,
      metric,
      expect,
      title,
      tier,
      families: families.length ? families : ["fenics"],
      tests: text(input.tests),
      scenario: text(input.scenario),
      rationale: text(input.rationale),
      expected: text(input.expected),
      gate: text(input.gate) || undefined,
      relax,
    },
  };
}

/** Adds a case, or replaces one — built-in cases are overridden, not rewritten. */
export function saveCase(input: Record<string, unknown>): SaveResult {
  const result = validateCase(input);
  if (!result.ok || !result.case) return result;
  const store = readStore();
  store.deleted = store.deleted.filter((id) => id !== result.case!.id);
  const i = store.cases.findIndex((c) => c.id === result.case!.id);
  if (i >= 0) store.cases[i] = result.case;
  else store.cases.push(result.case);
  writeStore(store);
  return result;
}

/**
 * Removes a case. A custom one is deleted outright; a built-in one is recorded
 * as switched off, so it can be brought back without reinstalling anything.
 */
export function deleteCase(id: string): { ok: boolean; restorable: boolean } {
  const store = readStore();
  const before = store.cases.length;
  store.cases = store.cases.filter((c) => c.id !== id);
  const wasBuiltIn = !!UAT_CASE_BY_ID[id];
  if (wasBuiltIn && !store.deleted.includes(id)) store.deleted.push(id);
  if (!wasBuiltIn && store.cases.length === before) return { ok: false, restorable: false };
  writeStore(store);
  return { ok: true, restorable: wasBuiltIn };
}

/** Puts one built-in case back the way it shipped. */
export function restoreCase(id: string): boolean {
  if (!UAT_CASE_BY_ID[id]) return false;
  const store = readStore();
  store.deleted = store.deleted.filter((x) => x !== id);
  store.cases = store.cases.filter((c) => c.id !== id);
  writeStore(store);
  return true;
}

/** Discards every local change. */
/**
 * Discards every local change. The file is removed rather than emptied, so
 * "no local changes" and "no file" are the same state however you look.
 */
export function resetCases(): void {
  try {
    fs.unlinkSync(casesFile());
  } catch {
    // nothing to discard
  }
}
