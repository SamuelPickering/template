import type {
  Counterparty,
  Instrument,
  ProductFamily,
  SourceDocument,
  Trader,
} from "@/lib/types";
import { creditDoc, fenicsDoc, ratesDoc, type FenicsFill } from "@/lib/gen/docs";
import { IMPACT_K } from "@/lib/gen/universe";
import { dayStartMs } from "@/lib/time";
import { UAT_CASES } from "./uatCases";

/**
 * The UAT pack: the actual trades behind every case in `uatCases.ts`.
 *
 * Written out as Master.Transaction documents in the production schemas and
 * shipped as a file to be imported, rather than seeded, so that importing is
 * itself part of what gets tested. Every document carries a QA.TestCase marker
 * naming the case it belongs to; nothing else in the file hints at what the
 * answer should be, and no detector reads that marker.
 *
 * Three rules shape the data:
 *
 *  - One instrument per case. The reference level for an instrument that is
 *    not in the local universe is derived from the prices in the file, so
 *    sharing instruments between cases would let one case move another's
 *    market level. A case per instrument keeps each one independent.
 *  - Fewer than five executions per trader, instrument and day wherever the
 *    case is not about ramping, because five is where the Ramping detector
 *    starts looking. This keeps each case attributable to one behaviour.
 *  - Nothing inside half an hour of the 16:00 close, so Banging the Close
 *    never has anything to say about these trades.
 */

/* ------------------------------------------------------------------ */
/* People and accounts                                                 */
/* ------------------------------------------------------------------ */

export const UAT_TRADERS: (Trader & { note: string })[] = [
  { trader_id: "UAT-T01", name: "N. Okafor", trade_role: "prop", note: "layering cases" },
  { trader_id: "UAT-T02", name: "P. Lindqvist", trade_role: "prop", note: "spoofing cases" },
  { trader_id: "UAT-T03", name: "G. Mbeki", trade_role: "prop", note: "wash trading cases" },
  {
    trader_id: "UAT-T04",
    name: "T. Varga",
    trade_role: "client_facilitation",
    note: "front running cases",
  },
  {
    trader_id: "UAT-T05",
    name: "I. Solberg",
    trade_role: "client_facilitation",
    note: "best execution cases",
  },
  {
    trader_id: "UAT-T06",
    name: "R. Duarte",
    trade_role: "client_facilitation",
    note: "wash and front running cases that must not fire",
  },
  {
    trader_id: "UAT-T07",
    name: "Y. Tanaka",
    trade_role: "prop",
    note: "spoofing and layering cases that must not fire",
  },
  {
    trader_id: "UAT-T08",
    name: "O. Brandt",
    trade_role: "client_facilitation",
    note: "ordinary business",
  },
  {
    trader_id: "UAT-T09",
    name: "M. Lindgren",
    trade_role: "client_facilitation",
    note: "ordinary business",
  },
];

/**
 * Counterparty codes follow a convention the pack declares in its envelope:
 * CLT- is a client, DLR- is a dealer, INT- is an internal book. No product
 * schema carries that distinction and Front Running and Best Execution both
 * need it, so it has to come from somewhere — for a real extract it comes from
 * the counterparty registry or from patterns typed on the import page.
 */
export const UAT_COUNTERPARTIES: Counterparty[] = [
  { counterparty_code: "CLT-ALPHA", name: "Alpha Pension Trust", kind: "client" },
  { counterparty_code: "CLT-BETA", name: "Beta Family Office", kind: "client" },
  { counterparty_code: "CLT-GAMMA", name: "Gamma Mutual Insurance", kind: "client" },
  { counterparty_code: "DLR-ONE", name: "Onebrook Securities", kind: "dealer" },
  { counterparty_code: "DLR-TWO", name: "Twyford Markets", kind: "dealer" },
  { counterparty_code: "INT-DESK", name: "Internal Book Transfer", kind: "internal" },
];

const CP = Object.fromEntries(UAT_COUNTERPARTIES.map((c) => [c.counterparty_code, c])) as Record<
  string,
  Counterparty
>;
const TR = Object.fromEntries(UAT_TRADERS.map((t) => [t.trader_id, t])) as Record<string, Trader>;

export const UAT_CLIENT_PATTERNS = ["CLT-"];
export const UAT_DEALER_PATTERNS = ["DLR-"];
/**
 * The pack puts a display name on each document and declares where it is. The
 * Fenics structure has nowhere to carry one, so this doubles as a test of the
 * import page's field mapping: without it every trader shows as a bare id,
 * which is exactly what happens to a real extract that carries no names.
 */
export const UAT_TRADER_NAME_PATH = "Execution.TraderName";

/* ------------------------------------------------------------------ */
/* Dates and instruments                                              */
/* ------------------------------------------------------------------ */

/** Positive cases, negative cases and ordinary business, one day each. */
export const UAT_DAYS = {
  positive: "2026-10-13",
  negative: "2026-10-14",
  clean: "2026-10-15",
} as const;

/** Milliseconds for a UTC wall-clock time on one of the pack's days. */
function at(date: string, hms: string): number {
  const [h, m, s] = hms.split(":").map(Number);
  return dayStartMs(date) + ((h * 60 + m) * 60 + (s ?? 0)) * 1000;
}

/**
 * Instruments are only ever used here to build documents — the detection side
 * derives its own reference data from the file. Only the key and the currency
 * are read by the builders.
 */
function inst(key: string, family: ProductFamily, currency = "USD"): Instrument {
  return {
    instrument: key,
    label: key,
    family,
    currency,
    price_type: family === "credit" ? "Spread" : family === "rates" ? "Rate" : "Price",
    base_level: 100,
    ann_vol: 0.05,
    adtv_usd: 5e8,
    impact_k: IMPACT_K[family],
    duration_years: 5,
  };
}

const bond = (isin: string) => inst(`BOND:${isin}`, "fenics");
const cds = (ticker: string, tenor = "5Y") => inst(`CDS:${ticker}/SNRFOR/${tenor}`, "credit");
const swap = (index: string, tenor = "5Y") => inst(`IR:${index}/${tenor}`, "rates");

/* ------------------------------------------------------------------ */
/* Builders                                                           */
/* ------------------------------------------------------------------ */

const docs: SourceDocument[] = [];
let seq = 0;

const docId = (caseId: string, kind: string) => `${caseId}-${kind}${++seq}`;

interface OrderSpec {
  case: string;
  trader: string;
  instrument: Instrument;
  side: 1 | -1;
  limit: number;
  amount: number;
  display?: number;
  start: number;
  /** Amendments at the same price, re-sizing the order. */
  resize?: { ms: number; amount: number }[];
  fills?: { ms: number; price?: number; amount: number; cp: string }[];
  /** When set, a Close event is written — the order was pulled. */
  close?: number;
}

/** A Fenics order stream. */
function order(o: OrderSpec) {
  const id = docId(o.case, "O");
  const fills: FenicsFill[] = (o.fills ?? []).map((f, i) => ({
    ms: f.ms,
    price: f.price ?? o.limit,
    amount: f.amount,
    counterparty: CP[f.cp],
    venueIndex: i,
  }));
  docs.push(
    fenicsDoc({
      docId: id,
      trader: TR[o.trader],
      instrument: o.instrument,
      side: o.side,
      limitPrice: o.limit,
      totalAmount: o.amount,
      displayAmount: o.display ?? o.amount,
      startMs: o.start,
      amendments: (o.resize ?? []).map((r) => ({
        ms: r.ms,
        limitPrice: o.limit,
        totalAmount: r.amount,
      })),
      fills,
      closeMs: o.close,
      scenarioTag: o.case,
    }),
  );
}

/** A ladder: `n` orders on one side at successive prices. */
function ladder(o: {
  case: string;
  trader: string;
  instrument: Instrument;
  side: 1 | -1;
  topPrice: number;
  step: number;
  rungs: number;
  amount: number;
  firstStart: number;
  startGapMs: number;
  lifeMs: number | number[];
  /** Rungs (0-based) that fill in full instead of being cancelled. */
  fillRungs?: number[];
  fillCp?: string;
  resizeRungs?: number[];
}) {
  for (let i = 0; i < o.rungs; i++) {
    const start = o.firstStart + i * o.startGapMs;
    const life = Array.isArray(o.lifeMs) ? o.lifeMs[i % o.lifeMs.length] : o.lifeMs;
    const price = Number((o.topPrice - i * o.step).toFixed(6));
    const filling = (o.fillRungs ?? []).includes(i);
    order({
      case: o.case,
      trader: o.trader,
      instrument: o.instrument,
      side: o.side,
      limit: price,
      amount: o.amount,
      start,
      resize: (o.resizeRungs ?? []).includes(i)
        ? [{ ms: start + Math.round(life / 3), amount: o.amount }]
        : undefined,
      fills: filling
        ? [{ ms: start + life, amount: o.amount, cp: o.fillCp ?? "DLR-ONE" }]
        : undefined,
      close: filling ? undefined : start + life,
    });
  }
}

/** A single trade that executed: an order that filled in one clip. */
function trade(t: {
  case: string;
  trader: string;
  instrument: Instrument;
  side: 1 | -1;
  price: number;
  amount: number;
  ms: number;
  cp: string;
  /** Seconds between placing the order and the fill. */
  leadMs?: number;
}) {
  order({
    case: t.case,
    trader: t.trader,
    instrument: t.instrument,
    side: t.side,
    limit: t.price,
    amount: t.amount,
    start: t.ms - (t.leadMs ?? 2000),
    fills: [{ ms: t.ms, price: t.price, amount: t.amount, cp: t.cp }],
  });
}

/** A credit CDS trade. */
function credit(c: {
  case: string;
  trader: string;
  instrument: Instrument;
  notional: number;
  direction: 1 | -1;
  ms: number;
  cp: string;
  tenorMonths?: string;
  internal?: boolean;
}) {
  docs.push(
    creditDoc({
      docId: docId(c.case, "C"),
      trader: TR[c.trader],
      counterparty: CP[c.cp],
      instrument: c.instrument,
      notional: c.notional,
      direction: c.direction,
      tradeMs: c.ms,
      tenorMonths: c.tenorMonths,
      internalTrade: c.internal,
      scenarioTag: c.case,
    }),
  );
}

/** A rates swaption. */
function swaption(r: {
  case: string;
  trader: string;
  instrument: Instrument;
  notional: number;
  direction: 1 | -1;
  strike: number;
  ms: number;
  cp: string;
}) {
  docs.push(
    ratesDoc({
      docId: docId(r.case, "R"),
      trader: TR[r.trader],
      counterparty: CP[r.cp],
      instrument: r.instrument,
      productType: "IR.Swaption",
      notional: r.notional,
      direction: r.direction,
      level: r.strike,
      tradeMs: r.ms,
      scenarioTag: r.case,
    }),
  );
}

const M = 1_000_000;
const SEC = 1000;
const POS = UAT_DAYS.positive;
const NEG = UAT_DAYS.negative;
const CLEAN = UAT_DAYS.clean;

/* ================================================================== */
/* Layering                                                            */
/* ================================================================== */

// UAT-LAYER-01 — five rungs, all pulled, $20m sold the other way.
ladder({
  case: "UAT-LAYER-01",
  trader: "UAT-T01",
  instrument: bond("XS2601000011"),
  side: 1,
  topPrice: 99.5,
  step: 0.01,
  rungs: 5,
  amount: 12 * M,
  firstStart: at(POS, "09:15:00"),
  startGapMs: 12 * SEC,
  lifeMs: [20 * SEC, 25 * SEC, 30 * SEC, 35 * SEC, 40 * SEC],
  resizeRungs: [1, 3],
});
trade({
  case: "UAT-LAYER-01",
  trader: "UAT-T01",
  instrument: bond("XS2601000011"),
  side: -1,
  price: 99.51,
  amount: 20 * M,
  ms: at(POS, "09:15:35"),
  cp: "DLR-ONE",
});

// UAT-LAYER-02 — four rungs, the configured floor, just over the threshold.
ladder({
  case: "UAT-LAYER-02",
  trader: "UAT-T01",
  instrument: bond("XS2601000022"),
  side: 1,
  topPrice: 99.6,
  step: 0.01,
  rungs: 4,
  amount: 6 * M,
  firstStart: at(POS, "09:40:00"),
  startGapMs: 10 * SEC,
  lifeMs: [20 * SEC, 22 * SEC, 25 * SEC, 25 * SEC],
});
trade({
  case: "UAT-LAYER-02",
  trader: "UAT-T01",
  instrument: bond("XS2601000022"),
  side: -1,
  price: 99.61,
  amount: 20 * M,
  ms: at(POS, "09:40:28"),
  cp: "DLR-TWO",
});

/* ================================================================== */
/* Spoofing                                                            */
/* ================================================================== */

// UAT-SPOOF-01 — one $50m bid, 18 seconds, $20m sold while it rested.
order({
  case: "UAT-SPOOF-01",
  trader: "UAT-T02",
  instrument: bond("XS2602000011"),
  side: 1,
  limit: 99.7,
  amount: 50 * M,
  start: at(POS, "09:50:00"),
  close: at(POS, "09:50:18"),
});
trade({
  case: "UAT-SPOOF-01",
  trader: "UAT-T02",
  instrument: bond("XS2602000011"),
  side: -1,
  price: 99.7,
  amount: 20 * M,
  ms: at(POS, "09:50:09"),
  cp: "DLR-ONE",
});

// UAT-SPOOF-02 — $32m offer, 25 seconds, $16m bought. Just over the threshold.
order({
  case: "UAT-SPOOF-02",
  trader: "UAT-T02",
  instrument: bond("XS2602000022"),
  side: -1,
  limit: 100.2,
  amount: 32 * M,
  start: at(POS, "10:05:00"),
  close: at(POS, "10:05:25"),
});
trade({
  case: "UAT-SPOOF-02",
  trader: "UAT-T02",
  instrument: bond("XS2602000022"),
  side: 1,
  price: 100.2,
  amount: 16 * M,
  ms: at(POS, "10:05:14"),
  cp: "DLR-TWO",
});

/* ================================================================== */
/* Wash trading                                                        */
/* ================================================================== */

// UAT-WASH-01 — $30m round trip against an internal book, six minutes.
trade({
  case: "UAT-WASH-01",
  trader: "UAT-T03",
  instrument: bond("XS2603000011"),
  side: 1,
  price: 100.0,
  amount: 30 * M,
  ms: at(POS, "10:02:00"),
  cp: "INT-DESK",
});
trade({
  case: "UAT-WASH-01",
  trader: "UAT-T03",
  instrument: bond("XS2603000011"),
  side: -1,
  price: 100.0,
  amount: 30 * M,
  ms: at(POS, "10:08:00"),
  cp: "INT-DESK",
});

// UAT-WASH-02 — the same round trip booked as 58M and 61M CDS.
credit({
  case: "UAT-WASH-02",
  trader: "UAT-T03",
  instrument: cds("UATPLC"),
  notional: 40 * M,
  direction: 1,
  ms: at(POS, "11:00:00"),
  cp: "INT-DESK",
  tenorMonths: "58M",
  internal: true,
});
credit({
  case: "UAT-WASH-02",
  trader: "UAT-T03",
  instrument: cds("UATPLC"),
  notional: 40 * M,
  direction: -1,
  ms: at(POS, "11:04:00"),
  cp: "INT-DESK",
  tenorMonths: "61M",
  internal: true,
});

// UAT-WASH-03 — $24m round trip, just over the threshold.
trade({
  case: "UAT-WASH-03",
  trader: "UAT-T03",
  instrument: bond("XS2603000033"),
  side: 1,
  price: 98.75,
  amount: 24 * M,
  ms: at(POS, "11:30:00"),
  cp: "INT-DESK",
});
trade({
  case: "UAT-WASH-03",
  trader: "UAT-T03",
  instrument: bond("XS2603000033"),
  side: -1,
  price: 98.75,
  amount: 24 * M,
  ms: at(POS, "11:39:00"),
  cp: "INT-DESK",
});

/* ================================================================== */
/* Front running                                                       */
/* ================================================================== */

// UAT-FRONT-01 — $20m own-account long, $60m of client business, exit two
// minutes after the last client fill.
trade({
  case: "UAT-FRONT-01",
  trader: "UAT-T04",
  instrument: bond("XS2604000011"),
  side: 1,
  price: 99.9,
  amount: 20 * M,
  ms: at(POS, "09:58:00"),
  cp: "DLR-ONE",
});
order({
  case: "UAT-FRONT-01",
  trader: "UAT-T04",
  instrument: bond("XS2604000011"),
  side: 1,
  limit: 99.94,
  amount: 60 * M,
  start: at(POS, "10:10:00"),
  fills: [
    { ms: at(POS, "10:12:00"), amount: 30 * M, cp: "CLT-ALPHA" },
    { ms: at(POS, "10:18:00"), amount: 30 * M, cp: "CLT-BETA" },
  ],
});
trade({
  case: "UAT-FRONT-01",
  trader: "UAT-T04",
  instrument: bond("XS2604000011"),
  side: -1,
  price: 99.98,
  amount: 20 * M,
  ms: at(POS, "10:20:00"),
  cp: "DLR-TWO",
});

// UAT-FRONT-02 — the same pattern in swaptions.
swaption({
  case: "UAT-FRONT-02",
  trader: "UAT-T04",
  instrument: swap("UATSOFR"),
  notional: 200 * M,
  direction: 1,
  strike: 3.95,
  ms: at(POS, "09:30:00"),
  cp: "DLR-ONE",
});
swaption({
  case: "UAT-FRONT-02",
  trader: "UAT-T04",
  instrument: swap("UATSOFR"),
  notional: 300 * M,
  direction: 1,
  strike: 3.96,
  ms: at(POS, "09:40:00"),
  cp: "CLT-ALPHA",
});
swaption({
  case: "UAT-FRONT-02",
  trader: "UAT-T04",
  instrument: swap("UATSOFR"),
  notional: 300 * M,
  direction: 1,
  strike: 3.96,
  ms: at(POS, "09:44:00"),
  cp: "CLT-GAMMA",
});
swaption({
  case: "UAT-FRONT-02",
  trader: "UAT-T04",
  instrument: swap("UATSOFR"),
  notional: 160 * M,
  direction: -1,
  strike: 3.97,
  ms: at(POS, "09:46:00"),
  cp: "DLR-TWO",
});

// UAT-FRONT-03 — smaller, just over the threshold.
trade({
  case: "UAT-FRONT-03",
  trader: "UAT-T04",
  instrument: bond("XS2604000033"),
  side: 1,
  price: 100.1,
  amount: 25 * M,
  ms: at(POS, "11:05:00"),
  cp: "DLR-ONE",
});
trade({
  case: "UAT-FRONT-03",
  trader: "UAT-T04",
  instrument: bond("XS2604000033"),
  side: 1,
  price: 100.12,
  amount: 30 * M,
  ms: at(POS, "11:20:00"),
  cp: "CLT-ALPHA",
  leadMs: 60 * SEC,
});
trade({
  case: "UAT-FRONT-03",
  trader: "UAT-T04",
  instrument: bond("XS2604000033"),
  side: -1,
  price: 100.12,
  amount: 25 * M,
  ms: at(POS, "11:22:00"),
  cp: "DLR-TWO",
});

/* ================================================================== */
/* Best execution                                                      */
/* ================================================================== */

// UAT-BESTEX-01 — client 30 bps behind the firm's own print 90s earlier.
trade({
  case: "UAT-BESTEX-01",
  trader: "UAT-T05",
  instrument: bond("XS2605000011"),
  side: 1,
  price: 99.8,
  amount: 8 * M,
  ms: at(POS, "09:30:00"),
  cp: "DLR-ONE",
});
trade({
  case: "UAT-BESTEX-01",
  trader: "UAT-T05",
  instrument: bond("XS2605000011"),
  side: 1,
  price: 99.5,
  amount: 25 * M,
  ms: at(POS, "09:31:30"),
  cp: "CLT-ALPHA",
});

// UAT-BESTEX-02 — 26 bps on $6m, one basis point over the materiality floor.
trade({
  case: "UAT-BESTEX-02",
  trader: "UAT-T05",
  instrument: bond("XS2605000022"),
  side: 1,
  price: 99.76,
  amount: 4 * M,
  ms: at(POS, "10:00:00"),
  cp: "DLR-ONE",
});
trade({
  case: "UAT-BESTEX-02",
  trader: "UAT-T05",
  instrument: bond("XS2605000022"),
  side: 1,
  price: 99.5,
  amount: 6 * M,
  ms: at(POS, "10:01:20"),
  cp: "CLT-BETA",
});

// UAT-BESTEX-03 — 45 bps on $40m.
trade({
  case: "UAT-BESTEX-03",
  trader: "UAT-T05",
  instrument: bond("XS2605000033"),
  side: 1,
  price: 100.05,
  amount: 10 * M,
  ms: at(POS, "13:00:00"),
  cp: "DLR-TWO",
});
trade({
  case: "UAT-BESTEX-03",
  trader: "UAT-T05",
  instrument: bond("XS2605000033"),
  side: 1,
  price: 99.6,
  amount: 40 * M,
  ms: at(POS, "13:02:00"),
  cp: "CLT-GAMMA",
});

/* ================================================================== */
/* Wash trading — must not fire                                        */
/* ================================================================== */

// UAT-NEG-WASH-01 — matching size and timing, two different bonds.
trade({
  case: "UAT-NEG-WASH-01",
  trader: "UAT-T06",
  instrument: bond("XS2606000011"),
  side: 1,
  price: 99.7,
  amount: 30 * M,
  ms: at(NEG, "10:00:05"),
  cp: "INT-DESK",
});
trade({
  case: "UAT-NEG-WASH-01",
  trader: "UAT-T06",
  instrument: bond("XS2606000012"),
  side: -1,
  price: 101.2,
  amount: 30 * M,
  ms: at(NEG, "10:00:12"),
  cp: "INT-DESK",
});

// UAT-NEG-WASH-02 — a position held for most of the session.
trade({
  case: "UAT-NEG-WASH-02",
  trader: "UAT-T06",
  instrument: bond("XS2606000022"),
  side: 1,
  price: 99.5,
  amount: 30 * M,
  ms: at(NEG, "09:15:00"),
  cp: "DLR-ONE",
});
trade({
  case: "UAT-NEG-WASH-02",
  trader: "UAT-T06",
  instrument: bond("XS2606000022"),
  side: -1,
  price: 99.85,
  amount: 30 * M,
  ms: at(NEG, "14:55:00"),
  cp: "DLR-TWO",
});

// UAT-NEG-WASH-03 — bought from one client, sold to another.
trade({
  case: "UAT-NEG-WASH-03",
  trader: "UAT-T06",
  instrument: bond("XS2606000033"),
  side: 1,
  price: 99.3,
  amount: 25 * M,
  ms: at(NEG, "10:00:00"),
  cp: "CLT-ALPHA",
});
trade({
  case: "UAT-NEG-WASH-03",
  trader: "UAT-T06",
  instrument: bond("XS2606000033"),
  side: -1,
  price: 99.34,
  amount: 25 * M,
  ms: at(NEG, "10:08:00"),
  cp: "CLT-BETA",
});

// UAT-NEG-WASH-04 — a 30% hedge, not a round trip.
trade({
  case: "UAT-NEG-WASH-04",
  trader: "UAT-T06",
  instrument: bond("XS2606000044"),
  side: 1,
  price: 100.0,
  amount: 30 * M,
  ms: at(NEG, "11:00:00"),
  cp: "INT-DESK",
});
trade({
  case: "UAT-NEG-WASH-04",
  trader: "UAT-T06",
  instrument: bond("XS2606000044"),
  side: -1,
  price: 100.0,
  amount: 9 * M,
  ms: at(NEG, "11:05:00"),
  cp: "INT-DESK",
});

/* ================================================================== */
/* Front running — must not fire                                       */
/* ================================================================== */

// UAT-NEG-FRONT-01 — the exit comes nearly six hours after the client flow.
trade({
  case: "UAT-NEG-FRONT-01",
  trader: "UAT-T06",
  instrument: bond("XS2607000011"),
  side: 1,
  price: 99.6,
  amount: 20 * M,
  ms: at(NEG, "09:00:00"),
  cp: "DLR-ONE",
});
order({
  case: "UAT-NEG-FRONT-01",
  trader: "UAT-T06",
  instrument: bond("XS2607000011"),
  side: 1,
  limit: 99.62,
  amount: 60 * M,
  start: at(NEG, "09:22:00"),
  fills: [
    { ms: at(NEG, "09:25:00"), amount: 30 * M, cp: "CLT-ALPHA" },
    { ms: at(NEG, "09:35:00"), amount: 30 * M, cp: "CLT-BETA" },
  ],
});
trade({
  case: "UAT-NEG-FRONT-01",
  trader: "UAT-T06",
  instrument: bond("XS2607000011"),
  side: -1,
  price: 99.7,
  amount: 20 * M,
  ms: at(NEG, "15:30:00"),
  cp: "DLR-TWO",
});

// UAT-NEG-FRONT-02 — the client business is on the other side of the market.
trade({
  case: "UAT-NEG-FRONT-02",
  trader: "UAT-T06",
  instrument: bond("XS2607000022"),
  side: 1,
  price: 100.0,
  amount: 20 * M,
  ms: at(NEG, "10:00:00"),
  cp: "DLR-ONE",
});
order({
  case: "UAT-NEG-FRONT-02",
  trader: "UAT-T06",
  instrument: bond("XS2607000022"),
  side: -1,
  limit: 99.98,
  amount: 60 * M,
  start: at(NEG, "10:03:00"),
  fills: [
    { ms: at(NEG, "10:05:00"), amount: 30 * M, cp: "CLT-ALPHA" },
    { ms: at(NEG, "10:09:00"), amount: 30 * M, cp: "CLT-BETA" },
  ],
});
trade({
  case: "UAT-NEG-FRONT-02",
  trader: "UAT-T06",
  instrument: bond("XS2607000022"),
  side: -1,
  price: 99.96,
  amount: 28 * M,
  ms: at(NEG, "10:12:00"),
  cp: "DLR-TWO",
});

// UAT-NEG-FRONT-03 — nothing held before the client business.
order({
  case: "UAT-NEG-FRONT-03",
  trader: "UAT-T06",
  instrument: bond("XS2607000033"),
  side: 1,
  limit: 99.5,
  amount: 60 * M,
  start: at(NEG, "09:58:00"),
  fills: [
    { ms: at(NEG, "10:00:00"), amount: 30 * M, cp: "CLT-ALPHA" },
    { ms: at(NEG, "10:06:00"), amount: 30 * M, cp: "CLT-BETA" },
  ],
});
trade({
  case: "UAT-NEG-FRONT-03",
  trader: "UAT-T06",
  instrument: bond("XS2607000033"),
  side: -1,
  price: 99.52,
  amount: 20 * M,
  ms: at(NEG, "10:08:00"),
  cp: "DLR-TWO",
});

/* ================================================================== */
/* Spoofing — must not fire                                            */
/* ================================================================== */

// UAT-NEG-SPOOF-01 — nothing executed the other way.
order({
  case: "UAT-NEG-SPOOF-01",
  trader: "UAT-T07",
  instrument: bond("XS2608000011"),
  side: 1,
  limit: 99.4,
  amount: 50 * M,
  start: at(NEG, "09:50:00"),
  close: at(NEG, "09:50:20"),
});

// UAT-NEG-SPOOF-02 — the order filled in full.
order({
  case: "UAT-NEG-SPOOF-02",
  trader: "UAT-T07",
  instrument: bond("XS2608000022"),
  side: 1,
  limit: 99.45,
  amount: 50 * M,
  start: at(NEG, "09:55:00"),
  fills: [
    { ms: at(NEG, "09:55:10"), amount: 25 * M, cp: "DLR-ONE" },
    { ms: at(NEG, "09:55:40"), amount: 25 * M, cp: "DLR-ONE" },
  ],
});
trade({
  case: "UAT-NEG-SPOOF-02",
  trader: "UAT-T07",
  instrument: bond("XS2608000022"),
  side: -1,
  price: 99.45,
  amount: 20 * M,
  ms: at(NEG, "09:55:20"),
  cp: "DLR-TWO",
});

// UAT-NEG-SPOOF-03 — it rested for eleven minutes.
order({
  case: "UAT-NEG-SPOOF-03",
  trader: "UAT-T07",
  instrument: bond("XS2608000033"),
  side: 1,
  limit: 99.55,
  amount: 50 * M,
  start: at(NEG, "10:10:00"),
  close: at(NEG, "10:21:00"),
});
trade({
  case: "UAT-NEG-SPOOF-03",
  trader: "UAT-T07",
  instrument: bond("XS2608000033"),
  side: -1,
  price: 99.55,
  amount: 20 * M,
  ms: at(NEG, "10:15:00"),
  cp: "DLR-TWO",
});

// UAT-NEG-SPOOF-04 — $5m of $50m displayed.
order({
  case: "UAT-NEG-SPOOF-04",
  trader: "UAT-T07",
  instrument: bond("XS2608000044"),
  side: 1,
  limit: 99.65,
  amount: 50 * M,
  display: 5 * M,
  start: at(NEG, "10:30:00"),
  close: at(NEG, "10:30:15"),
});
trade({
  case: "UAT-NEG-SPOOF-04",
  trader: "UAT-T07",
  instrument: bond("XS2608000044"),
  side: -1,
  price: 99.65,
  amount: 20 * M,
  ms: at(NEG, "10:30:08"),
  cp: "DLR-TWO",
});

/* ================================================================== */
/* Layering — must not fire                                            */
/* ================================================================== */

// UAT-NEG-LAYER-01 — five orders, one price.
ladder({
  case: "UAT-NEG-LAYER-01",
  trader: "UAT-T07",
  instrument: bond("XS2609000011"),
  side: 1,
  topPrice: 99.75,
  step: 0,
  rungs: 5,
  amount: 12 * M,
  firstStart: at(NEG, "10:40:00"),
  startGapMs: 20 * SEC,
  lifeMs: 90 * SEC,
});
trade({
  case: "UAT-NEG-LAYER-01",
  trader: "UAT-T07",
  instrument: bond("XS2609000011"),
  side: -1,
  price: 99.75,
  amount: 20 * M,
  ms: at(NEG, "10:41:00"),
  cp: "DLR-TWO",
});

// UAT-NEG-LAYER-02 — a ladder where three of five rungs traded.
ladder({
  case: "UAT-NEG-LAYER-02",
  trader: "UAT-T07",
  instrument: bond("XS2609000022"),
  side: 1,
  topPrice: 99.85,
  step: 0.01,
  rungs: 5,
  amount: 12 * M,
  firstStart: at(NEG, "11:00:00"),
  startGapMs: 20 * SEC,
  lifeMs: 30 * SEC,
  fillRungs: [0, 1, 2],
  fillCp: "DLR-ONE",
});
trade({
  case: "UAT-NEG-LAYER-02",
  trader: "UAT-T07",
  instrument: bond("XS2609000022"),
  side: -1,
  price: 99.85,
  amount: 20 * M,
  ms: at(NEG, "11:01:30"),
  cp: "DLR-TWO",
});

// UAT-NEG-LAYER-03 — a ladder parked six to ten basis points off the touch.
// The ordinary prints are what establish where the touch actually was: with no
// reference data for an unknown ISIN, the level is derived from the file.
ladder({
  case: "UAT-NEG-LAYER-03",
  trader: "UAT-T07",
  instrument: bond("XS2609000033"),
  side: 1,
  topPrice: 99.44,
  step: 0.01,
  rungs: 5,
  amount: 12 * M,
  firstStart: at(NEG, "13:00:00"),
  startGapMs: 15 * SEC,
  lifeMs: 30 * SEC,
});
trade({
  case: "UAT-NEG-LAYER-03",
  trader: "UAT-T07",
  instrument: bond("XS2609000033"),
  side: -1,
  price: 99.5,
  amount: 20 * M,
  ms: at(NEG, "13:00:40"),
  cp: "DLR-TWO",
});
(
  [
    ["UAT-T08", 1, 99.5, "08:40:00", "DLR-ONE"],
    ["UAT-T08", -1, 99.51, "09:25:00", "DLR-TWO"],
    ["UAT-T09", 1, 99.5, "10:10:00", "DLR-ONE"],
    ["UAT-T09", -1, 99.51, "11:05:00", "DLR-TWO"],
    ["UAT-T08", 1, 99.51, "11:50:00", "DLR-TWO"],
    ["UAT-T09", -1, 99.5, "12:35:00", "DLR-ONE"],
  ] as [string, 1 | -1, number, string, string][]
).forEach(([trader, side, price, hms, cp]) =>
  trade({
    case: "UAT-NEG-LAYER-03",
    trader,
    instrument: bond("XS2609000033"),
    side,
    price,
    amount: 2 * M,
    ms: at(NEG, hms),
    cp,
  }),
);

/* ================================================================== */
/* Best execution — must not fire                                      */
/* ================================================================== */

// UAT-NEG-BESTEX-01 — the client got 20 bps more than the dealer did.
trade({
  case: "UAT-NEG-BESTEX-01",
  trader: "UAT-T05",
  instrument: bond("XS2610000011"),
  side: 1,
  price: 99.5,
  amount: 8 * M,
  ms: at(NEG, "09:20:00"),
  cp: "DLR-ONE",
});
trade({
  case: "UAT-NEG-BESTEX-01",
  trader: "UAT-T05",
  instrument: bond("XS2610000011"),
  side: 1,
  price: 99.7,
  amount: 25 * M,
  ms: at(NEG, "09:21:30"),
  cp: "CLT-ALPHA",
});

// UAT-NEG-BESTEX-02 — 15 bps, inside the materiality floor.
trade({
  case: "UAT-NEG-BESTEX-02",
  trader: "UAT-T05",
  instrument: bond("XS2610000022"),
  side: 1,
  price: 99.65,
  amount: 5 * M,
  ms: at(NEG, "09:40:00"),
  cp: "DLR-ONE",
});
trade({
  case: "UAT-NEG-BESTEX-02",
  trader: "UAT-T05",
  instrument: bond("XS2610000022"),
  side: 1,
  price: 99.5,
  amount: 25 * M,
  ms: at(NEG, "09:41:20"),
  cp: "CLT-BETA",
});

// UAT-NEG-BESTEX-03 — 60 bps on $200k, below the size floor.
trade({
  case: "UAT-NEG-BESTEX-03",
  trader: "UAT-T05",
  instrument: bond("XS2610000033"),
  side: 1,
  price: 99.8,
  amount: 8 * M,
  ms: at(NEG, "10:50:00"),
  cp: "DLR-ONE",
});
trade({
  case: "UAT-NEG-BESTEX-03",
  trader: "UAT-T05",
  instrument: bond("XS2610000033"),
  side: 1,
  price: 99.2,
  amount: 200_000,
  ms: at(NEG, "10:51:00"),
  cp: "CLT-GAMMA",
});

/* ================================================================== */
/* Ordinary business                                                   */
/* ================================================================== */

const CLEAN_CASE = "UAT-CLEAN-01";

// Bonds, worked two-way through the day with hours between the legs.
(
  [
    ["UAT-T08", "XS2611000011", 1, 99.9, 5 * M, "08:30:00", "CLT-GAMMA"],
    ["UAT-T08", "XS2611000011", -1, 99.95, 4 * M, "10:45:00", "DLR-ONE"],
    ["UAT-T08", "XS2611000011", 1, 99.92, 6 * M, "13:30:00", "DLR-TWO"],
    ["UAT-T09", "XS2611000022", -1, 100.4, 7 * M, "09:10:00", "CLT-ALPHA"],
    ["UAT-T09", "XS2611000022", 1, 100.35, 7 * M, "12:20:00", "DLR-ONE"],
    ["UAT-T09", "XS2611000022", 1, 100.38, 2 * M, "14:30:00", "DLR-TWO"],
    ["UAT-T08", "XS2611000033", 1, 100.1, 3 * M, "10:00:00", "DLR-ONE"],
    ["UAT-T08", "XS2611000033", 1, 100.1, 3 * M, "15:00:00", "CLT-ALPHA"],
  ] as [string, string, 1 | -1, number, number, string, string][]
).forEach(([trader, isin, side, price, amount, hms, cp]) =>
  trade({
    case: CLEAN_CASE,
    trader,
    instrument: bond(isin),
    side,
    price,
    amount,
    ms: at(CLEAN, hms),
    cp,
  }),
);

// Credit: a position taken and left on, plus one unrelated tenor.
credit({
  case: CLEAN_CASE,
  trader: "UAT-T08",
  instrument: cds("UATGRP"),
  notional: 25 * M,
  direction: 1,
  ms: at(CLEAN, "11:00:00"),
  cp: "CLT-BETA",
});
credit({
  case: CLEAN_CASE,
  trader: "UAT-T08",
  instrument: cds("UATGRP"),
  notional: 15 * M,
  direction: 1,
  ms: at(CLEAN, "14:00:00"),
  cp: "DLR-ONE",
});
credit({
  case: CLEAN_CASE,
  trader: "UAT-T08",
  instrument: cds("UATGRP", "10Y"),
  notional: 20 * M,
  direction: -1,
  ms: at(CLEAN, "11:30:00"),
  cp: "DLR-TWO",
  tenorMonths: "120M",
});

// Rates: two curve points, one of them revisited hours later.
swaption({
  case: CLEAN_CASE,
  trader: "UAT-T09",
  instrument: swap("UATESTR"),
  notional: 150 * M,
  direction: 1,
  strike: 2.8,
  ms: at(CLEAN, "09:50:00"),
  cp: "CLT-GAMMA",
});
swaption({
  case: CLEAN_CASE,
  trader: "UAT-T09",
  instrument: swap("UATESTR", "2Y"),
  notional: 120 * M,
  direction: -1,
  strike: 2.6,
  ms: at(CLEAN, "13:10:00"),
  cp: "DLR-TWO",
});
swaption({
  case: CLEAN_CASE,
  trader: "UAT-T09",
  instrument: swap("UATESTR"),
  notional: 60 * M,
  direction: -1,
  strike: 2.8,
  ms: at(CLEAN, "14:50:00"),
  cp: "DLR-ONE",
});

/* ------------------------------------------------------------------ */
/* Assembly                                                           */
/* ------------------------------------------------------------------ */

export interface UatPackFile {
  TestPack: {
    Name: string;
    Version: number;
    Generated: string;
    Notes: string[];
    Overrides: {
      client_patterns: string[];
      dealer_patterns: string[];
      trader_name_path: string;
    };
  };
  Transactions: Record<string, unknown>[];
}

export const UAT_PACK_NAME = "MAST Challenger UAT pack";
export const UAT_PACK_VERSION = 1;

/** The documents, with their case tag attached as the QA marker. */
export function uatDocuments(): SourceDocument[] {
  return docs.map((d) => ({ ...d, source: "imported_synthetic" }));
}

/**
 * The file as it ships. Each payload carries a QA block naming its case and
 * whether the case expects an alert, and a TraderName the envelope points at —
 * the Fenics structure has nowhere to put one, which is exactly the kind of
 * gap the override fields on the import page exist for.
 */
export function uatPackFile(generatedAt = new Date().toISOString()): UatPackFile {
  const expectOf = new Map(UAT_CASES.map((c) => [c.id, c.expect]));
  const nameOf = new Map(UAT_TRADERS.map((t) => [t.trader_id, t.name]));

  // Books are named after the product rather than hashed from the trader id,
  // so a bond trade does not end up booked to an FX line.
  const bookOf: Record<ProductFamily, string> = {
    fenics: "UAT-FI-01",
    credit: "UAT-CRD-01",
    rates: "UAT-RTS-01",
    fx: "UAT-FX-01",
  };

  const transactions = docs.map((d) => {
    const payload = JSON.parse(JSON.stringify(d.payload)) as Record<string, unknown>;
    const exec = payload.Execution as Record<string, unknown>;
    const traderId = String(exec.TraderID ?? "");
    exec.TraderName = nameOf.get(traderId) ?? traderId;
    const unit = payload.Unit as Record<string, unknown> | undefined;
    if (unit) unit.BookName = bookOf[d.family];
    return {
      QA: {
        TestCase: d.scenario_tag,
        Expect: expectOf.get(d.scenario_tag ?? "") ?? "alert",
      },
      ...payload,
    };
  });

  return {
    TestPack: {
      Name: UAT_PACK_NAME,
      Version: UAT_PACK_VERSION,
      Generated: generatedAt,
      Notes: [
        "Engineered trades. Nothing here is production data and no instrument, trader or counterparty in it is real.",
        "Import this as synthetic test data. The QA.TestCase marker on each document is read only on a synthetic import, and no detection engine ever reads it — it exists so the UAT page can match alerts back to cases.",
        "Counterparty codes follow a convention: CLT- is a client, DLR- is a dealer, INT- is an internal book. The product schemas carry no client/dealer flag, so the pack declares its own patterns here.",
        "Trader display names sit at Execution.TraderName, which no product schema defines — the pack declares the path so the import can pick them up, the same way a real feed that carries names would be mapped.",
      ],
      Overrides: {
        client_patterns: UAT_CLIENT_PATTERNS,
        dealer_patterns: UAT_DEALER_PATTERNS,
        trader_name_path: UAT_TRADER_NAME_PATH,
      },
    },
    Transactions: transactions,
  };
}

/** Documents per case, for the design document and for sanity checks. */
export function uatDocumentsByCase(): Map<string, SourceDocument[]> {
  const m = new Map<string, SourceDocument[]>();
  for (const d of docs) {
    const key = d.scenario_tag ?? "untagged";
    const arr = m.get(key) ?? [];
    arr.push(d);
    m.set(key, arr);
  }
  return m;
}
