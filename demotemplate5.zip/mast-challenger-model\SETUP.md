# Setup — running this on another machine

## What you need first

- **Node.js 20 or newer** (22 LTS is fine, so is 24). Check with `node -v`.
  If it isn't installed: https://nodejs.org — the LTS installer, defaults are fine.
- Nothing else. No database server, no accounts, no API keys, and nothing that has to be
  compiled — every dependency is plain JavaScript, so no C++ build tools are needed. The
  generated data sits in `data/dataset.json`, which the seed step creates.

## Steps

1. Extract the zip somewhere with a short path, e.g. `C:\dev\mast-challenger-model`.
   (Avoid OneDrive-synced folders — the file watcher and OneDrive fight each other.)

2. Open the folder in VS Code: **File → Open Folder…** → pick the extracted folder.

3. Open a terminal in VS Code: **Terminal → New Terminal** (Ctrl + `).

4. Install dependencies — a few minutes the first time:

```bash
npm install
```

5. Generate the synthetic dataset (traders, instruments, market data, trade and order
   documents in all four product schemas, events, scenarios). Takes about 30 seconds and
   creates `data/dataset.json`:

```bash
npm run seed
```

6. Start the app:

```bash
npm run dev
```

7. Open http://localhost:3000 in a browser. Ctrl+C in the terminal stops it.

8. Optional, for the UAT pack: on the **Import** page choose **Synthetic test data**, leave the
   product type on detect, and upload `uat/mast-uat-synthetic-trades.json` from the project
   folder. The **UAT Pack** page then reports 31 of 31 cases passing. The same thing from the
   terminal, if you would rather not click:

```bash
npm run uat:load
npm run uat:report
```

## For the demo itself

A route through the app that shows the whole idea in a few minutes:

1. **Dashboard** — total documents vs. total alerts, USD Value by metric, alerts by product
   family, and which traders carry the most risk (shown in red with the abuse types flagged).
2. **Alerts** — everything above threshold across eleven metrics and four product families,
   sorted by USD Value.
3. Open a **Layering** or **Spoofing** alert — the order-by-order ladder, the events timeline,
   and the Narrative versus Counter-Narrative scoring. Expand the source document at the bottom
   to show the raw Fenics order stream it came from.
4. Open a **Best Execution** alert — the client fill against the better price the firm itself was
   printing moments earlier on the same ISIN.
5. **Blotter**, filtered to one trader — alerted executions are highlighted and labelled with the
   abuse type, with the trader's flagged abuses summarised at the top.
6. **Admin** — drop the Ramping threshold from $15,000 to $5,000, hit Apply, then go back to
   Alerts. The list grows immediately; nothing is precomputed. Reset to default afterwards.
7. **Wash Trading** — turn on "Require same product type" and watch the cross-product and
   cross-tenor variants drop out, because their offset hides behind a different contract.
8. **Import** — load `samples/sample-mixed.json` as production data and show the coverage table:
   which metrics the data supports, which cannot run and why, and any instruments whose reference
   data had to be derived from the file. Then use the **Production import only** switch in the
   header: the whole app now shows that data alone, with no synthetic traders or trades anywhere.
9. **Test Cases** — 27 cases, one per behaviour, each with its scenario and the alert it actually
   produced, plus the severity-tier ordering and threshold sweeps. Download the report from that
   page if someone wants it on paper.
10. **UAT Pack** — the part for business stakeholders. 31 cases, of which 18 exist to prove the
   tool stays quiet: two different bonds traded at the same moment is not a wash, a trade six
   hours after client business is not front running, an order that actually filled is not a spoof.
   Open one of those cases and show the three things under it: the trades that were analysed, the
   check that stopped it, and what happens when that check is relaxed. Then download the results
   file — it is the UAT evidence pack.
11. **Edit the test cases** — the link at the top of the UAT page. Worth 30 seconds if anyone
   asks "could you test for X?": add a case, download the starter trades, import them, and the new
   case is scored with the rest. Reset afterwards.
12. **Methodology** — one page on normalisation, the impact model, the value conversion, USD Value
   and what each product can and cannot evidence.

## If something goes wrong

- **`npm install` fails behind a corporate proxy** — the work machine may need a registry
  or proxy setting. `npm config get registry` should return a reachable URL. If IT uses an
  internal mirror, `npm config set registry <their-url>` before retrying.
- **Port 3000 already in use** — run `npm run dev -- -p 3001` and use that port instead.
- **Want to start over from clean data** — delete the `data` folder and run `npm run seed`
  again. That also clears any threshold changes, which live in `data/config.json`.
  Re-running `npm run seed` on its own regenerates the simulation but leaves imported files
  alone, so the UAT pack survives a re-seed.
- **The UAT page says the pack is not loaded** — it only reads the imported *synthetic* bucket.
  Importing the pack as production data puts it in the other bucket; re-import it with
  **Synthetic test data** selected.
- **Check the detection engine without the UI** — `npm run qa` prints per-metric alert
  counts, whether each engineered scenario was found, how many alerts come from ordinary
  background flow, and a threshold sweep.

## Running it a bit faster

`npm run dev` is the development server and recompiles pages as they are opened, so the
first visit to each page takes a second or two. For a smoother demo:

```bash
npm run build
npm start
```

Same app at http://localhost:3000, pages render immediately. Re-run `npm run build` after
any code change.
