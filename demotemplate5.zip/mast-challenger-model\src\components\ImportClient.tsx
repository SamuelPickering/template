"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import {
  IMPORT_MODES,
  OVERRIDE_FIELDS,
  type ImportAnalysis,
  type ImportMode,
  type TestPackEnvelope,
} from "@/lib/import/json";
import { DATASETS, DATASET_LABEL, DATASET_NOTE, type Dataset } from "@/lib/datasets";
import type { ImportOverrides } from "@/lib/types";

const FAMILIES: { value: string; label: string }[] = [
  { value: "auto", label: "detect from each document" },
  { value: "credit", label: "Credit (Credit.CDS)" },
  { value: "rates", label: "Rates (IR.Swaption / IR.CapFloor / IR.FRA)" },
  { value: "fenics", label: "Fenics order streams (FixedIncome.Bond)" },
  { value: "fx", label: "FX (FX.Spot)" },
];

interface PreviewResponse {
  format: string;
  fileErrors: string[];
  mode: ImportMode;
  pack: TestPackEnvelope | null;
  analysis: ImportAnalysis;
}

export function ImportClient({
  dataset,
  counts,
}: {
  dataset: Dataset;
  counts: Record<Dataset, number>;
}) {
  const router = useRouter();
  const [text, setText] = useState<string | null>(null);
  const [fileName, setFileName] = useState("");
  const [family, setFamily] = useState("auto");
  const [mode, setMode] = useState<ImportMode>("production");
  const [append, setAppend] = useState(false);
  const [overrides, setOverrides] = useState<Record<string, string>>({});
  const [preview, setPreview] = useState<PreviewResponse | null>(null);
  const [committed, setCommitted] = useState<{ imported: number; total: number } | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function buildOverrides(): ImportOverrides {
    const o: ImportOverrides = {};
    for (const f of OVERRIDE_FIELDS) {
      const raw = overrides[f.key]?.trim();
      if (!raw) continue;
      if (f.kind === "patterns") {
        (o as Record<string, unknown>)[f.key] = raw
          .split(",")
          .map((s) => s.trim())
          .filter(Boolean);
      } else {
        (o as Record<string, unknown>)[f.key] = raw;
      }
    }
    return o;
  }

  async function send(action: "preview" | "commit", content: string) {
    setBusy(true);
    setError(null);
    const res = await fetch("/api/import", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        action,
        text: content,
        family,
        mode,
        append,
        overrides: buildOverrides(),
      }),
    });
    const json = await res.json();
    setBusy(false);
    if (!res.ok) {
      setError(json.error ?? "Import failed.");
      return null;
    }
    return json;
  }

  async function onFile(file: File) {
    const content = await file.text();
    setText(content);
    setFileName(file.name);
    setCommitted(null);
    const json = await send("preview", content);
    if (json) setPreview(json);
  }

  async function reanalyse() {
    if (!text) return;
    const json = await send("preview", text);
    if (json) setPreview(json);
  }

  async function commit() {
    if (!text) return;
    const json = await send("commit", text);
    if (json) {
      setCommitted({ imported: json.imported, total: json.total });
      setPreview({ ...(preview as PreviewResponse), analysis: json.analysis });
      router.refresh();
    }
  }

  async function post(body: object) {
    setBusy(true);
    await fetch("/api/dataset", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
    });
    setBusy(false);
    router.refresh();
  }

  const a = preview?.analysis;
  const pack = preview?.pack;

  return (
    <>
      <fieldset>
        <legend>Active view: {DATASET_LABEL[dataset]}</legend>
        <p className="note small">
          The same switch is in the header. Production data is never mixed with synthetic data —
          there is no view that combines the two. The synthetic market reference data (levels,
          volatility, ADTV) and the event calendar are used in every view, because the impact model
          needs them and a trade extract does not carry them.
        </p>
        {DATASETS.map((view) => (
          <span key={view}>
            <button
              disabled={busy || (counts[view] ?? 0) === 0 || view === dataset}
              onClick={() => post({ dataset: view })}
              title={DATASET_NOTE[view]}
            >
              {DATASET_LABEL[view]} ({(counts[view] ?? 0).toLocaleString("en-US")})
            </button>{" "}
          </span>
        ))}
        <div style={{ marginTop: 6 }}>
          <button
            disabled={busy || counts.imported_synthetic === 0}
            onClick={() => {
              setPreview(null);
              setText(null);
              setCommitted(null);
              post({ action: "clear", source: "imported_synthetic" });
            }}
          >
            Clear imported synthetic
          </button>{" "}
          <button
            disabled={busy || counts.imported_production === 0}
            onClick={() => {
              setPreview(null);
              setText(null);
              setCommitted(null);
              post({ action: "clear", source: "imported_production" });
            }}
          >
            Clear imported production
          </button>
        </div>
      </fieldset>

      <fieldset>
        <legend>1. Is this production data or synthetic test data?</legend>
        {IMPORT_MODES.map((m) => (
          <div key={m.value}>
            <label className="f">
              <input
                type="radio"
                name="mode"
                checked={mode === m.value}
                onChange={() => {
                  setMode(m.value);
                  setPreview(null);
                  setCommitted(null);
                }}
              />{" "}
              <b>{m.label}</b>
            </label>
            <span className="note small"> — {m.help}</span>
          </div>
        ))}
        <p className="note small">
          This is a statement by whoever is importing, not something read out of the file. It
          decides which bucket the documents land in and whether QA markers are honoured.
        </p>
        <label className="f">
          <input
            type="checkbox"
            checked={append}
            onChange={(e) => {
              setAppend(e.target.checked);
              setCommitted(null);
            }}
          />{" "}
          add to what is already in this bucket instead of replacing it
        </label>
      </fieldset>

      <fieldset>
        <legend>2. What product is it?</legend>
        <label className="f">
          Product type{" "}
          <select value={family} onChange={(e) => setFamily(e.target.value)}>
            {FAMILIES.map((f) => (
              <option key={f.value} value={f.value}>
                {f.label}
              </option>
            ))}
          </select>
        </label>
        <p className="note small">
          Detection reads Execution.Economics.Type, Execution.Type and Unit.BusinessUnit. Choose the
          product explicitly if the extract has been stripped of those. A file holding more than one
          product — the test pack does — should be left on detect.
        </p>
      </fieldset>

      <fieldset>
        <legend>3. Upload the file</legend>
        <p className="note small">
          A JSON array of Master.Transaction documents, a single document, a wrapper object with the
          array inside it, or newline-delimited JSON. Nothing leaves this machine.
        </p>
        <input
          type="file"
          accept=".json,.ndjson,.txt,application/json"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) void onFile(f);
          }}
        />{" "}
        {fileName && <span className="note">{fileName}</span>}
        {busy && <span className="note"> working...</span>}
        {error && <p className="warn">{error}</p>}
      </fieldset>

      {pack && (
        <fieldset>
          <legend>Test pack declared by this file</legend>
          <p className="stats">
            <span>
              <b>Name:</b> {pack.name}
            </span>
            {pack.version !== null && (
              <span>
                <b>Version:</b> {pack.version}
              </span>
            )}
            {pack.generated && (
              <span>
                <b>Generated:</b> {pack.generated}
              </span>
            )}
            <span>
              <b>Documents marked with a test case:</b>{" "}
              {a?.taggedCount.toLocaleString("en-US") ?? 0} across {a?.testCases.length ?? 0} cases
            </span>
          </p>
          {pack.overrides?.client_patterns?.length ? (
            <p className="note small">
              The pack declares its own counterparty conventions — clients{" "}
              <span className="mono">{pack.overrides.client_patterns.join(", ")}</span>, dealers{" "}
              <span className="mono">{(pack.overrides.dealer_patterns ?? []).join(", ")}</span>.
              They are applied unless you type your own below. No product schema carries a
              client/dealer flag, and Front Running and Best Execution both need one.
            </p>
          ) : null}
          {pack.notes.length > 0 && (
            <ul className="small">
              {pack.notes.map((n, i) => (
                <li key={i}>{n}</li>
              ))}
            </ul>
          )}
        </fieldset>
      )}

      {a && (
        <>
          <fieldset>
            <legend>4. Fields the schema may not carry</legend>
            <p className="note small">
              Side comes from the sign of the amount (negative sells, positive buys) and both
              client and dealer counterparties arrive as Counterparty.Professional. If your feed
              works differently, point these at your own fields and re-check.
            </p>
            <table>
              <tbody>
                {OVERRIDE_FIELDS.map((f) => (
                  <tr key={f.key}>
                    <td>{f.label}</td>
                    <td>
                      <input
                        value={overrides[f.key] ?? ""}
                        placeholder={f.kind === "patterns" ? "CP-CL, PENSION, FUND" : "Execution.Side"}
                        size={26}
                        onChange={(e) =>
                          setOverrides({ ...overrides, [f.key]: e.target.value })
                        }
                      />
                    </td>
                    <td className="note" style={{ whiteSpace: "normal", maxWidth: 420 }}>
                      {f.help}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <button disabled={busy} onClick={reanalyse}>
              Re-check with these settings
            </button>
          </fieldset>

          <fieldset>
            <legend>5. What the adapters made of it</legend>
            <p className="stats">
              <span>
                <b>Documents:</b> {a.documentCount.toLocaleString("en-US")}
              </span>
              <span>
                <b>Executions:</b> {a.executions.toLocaleString("en-US")}
              </span>
              <span>
                <b>Order streams:</b> {a.orders.toLocaleString("en-US")}
              </span>
              <span>
                <b>Rejected:</b> {a.rejected.length}
              </span>
              {a.dateRange && (
                <span>
                  <b>Range:</b> {a.dateRange[0]} to {a.dateRange[1]}
                </span>
              )}
            </p>
            <p className="stats">
              <span>
                <b>By family:</b>{" "}
                {Object.entries(a.byFamily)
                  .map(([k, v]) => `${k} ${v.toLocaleString("en-US")}`)
                  .join(", ") || "none"}
              </span>
            </p>
            <p className="stats">
              <span>
                <b>Direction known:</b>{" "}
                <span className={a.directionKnownShare > 0.9 ? "ok" : "limited"}>
                  {(a.directionKnownShare * 100).toFixed(0)}%
                </span>
              </span>
              <span>
                <b>Counterparty classified:</b>{" "}
                <span className={a.counterpartyKnownShare > 0.9 ? "ok" : "limited"}>
                  {(a.counterpartyKnownShare * 100).toFixed(0)}%
                </span>
              </span>
              <span>
                <b>Client-facing:</b> {a.clientExecutions.toLocaleString("en-US")}
              </span>
              <span>
                <b>Own risk:</b> {a.propExecutions.toLocaleString("en-US")}
              </span>
              <span>
                <b>With a comparable price:</b> {a.pricedExecutions.toLocaleString("en-US")}
              </span>
            </p>

            {a.derivedInstruments.length > 0 && (
              <>
                <h3>Instruments not in the reference universe ({a.derivedInstruments.length})</h3>
                <p className="note small">
                  Their level is taken from what this file was printing, so price comparisons work.
                  The volatility and traded volume behind the impact model are asset-class defaults
                  rather than observations, so impact-based scores on these instruments are
                  indicative.
                </p>
                <ul className="small">
                  {a.derivedInstruments.slice(0, 8).map((d) => (
                    <li key={d.instrument}>
                      <span className="mono">{d.instrument}</span> — level taken as {d.level}
                    </li>
                  ))}
                  {a.derivedInstruments.length > 8 && (
                    <li className="note">
                      and {a.derivedInstruments.length - 8} more
                    </li>
                  )}
                </ul>
              </>
            )}

            {a.rejected.length > 0 && (
              <>
                <h3>Rejected documents</h3>
                <ul className="small">
                  {a.rejected.slice(0, 8).map((r) => (
                    <li key={r.doc}>
                      Document {r.doc}: {r.reason}
                    </li>
                  ))}
                </ul>
              </>
            )}

            {a.problems.length > 0 && (
              <>
                <h3>Notes on individual documents ({a.problems.length} shown)</h3>
                <ul className="small">
                  {a.problems.slice(0, 8).map((p, i) => (
                    <li key={i}>{p}</li>
                  ))}
                </ul>
              </>
            )}

            <h3>What each metric can do with this data</h3>
            <table>
              <thead>
                <tr>
                  <th>Metric</th>
                  <th>Status</th>
                  <th>Why</th>
                </tr>
              </thead>
              <tbody>
                {a.coverage.map((c) => (
                  <tr key={c.metric}>
                    <td>{c.label}</td>
                    <td className={c.status === "ok" ? "ok" : c.status === "limited" ? "limited" : "warn"}>
                      {c.status}
                    </td>
                    <td className="note" style={{ whiteSpace: "normal", maxWidth: 560 }}>
                      {c.note}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            {a.sampleExecutions.length > 0 && (
              <>
                <h3>Sample of the normalised executions</h3>
                <table>
                  <thead>
                    <tr>
                      <th>Trade</th>
                      <th>Trader</th>
                      <th>Instrument</th>
                      <th>Product</th>
                      <th>Side</th>
                      <th className="n">Notional</th>
                      <th className="n">USD</th>
                      <th>Counterparty</th>
                      <th>Role</th>
                    </tr>
                  </thead>
                  <tbody>
                    {a.sampleExecutions.map((e) => (
                      <tr key={e.exec_id}>
                        <td className="mono">{e.trade_id}</td>
                        <td>{e.trader_name}</td>
                        <td className="mono">{e.instrument_label}</td>
                        <td>{e.product_type}</td>
                        <td>{e.direction > 0 ? "buy" : "sell"}</td>
                        <td className="n">
                          {Math.round(e.notional).toLocaleString("en-US")} {e.currency}
                        </td>
                        <td className="n">${Math.round(e.notional_usd).toLocaleString("en-US")}</td>
                        <td>{e.counterparty_name ?? "-"}</td>
                        <td>{e.trade_role === "prop" ? "own risk" : "client"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </>
            )}

            <button disabled={busy || !a.documentCount} onClick={commit}>
              {busy
                ? "Importing..."
                : append
                  ? `Add to imported ${mode} and make active`
                  : `Import as ${mode} data and make active`}
            </button>
            {committed && (
              <p className="ok">
                {committed.imported.toLocaleString("en-US")} documents imported as {mode} data
                {append ? ` — ${committed.total.toLocaleString("en-US")} in that bucket now` : ""}.
                The view has switched to them and the detection engine has re-run.
                {mode === "synthetic" && (a.taggedCount ?? 0) > 0 ? (
                  <>
                    {" "}
                    <a href="/uat">Open the UAT page</a> for the test case results.
                  </>
                ) : null}
              </p>
            )}
          </fieldset>
        </>
      )}
    </>
  );
}
