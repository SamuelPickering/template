import { renderUatMarkdown, runUat } from "@/lib/testing/uatRun";

export const maxDuration = 120;

/**
 * The UAT results as a downloadable file: markdown for the pack that goes to
 * stakeholders, JSON for anything that wants to consume it.
 */
export async function GET(req: Request) {
  const format = new URL(req.url).searchParams.get("format") ?? "md";
  const report = runUat();
  const stamp = report.generated_at.slice(0, 10);

  if (format === "json") {
    return new Response(JSON.stringify(report, null, 2), {
      headers: {
        "content-type": "application/json",
        "content-disposition": `attachment; filename="UAT-results-${stamp}.json"`,
      },
    });
  }

  return new Response(renderUatMarkdown(report), {
    headers: {
      "content-type": "text/markdown; charset=utf-8",
      "content-disposition": `attachment; filename="UAT-results-${stamp}.md"`,
    },
  });
}
