import {
  dataStamp,
  loadCounterparties,
  loadDocuments,
  loadEvents,
  loadInstruments,
  loadMarketDaily,
  loadTraders,
} from "@/lib/db/repo";
import { MarketData } from "@/lib/models/market";
import { MarketImpactModel } from "@/lib/models/mim";
import { byInstrument } from "@/lib/models/instruments";
import { discoverInstruments } from "@/lib/models/discover";
import { adaptAll } from "@/lib/schema/adapt";
import { METRICS, type FullConfig, type MetricId } from "@/lib/config/metrics";
import {
  configHash,
  getConfig,
  getDataset,
  overridesForDataset,
  type Dataset,
} from "@/lib/config/store";
import type { DetectionContext, Detector, Instance } from "./types";
import type { OrderStream } from "@/lib/types";

import { detectRamping } from "./ramping";
import { detectWashTrading } from "./washTrading";
import { detectFrontRunning, detectInternalFrontRunning } from "./frontRunning";
import { detectInsiderTrading } from "./insiderTrading";
import { detectBangingTheClose } from "./bangingTheClose";
import { detectCrossTrading } from "./crossTrading";
import { detectOffMarket } from "./offMarket";
import { detectSpoofing } from "./spoofing";
import { detectLayering } from "./layering";
import { detectBestExecution } from "./bestExecution";

const DETECTORS: Record<MetricId, Detector> = {
  insider_trading: detectInsiderTrading,
  front_running: detectFrontRunning,
  internal_front_running: detectInternalFrontRunning,
  ramping: detectRamping,
  banging_the_close: detectBangingTheClose,
  wash_trading: detectWashTrading,
  cross_trading: detectCrossTrading,
  off_market_trading: detectOffMarket,
  spoofing: detectSpoofing,
  layering: detectLayering,
  best_execution: detectBestExecution,
};

const MAX_INSTANCES_PER_METRIC = 750;

export interface MetricStats {
  metric: MetricId;
  label: string;
  instances: number;
  alerts: number;
  threshold: number;
  usd_total: number;
  usd_over_threshold: number;
  top_usd: number;
}

export interface RunResult {
  dataset: Dataset;
  config_hash: string;
  computed_at: string;
  data_fingerprint: string;
  documents: number;
  executions: number;
  orders: number;
  /** Documents the adapters could not fully use, with the reason. */
  adapter_problems: string[];
  instances: Instance[];
  alerts: Instance[];
  stats: MetricStats[];
}

/* ------------------------- context ------------------------- */

let ctxCache: { key: string; ctx: DetectionContext } | null = null;

function dataFingerprint(dataset: Dataset): string {
  const docs = loadDocuments(dataset);
  const last = docs.length ? docs[docs.length - 1].doc_id : "none";
  // The field mappings are part of the input: changing which counterparty
  // codes count as clients changes what the detectors see.
  const ov = JSON.stringify(overridesForDataset(dataset) ?? {});
  // dataStamp() is what catches a file being replaced by one the same size in
  // documents - a corrected re-import, most often.
  return `${dataset}:${docs.length}:${last}:${loadEvents().length}:${loadInstruments().length}:${ov}:${dataStamp()}`;
}

export function buildContext(dataset: Dataset): DetectionContext & { problems: string[] } {
  const key = dataFingerprint(dataset);
  const cached = ctxCache as (DetectionContext & { problems: string[] }) | null;
  if (ctxCache && ctxCache.key === key) {
    return ctxCache.ctx as DetectionContext & { problems: string[] };
  }
  void cached;

  const instruments = loadInstruments();
  const marketRows = loadMarketDaily();
  let market = new MarketData(instruments, marketRows);
  const events = loadEvents();
  market.setEvents(events);

  const traders = new Map(loadTraders().map((t) => [t.trader_id, t]));
  const docs = loadDocuments(dataset);
  const { executions, orders, problems } = adaptAll(docs, {
    usdRate: (ccy, ms) => market.usdRate(ccy, ms),
    traders,
    counterparties: new Map(loadCounterparties().map((c) => [c.counterparty_code, c])),
    overrides: overridesForDataset(dataset),
  });

  // Imported data routinely references instruments the local universe has
  // never seen. Derive reference data for those from the file itself rather
  // than comparing their prices against a level of 1.
  const derived = discoverInstruments(
    executions,
    orders,
    new Set(instruments.map((i) => i.instrument)),
  );
  if (derived.length) {
    market = new MarketData([...instruments, ...derived], marketRows);
    market.setEvents(events);
    problems.unshift(
      `${derived.length} instrument${derived.length > 1 ? "s" : ""} not in the reference universe — ` +
        `level taken from the file, volatility and ADTV assumed for the asset class ` +
        `(${derived.slice(0, 4).map((d) => d.instrument).join(", ")}${derived.length > 4 ? ", ..." : ""})`,
    );
  }

  const mim = new MarketImpactModel(market, executions);
  const ordersByInstrument = new Map<string, OrderStream[]>();
  for (const o of orders) {
    const arr = ordersByInstrument.get(o.instrument);
    if (arr) arr.push(o);
    else ordersByInstrument.set(o.instrument, [o]);
  }

  const ctx: DetectionContext & { problems: string[] } = {
    executions,
    byInstrument: byInstrument(executions),
    orders,
    ordersByInstrument,
    events,
    market,
    mim,
    traders,
    execById: new Map(executions.map((e) => [e.exec_id, e])),
    docById: new Map(docs.map((d) => [d.doc_id, d])),
    problems,
  };
  ctxCache = { key, ctx };
  return ctx;
}

/* ------------------------- run ------------------------- */

const memCache = new Map<string, RunResult>();

export function runAnalysis(opts?: { config?: FullConfig; dataset?: Dataset }): RunResult {
  const dataset = opts?.dataset ?? getDataset();
  const cfg = opts?.config ?? getConfig();
  const hash = configHash(cfg);
  const fingerprint = dataFingerprint(dataset);
  const runKey = `${fingerprint}|${hash}`;

  const hit = memCache.get(runKey);
  if (hit) return hit;

  const ctx = buildContext(dataset);
  const instances: Instance[] = [];
  const alerts: Instance[] = [];
  const stats: MetricStats[] = [];

  for (const def of METRICS) {
    const params = cfg[def.id];
    const threshold = params.threshold_usd_value ?? 0;
    let found: Instance[] = [];
    try {
      found = DETECTORS[def.id](ctx, params);
    } catch (err) {
      console.error(`[detect] ${def.id} failed`, err);
    }
    found.sort((a, b) => b.usd_value - a.usd_value);
    const kept = found.slice(0, MAX_INSTANCES_PER_METRIC);
    const metricAlerts = kept.filter((i) => i.usd_value > threshold);
    instances.push(...kept);
    alerts.push(...metricAlerts);
    stats.push({
      metric: def.id,
      label: def.label,
      instances: found.length,
      alerts: metricAlerts.length,
      threshold,
      usd_total: metricAlerts.reduce((s, i) => s + i.usd_value, 0),
      usd_over_threshold: metricAlerts.reduce(
        (s, i) => s + Math.max(0, i.usd_value - threshold),
        0,
      ),
      top_usd: kept.length ? kept[0].usd_value : 0,
    });
  }

  alerts.sort((a, b) => b.usd_value - a.usd_value);

  const result: RunResult = {
    dataset,
    config_hash: hash,
    computed_at: new Date().toISOString(),
    data_fingerprint: fingerprint,
    documents: ctx.docById.size,
    executions: ctx.executions.length,
    orders: ctx.orders.length,
    adapter_problems: ctx.problems,
    instances,
    alerts,
    stats,
  };

  memCache.set(runKey, result);
  if (memCache.size > 12) {
    const oldest = memCache.keys().next().value;
    if (oldest) memCache.delete(oldest);
  }
  return result;
}

export function invalidateAnalysis() {
  memCache.clear();
  ctxCache = null;
}

/** Which abuse types each trader currently has alerts for. */
export function abuseByTrader(run: RunResult): Map<string, Set<MetricId>> {
  const m = new Map<string, Set<MetricId>>();
  for (const a of run.alerts) {
    const set = m.get(a.trader_id) ?? new Set<MetricId>();
    set.add(a.metric);
    m.set(a.trader_id, set);
  }
  return m;
}

/** Which alerts each execution appears in, for highlighting the blotter. */
export function alertsByExecution(run: RunResult): Map<string, Instance[]> {
  const m = new Map<string, Instance[]>();
  for (const a of run.alerts) {
    for (const id of a.exec_ids) {
      const arr = m.get(id);
      if (arr) arr.push(a);
      else m.set(id, [a]);
    }
  }
  return m;
}
