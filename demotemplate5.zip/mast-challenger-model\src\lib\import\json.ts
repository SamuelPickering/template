import type {
  DataSource,
  Execution,
  ImportOverrides,
  OrderStream,
  ProductFamily,
  SourceDocument,
} from "@/lib/types";
import type { MetricId } from "@/lib/config/metrics";
import { METRICS } from "@/lib/config/metrics";
import { adaptAll, detectFamily, type AdaptContext } from "@/lib/schema/adapt";
import { HAS_EXECUTION_PRICE } from "@/lib/schema/products";
import { discoverInstruments } from "@/lib/models/discover";

/**
 * Import of extracts.
 *
 * The file is expected to hold Master.Transaction documents in one of the
 * product schemas — Credit, Rates, Fenics order streams or FX — as a JSON
 * array, a single object, an object with a wrapper array inside it, or
 * newline-delimited JSON. The product type can be stated explicitly or
 * detected per document.
 *
 * Nothing is scored on a guess: the preview reports what the adapters could
 * and could not read, and which metrics the data actually supports.
 */
export type ImportFamily = ProductFamily | "auto";

/**
 * Which bucket an imported file lands in, and how its contents are read.
 *
 *   production  a real extract. Nothing in the file is treated as a statement
 *               about what the data is supposed to contain.
 *   synthetic   an engineered test pack. Documents may carry a QA block naming
 *               the test case they belong to, which is read so a UAT report
 *               can match results back to cases.
 *
 * This is stated by whoever is importing rather than sniffed from the file,
 * because the whole value of the distinction is that a file cannot claim to be
 * one or the other on its own.
 */
export type ImportMode = "production" | "synthetic";

export const IMPORT_MODES: { value: ImportMode; label: string; help: string }[] = [
  {
    value: "production",
    label: "Production data",
    help: "A real extract. Any QA markers in the file are ignored, and the data is kept in its own bucket apart from every synthetic trade.",
  },
  {
    value: "synthetic",
    label: "Synthetic test data",
    help: "Engineered trades, for test cases and demonstrations. A QA.TestCase marker on a document is read, so the UAT page can tie each alert back to the case that planted it.",
  },
];

export const BUCKET_OF_MODE: Record<ImportMode, DataSource> = {
  production: "imported_production",
  synthetic: "imported_synthetic",
};

const DOC_PREFIX_OF_MODE: Record<ImportMode, string> = {
  production: "IMP",
  synthetic: "SIM",
};

/** The optional envelope a generated test pack carries. */
export interface TestPackEnvelope {
  name: string;
  version: number | null;
  generated: string | null;
  notes: string[];
  overrides: ImportOverrides | null;
}

export interface ParsedImport {
  documents: Record<string, unknown>[];
  /** Problems with the file itself, as opposed to individual documents. */
  errors: string[];
  format: "array" | "object" | "ndjson" | "wrapped";
  /** Present when the file declares itself a test pack. */
  pack?: TestPackEnvelope;
}

const WRAPPER_KEYS = ["transactions", "Transactions", "data", "records", "items", "results"];
const PACK_KEYS = ["TestPack", "testPack", "testpack"];

/**
 * A test pack states its own name and, where the schema cannot carry it, how
 * its counterparty codes should be read — the product schemas have no field
 * that separates a client from a dealer, and Front Running and Best Execution
 * both need that split. Honoured only when the import is declared synthetic.
 */
function readPack(obj: Record<string, unknown>): TestPackEnvelope | undefined {
  const key = PACK_KEYS.find((k) => obj[k] && typeof obj[k] === "object");
  if (!key) return undefined;
  const p = obj[key] as Record<string, unknown>;
  const pick = (a: string, b: string) => p[a] ?? p[b];
  const ov = pick("Overrides", "overrides") as Record<string, unknown> | undefined;
  const patterns = (v: unknown): string[] | undefined =>
    Array.isArray(v) ? v.filter((x): x is string => typeof x === "string") : undefined;
  const str = (v: unknown) => (typeof v === "string" && v.trim() ? v.trim() : undefined);
  const overrides: ImportOverrides | null = ov
    ? {
        client_patterns: patterns(ov.client_patterns),
        dealer_patterns: patterns(ov.dealer_patterns),
        side_path: str(ov.side_path),
        trader_name_path: str(ov.trader_name_path),
        book_path: str(ov.book_path),
      }
    : null;
  const rawNotes = pick("Notes", "notes");
  const name = pick("Name", "name");
  const version = pick("Version", "version");
  const generated = pick("Generated", "generated");
  return {
    name: typeof name === "string" ? name : "test pack",
    version: typeof version === "number" ? version : null,
    generated: typeof generated === "string" ? generated : null,
    notes: Array.isArray(rawNotes)
      ? rawNotes.filter((x): x is string => typeof x === "string")
      : [],
    overrides,
  };
}

export function parseImport(text: string): ParsedImport {
  const trimmed = text.replace(/^﻿/, "").trim();
  if (!trimmed) return { documents: [], errors: ["The file is empty."], format: "array" };

  // Straight JSON first.
  try {
    const parsed = JSON.parse(trimmed) as unknown;
    if (Array.isArray(parsed)) {
      return { documents: parsed as Record<string, unknown>[], errors: [], format: "array" };
    }
    if (parsed && typeof parsed === "object") {
      const obj = parsed as Record<string, unknown>;
      const pack = readPack(obj);
      for (const key of WRAPPER_KEYS) {
        if (Array.isArray(obj[key])) {
          return {
            documents: obj[key] as Record<string, unknown>[],
            errors: [],
            format: "wrapped",
            pack,
          };
        }
      }
      return { documents: [obj], errors: [], format: "object", pack };
    }
  } catch {
    // fall through to newline-delimited
  }

  const docs: Record<string, unknown>[] = [];
  const errors: string[] = [];
  const lines = trimmed.split(/\r?\n/);
  lines.forEach((line, i) => {
    const l = line.trim();
    if (!l) return;
    try {
      const v = JSON.parse(l) as unknown;
      if (v && typeof v === "object") docs.push(v as Record<string, unknown>);
    } catch {
      if (errors.length < 10) errors.push(`Line ${i + 1} is not valid JSON.`);
    }
  });
  if (!docs.length) {
    errors.unshift("Could not read the file as JSON or as newline-delimited JSON.");
  }
  return { documents: docs, errors, format: "ndjson" };
}

export interface CoverageRow {
  metric: MetricId;
  label: string;
  status: "ok" | "limited" | "unavailable";
  note: string;
}

export interface ImportAnalysis {
  documentCount: number;
  /** Documents carrying a QA.TestCase marker. Synthetic imports only. */
  taggedCount: number;
  /** Distinct test cases those markers name. */
  testCases: string[];
  byFamily: Record<string, number>;
  executions: number;
  orders: number;
  /** Documents that produced nothing usable, with the reason. */
  rejected: { doc: number; reason: string }[];
  problems: string[];
  directionKnownShare: number;
  counterpartyKnownShare: number;
  clientExecutions: number;
  propExecutions: number;
  pricedExecutions: number;
  dateRange: [string, string] | null;
  /** Instruments not in the reference universe, whose data had to be derived. */
  derivedInstruments: { instrument: string; level: number }[];
  coverage: CoverageRow[];
  sampleExecutions: Execution[];
  sampleOrders: OrderStream[];
}

/** The test case a pack document declares, if any. */
function qaTag(payload: Record<string, unknown>): string | null {
  const qa = payload.QA;
  if (!qa || typeof qa !== "object") return null;
  const q = qa as Record<string, unknown>;
  const v = q.TestCase ?? q.testCase;
  return typeof v === "string" && v.trim() ? v.trim() : null;
}

export function toSourceDocuments(
  parsed: ParsedImport,
  family: ImportFamily,
  mode: ImportMode = "production",
  /** Documents already in the bucket, when appending rather than replacing. */
  startIndex = 0,
): { documents: SourceDocument[]; rejected: { doc: number; reason: string }[] } {
  const documents: SourceDocument[] = [];
  const rejected: { doc: number; reason: string }[] = [];
  const prefix = DOC_PREFIX_OF_MODE[mode];
  parsed.documents.forEach((payload, i) => {
    const detected = family === "auto" ? detectFamily(payload) : family;
    if (!detected) {
      if (rejected.length < 50) {
        rejected.push({
          doc: i + 1,
          reason:
            "could not tell which product this is — no Execution.Economics.Type, Execution.Type or Unit.BusinessUnit",
        });
      }
      return;
    }
    documents.push({
      doc_id: `${prefix}-${String(startIndex + i + 1).padStart(6, "0")}`,
      family: detected,
      source: BUCKET_OF_MODE[mode],
      // Only a declared test pack carries scenario tags, so nothing in a
      // production file can label itself as an expected result.
      scenario_tag: mode === "synthetic" ? qaTag(payload) : null,
      payload,
    });
  });
  return { documents, rejected };
}

export function analyseImport(
  documents: SourceDocument[],
  rejected: { doc: number; reason: string }[],
  ctx: AdaptContext,
  /** Instruments already in the reference universe, supplied by the caller. */
  knownInstruments: Set<string> = new Set(),
): ImportAnalysis {
  const { executions, orders, problems } = adaptAll(documents, ctx);

  const byFamily: Record<string, number> = {};
  for (const d of documents) byFamily[d.family] = (byFamily[d.family] ?? 0) + 1;

  const directionKnown = executions.filter((e) => e.direction_known).length;
  const cpKnown = executions.filter((e) => e.counterparty_kind_known).length;
  const clientExecs = executions.filter((e) => e.trade_role === "client_facilitation").length;
  const propExecs = executions.filter((e) => e.trade_role === "prop").length;
  const priced = executions.filter(
    (e) => HAS_EXECUTION_PRICE[e.product_type] && e.price > 0,
  ).length;
  const dates = executions.map((e) => e.trade_date).sort();

  // Anything the local universe has never seen gets reference data derived
  // from the file. Worth saying out loud: the level is observed, but the
  // volatility and traded volume behind the impact model are assumptions.
  const derived = discoverInstruments(executions, orders, knownInstruments).map((i) => ({
    instrument: i.instrument,
    level: i.base_level,
  }));

  const coverage: CoverageRow[] = METRICS.map((m) => {
    const row = (status: CoverageRow["status"], note: string): CoverageRow => ({
      metric: m.id,
      label: m.label,
      status,
      note,
    });
    switch (m.id) {
      case "spoofing":
      case "layering":
        return orders.length
          ? row("ok", `${orders.length.toLocaleString()} order streams available.`)
          : row(
              "unavailable",
              "No order-level data in this file. Both metrics score order behaviour, not executions — import a Fenics order-stream extract to run them.",
            );
      case "best_execution":
        if (!priced) {
          return row(
            "unavailable",
            "No executions carry a comparable execution price. Bond fills and FX rates do; swaption strikes and CDS upfront points do not.",
          );
        }
        return clientExecs
          ? row("ok", `${priced.toLocaleString()} priced executions, ${clientExecs.toLocaleString()} client-facing.`)
          : row(
              "limited",
              "No counterparty was identifiable as a client, so client detriment cannot be attributed. Add client patterns below, or turn off the client-counterparty requirement to review all fills.",
            );
      case "off_market_trading":
      case "cross_trading":
        return priced
          ? row("ok", `${priced.toLocaleString()} executions carry a comparable price.`)
          : row(
              "unavailable",
              "Needs an execution price to compare against the market. This file carries only strikes, rates or upfront points.",
            );
      case "front_running":
      case "internal_front_running":
        if (!clientExecs || !propExecs) {
          return row(
            "limited",
            "Front running needs both client business and the firm's own risk in the data. Everything here classified the same way — map client and dealer counterparty patterns below to separate them.",
          );
        }
        return row("ok", `${clientExecs.toLocaleString()} client-facing and ${propExecs.toLocaleString()} own-risk executions.`);
      case "insider_trading":
        return row(
          "limited",
          "Runs against the simulation's own event calendar. Positions come from your data; the events do not, so treat the output as illustrative until a real event feed is wired in.",
        );
      default:
        return executions.length
          ? row("ok", `${executions.length.toLocaleString()} executions available.`)
          : row("unavailable", "No usable executions in this file.");
    }
  });

  return {
    documentCount: documents.length,
    taggedCount: documents.filter((d) => d.scenario_tag).length,
    testCases: [...new Set(documents.map((d) => d.scenario_tag).filter((t): t is string => !!t))].sort(),
    byFamily,
    executions: executions.length,
    orders: orders.length,
    rejected,
    problems,
    directionKnownShare: executions.length ? directionKnown / executions.length : 0,
    counterpartyKnownShare: executions.length ? cpKnown / executions.length : 0,
    clientExecutions: clientExecs,
    propExecutions: propExecs,
    pricedExecutions: priced,
    dateRange: dates.length ? [dates[0], dates[dates.length - 1]] : null,
    derivedInstruments: derived,
    coverage,
    sampleExecutions: executions.slice(0, 6),
    sampleOrders: orders.slice(0, 3),
  };
}

/** Fields an import can point at when the schema does not carry them. */
export const OVERRIDE_FIELDS: {
  key: keyof ImportOverrides;
  label: string;
  help: string;
  kind: "path" | "patterns";
}[] = [
  {
    key: "side_path",
    label: "Side / buy-sell field",
    help: "Path to a field holding Buy/Sell, B/S or +1/-1, e.g. Execution.Side. Only needed if your feed does not use signed amounts; by default a negative amount is a sell and a positive amount is a buy.",
    kind: "path",
  },
  {
    key: "trader_name_path",
    label: "Trader name field",
    help: "Path to a display name, e.g. Execution.TraderName. Falls back to the trader ID.",
    kind: "path",
  },
  {
    key: "book_path",
    label: "Book field",
    help: "Path to the book, if it is not at Unit.BookName.",
    kind: "path",
  },
  {
    key: "client_patterns",
    label: "Client counterparty patterns",
    help: "Comma-separated codes or name fragments that identify clients. Front Running and Best Execution both need to know which business was a client's.",
    kind: "patterns",
  },
  {
    key: "dealer_patterns",
    label: "Dealer counterparty patterns",
    help: "Comma-separated codes or name fragments that identify dealers and brokers, where the firm is trading its own risk.",
    kind: "patterns",
  },
];
