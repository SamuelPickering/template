import { loadDocuments } from "@/lib/db/repo";
import { buildContext, runAnalysis } from "@/lib/detect/engine";
import { getConfig } from "@/lib/config/store";
import { METRICS, METRIC_BY_ID, type MetricId } from "@/lib/config/metrics";
import type { Instance } from "@/lib/detect/types";
import type { Execution, OrderStream } from "@/lib/types";
import { type UatCase } from "./uatCases";
import { loadUatCases, loadUatGroups, originOf, type CaseOrigin } from "./uatStore";
import { formatComponentValue } from "./run";

/**
 * The UAT run.
 *
 * Runs the whole detection pipeline against the imported synthetic pack, on
 * its own, and checks each case against what came out. Two kinds of verdict:
 *
 *  - a case expecting an alert passes when the named metric raised one from
 *    that case's trades;
 *  - a case expecting silence passes when *no* metric raised an alert from
 *    them. Not just the named metric — anything firing on data built to be
 *    unremarkable is a false positive and the case fails.
 *
 * The pack is always scored on its own rather than in whatever view happens
 * to be on screen, so the result does not change depending on what else has
 * been loaded. Thresholds are the live ones from the admin page.
 */
export const UAT_DATASET = "imported_synthetic" as const;

export interface UatTradeRow {
  kind: "execution" | "order";
  id: string;
  time: string;
  trader_id: string;
  trader_name: string;
  instrument: string;
  product: string;
  side: string;
  notional_usd: number;
  price: number | null;
  counterparty: string | null;
  role: string;
  /** Orders only: what became of it. */
  outcome: string | null;
  /** Orders only. */
  levels: number | null;
  display_share: number | null;
  life_seconds: number | null;
  /** True where this row is one of the trades an alert was built from. */
  in_alert: boolean;
}

export interface UatAlertRow {
  metric: MetricId;
  label: string;
  instance_id: string;
  usd_value: number;
  threshold: number;
  headline: string;
  explanation: string;
  trader_name: string;
  instrument_label: string;
  components: { label: string; value: string; help: string }[];
  /** False when this is a metric the case did not expect. */
  expected: boolean;
}

export interface UatCaseResult {
  testCase: UatCase;
  /** Whether this case shipped with the project or was written here. */
  origin: CaseOrigin;
  status: "pass" | "fail";
  documents: number;
  executions: number;
  orders: number;
  threshold: number;
  trades: UatTradeRow[];
  alerts: UatAlertRow[];
  /** Alerts of the metric the case is about. */
  targetAlerts: number;
  /** Labels of any other metric that fired on these trades. */
  otherMetrics: string[];
  /**
   * Highest-scoring thing the engine computed for this case's metric that did
   * not clear the threshold. For a negative case this is the evidence that the
   * data was looked at and scored rather than skipped.
   */
  nearMiss: {
    metric: MetricId;
    label: string;
    usd_value: number;
    threshold: number;
    headline: string;
  } | null;
  /** One line saying why the verdict is what it is. */
  verdict: string;
  /**
   * Negative cases: what happens when the check that is supposed to stop this
   * case is relaxed and the pack is scored again. This is what turns "nothing
   * fired" into "nothing fired for the stated reason".
   */
  gateProof: {
    label: string;
    param: string;
    from: number;
    to: number;
    shown: string;
    /** alert = it now alerts; scored = priced but under the threshold. */
    outcome: "alert" | "scored" | "nothing";
    usd_value: number;
    threshold: number;
    headline: string | null;
    note: string;
  } | null;
}

/** Trades in the pack whose marker names a case nobody has described yet. */
export interface UncataloguedGroup {
  tag: string;
  documents: number;
  executions: number;
  orders: number;
  alerts: { metric: MetricId; label: string; usd_value: number }[];
}

export interface UatReport {
  generated_at: string;
  available: boolean;
  pack_documents: number;
  executions: number;
  orders: number;
  total_alerts: number;
  results: UatCaseResult[];
  groups: { name: string; blurb: string; results: UatCaseResult[] }[];
  summary: {
    total: number;
    passed: number;
    failed: number;
    positive: number;
    positivePassed: number;
    negative: number;
    negativePassed: number;
    untagged: number;
  };
  thresholds: { metric: MetricId; label: string; threshold: number }[];
  /**
   * Markers found in the loaded pack with no case written for them. Importing
   * trades is how a new case gets its evidence, so these are the cases waiting
   * to be described rather than an error.
   */
  uncatalogued: UncataloguedGroup[];
}

const sideOfExec = (e: Execution) => (e.direction > 0 ? "buy" : "sell");
const sideOfOrder = (o: OrderStream) => (o.side > 0 ? "bid" : "offer");

function outcomeOf(o: OrderStream): string {
  if (o.filled_amount >= o.placed_amount * 0.999) return "filled";
  if (o.cancelled_unfilled) return "cancelled unfilled";
  if (o.filled_amount > 0) return "part filled";
  return "open";
}

export function runUat(): UatReport {
  const cfg = getConfig();
  const cases = loadUatCases();
  const docs = loadDocuments(UAT_DATASET);
  const thresholds = METRICS.map((m) => ({
    metric: m.id,
    label: m.label,
    threshold: cfg[m.id].threshold_usd_value ?? 0,
  }));
  const thresholdOf = (m: MetricId) => cfg[m].threshold_usd_value ?? 0;

  if (!docs.length) {
    return {
      generated_at: new Date().toISOString(),
      available: false,
      pack_documents: 0,
      executions: 0,
      orders: 0,
      total_alerts: 0,
      results: [],
      groups: [],
      summary: {
        total: cases.length,
        passed: 0,
        failed: 0,
        positive: cases.filter((c) => c.expect === "alert").length,
        positivePassed: 0,
        negative: cases.filter((c) => c.expect === "no_alert").length,
        negativePassed: 0,
        untagged: 0,
      },
      thresholds,
      uncatalogued: [],
    };
  }

  const run = runAnalysis({ config: cfg, dataset: UAT_DATASET });
  const ctx = buildContext(UAT_DATASET);

  // Trades carry their case tag through the adapters, so an alert can be tied
  // back to a case by the ids it was built from.
  const tagOfExec = new Map(ctx.executions.map((e) => [e.exec_id, e.scenario_tag]));
  const tagOfOrder = new Map(ctx.orders.map((o) => [o.order_id, o.scenario_tag]));

  const tagsOf = (a: Instance): Set<string> => {
    const tags = new Set<string>();
    for (const id of a.exec_ids) {
      const t = tagOfExec.get(id);
      if (t) tags.add(t);
    }
    for (const id of a.order_ids) {
      const t = tagOfOrder.get(id);
      if (t) tags.add(t);
    }
    return tags;
  };

  const alertsByTag = new Map<string, Instance[]>();
  const instancesByTag = new Map<string, Instance[]>();
  for (const i of run.instances) {
    for (const tag of tagsOf(i)) {
      (instancesByTag.get(tag) ?? instancesByTag.set(tag, []).get(tag)!).push(i);
    }
  }
  for (const a of run.alerts) {
    for (const tag of tagsOf(a)) {
      (alertsByTag.get(tag) ?? alertsByTag.set(tag, []).get(tag)!).push(a);
    }
  }

  const docsPerTag = new Map<string, number>();
  for (const d of docs) {
    if (!d.scenario_tag) continue;
    docsPerTag.set(d.scenario_tag, (docsPerTag.get(d.scenario_tag) ?? 0) + 1);
  }

  /**
   * Re-scores the pack with one setting opened up, and reports what the case's
   * own metric then makes of its trades.
   */
  const proveGate = (testCase: UatCase): UatCaseResult["gateProof"] => {
    const relax = testCase.relax;
    if (!relax) return null;
    const from = cfg[testCase.metric][relax.param];
    if (from === undefined) return null;
    const relaxed = structuredClone(cfg);
    relaxed[testCase.metric][relax.param] = relax.value;
    const alt = runAnalysis({ config: relaxed, dataset: UAT_DATASET });
    const threshold = relaxed[testCase.metric].threshold_usd_value ?? 0;
    const hit = alt.instances
      .filter((i) => i.metric === testCase.metric && tagsOf(i).has(testCase.id))
      .sort((a, b) => b.usd_value - a.usd_value)[0];

    if (!hit) {
      return {
        label: relax.label,
        param: relax.param,
        from,
        to: relax.value,
        shown: relax.shown,
        outcome: "nothing",
        usd_value: 0,
        threshold,
        headline: null,
        note:
          "Opening this check is not enough on its own — the model still does not price these trades as the behaviour once it is allowed to look at them.",
      };
    }
    const alerted = hit.usd_value > threshold;
    return {
      label: relax.label,
      param: relax.param,
      from,
      to: relax.value,
      shown: relax.shown,
      outcome: alerted ? "alert" : "scored",
      usd_value: hit.usd_value,
      threshold,
      headline: hit.headline,
      note: alerted
        ? "The alert appears. This check, and nothing else, is what kept the case quiet."
        : "The trades are now priced but stay under the threshold, so the check and the scoring agree about them.",
    };
  };

  const results: UatCaseResult[] = cases.map((testCase) => {
    const touching = (alertsByTag.get(testCase.id) ?? []).slice().sort((a, b) => b.usd_value - a.usd_value);
    const idsInAlerts = new Set<string>();
    for (const a of touching) {
      for (const id of a.exec_ids) idsInAlerts.add(id);
      for (const id of a.order_ids) idsInAlerts.add(id);
    }

    const execs = ctx.executions.filter((e) => e.scenario_tag === testCase.id);
    const orders = ctx.orders.filter((o) => o.scenario_tag === testCase.id);

    const trades: UatTradeRow[] = [
      ...orders.map((o) => ({
        kind: "order" as const,
        id: o.order_id,
        time: new Date(o.start_ms).toISOString().replace("T", " ").slice(0, 19),
        trader_id: o.trader_id,
        trader_name: o.trader_name,
        instrument: o.instrument_label,
        product: o.product_type,
        side: sideOfOrder(o),
        notional_usd: o.notional_usd,
        price: o.price_levels[0] ?? null,
        counterparty: null,
        role: "order",
        outcome: outcomeOf(o),
        levels: o.price_levels.length,
        display_share: o.placed_amount ? o.display_amount / o.placed_amount : null,
        life_seconds: (o.end_ms - o.start_ms) / 1000,
        in_alert: idsInAlerts.has(o.order_id),
      })),
      ...execs.map((e) => ({
        kind: "execution" as const,
        id: e.trade_id,
        time: e.event_datetime.replace("T", " ").slice(0, 19),
        trader_id: e.trader_id,
        trader_name: e.trader_name,
        instrument: e.instrument_label,
        product: e.product_type,
        side: sideOfExec(e),
        notional_usd: e.notional_usd,
        price: e.price || null,
        counterparty: e.counterparty_name,
        role: e.trade_role === "prop" ? "own risk" : "client",
        outcome: null,
        levels: null,
        display_share: null,
        life_seconds: null,
        in_alert: idsInAlerts.has(e.exec_id),
      })),
    ].sort((a, b) => a.time.localeCompare(b.time));

    const alerts: UatAlertRow[] = touching.map((a) => ({
      metric: a.metric,
      label: METRIC_BY_ID[a.metric].label,
      instance_id: a.instance_id,
      usd_value: a.usd_value,
      threshold: thresholdOf(a.metric),
      headline: a.headline,
      explanation: a.explanation,
      trader_name: a.trader_name,
      instrument_label: a.instrument_label,
      components: a.components.map((c) => ({
        label: c.label,
        value: formatComponentValue(c.value, c.unit),
        help: c.help,
      })),
      expected: testCase.expect === "alert" && a.metric === testCase.metric,
    }));

    const targetAlerts = touching.filter((a) => a.metric === testCase.metric).length;
    const otherMetrics = [
      ...new Set(
        touching.filter((a) => a.metric !== testCase.metric).map((a) => METRIC_BY_ID[a.metric].label),
      ),
    ];

    // The best sub-threshold score, which is what shows the engine scored the
    // case rather than never reaching it.
    const belowThreshold = (instancesByTag.get(testCase.id) ?? [])
      .filter((i) => i.usd_value <= thresholdOf(i.metric))
      .sort((a, b) => b.usd_value - a.usd_value);
    const near = belowThreshold.find((i) => i.metric === testCase.metric) ?? belowThreshold[0];
    const nearMiss = near
      ? {
          metric: near.metric,
          label: METRIC_BY_ID[near.metric].label,
          usd_value: near.usd_value,
          threshold: thresholdOf(near.metric),
          headline: near.headline,
        }
      : null;

    const documents = docsPerTag.get(testCase.id) ?? 0;
    const label = METRIC_BY_ID[testCase.metric].label;
    let status: UatCaseResult["status"];
    let verdict: string;

    if (documents === 0) {
      status = "fail";
      verdict = "No trades carrying this case marker are loaded.";
    } else if (testCase.expect === "alert") {
      status = targetAlerts > 0 ? "pass" : "fail";
      verdict =
        targetAlerts > 0
          ? `${label} raised ${targetAlerts} alert${targetAlerts === 1 ? "" : "s"} from these trades.` +
            (otherMetrics.length ? ` Also flagged by ${otherMetrics.join(", ")}.` : "")
          : nearMiss
            ? `No ${label} alert. The best score on these trades was ${Math.round(
                nearMiss.usd_value,
              ).toLocaleString("en-US")} against a threshold of ${Math.round(
                thresholdOf(testCase.metric),
              ).toLocaleString("en-US")}.`
            : `No ${label} alert, and nothing was scored — a gate stopped these trades before they were priced.`;
    } else {
      status = touching.length === 0 ? "pass" : "fail";
      verdict =
        touching.length === 0
          ? nearMiss
            ? `No alert from any metric. ${nearMiss.label} scored these trades at ${Math.round(
                nearMiss.usd_value,
              ).toLocaleString("en-US")}, under its ${Math.round(nearMiss.threshold).toLocaleString("en-US")} threshold.`
            : "No alert from any metric, and nothing was scored — the data never passed the gates."
          : `${touching.length} alert${touching.length === 1 ? "" : "s"} were raised on data that should have stayed quiet: ${[
              ...new Set(touching.map((a) => METRIC_BY_ID[a.metric].label)),
            ].join(", ")}.`;
    }

    return {
      testCase,
      origin: originOf(testCase.id),
      status,
      documents,
      executions: execs.length,
      orders: orders.length,
      threshold: thresholdOf(testCase.metric),
      trades,
      alerts,
      targetAlerts,
      otherMetrics,
      nearMiss,
      verdict,
      gateProof: testCase.expect === "no_alert" ? proveGate(testCase) : null,
    };
  });

  const byId = new Map(results.map((r) => [r.testCase.id, r]));
  const groups = loadUatGroups()
    .map((g) => ({
      name: g.name,
      blurb: g.blurb,
      results: cases.filter((c) => c.group === g.name).map((c) => byId.get(c.id)!),
    }))
    .filter((g) => g.results.length > 0);

  // Markers in the data that no case claims. A new case normally arrives this
  // way round — the trades are imported first, then described.
  const described = new Set(cases.map((c) => c.id));
  const uncatalogued: UncataloguedGroup[] = [];
  const tagsInData = new Set(
    docs.map((d) => d.scenario_tag).filter((t): t is string => !!t && !described.has(t)),
  );
  for (const tag of [...tagsInData].sort()) {
    const hits = (alertsByTag.get(tag) ?? []).sort((a, b) => b.usd_value - a.usd_value);
    uncatalogued.push({
      tag,
      documents: docsPerTag.get(tag) ?? 0,
      executions: ctx.executions.filter((e) => e.scenario_tag === tag).length,
      orders: ctx.orders.filter((o) => o.scenario_tag === tag).length,
      alerts: hits.map((a) => ({
        metric: a.metric,
        label: METRIC_BY_ID[a.metric].label,
        usd_value: a.usd_value,
      })),
    });
  }

  const positive = results.filter((r) => r.testCase.expect === "alert");
  const negative = results.filter((r) => r.testCase.expect === "no_alert");
  const untagged = docs.filter((d) => !d.scenario_tag).length;

  return {
    generated_at: new Date().toISOString(),
    available: true,
    pack_documents: docs.length,
    executions: ctx.executions.length,
    orders: ctx.orders.length,
    total_alerts: run.alerts.length,
    results,
    groups,
    summary: {
      total: results.length,
      passed: results.filter((r) => r.status === "pass").length,
      failed: results.filter((r) => r.status === "fail").length,
      positive: positive.length,
      positivePassed: positive.filter((r) => r.status === "pass").length,
      negative: negative.length,
      negativePassed: negative.filter((r) => r.status === "pass").length,
      untagged,
    },
    thresholds,
    uncatalogued,
  };
}

/* ------------------------------------------------------------------ */
/* Report rendering                                                    */
/* ------------------------------------------------------------------ */

const usd = (v: number) => "$" + Math.round(v).toLocaleString("en-US");
const amt = (v: number) =>
  v >= 1_000_000 ? `${(v / 1_000_000).toFixed(v >= 10_000_000 ? 0 : 1)}m` : `${Math.round(v / 1000)}k`;

export function renderUatMarkdown(report: UatReport): string {
  const L: string[] = [];
  L.push("# Market abuse detection — UAT results");
  L.push("");
  L.push(`Generated: ${report.generated_at}`);
  L.push("");

  if (!report.available) {
    L.push(
      "**The UAT pack is not loaded.** Import `uat/mast-uat-synthetic-trades.json` on the Import page as synthetic test data, then run this again.",
    );
    return L.join("\n");
  }

  const s = report.summary;
  L.push(
    `**${s.passed} of ${s.total} test cases passed** — ${s.positivePassed} of ${s.positive} cases that must raise an alert, ` +
      `and ${s.negativePassed} of ${s.negative} cases that must not.`,
  );
  L.push("");
  L.push(
    `The pack holds ${report.pack_documents} documents, which normalise to ${report.executions} executions and ` +
      `${report.orders} order streams. ${report.total_alerts} alerts were raised across all eleven metrics at the current thresholds.`,
  );
  L.push("");
  L.push(
    "Each case is matched to its results through a QA marker on the documents it planted. No detection engine reads that marker — " +
      "it exists only so this report can be written — so a pass on a positive case means the behaviour was found from trade and order data alone, " +
      "and a pass on a negative case means nothing in the data looked like abuse to the engine.",
  );
  L.push("");

  L.push("## Thresholds this run used");
  L.push("");
  L.push("| Metric | USD Value threshold |");
  L.push("|---|---:|");
  for (const t of report.thresholds) L.push(`| ${t.label} | ${usd(t.threshold)} |`);
  L.push("");

  L.push("## Summary");
  L.push("");
  L.push("| Case | Behaviour | Expected | Result | Alerts | USD Value |");
  L.push("|---|---|---|---|---:|---:|");
  for (const r of report.results) {
    const top = r.alerts.find((a) => a.metric === r.testCase.metric) ?? r.alerts[0];
    L.push(
      `| ${r.testCase.id} | ${r.testCase.title} | ${
        r.testCase.expect === "alert" ? "alert" : "no alert"
      } | ${r.status === "pass" ? "PASS" : "FAIL"} | ${r.alerts.length} | ${
        top ? usd(top.usd_value) : "-"
      } |`,
    );
  }
  L.push("");

  if (report.uncatalogued.length) {
    L.push("## Trades with no case written for them");
    L.push("");
    L.push(
      "Markers found in the loaded pack that no case claims. They are not failures — trades are " +
        "normally imported first and described afterwards — but nothing judges them until a case exists.",
    );
    L.push("");
    L.push("| Marker | Documents | Executions | Orders | Alerts raised |");
    L.push("|---|---:|---:|---:|---|");
    for (const u of report.uncatalogued) {
      L.push(
        `| ${u.tag} | ${u.documents} | ${u.executions} | ${u.orders} | ${
          u.alerts.length
            ? u.alerts.map((a) => `${a.label} ${usd(a.usd_value)}`).join(", ")
            : "none"
        } |`,
      );
    }
    L.push("");
  }

  const proofs = report.results.filter((r) => r.gateProof);
  if (proofs.length) {
    L.push("## What it would take to make the silent cases fire");
    L.push("");
    L.push(
      "Each row re-scores the pack with one setting opened up, so that a case passing on silence can be shown " +
        "to be silent for the stated reason rather than by accident.",
    );
    L.push("");
    L.push("| Case | Setting relaxed | From | To | Result |");
    L.push("|---|---|---:|---:|---|");
    for (const r of proofs) {
      const g = r.gateProof!;
      L.push(
        `| ${r.testCase.id} | ${g.label} | ${g.from} | ${g.shown} | ${
          g.outcome === "alert"
            ? `alerts at ${usd(g.usd_value)}`
            : g.outcome === "scored"
              ? `scored at ${usd(g.usd_value)}, under the ${usd(g.threshold)} threshold`
              : "still nothing"
        } |`,
      );
    }
    L.push("");
  }

  for (const g of report.groups) {
    L.push(`## ${g.name}`);
    L.push("");
    L.push(g.blurb);
    L.push("");
    for (const r of g.results) {
      const c = r.testCase;
      L.push(`### ${c.id} — ${c.title}`);
      L.push("");
      L.push(
        `**${r.status === "pass" ? "PASS" : "FAIL"}** — expected ${
          c.expect === "alert" ? `a ${METRIC_BY_ID[c.metric].label} alert` : "no alert"
        }. ${r.verdict}`,
      );
      L.push("");
      L.push(`- **Metric:** ${METRIC_BY_ID[c.metric].label} (threshold ${usd(r.threshold)})`);
      L.push(`- **Products:** ${c.families.join(", ")}`);
      if (r.origin !== "built-in") {
        L.push(
          `- **Case source:** ${r.origin === "custom" ? "written locally" : "a local edit of the case that ships with the tool"}`,
        );
      }
      const plural = (n: number, one: string, many = `${one}s`) =>
        `${n} ${n === 1 ? one : many}`;
      L.push(
        `- **Trades analysed:** ${plural(r.documents, "document")} — ${plural(
          r.executions,
          "execution",
        )}, ${plural(r.orders, "order stream")}`,
      );
      if (c.tier) L.push(`- **Size:** ${c.tier}`);
      if (c.gate) L.push(`- **Check that should stop it:** ${c.gate}`);
      L.push("");
      L.push(`**What is being tested.** ${c.tests}`);
      L.push("");
      L.push(`**Scenario.** ${c.scenario}`);
      L.push("");
      L.push(`**Why these trades.** ${c.rationale}`);
      L.push("");
      L.push(`**Expected.** ${c.expected}`);
      L.push("");

      L.push("**The trades analysed.**");
      L.push("");
      L.push("| | Id | Time (UTC) | Trader | Instrument | Side | Size | Price | Counterparty | Detail | In alert |");
      L.push("|---|---|---|---|---|---|---:|---:|---|---|---|");
      for (const t of r.trades) {
        const detail =
          t.kind === "order"
            ? `${t.outcome}, ${t.levels} level${t.levels === 1 ? "" : "s"}, ${
                t.display_share !== null ? `${Math.round(t.display_share * 100)}% shown` : ""
              }, ${t.life_seconds?.toFixed(0)}s`
            : t.role;
        L.push(
          `| ${t.kind === "order" ? "order" : "fill"} | ${t.id} | ${t.time} | ${t.trader_name} | ${
            t.instrument
          } | ${t.side} | ${amt(t.notional_usd)} | ${t.price ?? "-"} | ${t.counterparty ?? "-"} | ${detail} | ${
            t.in_alert ? "yes" : "-"
          } |`,
        );
      }
      L.push("");

      if (r.alerts.length) {
        for (const a of r.alerts) {
          L.push(
            `**Alert raised — ${a.label}, ${usd(a.usd_value)}** (threshold ${usd(a.threshold)})${
              a.expected ? "" : " — not the metric this case is about"
            }`,
          );
          L.push("");
          L.push(`> ${a.headline}`);
          L.push("");
          L.push(a.explanation);
          L.push("");
          L.push("| Computed value | Amount |");
          L.push("|---|---:|");
          for (const comp of a.components) L.push(`| ${comp.label} | ${comp.value} |`);
          L.push("");
        }
      } else if (r.nearMiss) {
        L.push(
          `**No alert.** The highest score the engine produced on these trades was ${r.nearMiss.label} at ` +
            `${usd(r.nearMiss.usd_value)}, below its threshold: ${r.nearMiss.headline}`,
        );
        L.push("");
      } else {
        L.push(
          "**No alert, and nothing scored.** The trades were read and normalised but never priced — a gate stopped them first, which is the intended behaviour for this case.",
        );
        L.push("");
      }

      if (r.gateProof) {
        const g = r.gateProof;
        L.push(
          `**Proof the check is what stopped it.** With **${g.label}** moved from ${g.from} to ${g.shown} ` +
            `and the pack scored again: ` +
            (g.outcome === "nothing"
              ? "still nothing."
              : `${METRIC_BY_ID[c.metric].label} scores these trades at ${usd(g.usd_value)} against a ` +
                `${usd(g.threshold)} threshold${g.outcome === "alert" ? " — an alert" : ", below the threshold"}.`) +
            ` ${g.note}`,
        );
        L.push("");
      } else if (c.expect === "no_alert") {
        L.push(
          "**No setting to relax.** This check is structural rather than configurable, so there is no version of the settings under which these trades become this behaviour.",
        );
        L.push("");
      }
    }
  }

  return L.join("\n");
}
