# UAT test cases

Every behaviour this tool claims to detect, and — just as important — the patterns that resemble those behaviours and must not be flagged. The trades for all of them are in `mast-uat-synthetic-trades.json`, which is imported on the Import page as synthetic test data.

13 cases must raise an alert. 18 cases must not. 31 groups of trades, 104 documents in total.

A tool that alerts on everything is as useless as one that alerts on nothing, so each negative case is built to sit one step away from a real pattern and names the single check that should stop it. Results — pass or fail, with the trades that were analysed and the alert text where one was raised — come from the UAT page in the app, or from `npm run uat:report`.

## The cases

| Case | Behaviour | Metric | Expected |
|---|---|---|---|
| UAT-LAYER-01 | Five-rung bid ladder pulled unfilled while the trader sells | Layering | **alert**  |
| UAT-LAYER-02 | Four-rung ladder, just over the threshold | Layering | **alert**  |
| UAT-SPOOF-01 | $50m bid pulled after 18 seconds, $20m sold the other way | Spoofing | **alert**  |
| UAT-SPOOF-02 | $32m offer pulled after 25 seconds, just over the threshold | Spoofing | **alert**  |
| UAT-WASH-01 | $30m bought and sold back to the same internal account in six minutes | Wash Trading | **alert**  |
| UAT-WASH-02 | Round trip disguised as two different CDS tenors | Wash Trading | **alert**  |
| UAT-WASH-03 | $24m round trip, just over the threshold | Wash Trading | **alert**  |
| UAT-FRONT-01 | $20m bought ahead of $60m of client business, sold two minutes after it | Front Running | **alert**  |
| UAT-FRONT-02 | The same pattern in swaptions, not bonds | Front Running | **alert**  |
| UAT-FRONT-03 | $25m exited after $30m of client business, just over the threshold | Front Running | **alert**  |
| UAT-BESTEX-01 | Client filled 30 bps behind the firm's own print 90 seconds earlier | Best Execution | **alert**  |
| UAT-BESTEX-02 | $6m client fill, 26 bps behind, just over the threshold | Best Execution | **alert**  |
| UAT-BESTEX-03 | $40m client fill, 45 bps behind the firm's own print | Best Execution | **alert**  |
| UAT-NEG-WASH-01 | Two completely different bonds, bought and sold at the same moment | Wash Trading | no alert  |
| UAT-NEG-WASH-02 | Position opened in the morning, closed in the afternoon | Wash Trading | no alert  |
| UAT-NEG-WASH-03 | Market making: bought from one client, sold to another | Wash Trading | no alert  |
| UAT-NEG-WASH-04 | Partial hedge against an internal book | Wash Trading | no alert  |
| UAT-NEG-FRONT-01 | Own-account trade six hours after the client business | Front Running | no alert  |
| UAT-NEG-FRONT-02 | Client business on the other side of the market | Front Running | no alert  |
| UAT-NEG-FRONT-03 | No position held before the client business | Front Running | no alert  |
| UAT-NEG-SPOOF-01 | Large bid pulled, nothing executed the other way | Spoofing | no alert  |
| UAT-NEG-SPOOF-02 | The large order actually traded | Spoofing | no alert  |
| UAT-NEG-SPOOF-03 | The order rested for eleven minutes | Spoofing | no alert  |
| UAT-NEG-SPOOF-04 | The order was hidden, not displayed | Spoofing | no alert  |
| UAT-NEG-LAYER-01 | One order re-posted five times at the same price | Layering | no alert  |
| UAT-NEG-LAYER-02 | A ladder that mostly traded | Layering | no alert  |
| UAT-NEG-LAYER-03 | A ladder standing well away from the touch | Layering | no alert  |
| UAT-NEG-BESTEX-01 | The client got the better price | Best Execution | no alert  |
| UAT-NEG-BESTEX-02 | Fifteen basis points behind — inside the materiality floor | Best Execution | no alert  |
| UAT-NEG-BESTEX-03 | A $200k client fill, well behind the print | Best Execution | no alert  |
| UAT-CLEAN-01 | A day of ordinary two-way business across three product families | Wash Trading | no alert  |

## Layering

A ladder of orders across several price levels on one side of the book, pulled together without trading, while the genuine execution goes the other way.

### UAT-LAYER-01 — Five-rung bid ladder pulled unfilled while the trader sells

**Expected result:** a Layering alert. **Products:** fenics. **Size:** significant.

**What is being tested.** That a ladder of orders across several price levels is detected from order data alone, scored on the depth it appeared to add, and reported separately from spoofing.

**Scenario.** One trader places five bids on the same bond within about a minute, at five successive prices from the touch downwards, $12m each and fully displayed. Two are amended to walk the price in. All five are cancelled 20 to 40 seconds after being placed, with no fills. While the ladder stands, the same trader sells $20m of the same bond to a dealer.

**Why these trades.** Five rungs is the smallest ladder that is unambiguously a ladder — it clears the four-level floor with one to spare, so the case does not pass on a rounding accident. $12m a rung matters as much as the total: each individual order is too small to score as a spoof on its own, so the only way this becomes an alert is if the engine assembles the five orders into one ladder. The sell is what gives the ladder a purpose; without it there is nothing the ladder could have benefited.

**Expected.** A Layering alert naming five orders across five price levels, a 100% cancel ratio, an average life under a minute, and the $20m sell as the execution on the other side. No Spoofing alert, because no single rung is large enough to score.

### UAT-LAYER-02 — Four-rung ladder, just over the threshold

**Expected result:** a Layering alert. **Products:** fenics. **Size:** barely.

**What is being tested.** That the minimum shape of a ladder — four price levels, the configured floor — is still caught, and that it scores close to the threshold rather than far above it.

**Scenario.** Four bids at four prices, $6m each, placed over 30 seconds and all cancelled within 25 seconds, against a $20m sell on the other side. Deliberately sized to land just above the threshold, which is what shows the threshold is doing real work rather than letting everything through.

**Why these trades.** The four-level floor is the single most important setting on this metric, because it is what separates a ladder from a trader legitimately working one order at a couple of prices. This case sits exactly on that floor, so if the floor is ever raised to five this case is the one that stops alerting — which is the behaviour an analyst should be able to predict from the admin page.

**Expected.** A Layering alert with four price levels and a USD Value a short way above the Layering threshold.

## Spoofing

One large, fully visible order placed at the touch and pulled within seconds, while the trader executes on the opposite side.

### UAT-SPOOF-01 — $50m bid pulled after 18 seconds, $20m sold the other way

**Expected result:** a Spoofing alert. **Products:** fenics. **Size:** significant.

**What is being tested.** That a single large, fully displayed order placed at the touch, pulled quickly without trading, while the trader executes in the opposite direction, is detected from order data.

**Scenario.** A trader places one $50m bid on a bond at the prevailing level, all of it displayed, and cancels it 18 seconds later with nothing filled. Nine seconds into its life, the same trader sells $20m of the same bond to a dealer.

**Why these trades.** Every element is there because a gate depends on it: the size and the display make the order worth seeing, sitting at the touch makes it competitive, the 18-second life makes it implausible as genuine liquidity, the nil fill makes it a decoy rather than a trade, and the sale on the other side is what the decoy was for. Remove any one of them and this should stop being an alert — which is exactly what the four spoofing negative cases do, one gate at a time.

**Expected.** A Spoofing alert quoting the order notional, 100% displayed, the order life, nil fills, and the $20m executed the other way, with the Narrative beating the Counter-Narrative comfortably. No Layering alert, because there is only one order.

### UAT-SPOOF-02 — $32m offer pulled after 25 seconds, just over the threshold

**Expected result:** a Spoofing alert. **Products:** fenics. **Size:** barely.

**What is being tested.** That the same pattern at a size where the decoy's own risk of being filled starts to matter still clears the threshold, and only just.

**Scenario.** A $32m offer at the touch, fully displayed, cancelled after 25 seconds, with $16m bought on the other side while it rested. Deliberately sized to land just above the threshold, which is what shows the threshold is doing real work rather than letting everything through.

**Why these trades.** The Counter-Narrative — what it would have cost the trader if the decoy had actually been filled — grows with both the size of the order and how long it rested. At 25 seconds this case carries noticeably more of that cost than the 18-second case, so it tests that the model nets the two readings off against each other rather than just counting the pattern.

**Expected.** A Spoofing alert a short way above the threshold, with a visibly larger Counter-Narrative than UAT-SPOOF-01.

## Wash trading

Offsetting legs that leave no genuine market risk, including the versions disguised behind a different tenor or a different account.

### UAT-WASH-01 — $30m bought and sold back to the same internal account in six minutes

**Expected result:** a Wash Trading alert. **Products:** fenics. **Size:** significant.

**What is being tested.** That a round trip against a related account, with no genuine risk taken in between, is identified and priced on the activity it manufactured.

**Scenario.** A trader buys $30m of a bond from an internal book at 10:02 and sells the same $30m back to that internal book at 10:08, at the same price.

**Why these trades.** This is the textbook case, and it is in the pack as the control for the three disguised variants that follow: same instrument, same size, same account, minutes apart. The six-minute gap is the point — it is long enough to look like two separate decisions on a blotter and far too short for any real risk to have been run, which is what the Counter-Narrative measures.

**Expected.** A Wash Trading alert with a relatedness of 1.00 because both legs face an internal account, the full $30m matched, and a Counter-Narrative of almost nothing because the instrument did not move between the legs.

### UAT-WASH-02 — Round trip disguised as two different CDS tenors

**Expected result:** a Wash Trading alert. **Products:** credit. **Size:** major.

**What is being tested.** That tenor normalisation defeats the simplest disguise available in the credit schema — booking the two legs as different contracts on the same curve point.

**Scenario.** $40m of protection bought on a reference entity with the tenor stated as 58M, and $40m sold on the same entity four minutes later with the tenor stated as 61M, both against an internal book. Sized far above the threshold, so it stays an alert even if the threshold is raised several times over.

**Why these trades.** On any blotter these are two different contracts and the round trip is invisible. They are only the same position after the tenor strings have been bucketed onto a standard curve point, which happens in the adapter, before any detector runs. That is the whole argument for normalising first and detecting second, and this case is what proves it happens.

**Expected.** A Wash Trading alert on the bucketed 5Y instrument, with both legs listed against one instrument and the full $40m matched.

### UAT-WASH-03 — $24m round trip, just over the threshold

**Expected result:** a Wash Trading alert. **Products:** fenics. **Size:** barely.

**What is being tested.** That the metric scales with size rather than firing on the pattern alone, and that a smaller round trip lands just above the threshold.

**Scenario.** The same shape as UAT-WASH-01 at $24m, nine minutes apart. Deliberately sized to land just above the threshold, which is what shows the threshold is doing real work rather than letting everything through.

**Why these trades.** Scored on impact rather than on the pattern, a $24m round trip has to come out materially lower than a $30m one — the two together show the score is a function of size and are what make the threshold meaningful. This is also the case to watch when someone asks what the threshold should be: it is the one that disappears first.

**Expected.** A Wash Trading alert at well under half the USD Value of UAT-WASH-01, still above the threshold.

## Front running

A position opened on the firm's own book ahead of the firm's own client business, and exited into the price impact that business creates.

### UAT-FRONT-01 — $20m bought ahead of $60m of client business, sold two minutes after it

**Expected result:** a Front Running alert. **Products:** fenics. **Size:** significant.

**What is being tested.** That a position opened on the firm's own book before the firm's own client flow, and closed into the impact of that flow, is detected and priced on the impact still standing at the exit.

**Scenario.** At 09:58 a trader buys $20m of a bond from a dealer, for the firm's own book. Between 10:12 and 10:18 the same trader buys $60m of the same bond from two clients. At 10:20, two minutes after the last client fill, the trader sells the $20m back to a dealer.

**Why these trades.** The order of events is the evidence, so the data is built to make the order unambiguous: the own-account position exists before the client flow begins, the client flow is large enough to move the instrument, and the exit comes two minutes after it — close enough that most of the modelled impact is still there. Only two client fills are used, which keeps the trader under five executions on the day and stops this from also reading as ramping; that keeps the case about one thing.

**Expected.** A Front Running alert with the position opened before the flow, the two client fills as the impacting business, a two-minute lead time, and a PTC capped at the exit notional.

### UAT-FRONT-02 — The same pattern in swaptions, not bonds

**Expected result:** a Front Running alert. **Products:** rates. **Size:** major.

**What is being tested.** That front running is detected identically in a product with no traded price, no order book and a different schema — which is the test of whether normalising first actually works.

**Scenario.** A trader pays fixed on $200m of a 5Y swaption against a dealer, then executes $600m of client business paying fixed on the same curve point, then receives fixed on $200m eight minutes later. Sized far above the threshold, so it stays an alert even if the threshold is raised several times over.

**Why these trades.** A swaption carries a strike rather than a price, settles against a curve point rather than an ISIN, and arrives in a different Economics shape with its direction in PayOrReceive instead of the sign of the notional. If the detector works here without being told any of that, it is working on the normalised model rather than on the Fenics feed it was first written against. The rates notionals are larger because a swap curve absorbs far more size than a single bond before it moves.

**Expected.** A Front Running alert on the bucketed 5Y curve point, with the impact converted into value terms through duration rather than being read off the rate.

### UAT-FRONT-03 — $25m exited after $30m of client business, just over the threshold

**Expected result:** a Front Running alert. **Products:** fenics. **Size:** barely.

**What is being tested.** That a smaller position exiting into smaller client flow still clears the threshold, and only just.

**Scenario.** A $25m own-account position opened at 11:05, a single $30m client fill at 11:20, and the exit at 11:22. Deliberately sized to land just above the threshold, which is what shows the threshold is doing real work rather than letting everything through.

**Why these trades.** Front running is priced on the impact the client business left standing, so one $30m fill creates far less of it than three $20m fills would. This case is the lower bound of what the metric reports at the default threshold, and it is the one to re-run after any change to the impact model.

**Expected.** A Front Running alert a short way above the threshold, with a single client fill as the impacting business.

## Best execution

A client filled on worse terms than the firm itself was demonstrably achieving moments earlier on the same instrument.

### UAT-BESTEX-01 — Client filled 30 bps behind the firm's own print 90 seconds earlier

**Expected result:** a Best Execution alert. **Products:** fenics. **Size:** significant.

**What is being tested.** That a client filled worse than the firm itself was demonstrably achieving is identified, measured against the firm's own print rather than against a model, and quantified as detriment to the client.

**Scenario.** At 09:30 the firm buys $8m of a bond from a dealer at 99.80. At 09:31:30 it buys $25m of the same bond from a client at 99.50 — the client sold 30 bps lower than the dealer did, 90 seconds apart.

**Why these trades.** The strongest evidence available for this metric is the firm's own contemporaneous print on the same instrument, because there is no argument about what was reachable: the firm reached it itself, a minute and a half earlier, in the same feed. The dealer print is deliberately smaller than the client fill, so no one can argue the client got a worse price for being bigger. The gap is 30 bps against a 25 bps floor, comfortably material but nowhere near the 60 bps that would make this an off-market trade instead.

**Expected.** A Best Execution alert quoting both prices, the 90-second gap, the reference basis as the firm's own print, and a USD Value equal to the detriment applied to the client's $25m.

### UAT-BESTEX-02 — $6m client fill, 26 bps behind, just over the threshold

**Expected result:** a Best Execution alert. **Products:** fenics. **Size:** barely.

**What is being tested.** That a fill one basis point over the materiality floor on a modest notional still reports, and lands just above the threshold.

**Scenario.** A $4m dealer print at 99.76, then a $6m client fill at 99.56 — 26 bps worse, inside the five-minute reference window. Deliberately sized to land just above the threshold, which is what shows the threshold is doing real work rather than letting everything through.

**Why these trades.** This case sits one basis point above the 25 bps materiality floor and only a little above the USD threshold, so it exercises both limits at once. It is the companion to UAT-NEG-BESTEX-02, which is the same shape at 15 bps and must not fire: between them they show exactly where the line is.

**Expected.** A Best Execution alert a short way above the threshold, with a level difference just over 25 bps.

### UAT-BESTEX-03 — $40m client fill, 45 bps behind the firm's own print

**Expected result:** a Best Execution alert. **Products:** fenics. **Size:** major.

**What is being tested.** That detriment scales with the client's notional, so the largest client loses the most and sorts to the top of the queue.

**Scenario.** A $10m dealer print at 100.05, then a $40m client fill at 99.60 — 45 bps worse, two minutes later. Sized far above the threshold, so it stays an alert even if the threshold is raised several times over.

**Why these trades.** Best Execution is the one metric here that measures harm to the client rather than gain to the trader, so what matters most is that the score tracks the size of the harm. Put next to UAT-BESTEX-02 it shows an order of magnitude between a $6m fill 26 bps behind and a $40m fill 45 bps behind, which is the right ordering for a review queue.

**Expected.** A Best Execution alert an order of magnitude above UAT-BESTEX-02, and the largest best execution score in the pack.

## Wash trading — must not fire

Four patterns that resemble a round trip and are not one. Each is stopped by a different check.

### UAT-NEG-WASH-01 — Two completely different bonds, bought and sold at the same moment

**Expected result:** no alert from any metric. **Products:** fenics.

**What is being tested.** That a buy and a sell of the same size at the same moment are not treated as a round trip when they are in different instruments.

**Scenario.** A trader buys $30m of one bond at 10:00:05 and sells $30m of a different bond at 10:00:12, both against the same internal book.

**Why these trades.** This is the most obvious way to produce a false positive: the sizes match, the accounts match, the timestamps are seconds apart, and on a summary screen it looks exactly like a wash. The only thing that makes it legitimate is that the two trades are in different instruments, so no position was closed. If the detector were matching on size and time rather than on a normalised instrument, this is the case that would expose it.

**Expected.** No alert of any kind on either trade.

**The check that should stop it.** Offsetting legs are only ever looked for within one trader, one instrument and one day. Two instruments are never compared against each other.

### UAT-NEG-WASH-02 — Position opened in the morning, closed in the afternoon

**Expected result:** no alert from any metric. **Products:** fenics.

**What is being tested.** That a genuine position held for most of the session and then closed is not a round trip, however exactly the sizes offset.

**Scenario.** A trader buys $30m of a bond from a dealer at 09:15 and sells the same $30m to another dealer at 14:55, five hours and 40 minutes later.

**Why these trades.** Taking a position and closing it later in the day is the ordinary business of a trading book, and the sizes offsetting exactly is normal rather than suspicious — that is what closing a position means. What separates it from a wash is that real market risk was carried for most of a session. The engine's own limit on the gap between legs is what has to catch this, and at five hours and 40 minutes it is nowhere near it.

**Expected.** No alert of any kind.

**The check that should stop it.** The maximum gap between offsetting legs, 30 minutes by default. Beyond it the two trades are never considered as a pair.

### UAT-NEG-WASH-03 — Market making: bought from one client, sold to another

**Expected result:** no alert from any metric. **Products:** fenics.

**What is being tested.** That quoting both sides to clients — buying from one and selling to another within minutes — is not read as a wash, even though the legs offset.

**Scenario.** A trader buys $25m of a bond from one client at 10:00 and sells $25m of the same bond to a different client at 10:08, four basis points higher.

**Why these trades.** This is the single most dangerous false positive in the whole metric, because it is what a market maker does all day: the instrument is the same, the size is the same, the gap is minutes, and the position nets to flat. The difference is that risk genuinely changed hands twice, with two unrelated clients, and the firm earned the spread for it. The engine has to reach that conclusion on its own from the counterparties and the client-facing role, and say so — rather than being told to ignore it.

**Expected.** No alert. The legitimate reading has to come out at least as large as the abusive one, so nothing is even scored.

**The check that should stop it.** Relatedness and the Counter-Narrative. Two unrelated external clients score far below an internal account, and the client-facilitation explanation cancels what is left.

### UAT-NEG-WASH-04 — Partial hedge against an internal book

**Expected result:** no alert from any metric. **Products:** fenics.

**What is being tested.** That a partial offset is not reported as a round trip just because both sides face the same internal account.

**Scenario.** A trader buys $30m of a bond from an internal book at 11:00 and sells $9m of it back five minutes later — 30% of the position, leaving $21m of exposure.

**Why these trades.** Everything that makes UAT-WASH-01 an alert is present here except that the legs do not offset: same instrument, same internal account, five minutes apart. What is missing is the round trip, because 70% of the position is still live and still carrying risk. Without a size-match requirement this case would be indistinguishable from the real thing, which is why the tolerance exists and why it is on the admin page.

**Expected.** No alert of any kind.

**The check that should stop it.** The size match tolerance, 15% by default. $9m against $30m is nowhere near offsetting.

## Front running — must not fire

Three patterns involving both client business and the firm's own risk, none of which is front running.

### UAT-NEG-FRONT-01 — Own-account trade six hours after the client business

**Expected result:** no alert from any metric. **Products:** fenics.

**What is being tested.** That a trade in the same instrument and the same direction as earlier client business is not front running when it happens hours later.

**Scenario.** A trader holds a $20m own-account position from 09:00, fills $60m of client business between 09:25 and 09:35, and sells the $20m at 15:30 — nearly six hours after the last client fill.

**Why these trades.** This is the case the request asked for by name, and it matters because the sequence is identical to UAT-FRONT-01 — position, client flow, exit, all in the right order. The only difference is the gap. Front running is priced on the impact the client business left standing at the moment of the exit, and six hours later there is none: the modelled impact has decayed through roughly twelve half-lives. A tool that flagged this would flag every position a trader ever closed on a day they also served a client.

**Expected.** No alert of any kind.

**The check that should stop it.** The maximum lead time, 15 minutes by default. Client business older than that is not considered as the impacting flow at all.

### UAT-NEG-FRONT-02 — Client business on the other side of the market

**Expected result:** no alert from any metric. **Products:** fenics.

**What is being tested.** That client business in the opposite direction to the trader's own position cannot be the impacting flow, however close in time.

**Scenario.** A trader buys $20m of a bond for the firm's own book at 10:00, then sells $60m of the same bond to clients between 10:05 and 10:09, then sells $28m for the firm's own book at 10:12.

**Why these trades.** The timing here is tighter than in the real case — three minutes rather than two — so timing alone cannot be what saves it. Selling to clients pushes the instrument down, which is the wrong way for someone holding a long position to profit; the trader's own sale is into a market their client business just moved against them. Direction is the substance of this metric, not an incidental field, and this case is what proves it is being read.

**Expected.** No alert of any kind.

**The check that should stop it.** The impacting flow must be in the opposite direction to the exit — in other words, the same direction as the position being held.

### UAT-NEG-FRONT-03 — No position held before the client business

**Expected result:** no alert from any metric. **Products:** fenics.

**What is being tested.** That trading after client business is not front running when the trader was flat beforehand — the position has to pre-date the flow.

**Scenario.** A trader fills $60m of client business between 10:00 and 10:06 holding no position of their own, then sells $20m for the firm's own book at 10:08, two minutes later.

**Why these trades.** Front running requires foreknowledge turned into a position, and a trader who was flat when the client business arrived had nothing in place to benefit. Selling afterwards may be any number of things — hedging the inventory the client business just created, most likely — but it cannot be front running, because there was no earlier position to exit. The two-minute gap is identical to UAT-FRONT-01, so the only difference between an alert and silence here is whether the position existed first.

**Expected.** No alert of any kind.

**The check that should stop it.** The position being exited must have been opened before the client flow began, and must be at least a quarter of the size of the exit.

## Spoofing — must not fire

Four large orders that were pulled, none of which is a decoy. The gates are the order's life, how much of it was visible, whether it traded, and whether anything was executed the other way.

### UAT-NEG-SPOOF-01 — Large bid pulled, nothing executed the other way

**Expected result:** no alert from any metric. **Products:** fenics.

**What is being tested.** That a large order placed and cancelled is not spoofing on its own, with no trade on the opposite side for it to have benefited.

**Scenario.** A $50m bid at the touch, fully displayed, cancelled 20 seconds later with no fills. The trader executes nothing else in that bond all day.

**Why these trades.** Pulling a large order quickly is ordinary: the market moves, a client cancels, a risk limit changes, the price is no longer wanted. What makes it spoofing is that the trader was doing something on the other side that the order's visible weight helped. With nothing on the other side there is no benefit to measure and no reason to suspect anything, and this case is identical to UAT-SPOOF-01 in every other respect.

**Expected.** No alert of any kind.

**The check that should stop it.** There must be an execution in the opposite direction while the order rested, worth at least 15% of the order.

### UAT-NEG-SPOOF-02 — The large order actually traded

**Expected result:** no alert from any metric. **Products:** fenics.

**What is being tested.** That an order that filled is genuine liquidity, whatever else the trader was doing at the time.

**Scenario.** A $50m bid at the touch, fully displayed, which fills completely in two clips over 40 seconds. The trader also sells $20m of the same bond while it is working.

**Why these trades.** A spoof is an order placed with no intention of trading, so an order that traded in full is the clearest possible refutation — the trader took the risk they were displaying. The $20m sale is left in deliberately, so that the opposite-side execution the metric looks for is present and the only thing standing between this case and an alert is the fill.

**Expected.** No alert of any kind.

**The check that should stop it.** The order must have been cancelled with effectively nothing filled. A filled order is never a candidate.

### UAT-NEG-SPOOF-03 — The order rested for eleven minutes

**Expected result:** no alert from any metric. **Products:** fenics.

**What is being tested.** That an order left in the market long enough to be hit is treated as genuine liquidity even if it is eventually pulled unfilled.

**Scenario.** A $50m bid at the touch, fully displayed, cancelled unfilled after 11 minutes. $20m is sold the other way while it rests.

**Why these trades.** Time is the cleanest evidence of intent available in order data. A decoy has to be withdrawn before anyone can trade against it; an order that sits at the touch for eleven minutes was genuinely exposed to being filled for eleven minutes, and the trader carried that risk. Everything else here is identical to UAT-SPOOF-01, including the sale on the other side, so the order's life is doing all the work.

**Expected.** No alert of any kind.

**The check that should stop it.** The maximum order life, 60 seconds by default. Anything resting longer is treated as real liquidity.

### UAT-NEG-SPOOF-04 — The order was hidden, not displayed

**Expected result:** no alert from any metric. **Products:** fenics.

**What is being tested.** That an order the market could not see is not a decoy, because nothing can be misled by it.

**Scenario.** A $50m bid with only $5m displayed — the rest held back — cancelled after 15 seconds, with $20m sold the other way.

**Why these trades.** Spoofing works by being seen. An iceberg showing $5m of $50m is the opposite technique: a trader who wants to buy without moving the price against themselves, which is a legitimate and common way to work a large order. The displayed share is the field that separates the two intentions, and this case is identical to UAT-SPOOF-01 apart from that one number.

**Expected.** No alert of any kind.

**The check that should stop it.** The minimum displayed share, 70% by default. An order showing 10% of its size is not a candidate.

## Layering — must not fire

Three sets of orders on one side of the book that are not ladders built to mislead.

### UAT-NEG-LAYER-01 — One order re-posted five times at the same price

**Expected result:** no alert from any metric. **Products:** fenics.

**What is being tested.** That repeatedly posting at a single price is not a ladder, however many orders it takes.

**Scenario.** Five bids of $12m on the same bond, all at exactly the same price, each resting about 90 seconds before being cancelled, with $20m sold the other way.

**Why these trades.** A trader working one order re-posts it as the book changes around them, which produces several orders on one side of the market in quick succession — the same raw shape as a ladder. What a ladder adds is depth: rungs at successive prices, so the book appears to have weight behind it at several levels. Counting orders would flag this; counting distinct price levels does not. The 90-second lives also keep it clear of the spoofing test, so nothing fires.

**Expected.** No alert of any kind.

**The check that should stop it.** The minimum number of distinct price levels, four by default. Five orders at one price is one level — and the floor cannot be set below two, because a single price can never be a ladder, so no configuration makes this case fire.

### UAT-NEG-LAYER-02 — A ladder that mostly traded

**Expected result:** no alert from any metric. **Products:** fenics.

**What is being tested.** That orders at several price levels are not layering when most of that size actually filled.

**Scenario.** Five bids at five prices, $12m each. Three fill in full, two are cancelled — 40% of the notional cancelled. $20m is sold the other way.

**Why these trades.** Working an order down through several price levels and getting most of it done is a normal way to buy a bond, and it leaves exactly the same footprint as a ladder in everything except the outcome. Layering is characterised by the orders being withdrawn: the appearance of depth is the point, and filling it would defeat the purpose. The cancel ratio is what distinguishes the two, and at 40% this case is well under the 80% the engine requires.

**Expected.** No alert of any kind.

**The check that should stop it.** The cancel ratio threshold, 80% of the ladder's notional by default. This ladder cancelled 40%.

### UAT-NEG-LAYER-03 — A ladder standing well away from the touch

**Expected result:** no alert from any metric. **Products:** fenics.

**What is being tested.** That orders parked away from the market are not layering, because they are not close enough to influence the price.

**Scenario.** Five bids at five prices, $12m each, all cancelled within 30 seconds — but placed six to ten basis points below where the bond was trading, which the same file establishes through a morning of ordinary two-way prints. $20m is sold the other way.

**Why these trades.** Resting orders away from the touch is how traders leave standing interest in the market without being hit: they are visible, they are cancelled constantly, and they are not pretending anything. An order only shifts the apparent balance of the book if it is near the price people are actually trading at. This is the one gate in the metric that depends on knowing where the market was, which is why the pack includes the ordinary prints that establish it.

**Expected.** No alert of any kind.

**The check that should stop it.** The minimum competitiveness, 0.35 by default — a size-weighted measure of how close to the touch the ladder sat.

## Best execution — must not fire

Three client fills that are not detriment: one better than the reference, one inside the materiality floor, one below the size floor.

### UAT-NEG-BESTEX-01 — The client got the better price

**Expected result:** no alert from any metric. **Products:** fenics.

**What is being tested.** That a client filled better than the firm's own contemporaneous print is not detriment, and that the comparison is signed correctly.

**Scenario.** The firm buys $8m of a bond from a dealer at 99.50, then buys $25m from a client at 99.70 — the client sold 20 bps higher than the dealer did.

**Why these trades.** This is the mirror image of UAT-BESTEX-01 and it tests the one thing that is easy to get wrong in both directions: which side of the comparison the client is on. A client who sold wanted the highest price available; a client who bought wanted the lowest. Comparing the two prices without reference to the client's side would flag this case exactly as hard as the real one, which is why it is in the pack.

**Expected.** No alert of any kind. The client was better off, so there is no detriment to measure.

**The check that should stop it.** Detriment is measured on the client's side of the market and must be positive.

### UAT-NEG-BESTEX-02 — Fifteen basis points behind — inside the materiality floor

**Expected result:** no alert from any metric. **Products:** fenics.

**What is being tested.** That a small difference between a client fill and an earlier print is not reported, so the queue is not filled with ordinary spread.

**Scenario.** A $5m dealer print at 99.65, then a $25m client fill at 99.50 — 15 bps worse, 80 seconds later.

**Why these trades.** Two prices on the same bond minutes apart are almost never identical, and the gap between them is usually just the spread, the size difference and the market moving. If every such gap were an alert the metric would be unusable. The floor is where the firm says what counts as material, and this case sits deliberately below it while UAT-BESTEX-02 sits one basis point above — the pair is what demonstrates where the line is.

**Expected.** No alert of any kind.

**The check that should stop it.** The minimum client detriment, 25 bps by default. This fill was 15 bps behind.

### UAT-NEG-BESTEX-03 — A $200k client fill, well behind the print

**Expected result:** no alert from any metric. **Products:** fenics.

**What is being tested.** That a client fill below the size floor is not reported even when the price difference is large.

**Scenario.** An $8m dealer print at 99.80, then a $200k client fill at 99.20 — 60 bps worse, inside the reference window.

**Why these trades.** Small tickets are priced differently and always will be: a $200k fill does not get the price an $8m fill gets, and the difference is the cost of doing a small trade rather than a failure of execution. The size floor is what keeps the review queue pointed at the fills where the money is, and this case checks that the floor is applied before the price comparison rather than after, so a large percentage on a tiny notional cannot climb the queue.

**Expected.** No alert of any kind, from this metric or from Off-Market Trading, which has the same floor.

**The check that should stop it.** The minimum client notional, $250,000 by default.

## Ordinary business

A day of unremarkable two-way trading. Nothing in it should produce an alert of any kind.

### UAT-CLEAN-01 — A day of ordinary two-way business across three product families

**Expected result:** no alert from any metric. **Products:** fenics, credit, rates.

**What is being tested.** That an unremarkable trading day produces no alerts at all — the base case for every other number in this report.

**Scenario.** Fourteen trades on one day across three traders and three product families: bonds bought and sold with clients and dealers an hour or more apart, a CDS position taken and left on, two swaptions at different curve points, and two bond orders that filled normally.

**Why these trades.** Every other case in this pack is engineered, which means they say nothing on their own about what happens to normal business. This case is the control: ordinary sizes, ordinary spacing, two-way flow, real counterparties on both sides, nothing offsetting inside half an hour, nothing cancelled, nothing concentrated into the close. If anything fires here, the false positive rate on real data is not acceptable, and no amount of passing on the engineered cases would make up for it.

**Expected.** No alert from any of the eleven metrics on any of these trades.

**The check that should stop it.** None in particular — the whole engine. This case passes only if every metric stays quiet on ordinary flow.
