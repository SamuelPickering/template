import { fenicsDoc } from "@/lib/gen/docs";
import { dayStartMs } from "@/lib/time";
import type { Instrument } from "@/lib/types";
import { IMPACT_K } from "@/lib/gen/universe";
import {
  UAT_CLIENT_PATTERNS,
  UAT_DEALER_PATTERNS,
  UAT_COUNTERPARTIES,
  UAT_TRADER_NAME_PATH,
} from "./uatPack";

/**
 * A starter file of trades for a new test case.
 *
 * Writing a case is two halves: the description, which the editor handles, and
 * the trades it is judged on, which have to exist in the data. This produces a
 * small, valid, importable file already carrying the case's marker, so the
 * second half starts from something that works rather than from a blank page.
 */
export function starterTrades(caseId: string, traderId = "UAT-NEW-01"): string {
  const trader = { trader_id: traderId, name: traderId, trade_role: "prop" as const };
  const isin = `XS99${caseId.replace(/\D/g, "").padEnd(8, "0").slice(0, 8)}0`.slice(0, 12);
  const instrument: Instrument = {
    instrument: `BOND:${isin}`,
    label: isin,
    family: "fenics",
    currency: "USD",
    price_type: "Price",
    base_level: 100,
    ann_vol: 0.05,
    adtv_usd: 5e8,
    impact_k: IMPACT_K.fenics,
    duration_years: 5,
  };

  // Yesterday, mid-session: clear of the close, and a date the seeded market
  // data does not cover, so the level is derived from these prices alone.
  const day = new Date(Date.now() - 86_400_000).toISOString().slice(0, 10);
  const at = (h: number, m: number) => dayStartMs(day) + ((h * 60 + m) * 60) * 1000;
  const cp = Object.fromEntries(UAT_COUNTERPARTIES.map((c) => [c.counterparty_code, c]));

  const docs = [
    fenicsDoc({
      docId: `${caseId}-O1`,
      trader,
      instrument,
      side: 1,
      limitPrice: 100,
      totalAmount: 30_000_000,
      startMs: at(10, 0),
      fills: [
        { ms: at(10, 0) + 2000, price: 100, amount: 30_000_000, counterparty: cp["INT-DESK"] },
      ],
      scenarioTag: caseId,
    }),
    fenicsDoc({
      docId: `${caseId}-O2`,
      trader,
      instrument,
      side: -1,
      limitPrice: 100,
      totalAmount: 30_000_000,
      startMs: at(10, 6),
      fills: [
        { ms: at(10, 6) + 2000, price: 100, amount: 30_000_000, counterparty: cp["INT-DESK"] },
      ],
      scenarioTag: caseId,
    }),
  ];

  const transactions = docs.map((d) => {
    const payload = JSON.parse(JSON.stringify(d.payload)) as Record<string, unknown>;
    const exec = payload.Execution as Record<string, unknown>;
    exec.TraderName = traderId;
    const unit = payload.Unit as Record<string, unknown>;
    if (unit) unit.BookName = "UAT-NEW-01";
    return { QA: { TestCase: caseId }, ...payload };
  });

  return (
    JSON.stringify(
      {
        TestPack: {
          Name: `Starter trades for ${caseId}`,
          Version: 1,
          Generated: new Date().toISOString(),
          Notes: [
            `Every document here carries QA.TestCase = "${caseId}". That marker is what ties these trades to the case; change it and they belong to a different case.`,
            "As it stands this is a $30m bond bought from an internal book and sold straight back to it six minutes later — a wash trade, scored at about $27,000 against a $15,000 threshold. Import it unchanged and the case passes, which tells you the plumbing works; then edit the amounts, prices, timestamps, sides and counterparties until it is the behaviour your case actually describes.",
            "Counterparty codes: CLT- is treated as a client, DLR- as a dealer, INT- as an internal book. Amounts are signed — negative sells, positive buys.",
            "Import this on the Import page as synthetic test data with \"add to what is already in this bucket\" ticked, so it joins the pack instead of replacing it.",
          ],
          Overrides: {
            client_patterns: UAT_CLIENT_PATTERNS,
            dealer_patterns: UAT_DEALER_PATTERNS,
            trader_name_path: UAT_TRADER_NAME_PATH,
          },
        },
        Transactions: transactions,
      },
      null,
      2,
    ) + "\n"
  );
}
