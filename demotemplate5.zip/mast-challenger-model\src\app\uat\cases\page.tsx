import Link from "next/link";
import { METRICS } from "@/lib/config/metrics";
import { UAT_CASE_BY_ID } from "@/lib/testing/uatCases";
import {
  casesFile,
  deletedCaseIds,
  loadUatCases,
  loadUatGroups,
  originOf,
} from "@/lib/testing/uatStore";
import { runUat } from "@/lib/testing/uatRun";
import { UatCaseEditor } from "@/components/UatCaseEditor";

export const dynamic = "force-dynamic";

export default function UatCasesPage() {
  const report = runUat();

  const catalogue = {
    file: casesFile(),
    cases: loadUatCases().map((c) => ({ ...c, origin: originOf(c.id) })),
    groups: loadUatGroups().map((g) => g.name),
    switchedOff: deletedCaseIds().map((id) => ({
      id,
      title: UAT_CASE_BY_ID[id]?.title ?? id,
    })),
    metrics: METRICS.map((m) => ({
      id: m.id,
      label: m.label,
      params: m.params
        .filter((p) => p.key !== "threshold_usd_value")
        .map((p) => ({ key: p.key, label: p.label, default: p.default, unit: p.unit ?? "" })),
    })),
  };

  return (
    <>
      <h1>Test Cases — edit</h1>
      <p className="note">
        A test case is two halves. The <b>description and the verdict rule</b> live here: what is
        being tested, the scenario, why those trades, and whether the metric must raise an alert or
        must stay silent. The <b>trades</b> live in the data, matched to the case by a{" "}
        <span className="mono">QA.TestCase</span> marker on each document. Changing a description
        never changes a result; changing the expectation or the trades does.
      </p>
      <p className="note small">
        <Link href="/uat">Back to the UAT results</Link>. Nothing here touches the seeded{" "}
        <Link href="/validation">Test Cases</Link>, which describe behaviour engineered into the
        generated population and are part of the code.
      </p>

      <div className="box">
        <b>Adding a case, start to finish</b>
        <ol className="small">
          <li>
            <b>Add the case</b> below — give it an id, say which metric it is about and whether it
            must alert or must stay quiet.
          </li>
          <li>
            <b>Give it trades.</b> Download the starter file the editor offers, edit it into the
            behaviour you are describing, and import it as <i>synthetic test data</i> with{" "}
            <i>add to what is already in this bucket</i> ticked. Any file works as long as each
            document carries <span className="mono">QA.TestCase</span> set to your case id.
          </li>
          <li>
            <b>Open the <Link href="/uat">UAT page</Link>.</b> The case is scored with the rest,
            and appears in the downloadable results.
          </li>
        </ol>
      </div>

      <UatCaseEditor initial={catalogue} uncatalogued={report.uncatalogued} />
    </>
  );
}
