import type { MetricId } from "@/lib/config/metrics";
import type { ProductFamily } from "@/lib/types";

/**
 * The test catalogue.
 *
 * Each case names a behaviour the tool claims to detect, the scenario built
 * into the dataset to exercise it, and what the detector has to produce for
 * the case to pass. Cases are matched to results through the `scenario_tag`
 * carried on the engineered documents — a tag the detection engines never
 * read, so a pass means the engine found the behaviour from trade and order
 * data alone.
 */
export interface TestCase {
  id: string;
  /** scenario_tag on the engineered documents. */
  tag: string;
  /** The metric expected to raise the alert. */
  metric: MetricId;
  title: string;
  tier?: "barely" | "significant" | "major";
  families: ProductFamily[];
  /** The capability being proven. */
  tests: string;
  /** How the data is constructed. */
  scenario: string;
  /** What has to happen for this to pass. */
  expected: string;
  /** What the resulting alert must be able to show an investigator. */
  evidence: string;
}

const TIER_NOTE: Record<string, string> = {
  barely:
    "Sized to land just above the default threshold, so it proves the threshold is doing real work rather than letting everything through.",
  significant: "Sized well above the threshold — a clear case an analyst would pick up first.",
  major:
    "Sized far above the threshold, and should remain an alert even if the threshold is raised several times over.",
};

export const TEST_CASES: TestCase[] = [
  /* ---------------- Ramping ---------------- */
  ...(["barely", "significant", "major"] as const).map((tier, i) => ({
    id: `TC-RAMP-0${i + 1}`,
    tag: `ramping_${tier}`,
    metric: "ramping" as MetricId,
    title: `Ramping — ${tier} above threshold`,
    tier,
    families: ["credit", "rates", "fenics", "fx"] as ProductFamily[],
    tests:
      "That a run of aggressive same-direction trading followed by a reversal is priced on the impact it created, across all four product families.",
    scenario:
      "One trader buys (or sells) the same instrument five to eight times over roughly half an hour, all in the same direction and with no offsetting flow, then reverses the whole position in two or three clips four to eighteen minutes after the last build trade. Built once per product family. " +
      TIER_NOTE[tier],
    expected:
      "A Ramping alert on the synthetic instrument, with the reversal matched back to the build phase by the allocation algorithm and USD Value above the Ramping threshold.",
    evidence:
      "EMI as the cumulative modelled impact at the moment of reversal, PTC as the notional reversed out, the build and reversal trades listed separately, and the impact curve showing the push and the exit into it.",
  })),

  /* ---------------- Wash trading ---------------- */
  ...(["barely", "significant", "major"] as const).map((tier, i) => ({
    id: `TC-WASH-0${i + 1}`,
    tag: `wash_${tier}`,
    metric: "wash_trading" as MetricId,
    title: `Wash trading — ${tier} above threshold`,
    tier,
    families: ["credit", "rates", "fenics", "fx"] as ProductFamily[],
    tests:
      "That a round trip with no genuine risk transfer is caught and priced, in every product family.",
    scenario:
      "A trader opens a position and reverses it within one to nine minutes at near-identical size, both legs booked against the same internal account. Built once per product family. " +
      TIER_NOTE[tier],
    expected:
      "A Wash Trading alert where the Narrative (manufactured activity) exceeds the Counter-Narrative (genuine market risk run between the legs).",
    evidence:
      "Narrative and Counter-Narrative side by side, the matched notional, the gap between the legs, the price move over that gap, and a relatedness score reflecting the internal counterparty.",
  })),
  {
    id: "TC-WASH-04",
    tag: "wash_cross_tenor",
    metric: "wash_trading",
    title: "Wash trading disguised across tenors",
    families: ["credit"],
    tests:
      "That tenor normalisation defeats the simplest disguise: booking the two legs as different contracts on the same curve point.",
    scenario:
      "A credit round trip where one leg states a tenor of 58 months and the other 61 months. On any blotter they are two different contracts; both bucket onto the same five-year point.",
    expected:
      "A Wash Trading alert on the bucketed instrument. The legs only meet after the tenor strings have been normalised onto a standard curve point.",
    evidence:
      "Both legs listed against one instrument, with the matched notional showing they fully offset.",
  },
  {
    id: "TC-WASH-05",
    tag: "wash_cross_product",
    metric: "wash_trading",
    title: "Wash trading disguised across products",
    families: ["rates"],
    tests:
      "That a round trip split across two different product types on the same curve point is still seen as one offset.",
    scenario:
      "A swaption in one direction and a cap in the other, same curve point, same size, minutes apart, both against an internal account. Neither product's own blotter shows a round trip.",
    expected:
      "A Wash Trading alert naming both product types, found with the default 'require same product type' setting off.",
    evidence:
      "A 'cross-product wash' variant label and the two product types listed in the components.",
  },
  {
    id: "TC-WASH-06",
    tag: "wash_multi_counterparty",
    metric: "wash_trading",
    title: "Wash trading spread across related accounts",
    families: ["credit", "rates", "fenics", "fx"],
    tests:
      "That an offset broken into pieces across several related accounts is still assembled into one round trip.",
    scenario:
      "An opening leg, then two half-size opposite legs booked to two different internal accounts within minutes. No single account shows a complete round trip.",
    expected:
      "A Wash Trading alert that accumulates the offsetting legs until they cover the anchor, labelled as a multi-counterparty wash.",
    evidence: "All three legs listed, the counterparties named, and the matched notional.",
  },
  {
    id: "TC-WASH-07",
    tag: "wash_cross_currency",
    metric: "wash_trading",
    title: "Wash trading disguised across currency pairs",
    families: ["fx"],
    tests:
      "That splitting an FX round trip across two different pairs does not hide it, because both legs map onto the same synthetic instrument.",
    scenario:
      "A currency is bought against one cross and sold against another within minutes, same size, both against an internal account.",
    expected:
      "A Wash Trading alert on the CCY/USD instrument, labelled as a cross-currency wash.",
    evidence: "The two different headline pairs named, both resolving to one instrument.",
  },

  /* ---------------- Front running ---------------- */
  ...(["barely", "significant", "major"] as const).map((tier, i) => ({
    id: `TC-FRONT-0${i + 1}`,
    tag: `front_running_${tier}`,
    metric: "front_running" as MetricId,
    title: `Front running — ${tier} above threshold`,
    tier,
    families: ["credit", "rates", "fenics", "fx"] as ProductFamily[],
    tests:
      "That a proprietary position opened ahead of the firm's own client flow, and exited into the impact of that flow, is detected and priced.",
    scenario:
      "A trader opens a position on their own book, then fills two to four client orders in the same instrument and direction, then closes the position one and a half to five minutes after the last client fill. Built once per product family. " +
      TIER_NOTE[tier],
    expected:
      "A Front Running alert where the residual impact of the client flow at the moment of the exit drives EMI, and the exit notional drives PTC.",
    evidence:
      "The position opened before the client flow, the client fills themselves, the exit, the lead time, and the portion of the exit the allocation algorithm ties back to the opening trades.",
  })),
  {
    id: "TC-FRONT-04",
    tag: "internal_front_running",
    metric: "internal_front_running",
    title: "Internal front running across books",
    families: ["credit", "rates", "fenics", "fx"],
    tests:
      "That the same mechanic is caught when the impact comes from a different book inside the firm — information leaking across an internal wall.",
    scenario:
      "One trader opens a position; a different trader then pushes large client flow through the same instrument in the same direction; the first trader exits into it.",
    expected:
      "An Internal Front Running alert attributing the impact to the other trader's flow.",
    evidence: "The impacting traders named, with the lead time and the impacting notional.",
  },

  /* ---------------- Best execution ---------------- */
  ...(["barely", "significant", "major"] as const).map((tier, i) => ({
    id: `TC-BESTEX-0${i + 1}`,
    tag: `best_execution_${tier}`,
    metric: "best_execution" as MetricId,
    title: `Best execution — ${tier} above threshold`,
    tier,
    families: ["fenics", "fx"] as ProductFamily[],
    tests:
      "That a client filled worse than the firm could demonstrably have achieved is identified and the detriment quantified.",
    scenario:
      "The firm prints a bond with a dealer at the prevailing level, then fills a client on the same ISIN seconds to minutes later at a materially worse price — worse for the client on the side they traded. An FX variant prices a client away from the market level. " +
      TIER_NOTE[tier],
    expected:
      "A Best Execution alert measuring the client fill against the better contemporaneous print, with USD Value equal to the detriment times the client notional.",
    evidence:
      "Client price, reference price, which print the reference came from and how long before, and the gap in basis points and dollars.",
  })),

  /* ---------------- Spoofing ---------------- */
  ...(["barely", "significant", "major"] as const).map((tier, i) => ({
    id: `TC-SPOOF-0${i + 1}`,
    tag: `spoofing_${tier}`,
    metric: "spoofing" as MetricId,
    title: `Spoofing — ${tier} above threshold`,
    tier,
    families: ["fenics"] as ProductFamily[],
    tests:
      "That a large visible order placed with no intention of filling, pulled quickly, while the trader executes the other way, is detected from order data.",
    scenario:
      "A single fully displayed order is placed at the touch and cancelled within three to twenty-five seconds without filling. While it rests, the same trader executes a third to a half of that size in the opposite direction. " +
      TIER_NOTE[tier],
    expected:
      "A Spoofing alert where the Narrative (competitiveness- and visibility-weighted order impact applied to the opposite-side execution) exceeds the Counter-Narrative (cost of being filled, scaled by how briefly it rested).",
    evidence:
      "Order notional, displayed share, competitiveness, order life, the opposite-side execution, and nil fills on the decoy.",
  })),

  /* ---------------- Layering ---------------- */
  ...(["barely", "significant", "major"] as const).map((tier, i) => ({
    id: `TC-LAYER-0${i + 1}`,
    tag: `layering_${tier}`,
    metric: "layering" as MetricId,
    title: `Layering — ${tier} above threshold`,
    tier,
    families: ["fenics"] as ProductFamily[],
    tests:
      "That a ladder of orders across several price levels — as distinct from one conspicuous order — is detected and scored separately from spoofing.",
    scenario:
      "Four to seven orders are placed on one side at successive price levels within seconds of each other, some amended to walk the price in, all cancelled within eight to fifty seconds without filling, with a genuine execution on the opposite side. " +
      TIER_NOTE[tier],
    expected:
      "A Layering alert requiring at least four distinct price levels, a high cancel ratio and a short average life, with the ladder's apparent depth weighted into the score.",
    evidence:
      "Number of orders and distinct price levels, cancel ratio, amendments, average order life, and the opposite-side execution.",
  })),

  /* ---------------- The rest ---------------- */
  {
    id: "TC-INSIDER-01",
    tag: "insider_trading",
    metric: "insider_trading",
    title: "Position built ahead of a non-public event",
    families: ["credit", "rates", "fenics", "fx"],
    tests:
      "That a position concentrated in the hours before an announcement is separated from ordinary book-running, and valued at the move it captured.",
    scenario:
      "A trader builds a position in the direction of a coming event across three to five trades in the one and a half to nine hours before it becomes public, then closes within an hour or so of the news.",
    expected:
      "An Insider Trading alert where the excess over the time-weighted expected position, valued at the realised move in value terms, clears the threshold.",
    evidence:
      "Observed versus expected position, the excess, the event and its move, the time from the last build trade to the announcement, and the closing trade.",
  },
  {
    id: "TC-CLOSE-01",
    tag: "banging_the_close",
    metric: "banging_the_close",
    title: "Trading concentrated into the closing window",
    families: ["fenics", "fx"],
    tests:
      "That volume deliberately concentrated before a closing level is distinguished from the same volume worked evenly through the session.",
    scenario:
      "A trader takes exposure in the morning that settles against the close, then pushes four to seven clips through the final fifteen minutes before 16:00 in the direction that helps it.",
    expected:
      "A Banging the Close alert where the impact standing at the close exceeds what evenly-spread trading would have left.",
    evidence:
      "Actual versus modelled fair closing impact, the window notional, the concentration ratio, and the exposure carried into the close.",
  },
  {
    id: "TC-CROSS-01",
    tag: "cross_trading",
    metric: "cross_trading",
    title: "Two books crossing at an off-market level",
    families: ["fenics", "fx"],
    tests:
      "That risk moved between two internal books at a level away from the market is caught and the transferred value quantified.",
    scenario:
      "Two traders take opposite sides of the same instrument within a few seconds at matched size, both booked to internal accounts, at a level 40 to 200 basis points away from the market.",
    expected:
      "A Cross Trading alert pricing the deviation from the market level against the crossed notional.",
    evidence: "Both sides, the agreed level, the market level, the timestamp gap and the two books.",
  },
  {
    id: "TC-OFFMKT-01",
    tag: "off_market",
    metric: "off_market_trading",
    title: "Execution booked away from the market",
    families: ["fenics", "fx"],
    tests:
      "That a single execution priced well away from the prevailing level is flagged and the value transfer measured.",
    scenario:
      "One execution is booked 120 to 500 basis points from the modelled market level, against a client or an internal account.",
    expected:
      "An Off-Market Trading alert with USD Value equal to the deviation times the notional, and a statement of which side the transfer favours.",
    evidence: "Executed level, market level, deviation in basis points, and the direction of the transfer.",
  },
];

export const CASES_BY_METRIC = TEST_CASES.reduce<Record<string, TestCase[]>>((acc, c) => {
  (acc[c.metric] ??= []).push(c);
  return acc;
}, {});
