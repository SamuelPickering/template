import { NextResponse } from "next/server";
import { MarketData } from "@/lib/models/market";
import {
  analyseImport,
  BUCKET_OF_MODE,
  parseImport,
  toSourceDocuments,
  type ImportFamily,
  type ImportMode,
} from "@/lib/import/json";
import {
  insertDocuments,
  loadCounterparties,
  loadDocuments,
  loadEvents,
  loadInstruments,
  loadMarketDaily,
  loadTraders,
  replaceDocuments,
} from "@/lib/db/repo";
import { invalidateAnalysis } from "@/lib/detect/engine";
import { setDataset, setImportOverrides } from "@/lib/config/store";
import type { Dataset } from "@/lib/datasets";
import type { AdaptContext } from "@/lib/schema/adapt";
import type { ImportOverrides } from "@/lib/types";

export const maxDuration = 120;

function adaptContext(overrides?: ImportOverrides): AdaptContext {
  const market = new MarketData(loadInstruments(), loadMarketDaily());
  market.setEvents(loadEvents());
  return {
    usdRate: (ccy, ms) => market.usdRate(ccy, ms),
    traders: new Map(loadTraders().map((t) => [t.trader_id, t])),
    counterparties: new Map(loadCounterparties().map((c) => [c.counterparty_code, c])),
    overrides,
  };
}

/** Which view to switch to once a file has been imported. */
const VIEW_OF_MODE: Record<ImportMode, Dataset> = {
  production: "imported_production",
  synthetic: "imported_synthetic",
};

/** Merge: anything the operator typed wins over what the pack declares. */
function mergeOverrides(
  typed: ImportOverrides | undefined,
  pack: ImportOverrides | null | undefined,
): ImportOverrides | undefined {
  if (!pack) return typed;
  const out: ImportOverrides = { ...pack, ...(typed ?? {}) };
  for (const key of ["client_patterns", "dealer_patterns"] as const) {
    const t = typed?.[key];
    if (!t || !t.length) out[key] = pack[key];
  }
  for (const key of ["side_path", "trader_name_path", "book_path"] as const) {
    if (!out[key]) out[key] = pack[key];
  }
  return out;
}

export async function POST(req: Request) {
  const body = (await req.json()) as {
    action: "preview" | "commit";
    text: string;
    family?: ImportFamily;
    mode?: ImportMode;
    append?: boolean;
    overrides?: ImportOverrides;
    activate?: boolean;
  };

  if (!body?.text || typeof body.text !== "string") {
    return NextResponse.json({ error: "No file content received." }, { status: 400 });
  }

  const parsed = parseImport(body.text);
  if (!parsed.documents.length) {
    return NextResponse.json(
      { error: parsed.errors.join(" ") || "No documents found in the file." },
      { status: 400 },
    );
  }

  const mode: ImportMode = body.mode === "synthetic" ? "synthetic" : "production";
  const bucket = BUCKET_OF_MODE[mode];
  // Count it now: loadDocuments hands back the live array, and appending
  // would otherwise be counted twice.
  const existingCount = loadDocuments(bucket).length;
  const append = body.append === true;
  const startIndex = append ? existingCount : 0;

  const family = body.family ?? "auto";
  const { documents, rejected } = toSourceDocuments(parsed, family, mode, startIndex);
  if (!documents.length) {
    return NextResponse.json(
      {
        error:
          "None of the documents could be matched to a product schema. Choose the product type explicitly instead of letting it be detected.",
        rejected: rejected.slice(0, 10),
      },
      { status: 400 },
    );
  }

  // A pack's declared counterparty patterns only apply to a synthetic import.
  const overrides =
    mode === "synthetic"
      ? mergeOverrides(body.overrides, parsed.pack?.overrides)
      : body.overrides;

  const analysis = analyseImport(
    documents,
    rejected,
    adaptContext(overrides),
    new Set(loadInstruments().map((i) => i.instrument)),
  );

  if (body.action === "preview") {
    return NextResponse.json({
      format: parsed.format,
      fileErrors: parsed.errors,
      pack: mode === "synthetic" ? (parsed.pack ?? null) : null,
      mode,
      analysis,
    });
  }

  if (append) insertDocuments(documents);
  else replaceDocuments(bucket, documents);
  // Remembered against the bucket, so the detection run reads the file the
  // same way the preview did.
  setImportOverrides(bucket, overrides);
  invalidateAnalysis();
  if (body.activate !== false) setDataset(VIEW_OF_MODE[mode]);

  return NextResponse.json({
    imported: documents.length,
    total: append ? existingCount + documents.length : documents.length,
    mode,
    bucket,
    appended: append,
    pack: mode === "synthetic" ? (parsed.pack ?? null) : null,
    analysis,
    activated: body.activate !== false,
  });
}
