import Link from "next/link";
import { runUat, type UatCaseResult } from "@/lib/testing/uatRun";
import { METRIC_BY_ID } from "@/lib/config/metrics";
import { getDataset } from "@/lib/config/store";
import { DATASET_LABEL } from "@/lib/datasets";
import { fmtAmount, fmtUsd } from "@/lib/format";

export const dynamic = "force-dynamic";

const green = "#060";
const red = "#a00";

function CaseDetail({ r }: { r: UatCaseResult }) {
  const c = r.testCase;
  const wantsAlert = c.expect === "alert";
  return (
    <details>
      <summary>
        <span className="mono">{c.id}</span> — {c.title} —{" "}
        <b style={{ color: r.status === "pass" ? green : red }}>
          {r.status === "pass" ? "PASS" : "FAIL"}
        </b>
        <span className="note">
          {" "}
          (expected {wantsAlert ? `a ${METRIC_BY_ID[c.metric].label} alert` : "no alert"};{" "}
          {r.alerts.length} raised{r.origin === "custom" ? "; written locally" : ""}
          {r.origin === "edited" ? "; edited locally" : ""})
        </span>
      </summary>

      <p className={r.status === "pass" ? "" : "warn"}>
        <b>{r.verdict}</b>
      </p>

      <h3>What is being tested</h3>
      <p>{c.tests}</p>
      <h3>Scenario</h3>
      <p>{c.scenario}</p>
      <h3>Why these trades</h3>
      <p>{c.rationale}</p>
      <h3>Expected</h3>
      <p>{c.expected}</p>
      {c.gate && (
        <>
          <h3>The check that should stop it</h3>
          <p>{c.gate}</p>
        </>
      )}

      <h3>The trades analysed</h3>
      <p className="note small">
        Every trade carrying this case&apos;s marker, as the adapters normalised it. The last column
        says whether the trade is one an alert was actually built from.
      </p>
      <table>
        <thead>
          <tr>
            <th></th>
            <th>Id</th>
            <th>Time (UTC)</th>
            <th>Trader</th>
            <th>Instrument</th>
            <th>Side</th>
            <th className="n">Size</th>
            <th className="n">Price</th>
            <th>Counterparty</th>
            <th>Detail</th>
            <th>In alert</th>
          </tr>
        </thead>
        <tbody>
          {r.trades.map((t) => (
            <tr key={`${t.kind}-${t.id}`} className={t.in_alert ? "alerted" : ""}>
              <td className="note">{t.kind === "order" ? "order" : "fill"}</td>
              <td className="mono">{t.id}</td>
              <td className="mono">{t.time}</td>
              <td>{t.trader_name}</td>
              <td className="mono">{t.instrument}</td>
              <td>{t.side}</td>
              <td className="n">{fmtUsd(t.notional_usd)}</td>
              <td className="n">{t.price ?? "-"}</td>
              <td>{t.counterparty ?? "-"}</td>
              <td className="note">
                {t.kind === "order"
                  ? `${t.outcome}, ${t.levels} level${t.levels === 1 ? "" : "s"}, ${Math.round(
                      (t.display_share ?? 0) * 100,
                    )}% shown, ${t.life_seconds?.toFixed(0)}s`
                  : t.role}
              </td>
              <td>{t.in_alert ? "yes" : "-"}</td>
            </tr>
          ))}
        </tbody>
      </table>

      {r.alerts.length > 0 ? (
        r.alerts.map((a) => (
          <div key={a.instance_id} className="box" style={{ marginTop: 8 }}>
            <b>
              {a.label} — {fmtUsd(a.usd_value)}
            </b>{" "}
            <span className="note">
              (threshold {fmtUsd(a.threshold)})
              {a.expected ? "" : " — not the metric this case is about"}
            </span>
            <p>
              <b>{a.headline}</b>
            </p>
            <p>{a.explanation}</p>
            <p className="note">
              {a.trader_name} · {a.instrument_label} ·{" "}
              <Link href={`/instance/${encodeURIComponent(a.instance_id)}`}>open this alert</Link>
            </p>
            <table>
              <thead>
                <tr>
                  <th>Computed value</th>
                  <th className="n">Amount</th>
                </tr>
              </thead>
              <tbody>
                {a.components.map((comp) => (
                  <tr key={comp.label}>
                    <td title={comp.help}>{comp.label}</td>
                    <td className="n">{comp.value}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ))
      ) : r.nearMiss ? (
        <p>
          <b>No alert.</b> The highest score the engine produced on these trades was{" "}
          {r.nearMiss.label} at {fmtUsd(r.nearMiss.usd_value)}, below its{" "}
          {fmtUsd(r.nearMiss.threshold)} threshold: <span className="note">{r.nearMiss.headline}</span>
        </p>
      ) : (
        <p>
          <b>No alert, and nothing scored.</b> The trades were read and normalised but never priced —
          a gate stopped them first, which is the intended behaviour for this case.
        </p>
      )}

      {r.gateProof ? (
        <>
          <h3>Proof the check is what stopped it</h3>
          <p>
            With <b>{r.gateProof.label}</b> moved from {r.gateProof.from} to {r.gateProof.shown} and
            the pack scored again:{" "}
            {r.gateProof.outcome === "nothing" ? (
              <b>still nothing.</b>
            ) : (
              <>
                {METRIC_BY_ID[c.metric].label} scores these trades at{" "}
                <b>{fmtUsd(r.gateProof.usd_value)}</b> against a {fmtUsd(r.gateProof.threshold)}{" "}
                threshold
                {r.gateProof.outcome === "alert" ? " — an alert" : ", below the threshold"}.
              </>
            )}{" "}
            {r.gateProof.note}
          </p>
        </>
      ) : c.expect === "no_alert" ? (
        <>
          <h3>Proof the check is what stopped it</h3>
          <p>
            No setting to relax — this check is structural rather than configurable, so there is no
            version of the settings under which these trades become this behaviour.
          </p>
        </>
      ) : null}
    </details>
  );
}

export default function UatPage() {
  const report = runUat();
  const dataset = getDataset();
  const s = report.summary;
  const allPassed = s.failed === 0 && report.available;

  if (!report.available) {
    return (
      <>
        <h1>UAT Pack</h1>
        <p className="note">
          The UAT pack is a file of engineered trades, built to exercise every detector and to prove
          that the ones which should stay quiet do. It is imported rather than seeded, so importing
          is itself part of what gets tested.
        </p>
        <div className="box">
          <b className="warn">The pack is not loaded.</b>
          <ol className="small">
            <li>
              Go to <Link href="/import">Import</Link>.
            </li>
            <li>
              Choose <b>Synthetic test data</b> — not production.
            </li>
            <li>
              Leave the product type on <b>detect</b>; the pack holds credit, rates and Fenics
              documents together.
            </li>
            <li>
              Upload <span className="mono">uat/mast-uat-synthetic-trades.json</span> from the
              project folder, then press Import.
            </li>
            <li>Come back here.</li>
          </ol>
          <p className="note small">
            Writing your own cases rather than running these:{" "}
            <Link href="/uat/cases">the case editor</Link> adds, edits and switches off cases, and
            hands you a starter file of trades for a new one.
          </p>
          <p className="note small">
            The pack is regenerated with <span className="mono">npm run uat:pack</span>. What each
            case tests is in <span className="mono">uat/UAT-test-cases.md</span>, and every trade in
            the file with the reasoning behind it is in{" "}
            <span className="mono">uat/UAT-trade-design.md</span>.
          </p>
        </div>
      </>
    );
  }

  return (
    <>
      <h1>UAT Pack</h1>
      <p className="note">
        {s.total} test cases run against the imported synthetic pack. {s.positive} of them require
        an alert; {s.negative} require silence, because a tool that alerts on everything is as
        useless as one that alerts on nothing.
      </p>

      <div className="box">
        <b style={{ color: allPassed ? green : red }}>
          {s.passed} of {s.total} test cases passed
        </b>
        <div className="note" style={{ marginTop: 3 }}>
          {s.positivePassed} of {s.positive} cases that must raise an alert ·{" "}
          {s.negativePassed} of {s.negative} cases that must not ·{" "}
          {report.pack_documents.toLocaleString("en-US")} documents →{" "}
          {report.executions.toLocaleString("en-US")} executions and{" "}
          {report.orders.toLocaleString("en-US")} order streams ·{" "}
          {report.total_alerts.toLocaleString("en-US")} alerts in total · run{" "}
          {report.generated_at.slice(0, 19).replace("T", " ")}Z
        </div>
        <div style={{ marginTop: 6 }}>
          <Link href="/uat/cases">
            <b>Edit the test cases</b>
          </Link>
          {" | "}
          <a href="/api/uat?format=md" download>
            Download results (Markdown)
          </a>
          {" | "}
          <a href="/api/uat?format=json" download>
            Download results (JSON)
          </a>
          <span className="note">
            {" "}
            — or <span className="mono">npm run uat:report</span> to write it to{" "}
            <span className="mono">reports/</span>
          </span>
        </div>
      </div>

      <p className="note small">
        The pack is always scored on its own, whatever view is on screen — currently{" "}
        <b>{DATASET_LABEL[dataset]}</b> — so this result does not change depending on what else has
        been loaded. Cases are matched to results through a QA marker on the documents;{" "}
        <b>no detection engine reads that marker</b>, so a pass on an alert case means the behaviour
        was found from trade and order data alone, and a pass on a silent case means nothing in the
        data looked like abuse to the engine. Thresholds are the live ones from the{" "}
        <Link href="/admin">admin page</Link>.
      </p>

      <h2>Summary</h2>
      <table>
        <thead>
          <tr>
            <th>Case</th>
            <th>Behaviour</th>
            <th>Metric</th>
            <th>Expected</th>
            <th className="n">Alerts</th>
            <th className="n">USD Value</th>
            <th>Result</th>
          </tr>
        </thead>
        <tbody>
          {report.results.map((r) => {
            const top = r.alerts.find((a) => a.metric === r.testCase.metric) ?? r.alerts[0];
            return (
              <tr key={r.testCase.id} className={r.status === "pass" ? "" : "alerted"}>
                <td className="mono">{r.testCase.id}</td>
                <td>{r.testCase.title}</td>
                <td>{METRIC_BY_ID[r.testCase.metric].label}</td>
                <td>{r.testCase.expect === "alert" ? "alert" : "no alert"}</td>
                <td className="n">{r.alerts.length}</td>
                <td className="n">{top ? fmtUsd(top.usd_value) : "-"}</td>
                <td style={{ color: r.status === "pass" ? green : red, fontWeight: "bold" }}>
                  {r.status === "pass" ? "PASS" : "FAIL"}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>

      <h2>Thresholds this run used</h2>
      <p className="stats">
        {report.thresholds.map((t) => (
          <span key={t.metric}>
            <b>{t.label}:</b> {fmtUsd(t.threshold)}
          </span>
        ))}
      </p>

      <h2>What it would take to make the silent cases fire</h2>
      <p className="note">
        Each row re-scores the pack with one setting opened up. It is the difference between &quot;no
        alert&quot; and &quot;no alert, for the stated reason&quot;.
      </p>
      <table>
        <thead>
          <tr>
            <th>Case</th>
            <th>Setting relaxed</th>
            <th className="n">From</th>
            <th className="n">To</th>
            <th>What happens</th>
          </tr>
        </thead>
        <tbody>
          {report.results
            .filter((r) => r.testCase.expect === "no_alert")
            .map((r) => (
              <tr key={r.testCase.id}>
                <td className="mono">{r.testCase.id}</td>
                <td>{r.gateProof?.label ?? <span className="note">structural — no setting</span>}</td>
                <td className="n">{r.gateProof ? fmtAmount(r.gateProof.from) : "-"}</td>
                <td className="n">{r.gateProof?.shown ?? "-"}</td>
                <td>
                  {!r.gateProof ? (
                    <span className="note">
                      no configuration makes these trades this behaviour
                    </span>
                  ) : r.gateProof.outcome === "alert" ? (
                    <b style={{ color: red }}>alerts at {fmtUsd(r.gateProof.usd_value)}</b>
                  ) : r.gateProof.outcome === "scored" ? (
                    <>
                      scored at {fmtUsd(r.gateProof.usd_value)}, still under the{" "}
                      {fmtUsd(r.gateProof.threshold)} threshold
                    </>
                  ) : (
                    <>still nothing</>
                  )}
                </td>
              </tr>
            ))}
        </tbody>
      </table>

      {report.uncatalogued.length > 0 && (
        <>
          <h2>Trades with no case written for them</h2>
          <p className="note">
            Markers found in the loaded pack that no case claims. Not a failure — trades are
            normally imported first and described afterwards — but nothing judges them until a case
            exists. <Link href="/uat/cases">Describe them here.</Link>
          </p>
          <table>
            <thead>
              <tr>
                <th>Marker</th>
                <th className="n">Documents</th>
                <th className="n">Executions</th>
                <th className="n">Orders</th>
                <th>Alerts raised</th>
              </tr>
            </thead>
            <tbody>
              {report.uncatalogued.map((u) => (
                <tr key={u.tag}>
                  <td className="mono">{u.tag}</td>
                  <td className="n">{u.documents}</td>
                  <td className="n">{u.executions}</td>
                  <td className="n">{u.orders}</td>
                  <td className="note">
                    {u.alerts.length
                      ? u.alerts.map((a) => `${a.label} ${fmtUsd(a.usd_value)}`).join(", ")
                      : "none"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </>
      )}

      {report.groups.map((g) => (
        <section key={g.name}>
          <h2>{g.name}</h2>
          <p className="note">{g.blurb}</p>
          {g.results.map((r) => (
            <CaseDetail key={r.testCase.id} r={r} />
          ))}
        </section>
      ))}
    </>
  );
}
