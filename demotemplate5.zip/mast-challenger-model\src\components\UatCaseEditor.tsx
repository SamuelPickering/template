"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import type { UatCase } from "@/lib/testing/uatCases";
import type { CaseOrigin } from "@/lib/testing/uatStore";
import type { UncataloguedGroup } from "@/lib/testing/uatRun";

type EditableCase = UatCase & { origin: CaseOrigin };

interface MetricOption {
  id: string;
  label: string;
  params: { key: string; label: string; default: number; unit: string }[];
}

interface Catalogue {
  file: string;
  cases: EditableCase[];
  groups: string[];
  switchedOff: { id: string; title: string }[];
  metrics: MetricOption[];
}

const FAMILIES = ["credit", "rates", "fenics", "fx"] as const;

const blank = (id = ""): UatCase => ({
  id,
  group: "",
  metric: "wash_trading",
  expect: "alert",
  title: "",
  families: ["fenics"],
  tests: "",
  scenario: "",
  rationale: "",
  expected: "",
});

export function UatCaseEditor({
  initial,
  uncatalogued,
}: {
  initial: Catalogue;
  uncatalogued: UncataloguedGroup[];
}) {
  const router = useRouter();
  const [cat, setCat] = useState(initial);
  const [draft, setDraft] = useState<UatCase | null>(null);
  const [isNew, setIsNew] = useState(false);
  const [errors, setErrors] = useState<string[]>([]);
  const [note, setNote] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const metric = cat.metrics.find((m) => m.id === draft?.metric);

  async function send(body: object) {
    setBusy(true);
    setErrors([]);
    const res = await fetch("/api/uat/cases", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
    });
    const json = await res.json();
    setBusy(false);
    if (!res.ok) {
      setErrors(json.errors ?? ["Something went wrong."]);
      return null;
    }
    setCat(json as Catalogue);
    router.refresh();
    return json;
  }

  async function save() {
    if (!draft) return;
    const json = await send({ action: "save", case: draft });
    if (json) {
      setNote(`${draft.id} saved to ${json.file}. Re-run the UAT page to score it.`);
      setDraft(null);
      setIsNew(false);
    }
  }

  async function remove(c: EditableCase) {
    const builtIn = c.origin !== "custom";
    const msg = builtIn
      ? `Switch off ${c.id}? It ships with the tool, so it can be restored later.`
      : `Delete ${c.id}? This case was written here, so it goes for good. The trades carrying its marker stay in the data.`;
    if (!confirm(msg)) return;
    const json = await send({ action: "delete", id: c.id });
    if (json) setNote(json.restorable ? `${c.id} switched off.` : `${c.id} deleted.`);
  }

  function edit(c: EditableCase) {
    setDraft({ ...c });
    setIsNew(false);
    setErrors([]);
    setNote(null);
  }

  function startNew(id = "") {
    setDraft(blank(id));
    setIsNew(true);
    setErrors([]);
    setNote(null);
  }

  const set = (patch: Partial<UatCase>) => setDraft((d) => (d ? { ...d, ...patch } : d));

  const field = (
    label: string,
    key: "tests" | "scenario" | "rationale" | "expected" | "gate",
    help: string,
    rows = 3,
  ) => (
    <tr>
      <td style={{ verticalAlign: "top", width: 150 }}>
        <b>{label}</b>
        <div className="note small" style={{ whiteSpace: "normal", maxWidth: 150 }}>
          {help}
        </div>
      </td>
      <td>
        <textarea
          rows={rows}
          cols={90}
          value={(draft?.[key] as string) ?? ""}
          onChange={(e) => set({ [key]: e.target.value } as Partial<UatCase>)}
        />
      </td>
    </tr>
  );

  return (
    <>
      {note && <p className="ok">{note}</p>}
      {errors.length > 0 && (
        <div className="box">
          <b className="warn">Not saved:</b>
          <ul className="small">
            {errors.map((e, i) => (
              <li key={i}>{e}</li>
            ))}
          </ul>
        </div>
      )}

      {uncatalogued.length > 0 && (
        <>
          <h2>Trades waiting for a case</h2>
          <p className="note">
            Markers found in the loaded pack that no case claims. This is the normal way round —
            import the trades, then describe what they are supposed to prove.
          </p>
          <table>
            <thead>
              <tr>
                <th>Marker</th>
                <th className="n">Documents</th>
                <th className="n">Executions</th>
                <th className="n">Orders</th>
                <th>Alerts raised</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {uncatalogued.map((u) => (
                <tr key={u.tag}>
                  <td className="mono">{u.tag}</td>
                  <td className="n">{u.documents}</td>
                  <td className="n">{u.executions}</td>
                  <td className="n">{u.orders}</td>
                  <td className="note">
                    {u.alerts.length
                      ? u.alerts
                          .map((a) => `${a.label} $${Math.round(a.usd_value).toLocaleString("en-US")}`)
                          .join(", ")
                      : "none"}
                  </td>
                  <td>
                    <button onClick={() => startNew(u.tag)}>Describe this</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </>
      )}

      <h2>The catalogue ({cat.cases.length} cases)</h2>
      <p>
        <button onClick={() => startNew()} disabled={busy}>
          Add a case
        </button>{" "}
        <span className="note">
          Edits are written to <span className="mono">{cat.file}</span> — a plain file you can read,
          commit or delete. The cases that ship with the tool are left where they are, so an update
          never quietly drops yours.
        </span>
      </p>
      <table>
        <thead>
          <tr>
            <th>Case</th>
            <th>Title</th>
            <th>Group</th>
            <th>Metric</th>
            <th>Expected</th>
            <th>Source</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {cat.cases.map((c) => (
            <tr key={c.id} className={draft?.id === c.id && !isNew ? "alerted" : ""}>
              <td className="mono">{c.id}</td>
              <td>{c.title}</td>
              <td className="note">{c.group}</td>
              <td className="note">{cat.metrics.find((m) => m.id === c.metric)?.label ?? c.metric}</td>
              <td>{c.expect === "alert" ? "alert" : "no alert"}</td>
              <td className="note">{c.origin}</td>
              <td>
                <button onClick={() => edit(c)} disabled={busy}>
                  Edit
                </button>{" "}
                <button onClick={() => remove(c)} disabled={busy}>
                  {c.origin === "custom" ? "Delete" : "Switch off"}
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {cat.switchedOff.length > 0 && (
        <>
          <h2>Switched off</h2>
          <p className="note">
            Cases that ship with the tool but are not being run. Nothing was deleted; they come back
            as they were.
          </p>
          <ul className="small">
            {cat.switchedOff.map((c) => (
              <li key={c.id}>
                <span className="mono">{c.id}</span> — {c.title}{" "}
                <button disabled={busy} onClick={() => send({ action: "restore", id: c.id })}>
                  Restore
                </button>
              </li>
            ))}
          </ul>
        </>
      )}

      {draft && (
        <>
          <h2>{isNew ? "New case" : `Editing ${draft.id}`}</h2>
          <fieldset>
            <legend>What the case is</legend>
            <table>
              <tbody>
                <tr>
                  <td style={{ width: 150 }}>
                    <b>Case id</b>
                    <div className="note small" style={{ whiteSpace: "normal", maxWidth: 150 }}>
                      Ties the case to its trades: every document carrying this id in
                      QA.TestCase is judged by it.
                    </div>
                  </td>
                  <td>
                    <input
                      value={draft.id}
                      size={30}
                      disabled={!isNew}
                      placeholder="UAT-MYTEST-01"
                      onChange={(e) => set({ id: e.target.value })}
                    />
                    {!isNew && (
                      <span className="note">
                        {" "}
                        fixed — renaming would separate the case from its trades
                      </span>
                    )}
                  </td>
                </tr>
                <tr>
                  <td>
                    <b>Title</b>
                  </td>
                  <td>
                    <input
                      value={draft.title}
                      size={90}
                      placeholder="One line naming the behaviour"
                      onChange={(e) => set({ title: e.target.value })}
                    />
                  </td>
                </tr>
                <tr>
                  <td>
                    <b>Group</b>
                  </td>
                  <td>
                    <input
                      value={draft.group}
                      size={40}
                      list="uat-groups"
                      placeholder="Wash trading — must not fire"
                      onChange={(e) => set({ group: e.target.value })}
                    />
                    <datalist id="uat-groups">
                      {cat.groups.map((g) => (
                        <option key={g} value={g} />
                      ))}
                    </datalist>
                    <span className="note"> heading it appears under</span>
                  </td>
                </tr>
                <tr>
                  <td>
                    <b>Metric</b>
                  </td>
                  <td>
                    <select
                      value={draft.metric}
                      onChange={(e) =>
                        set({ metric: e.target.value as UatCase["metric"], relax: undefined })
                      }
                    >
                      {cat.metrics.map((m) => (
                        <option key={m.id} value={m.id}>
                          {m.label}
                        </option>
                      ))}
                    </select>
                    <span className="note"> the metric this case is about</span>
                  </td>
                </tr>
                <tr>
                  <td>
                    <b>Expected result</b>
                  </td>
                  <td>
                    <label className="f">
                      <input
                        type="radio"
                        checked={draft.expect === "alert"}
                        onChange={() => set({ expect: "alert" })}
                      />{" "}
                      this metric <b>must</b> raise an alert on these trades
                    </label>
                    <br />
                    <label className="f">
                      <input
                        type="radio"
                        checked={draft.expect === "no_alert"}
                        onChange={() => set({ expect: "no_alert" })}
                      />{" "}
                      <b>no</b> metric may raise an alert on these trades
                    </label>
                  </td>
                </tr>
                <tr>
                  <td>
                    <b>Size</b>
                  </td>
                  <td>
                    <select
                      value={draft.tier ?? ""}
                      onChange={(e) =>
                        set({ tier: (e.target.value || undefined) as UatCase["tier"] })
                      }
                    >
                      <option value="">not one of a set</option>
                      <option value="barely">barely over the threshold</option>
                      <option value="significant">significant</option>
                      <option value="major">major</option>
                    </select>
                    <span className="note"> only for a case that is one of several sizes</span>
                  </td>
                </tr>
                <tr>
                  <td>
                    <b>Products</b>
                  </td>
                  <td>
                    {FAMILIES.map((f) => (
                      <label className="f" key={f}>
                        <input
                          type="checkbox"
                          checked={draft.families.includes(f)}
                          onChange={(e) =>
                            set({
                              families: e.target.checked
                                ? [...draft.families, f]
                                : draft.families.filter((x) => x !== f),
                            })
                          }
                        />{" "}
                        {f}
                      </label>
                    ))}
                  </td>
                </tr>
              </tbody>
            </table>
          </fieldset>

          <fieldset>
            <legend>What it says</legend>
            <table>
              <tbody>
                {field("What is being tested", "tests", "The capability being proven.")}
                {field("Scenario", "scenario", "The trades, in plain terms.")}
                {field(
                  "Why these trades",
                  "rationale",
                  "Why these sizes, timings and counterparties and not others. This is the part a reviewer reads.",
                  4,
                )}
                {field("Expected", "expected", "What has to come out for this to pass.")}
                {draft.expect === "no_alert" &&
                  field(
                    "Check that should stop it",
                    "gate",
                    "The single check that keeps this quiet. Leave blank if it is structural.",
                  )}
              </tbody>
            </table>
          </fieldset>

          {draft.expect === "no_alert" && (
            <fieldset>
              <legend>Proving it stayed quiet for the right reason</legend>
              <p className="note small">
                Optional, and the strongest thing a silent case can carry. Name a setting to relax
                and the report re-scores these trades with it opened up — if the alert then appears,
                that check is demonstrably what stopped it. Leave the setting blank where the check
                is structural, like matching on instrument or on direction.
              </p>
              <label className="f">
                Setting{" "}
                <select
                  value={draft.relax?.param ?? ""}
                  onChange={(e) => {
                    const p = metric?.params.find((x) => x.key === e.target.value);
                    set({
                      relax: p
                        ? {
                            param: p.key,
                            label: p.label,
                            value: draft.relax?.value ?? p.default,
                            shown: draft.relax?.shown ?? String(p.default),
                          }
                        : undefined,
                    });
                  }}
                >
                  <option value="">none — the check is structural</option>
                  {(metric?.params ?? []).map((p) => (
                    <option key={p.key} value={p.key}>
                      {p.label} (default {p.default}
                      {p.unit ? ` ${p.unit}` : ""})
                    </option>
                  ))}
                </select>
              </label>
              {draft.relax && (
                <>
                  <label className="f">
                    Relax it to{" "}
                    <input
                      value={draft.relax.value}
                      size={10}
                      onChange={(e) =>
                        set({
                          relax: { ...draft.relax!, value: Number(e.target.value) },
                        })
                      }
                    />
                  </label>
                  <label className="f">
                    Written as{" "}
                    <input
                      value={draft.relax.shown}
                      size={16}
                      placeholder="7 hours"
                      onChange={(e) => set({ relax: { ...draft.relax!, shown: e.target.value } })}
                    />
                  </label>
                </>
              )}
            </fieldset>
          )}

          <p>
            <button onClick={save} disabled={busy}>
              {busy ? "Saving..." : "Save case"}
            </button>{" "}
            <button
              onClick={() => {
                setDraft(null);
                setIsNew(false);
                setErrors([]);
              }}
              disabled={busy}
            >
              Cancel
            </button>{" "}
            {isNew && draft.id && (
              <a href={`/api/uat/cases?template=${encodeURIComponent(draft.id)}`} download>
                Download starter trades for {draft.id}
              </a>
            )}
          </p>
          {isNew && (
            <p className="note small">
              A case with no trades carrying its id will fail, because there is nothing to judge.
              Either import documents marked <span className="mono">QA.TestCase: {draft.id || "..."}</span>{" "}
              on the <Link href="/import">Import page</Link> as synthetic test data with{" "}
              <i>add to what is already in this bucket</i> ticked, or start from the starter file
              above and edit it into the behaviour you are describing.
            </p>
          )}
        </>
      )}

      <h2>Starting over</h2>
      <p className="note">
        Discards every local change — added cases, edits and switched-off cases alike — and puts the
        catalogue back the way it ships.
      </p>
      <button
        disabled={busy}
        onClick={() => {
          if (confirm("Discard every local change to the test catalogue?")) {
            void send({ action: "reset" }).then(() => setNote("Catalogue reset."));
          }
        }}
      >
        Reset the catalogue
      </button>
    </>
  );
}
