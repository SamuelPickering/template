# UAT pack

Engineered trades for user acceptance testing, and the documents that explain them. Nothing in
here is production data: no instrument, trader or counterparty in it is real.

| File | What it is |
|---|---|
| `mast-uat-synthetic-trades.json` | The pack itself — 104 Master.Transaction documents in the Credit, Rates and Fenics product schemas. Import this on the Import page as **synthetic test data**. |
| `UAT-test-cases.md` | Every case: what is being tested, the scenario, why those particular trades, and what has to come out. |
| `UAT-trade-design.md` | Every trade in the file, by case, exactly as it appears in the JSON, with the reasoning behind its size, timing and counterparty. |
| `UAT-results.md` | A recorded run: pass or fail per case, the trades that were analysed, the alert text and its arithmetic where one was raised, and what it would take to make each silent case fire. |
| `UAT-walkthrough.md` | A script for walking someone through the results in about twenty minutes, with the questions to expect and how to answer them. |
| `uat-cases.custom.json` | Only present once a case has been added, edited or switched off here. Delete it to go back to the cases that ship. |

## Running it

```bash
npm run uat:load      # import the pack from the command line
npm run uat:report    # write a fresh results file to reports/
```

Or, in the app: **Import** → Synthetic test data → upload the JSON → **UAT Pack**.

`UAT-results.md` was produced at the default thresholds. Change a threshold on the admin page and
the results change with it — that is the point of the threshold sensitivity section, so re-run the
report rather than trusting the committed copy if the settings have moved.

## Changing the cases

The description and the verdict rule are edited in the app: **UAT Pack → Edit the test cases**. Add
a case, reword one, switch one off, put it back, or reset everything. Changes land in
`uat-cases.custom.json` next to this file — plain JSON, readable, committable, and deletable. The
cases that ship with the tool live in the source and are never rewritten, so an update cannot drop
yours.

Giving a new case its trades is the other half. Every document is tied to a case by a
`QA.TestCase` marker, so:

1. Add the case in the editor and download the starter file it offers.
2. Import that file as **synthetic test data** with *add to what is already in this bucket* ticked.
   Unchanged, it is a $30m round trip against an internal book and the case passes — which proves
   the plumbing before you have written a line of your own data.
3. Edit the amounts, prices, timestamps, sides and counterparties until it is the behaviour your
   case describes, and import it again.

Trades whose marker no case claims appear on the UAT page as *trades with no case written for
them*, with a button to describe them. Import first, describe second, is the normal order.

## What it is for

31 cases. 13 require an alert — layering, spoofing, wash trading, front running and best execution,
each at two or three sizes so one of them sits just above the threshold. The other 18 require
silence, because a surveillance tool that alerts on everything is as useless as one that alerts on
nothing:

- two completely different bonds bought and sold at the same moment is not a wash trade
- a position opened in the morning and closed in the afternoon is not a wash trade
- buying from one client and selling to another is market making, not a wash trade
- a trade six hours after client business is not front running
- an order that filled, or rested for eleven minutes, or was never visible, is not a spoof
- five orders at the same price are not a ladder
- a client who got the better price has suffered no detriment
- and an ordinary day of two-way business produces nothing at all

Each of those names the one check that is supposed to stop it, and the results file re-scores the
pack with that check relaxed. That is what turns "no alert" into "no alert, for the stated reason".

## How a case is tied to its result

Every document carries a `QA.TestCase` marker naming its case. That marker is read only when a file
is imported as synthetic test data, and **no detection engine ever reads it** — it exists so the
report can be written. A positive case passing therefore means the behaviour was found from trade
and order data alone; a negative case passing means nothing in the data looked like abuse to the
engine.

The pack also declares its own counterparty conventions in a `TestPack` envelope, because no
product schema carries a field that separates a client from a dealer and both Front Running and
Best Execution turn on that distinction. On a real extract the same job is done by the counterparty
registry or by typing patterns on the import page.
