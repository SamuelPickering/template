import { NextResponse } from "next/server";
import { getDataset, setDataset, setImportOverrides } from "@/lib/config/store";
import { deleteDocumentsBySource } from "@/lib/db/repo";
import { invalidateAnalysis } from "@/lib/detect/engine";
import { isDataSource, isDataset } from "@/lib/datasets";

export async function GET() {
  return NextResponse.json({ dataset: getDataset() });
}

export async function POST(req: Request) {
  const body = (await req.json()) as {
    dataset?: string;
    action?: "clear";
    /** Which bucket to empty: imported_synthetic or imported_production. */
    source?: string;
  };

  if (body.action === "clear") {
    if (!isDataSource(body.source) || body.source === "synthetic") {
      return NextResponse.json(
        { error: "Only an imported bucket can be cleared; re-run the seed to replace synthetic data." },
        { status: 400 },
      );
    }
    deleteDocumentsBySource(body.source);
    setImportOverrides(body.source, undefined);
    if (getDataset() === body.source) setDataset("synthetic");
    invalidateAnalysis();
    return NextResponse.json({ dataset: getDataset(), cleared: body.source });
  }

  if (isDataset(body.dataset)) setDataset(body.dataset);
  return NextResponse.json({ dataset: getDataset() });
}
