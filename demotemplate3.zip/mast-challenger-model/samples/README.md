# Sample extracts

This folder holds sample extracts in the four product schemas, for exercising the Import page
without a production file to hand. They are generated rather than committed:

```bash
npm run seed            # if you have not already
npx tsx scripts/make-sample-json.ts
```

That writes `sample-credit.json`, `sample-rates.json`, `sample-fenics.json`, `sample-fx.json` and
`sample-mixed.json`. Each one carries the engineered scenario cases for its family plus a slice of
ordinary business, so importing one actually produces alerts. The files contain only trade data —
the internal scenario tags are dropped on the way out, exactly as a real extract would be.
