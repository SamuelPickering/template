/**
 * How we get from a JSON extract to a Layering, Spoofing or Best Execution
 * finding — written out step by step, with every intermediate number printed.
 *
 *   npx tsx scripts/explain-detection.ts samples/sample-fenics.json
 *   npx tsx scripts/explain-detection.ts samples/sample-credit.json
 *
 * This is a self-contained walkthrough: it reads nothing but the file you give
 * it, so it can be handed to someone on its own. The production code is the
 * same sequence, split across modules:
 *
 *   src/lib/schema/adapt.ts        normalising the documents  (step 1)
 *   src/lib/detect/spoofing.ts     the spoofing checks        (step 3)
 *   src/lib/detect/layering.ts     the layering checks        (step 4)
 *   src/lib/detect/bestExecution.ts the best execution checks (step 5)
 *
 * Two things production has that a standalone script cannot: a market
 * reference series per instrument (levels, volatility, average daily volume)
 * and a counterparty registry. Where those are needed, this script derives a
 * stand-in from the file itself and says so. The gates and the arithmetic are
 * otherwise identical.
 */
import fs from "node:fs";

/* ------------------------------------------------------------------ */
/* Every knob in one place, so nothing below is hidden                 */
/* ------------------------------------------------------------------ */

const CONFIG = {
  spoofing: {
    threshold_usd: 12_000,
    max_order_life_seconds: 60,
    min_display_ratio: 0.7,
    min_competitiveness: 0.5,
    min_opposite_ratio: 0.15,
  },
  layering: {
    threshold_usd: 12_000,
    min_price_levels: 4,
    max_order_life_seconds: 120,
    cancel_ratio_threshold: 0.8,
    min_competitiveness: 0.35,
    cluster_gap_seconds: 60,
  },
  bestExecution: {
    threshold_usd: 15_000,
    min_detriment_bps: 25,
    reference_window_seconds: 300,
    min_notional_usd: 250_000,
  },
  /**
   * The market impact model needs volatility and average daily traded volume
   * per instrument. Production reads them from the instrument reference data;
   * here they are stated as assumptions for a corporate bond so the arithmetic
   * stays visible.
   *
   *   level impact = K x daily volatility x (notional / ADTV)
   */
  impact: {
    K: 3,
    daily_volatility: 0.004,
    adtv_usd: 800_000_000,
    half_spread: 0.00005,
    /** How far from the market an order stops counting as competitive. */
    competitive_scale_bps: 8,
  },
  /**
   * Which counterparties are clients. Production resolves this from the
   * counterparty registry, or from patterns supplied on the import page,
   * because both clients and dealers arrive as Counterparty.Professional.
   */
  clientCodePattern: /^CP-CL/,
};

/* ------------------------------------------------------------------ */
/* Printing helpers                                                    */
/* ------------------------------------------------------------------ */

const usd = (v: number) => "$" + Math.round(v).toLocaleString("en-US");
const bps = (fraction: number) => `${(fraction * 10_000).toFixed(2)} bps`;
const secs = (ms: number) => `${(ms / 1000).toFixed(1)}s`;
const time = (ms: number) => new Date(ms).toISOString().slice(11, 23);

function heading(n: string, title: string) {
  console.log(`\n${"=".repeat(78)}\nSTEP ${n}  ${title}\n${"=".repeat(78)}`);
}

type Check = readonly [label: string, pass: boolean, detail: string];

interface Candidate {
  title: string;
  /** Extra context lines printed above the gates. */
  context: string[];
  checks: Check[];
  passed: boolean;
  usd: number;
  /** Arithmetic lines printed once every gate passes. */
  workings: string[];
}

function printCandidate(c: Candidate, threshold: number) {
  console.log(`\n-- ${c.title}`);
  for (const line of c.context) console.log(`      ${line}`);
  for (const [label, pass, detail] of c.checks) {
    console.log(`   ${pass ? "PASS" : "FAIL"}  ${label.padEnd(34)} ${detail}`);
  }
  for (const line of c.workings) console.log(`         ${line}`);
  if (c.passed) {
    console.log(
      `         ${"verdict".padEnd(28)}${c.usd > threshold ? "ALERT" : "below threshold"} (threshold ${usd(threshold)})`,
    );
  }
}

/**
 * Narrate the highest-scoring cases, then one near miss, because the gate that
 * stopped something is as informative as the ones that let it through.
 */
function narrate(candidates: Candidate[], threshold: number, topN = 2) {
  const alerts = candidates.filter((c) => c.passed && c.usd > threshold).sort((a, b) => b.usd - a.usd);
  for (const c of alerts.slice(0, topN)) printCandidate(c, threshold);

  const nearMiss = candidates
    .filter((c) => !c.passed && c.checks.filter(([, ok]) => !ok).length === 1)
    .sort((a, b) => b.checks.length - a.checks.length)[0];
  if (nearMiss) {
    console.log("\n   (one near miss, to show what the gates stop)");
    printCandidate(nearMiss, threshold);
  }
  if (!alerts.length) console.log("\n   nothing cleared every gate in this file.");
}

/* ------------------------------------------------------------------ */
/* STEP 1 — normalise the documents                                    */
/* ------------------------------------------------------------------ */

interface OrderEvent {
  type: string;
  eventId: string;
  ms: number;
  limitPrice: number | null;
  totalAmount: number | null;
  displayAmount: number | null;
  fillPrice: number | null;
  fillAmount: number | null;
  counterpartyCode: string | null;
  counterpartyName: string | null;
  venue: string | null;
}

interface OrderStream {
  orderId: string;
  traderId: string;
  instrument: string;
  currency: string;
  /** +1 = bid (buying), -1 = offer (selling). */
  side: 1 | -1;
  sideKnown: boolean;
  startMs: number;
  endMs: number;
  placed: number;
  displayed: number;
  filled: number;
  cancelledUnfilled: boolean;
  amendments: number;
  priceLevels: number[];
  events: OrderEvent[];
}

interface Fill {
  orderId: string;
  traderId: string;
  instrument: string;
  ms: number;
  price: number;
  amount: number;
  /** +1 = the firm bought, -1 = the firm sold. Inherited from the order side. */
  direction: 1 | -1;
  counterpartyCode: string | null;
  counterpartyName: string | null;
  isClient: boolean;
}

/** Fenics timestamps have microseconds and no zone marker; they are UTC. */
function parseTime(raw: unknown): number {
  if (typeof raw !== "string") return NaN;
  const m = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2}):(\d{2})(?:\.(\d{1,6}))?/.exec(raw);
  if (m) {
    const micro = (m[7] ?? "0").padEnd(6, "0");
    return Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +m[6], Math.round(+micro / 1000));
  }
  const d = Date.parse(raw);
  return Number.isFinite(d) ? d : NaN;
}

/** Numbers arrive as strings in the Fenics schema. */
const num = (v: unknown): number | null => {
  if (typeof v === "number") return v;
  if (typeof v === "string" && v.trim() !== "") {
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
  }
  return null;
};

const path = (obj: unknown, p: string): unknown =>
  p.split(".").reduce<unknown>((cur, key) => {
    if (cur === null || typeof cur !== "object") return undefined;
    return (cur as Record<string, unknown>)[key];
  }, obj);

function normalise(documents: Record<string, unknown>[]) {
  const orders: OrderStream[] = [];
  const fills: Fill[] = [];
  const skipped: Record<string, number> = {};
  const note = (reason: string) => {
    skipped[reason] = (skipped[reason] ?? 0) + 1;
  };

  for (const doc of documents) {
    // Only order-stream documents carry order behaviour. Everything else — a
    // CDS trade, a swaption, an FX spot — is an execution record with no
    // placement or cancellation, so layering and spoofing cannot be evidenced
    // from it at all.
    if (path(doc, "Execution.Type") !== "Execution.OrderStream") {
      note(`not an order stream (${String(path(doc, "Execution.Economics.Type") ?? "unknown product")})`);
      continue;
    }

    const isin = path(doc, "Execution.Economics.Identifier.ISINCode");
    const startMs = parseTime(path(doc, "Execution.OrderStartDate"));
    if (typeof isin !== "string" || !Number.isFinite(startMs)) {
      note("missing ISIN or unparseable start date");
      continue;
    }

    const rawEvents = path(doc, "Execution.Events");
    const events: OrderEvent[] = [];
    if (Array.isArray(rawEvents)) {
      for (const e of rawEvents as Record<string, unknown>[]) {
        const ms = parseTime(e.EventDateTime);
        if (!Number.isFinite(ms)) continue;
        // Event objects carry different fields depending on Type: an open or
        // amendment has a limit price and sizes, a fill has a price, an amount,
        // a counterparty and a venue, a close has only a timestamp.
        events.push({
          type: String(e.Type ?? "").replace(/^OrderEvent\./, ""),
          eventId: String(e.EventID ?? ""),
          ms,
          limitPrice: num(e.LimitPrice),
          totalAmount: num(e.TotalAmount),
          displayAmount: num(e.DisplayAmount),
          fillPrice: num(e.Price),
          fillAmount: num(e.Amount),
          counterpartyCode: (path(e, "Counterparty.CounterpartyCode") as string) ?? null,
          counterpartyName: (path(e, "Counterparty.CounterpartyName") as string) ?? null,
          venue: (path(e, "Venue.VenueName") as string) ?? null,
        });
      }
    }
    events.sort((a, b) => a.ms - b.ms);
    if (!events.length) {
      note("order stream with no usable events");
      continue;
    }

    const open = events.find((e) => e.type === "OpenLimitOrder");
    const orderFills = events.filter((e) => e.type === "Fill");
    const closes = events.filter((e) => e.type === "Close" || e.type === "Cancel");
    const amendments = events.filter((e) => e.type === "Amendment");

    // The schema carries no explicit buy/sell, so a negative amount is the
    // convention for the sell side. Where a feed only ever sends positive
    // numbers the side is unknown and gets flagged — on the import page you can
    // point at a real side field instead.
    const signed = [
      num(path(doc, "Execution.Economics.PrincipalAmount")),
      open?.totalAmount ?? null,
      ...orderFills.map((f) => f.fillAmount),
    ].filter((n): n is number => n !== null && n !== 0);
    const side: 1 | -1 = signed.some((n) => n < 0) ? -1 : 1;
    const sideKnown = signed.some((n) => n < 0) || signed.length === 0;

    const placed = Math.abs(open?.totalAmount ?? 0);
    const displayed = Math.abs(open?.displayAmount ?? placed);
    const filled = orderFills.reduce((s, f) => s + Math.abs(f.fillAmount ?? 0), 0);
    const priceLevels = [
      ...new Set(
        events
          .map((e) => e.limitPrice)
          .filter((v): v is number => v !== null)
          .map((v) => Number(v.toFixed(6))),
      ),
    ];
    const endMs = Math.max(startMs, ...events.map((e) => e.ms));

    orders.push({
      orderId: String(path(doc, "Execution.OrderMessageID") ?? ""),
      traderId: String(path(doc, "Execution.TraderID") ?? "unknown"),
      instrument: `BOND:${isin}`,
      currency: (path(doc, "Execution.Economics.PriceCurrency.ISOCode") as string) ?? "USD",
      side,
      sideKnown,
      startMs,
      endMs,
      placed,
      displayed,
      filled,
      // "Cancelled without filling" is the signature both order metrics turn on.
      cancelledUnfilled: closes.length > 0 && filled < placed * 0.1,
      amendments: amendments.length,
      priceLevels,
      events,
    });

    for (const f of orderFills) {
      const code = f.counterpartyCode;
      fills.push({
        orderId: String(path(doc, "Execution.OrderMessageID") ?? ""),
        traderId: String(path(doc, "Execution.TraderID") ?? "unknown"),
        instrument: `BOND:${isin}`,
        ms: f.ms,
        price: f.fillPrice ?? 0,
        amount: Math.abs(f.fillAmount ?? 0),
        direction: side,
        counterpartyCode: code,
        counterpartyName: f.counterpartyName,
        isClient: !!code && CONFIG.clientCodePattern.test(code),
      });
    }
  }

  return { orders, fills, skipped };
}

/* ------------------------------------------------------------------ */
/* STEP 2 — a stand-in for the market level                            */
/* ------------------------------------------------------------------ */

/**
 * Both order metrics need to know how close to the market an order sat, and
 * best execution needs a fallback reference price. Production reads a market
 * reference series. Here the level is taken from what was actually printing on
 * the same instrument nearby — the median fill price within half an hour,
 * falling back to the median limit price on the instrument.
 */
function marketLevelFn(orders: OrderStream[], fills: Fill[]) {
  const fillsBy = new Map<string, Fill[]>();
  for (const f of fills) {
    const arr = fillsBy.get(f.instrument) ?? [];
    arr.push(f);
    fillsBy.set(f.instrument, arr);
  }
  const limitsBy = new Map<string, number[]>();
  for (const o of orders) {
    const arr = limitsBy.get(o.instrument) ?? [];
    arr.push(...o.priceLevels);
    limitsBy.set(o.instrument, arr);
  }
  const median = (xs: number[]) => {
    if (!xs.length) return 0;
    const s = xs.slice().sort((a, b) => a - b);
    return s[Math.floor(s.length / 2)];
  };

  return (instrument: string, ms: number): number => {
    const near = (fillsBy.get(instrument) ?? []).filter(
      (f) => Math.abs(f.ms - ms) <= 30 * 60_000 && f.price > 0,
    );
    if (near.length) return median(near.map((f) => f.price));
    return median(limitsBy.get(instrument) ?? []);
  };
}

/** level impact = K x volatility x (notional / ADTV), capped. */
function levelImpact(notionalUsd: number): number {
  const { K, daily_volatility, adtv_usd } = CONFIG.impact;
  return Math.min(0.05, K * daily_volatility * (Math.abs(notionalUsd) / adtv_usd));
}

/**
 * How close to the market the order sat: 1 means at or through it, 0 means far
 * enough away that nobody would react to it. A bid below the market and an
 * offer above it are both "away".
 */
function competitiveness(order: OrderStream, level: number): number {
  const limit = order.priceLevels[0];
  if (!level || limit === undefined) return 0;
  const awayBps = ((order.side > 0 ? level - limit : limit - level) / level) * 10_000;
  return Math.max(0, Math.min(1, 1 - awayBps / CONFIG.impact.competitive_scale_bps));
}

/* ------------------------------------------------------------------ */
/* STEP 3 — Spoofing                                                   */
/* ------------------------------------------------------------------ */

/**
 * One large, visible order placed at the touch and pulled without filling,
 * while the trader executes on the other side.
 *
 *   Narrative         = order impact, weighted by how competitive and how
 *                       visible it was, applied to the notional executed the
 *                       other way
 *   Counter-Narrative = cost of unwinding had it actually filled, scaled by
 *                       how long it was exposed to that risk
 *   USD Value         = Narrative - Counter-Narrative
 */
function findSpoofing(
  orders: OrderStream[],
  fills: Fill[],
  level: (i: string, ms: number) => number,
) {
  const p = CONFIG.spoofing;
  const candidates: Candidate[] = [];

  for (const order of orders) {
    const lifeMs = order.endMs - order.startMs;
    const displayRatio = order.placed ? order.displayed / order.placed : 0;
    const mkt = level(order.instrument, order.startMs);
    const comp = competitiveness(order, mkt);
    // Notional in USD. The sample bonds are quoted per 100 of face, so face
    // value is a good enough proxy for the notional at risk.
    const notionalUsd = order.placed;

    // Everything the trader executed the other way while this order rested.
    const opposite = fills.filter(
      (f) =>
        f.instrument === order.instrument &&
        f.traderId === order.traderId &&
        f.direction === (order.side > 0 ? -1 : 1) &&
        f.ms >= order.startMs - 60_000 &&
        f.ms <= order.endMs + 120_000,
    );
    const oppositeUsd = opposite.reduce((s, f) => s + f.amount, 0);

    const checks = [
      ["cancelled without filling", order.cancelledUnfilled, `filled ${order.filled} of ${order.placed}`],
      ["order life within limit", lifeMs <= p.max_order_life_seconds * 1000, `${secs(lifeMs)} vs ${p.max_order_life_seconds}s`],
      ["displayed share", displayRatio >= p.min_display_ratio, `${(displayRatio * 100).toFixed(0)}% vs ${(p.min_display_ratio * 100).toFixed(0)}%`],
      ["competitive enough", comp >= p.min_competitiveness, `${comp.toFixed(2)} vs ${p.min_competitiveness}`],
      ["executed the other way", oppositeUsd >= p.min_opposite_ratio * notionalUsd, `${usd(oppositeUsd)} vs ${usd(p.min_opposite_ratio * notionalUsd)}`],
    ] as const;

    const passed = checks.every(([, ok]) => ok);

    const impact = levelImpact(notionalUsd);
    const weighted = comp * displayRatio * impact;
    const narrative = weighted * Math.min(oppositeUsd, notionalUsd);
    const exposure = Math.min(1, lifeMs / (5 * 60_000));
    const unwind = notionalUsd * exposure * (CONFIG.impact.half_spread + 0.5 * impact);
    const usdValue = narrative - unwind;

    candidates.push({
      title:
        `order ${order.orderId} | ${order.instrument} | ${order.side > 0 ? "bid" : "offer"} ` +
        `${order.placed.toLocaleString("en-US")} @ ${order.priceLevels[0]} | market ~${mkt.toFixed(4)}`,
      context: [],
      checks: [...checks],
      passed,
      usd: passed ? usdValue : 0,
      workings: passed
        ? [
            `${"order impact".padEnd(28)}${bps(impact)} of level`,
            `${"weighted by comp x display".padEnd(28)}${bps(weighted)}`,
            `${"Narrative".padEnd(28)}${bps(weighted)} x ${usd(Math.min(oppositeUsd, notionalUsd))} = ${usd(narrative)}`,
            `${"Counter-Narrative".padEnd(28)}${usd(notionalUsd)} x ${exposure.toFixed(2)} exposure x ${bps(CONFIG.impact.half_spread + 0.5 * impact)} = ${usd(unwind)}`,
            `${"USD Value".padEnd(28)}${usd(narrative)} - ${usd(unwind)} = ${usd(usdValue)}`,
          ]
        : [],
    });
  }
  return candidates;
}

/* ------------------------------------------------------------------ */
/* STEP 4 — Layering                                                   */
/* ------------------------------------------------------------------ */

/**
 * Spoofing in depth: several orders at successive price levels on one side,
 * building an impression of weight behind the price, pulled together. The
 * number of distinct price levels is what separates it from a trader
 * legitimately working one order.
 */
function findLayering(
  orders: OrderStream[],
  fills: Fill[],
  level: (i: string, ms: number) => number,
) {
  const p = CONFIG.layering;
  const candidates: Candidate[] = [];

  // Group a trader's orders on one instrument and side, per day, then split
  // into bursts placed close together.
  const books = new Map<string, OrderStream[]>();
  for (const o of orders) {
    const key = `${o.traderId}|${o.instrument}|${o.side > 0 ? "bid" : "offer"}|${new Date(o.startMs)
      .toISOString()
      .slice(0, 10)}`;
    const arr = books.get(key) ?? [];
    arr.push(o);
    books.set(key, arr);
  }

  for (const [key, book] of books) {
    const sorted = book.slice().sort((a, b) => a.startMs - b.startMs);
    const clusters: OrderStream[][] = [];
    let cur: OrderStream[] = [];
    for (const o of sorted) {
      if (!cur.length || o.startMs - cur[cur.length - 1].startMs <= p.cluster_gap_seconds * 1000) {
        cur.push(o);
      } else {
        clusters.push(cur);
        cur = [o];
      }
    }
    if (cur.length) clusters.push(cur);

    for (const ladder of clusters) {
      if (ladder.length < 2) continue;

      const levels = new Set<number>();
      for (const o of ladder) for (const l of o.priceLevels) levels.add(Number(l.toFixed(6)));
      const totalUsd = ladder.reduce((s, o) => s + o.placed, 0);
      const cancelledUsd = ladder.filter((o) => o.cancelledUnfilled).reduce((s, o) => s + o.placed, 0);
      const cancelRatio = totalUsd ? cancelledUsd / totalUsd : 0;
      const avgLife = ladder.reduce((s, o) => s + (o.endMs - o.startMs), 0) / ladder.length;
      const first = ladder[0];
      const mkt = level(first.instrument, first.startMs);
      const comp = ladder.reduce((s, o) => s + competitiveness(o, mkt) * o.placed, 0) / (totalUsd || 1);
      const amendments = ladder.reduce((s, o) => s + o.amendments, 0);

      const startMs = Math.min(...ladder.map((o) => o.startMs));
      const endMs = Math.max(...ladder.map((o) => o.endMs));
      const opposite = fills.filter(
        (f) =>
          f.instrument === first.instrument &&
          f.traderId === first.traderId &&
          f.direction === (first.side > 0 ? -1 : 1) &&
          f.ms >= startMs - 60_000 &&
          f.ms <= endMs + 120_000,
      );
      const oppositeUsd = opposite.reduce((s, f) => s + f.amount, 0);

      const checks = [
        ["orders in the ladder", ladder.length >= 2, `${ladder.length}`],
        ["distinct price levels", levels.size >= p.min_price_levels, `${levels.size} vs ${p.min_price_levels}`],
        ["cancel ratio", cancelRatio >= p.cancel_ratio_threshold, `${(cancelRatio * 100).toFixed(0)}% vs ${(p.cancel_ratio_threshold * 100).toFixed(0)}%`],
        ["average order life", avgLife <= p.max_order_life_seconds * 1000, `${secs(avgLife)} vs ${p.max_order_life_seconds}s`],
        ["competitive enough", comp >= p.min_competitiveness, `${comp.toFixed(2)} vs ${p.min_competitiveness}`],
        ["executed the other way", oppositeUsd > 0, usd(oppositeUsd)],
      ] as const;

      const passed = checks.every(([, ok]) => ok);

      // A ladder standing at several levels looks heavier than the same
      // notional at a single price.
      const depthWeight = Math.min(1.5, 0.6 + 0.12 * levels.size);
      const impact = levelImpact(totalUsd);
      const weighted = comp * depthWeight * impact;
      const narrative = weighted * Math.min(oppositeUsd, totalUsd);
      const exposure = Math.min(1, avgLife / (5 * 60_000));
      const unwind = totalUsd * exposure * (CONFIG.impact.half_spread + 0.5 * impact);
      const usdValue = narrative - unwind;

      candidates.push({
        title: `ladder ${key.split("|").slice(0, 3).join(" ")} | ${ladder.length} orders`,
        context: ladder.map(
          (o) =>
            `${time(o.startMs)}  ${o.placed.toLocaleString("en-US").padStart(12)} @ ${String(
              o.priceLevels[0],
            ).padEnd(10)} levels=${o.priceLevels.length} amend=${o.amendments} life=${secs(
              o.endMs - o.startMs,
            )} ${o.cancelledUnfilled ? "cancelled" : "filled"}`,
        ),
        checks: [...checks],
        passed,
        usd: passed ? usdValue : 0,
        workings: passed
          ? [
              `${"ladder notional".padEnd(28)}${usd(totalUsd)} across ${levels.size} levels, ${amendments} amendments`,
              `${"ladder impact".padEnd(28)}${bps(impact)}, depth weight ${depthWeight.toFixed(2)}`,
              `${"Narrative".padEnd(28)}${bps(weighted)} x ${usd(Math.min(oppositeUsd, totalUsd))} = ${usd(narrative)}`,
              `${"Counter-Narrative".padEnd(28)}${usd(unwind)}`,
              `${"USD Value".padEnd(28)}${usd(usdValue)}`,
            ]
          : [],
      });
    }
  }
  return candidates;
}

/* ------------------------------------------------------------------ */
/* STEP 5 — Best Execution                                             */
/* ------------------------------------------------------------------ */

/**
 * Was the client filled on the best terms reasonably available?
 *
 * The strongest evidence is the firm's own print: if we traded the same bond
 * at a better price minutes earlier, the client could have had that price.
 * Where there is no contemporaneous print, the market level is the fallback.
 *
 *   EMI = the price disadvantage the client suffered
 *   PTC = the client notional
 */
function findBestExecution(fills: Fill[], level: (i: string, ms: number) => number) {
  const p = CONFIG.bestExecution;
  const candidates: Candidate[] = [];

  for (const fill of fills) {
    if (!fill.isClient || fill.price <= 0) continue;
    if (fill.amount < p.min_notional_usd) continue;

    // A client selling to the firm wanted a higher price; a client buying from
    // the firm wanted a lower one.
    const clientWantedHigher = fill.direction > 0;

    const window = fills.filter(
      (f) =>
        f.instrument === fill.instrument &&
        f !== fill &&
        f.price > 0 &&
        f.ms <= fill.ms &&
        fill.ms - f.ms <= p.reference_window_seconds * 1000,
    );
    let reference = 0;
    let best: Fill | null = null;
    for (const r of window) {
      if (clientWantedHigher ? r.price > reference : reference === 0 || r.price < reference) {
        reference = r.price;
        best = r;
      }
    }
    const fromPrint = !!best;
    if (!fromPrint) reference = level(fill.instrument, fill.ms);
    if (!reference) continue;

    const detriment = clientWantedHigher ? reference - fill.price : fill.price - reference;
    const levelFraction = detriment / reference;
    // For a bond price, a move in the level is a move in value. A credit spread
    // or a rate would be multiplied through by duration first.
    const usdValue = levelFraction * fill.amount;

    const checks = [
      ["client counterparty", fill.isClient, `${fill.counterpartyName ?? "?"} (${fill.counterpartyCode})`],
      ["notional above floor", fill.amount >= p.min_notional_usd, usd(fill.amount)],
      ["worse than the reference", detriment > 0, `${detriment > 0 ? "+" : ""}${detriment.toFixed(4)} price points`],
      ["detriment above floor", levelFraction * 10_000 >= p.min_detriment_bps, `${(levelFraction * 10_000).toFixed(1)} bps vs ${p.min_detriment_bps} bps`],
    ] as const;

    const passed = checks.every(([, ok]) => ok);

    candidates.push({
      title:
        `fill on ${fill.instrument} at ${time(fill.ms)} | client ${fill.counterpartyName} ` +
        `${clientWantedHigher ? "sold to" : "bought from"} the firm`,
      context: [
        `client price ${fill.price.toFixed(4)}, amount ${usd(fill.amount)}`,
        `reference    ${reference.toFixed(4)} from ${
          fromPrint
            ? `the firm's own print ${secs(fill.ms - (best as Fill).ms)} earlier with ${(best as Fill).counterpartyName}`
            : "the market level (no contemporaneous print)"
        }`,
      ],
      checks: [...checks],
      passed,
      usd: passed ? usdValue : 0,
      workings: passed
        ? [
            `${"client detriment".padEnd(28)}${bps(levelFraction)}`,
            `${"USD Value".padEnd(28)}${bps(levelFraction)} x ${usd(fill.amount)} = ${usd(usdValue)}`,
          ]
        : [],
    });
  }
  return candidates;
}

/* ------------------------------------------------------------------ */
/* Run it                                                             */
/* ------------------------------------------------------------------ */

function main() {
  const file = process.argv[2] ?? "samples/sample-fenics.json";
  if (!fs.existsSync(file)) {
    console.error(
      `Cannot find ${file}.\nGenerate the samples first:\n  npm run seed\n  npx tsx scripts/make-sample-json.ts`,
    );
    process.exit(1);
  }

  const parsed = JSON.parse(fs.readFileSync(file, "utf8"));
  const documents: Record<string, unknown>[] = Array.isArray(parsed) ? parsed : [parsed];
  console.log(`Reading ${file}: ${documents.length.toLocaleString("en-US")} documents`);

  heading("1", "Normalise the documents into order streams and fills");
  const { orders, fills, skipped } = normalise(documents);
  console.log(`order streams: ${orders.length.toLocaleString("en-US")}`);
  console.log(`fills:         ${fills.length.toLocaleString("en-US")} (${fills.filter((f) => f.isClient).length} facing a client)`);
  for (const [reason, n] of Object.entries(skipped)) {
    console.log(`skipped:       ${n.toLocaleString("en-US")} — ${reason}`);
  }

  if (!orders.length) {
    console.log(
      [
        "",
        "No order-level data in this file, so there is nothing for Layering or Spoofing to score.",
        "Both metrics are about order behaviour — placement, display size, cancellation — and an",
        "execution-only extract (Credit, Rates, FX) simply does not contain it.",
        "",
        "Best Execution needs a comparable execution price. A bond fill and an FX rate have one; a",
        "CDS carries upfront points and a swaption carries a negotiated strike, so neither can be",
        "compared against a market level either.",
        "",
        "Run this against samples/sample-fenics.json to see all three work.",
      ].join("\n"),
    );
    return;
  }

  // Show one raw document so the shape being parsed is visible.
  const sample = documents.find(
    (d) => path(d, "Execution.Type") === "Execution.OrderStream",
  );
  if (sample) {
    const events = path(sample, "Execution.Events");
    const trimmed = {
      ...sample,
      Execution: {
        ...(sample.Execution as Record<string, unknown>),
        Events: Array.isArray(events) ? (events as unknown[]).slice(0, 3) : events,
      },
    };
    console.log("\nOne document, as it arrives (events truncated):");
    console.log(
      JSON.stringify(trimmed, null, 2)
        .split("\n")
        .map((l) => "   " + l)
        .join("\n"),
    );
  }

  const sides = { bid: orders.filter((o) => o.side > 0).length, offer: orders.filter((o) => o.side < 0).length };
  console.log(`\nafter normalisation: ${sides.bid} bids, ${sides.offer} offers, ` +
    `${orders.filter((o) => o.cancelledUnfilled).length} cancelled without filling, ` +
    `${orders.filter((o) => !o.sideKnown).length} with an inferred side`);

  heading("2", "Derive a market level per instrument");
  const level = marketLevelFn(orders, fills);
  const instruments = [...new Set(orders.map((o) => o.instrument))];
  console.log(`${instruments.length} instruments in the file. Sample levels:`);
  for (const i of instruments.slice(0, 5)) {
    const anyOrder = orders.find((o) => o.instrument === i)!;
    console.log(`   ${i.padEnd(20)} ~${level(i, anyOrder.startMs).toFixed(4)}`);
  }
  console.log(
    `\nimpact model assumption: K=${CONFIG.impact.K}, daily vol ${(CONFIG.impact.daily_volatility * 100).toFixed(
      2,
    )}%, ADTV ${usd(CONFIG.impact.adtv_usd)}`,
  );

  heading("3", "Spoofing — one conspicuous order, pulled unfilled");
  const spoofs = findSpoofing(orders, fills, level);
  console.log(`${spoofs.length} orders examined, ${spoofs.filter((c) => c.passed).length} cleared every gate.`);
  narrate(spoofs, CONFIG.spoofing.threshold_usd);

  heading("4", "Layering — a ladder across price levels");
  const ladders = findLayering(orders, fills, level);
  console.log(`${ladders.length} ladders examined, ${ladders.filter((c) => c.passed).length} cleared every gate.`);
  narrate(ladders, CONFIG.layering.threshold_usd);

  heading("5", "Best Execution — was the client filled on the best terms available?");
  const bestEx = findBestExecution(fills, level);
  console.log(`${bestEx.length} client fills examined, ${bestEx.filter((c) => c.passed).length} cleared every gate.`);
  narrate(bestEx, CONFIG.bestExecution.threshold_usd);

  heading("6", "Summary");
  const summarise = (name: string, threshold: number, rows: Candidate[]) => {
    const scored = rows.filter((r) => r.passed);
    const alerts = scored.filter((r) => r.usd > threshold);
    const sorted = alerts.map((r) => r.usd).sort((a, b) => b - a);
    console.log(
      `${name.padEnd(16)} ${String(rows.length).padStart(5)} examined  ${String(scored.length).padStart(
        4,
      )} passed gates  ${String(alerts.length).padStart(4)} above ${usd(threshold).padStart(8)}  ` +
        (sorted.length
          ? `largest ${usd(sorted[0])}, median ${usd(sorted[Math.floor(sorted.length / 2)])}`
          : ""),
    );
  };
  summarise("Spoofing", CONFIG.spoofing.threshold_usd, spoofs);
  summarise("Layering", CONFIG.layering.threshold_usd, ladders);
  summarise("Best Execution", CONFIG.bestExecution.threshold_usd, bestEx);

  console.log(
    [
      "",
      "Every number above came out of the JSON and the constants at the top of this file.",
      "Change a threshold there and the same data produces a different answer — which is the",
      "whole point of scoring in dollars rather than pattern-matching.",
    ].join("\n"),
  );
}

main();
