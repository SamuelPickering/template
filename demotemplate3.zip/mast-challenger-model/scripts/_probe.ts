import { getConfig } from "@/lib/config/store";
import { invalidateAnalysis, runAnalysis, buildContext } from "@/lib/detect/engine";
invalidateAnalysis();
const run = runAnalysis({ config: getConfig(), dataset: "imported" });
console.log("alerts:", run.alerts.length, "instances:", run.instances.length);
console.log("per metric:", run.stats.filter(s=>s.instances>0).map(s=>`${s.metric} ${s.instances}/${s.alerts}`).join(", ") || "(all zero)");
const ctx = buildContext("imported");
for (const e of ctx.executions) {
  const inst = ctx.market.instrument(e.instrument);
  console.log(` exec ${e.trade_id.slice(0,28)} ${e.instrument} price=${e.price} marketLevel=${ctx.market.level(e.instrument, e.event_ms)} knownInstrument=${!!inst}`);
}
for (const o of ctx.orders) {
  console.log(` order ${o.order_id.slice(0,26)} side=${o.side} placed=${o.placed_amount} filled=${o.filled_amount} cancelledUnfilled=${o.cancelled_unfilled} levels=${o.price_levels.length} amend=${o.amendments} usd=${o.notional_usd}`);
}
