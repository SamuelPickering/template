/**
 * Writes one sample extract per product family into samples/, straight out of
 * the generated dataset. Useful for exercising the import flow without a
 * production file to hand.
 */
import fs from "node:fs";
import { loadDocuments } from "@/lib/db/repo";

const docs = loadDocuments("synthetic");

/**
 * Each sample carries every engineered document for that family plus a slice of
 * ordinary business around it, so importing one actually produces alerts
 * instead of looking inert. The scenario tag is dropped on the way out - what
 * lands in the file is just the trade data, exactly as a real extract would be.
 */
function sampleFor(families: string[], backgroundPerFamily: number) {
  const out: Record<string, unknown>[] = [];
  for (const family of families) {
    const forFamily = docs.filter((d) => d.family === family);
    const tagged = forFamily.filter((d) => d.scenario_tag);
    const background = forFamily.filter((d) => !d.scenario_tag).slice(0, backgroundPerFamily);
    out.push(...tagged.map((d) => d.payload), ...background.map((d) => d.payload));
  }
  return out;
}

for (const family of ["credit", "rates", "fenics", "fx"] as const) {
  const subset = sampleFor([family], 400);
  const file = `samples/sample-${family}.json`;
  fs.writeFileSync(file, JSON.stringify(subset, null, 2));
  console.log(`wrote ${file} (${subset.length} documents)`);
}

const mixed = sampleFor(["credit", "rates", "fenics", "fx"], 150);
fs.writeFileSync("samples/sample-mixed.json", JSON.stringify(mixed, null, 2));
console.log(`wrote samples/sample-mixed.json (${mixed.length} documents)`);
