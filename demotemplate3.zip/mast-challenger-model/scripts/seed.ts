/**
 * Regenerates the whole synthetic dataset: traders, counterparties, the
 * instrument universe, market reference data, the event calendar, the
 * background population and the scenario-engineered instances.
 *
 * Everything is emitted as Master.Transaction documents in the Credit, Rates,
 * Fenics and FX product schemas, then read back through the same adapters the
 * import path uses.
 *
 *   npm run seed
 */
import {
  resetDb,
  insertCounterparties,
  insertDocuments,
  insertEvents,
  insertInstruments,
  insertMarketDaily,
  insertTraders,
} from "@/lib/db/repo";
import { MarketData } from "@/lib/models/market";
import { generateMarketDaily } from "@/lib/gen/market";
import { generateBackground } from "@/lib/gen/background";
import { generateEvents } from "@/lib/gen/events";
import { generateScenarios } from "@/lib/gen/scenarios";
import {
  generateCounterparties,
  generateInstruments,
  generateTraders,
} from "@/lib/gen/universe";
import { resetDocIds } from "@/lib/gen/docs";
import { businessDays } from "@/lib/time";

const END_DATE = process.env.MAST_END_DATE ?? "2026-10-09";
const N_DAYS = Number(process.env.MAST_DAYS ?? 65);
const SEED = Number(process.env.MAST_SEED ?? 20260101);

function main() {
  console.log(`Seeding ${N_DAYS} business days ending ${END_DATE} (seed ${SEED})`);
  resetDb();
  resetDocIds();

  const dates = businessDays(END_DATE, N_DAYS);
  const traders = generateTraders(SEED);
  const counterparties = generateCounterparties();
  const instruments = generateInstruments(SEED);
  const marketRows = generateMarketDaily(instruments, dates, SEED);
  const market = new MarketData(instruments, marketRows);

  insertTraders(traders);
  insertCounterparties(counterparties);
  insertInstruments(instruments);
  insertMarketDaily(marketRows);

  const byFamily = new Map<string, number>();
  for (const i of instruments) byFamily.set(i.family, (byFamily.get(i.family) ?? 0) + 1);
  console.log(`  traders: ${traders.length}, counterparties: ${counterparties.length}`);
  console.log(
    `  instruments: ${instruments.length} (${[...byFamily].map(([k, v]) => `${k} ${v}`).join(", ")})`,
  );
  console.log(`  market rows: ${marketRows.length}`);

  // Events first, so every execution prices off a market that already carries
  // the shock overlay.
  const events = generateEvents({ instruments, dates, seed: SEED });
  market.setEvents(events);
  insertEvents(events);
  console.log(`  events: ${events.length}`);

  const background = generateBackground({
    dates,
    traders,
    counterparties,
    instruments,
    market,
    seed: SEED,
  });
  insertDocuments(background);
  const bgFamilies = new Map<string, number>();
  for (const d of background) bgFamilies.set(d.family, (bgFamilies.get(d.family) ?? 0) + 1);
  console.log(
    `  background documents: ${background.length} (${[...bgFamilies]
      .map(([k, v]) => `${k} ${v}`)
      .join(", ")})`,
  );

  const scen = generateScenarios({
    dates,
    traders,
    counterparties,
    instruments,
    market,
    events,
    seed: SEED,
  });
  insertDocuments(scen.documents);
  console.log(`  scenario documents: ${scen.documents.length}`);
  const byTag = new Map<string, number>();
  for (const d of scen.documents) {
    const tag = d.scenario_tag ?? "untagged";
    byTag.set(tag, (byTag.get(tag) ?? 0) + 1);
  }
  for (const [tag, n] of [...byTag].sort()) console.log(`    ${tag}: ${n}`);

  console.log("Done.");
}

main();
