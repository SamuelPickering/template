/**
 * QA harness. Runs the detection engine against the live config and reports:
 *   - what the adapters made of the source documents
 *   - per-metric instance/alert counts and USD Value totals
 *   - per-scenario-tag recall: did each engineered instance surface, and at
 *     what USD Value (the tag is never visible to the detectors)
 *   - how much of the alert population comes from ordinary background flow
 *   - threshold sweeps and the effect of the wash trading product toggle
 *
 *   npm run qa
 */
import { loadDocuments } from "@/lib/db/repo";
import { invalidateAnalysis, runAnalysis } from "@/lib/detect/engine";
import { getConfig } from "@/lib/config/store";

const fmt = (v: number) => "$" + Math.round(v).toLocaleString("en-US");

function main() {
  invalidateAnalysis();
  const cfg = getConfig();
  const t0 = Date.now();
  const run = runAnalysis({ config: cfg });
  console.log(
    `dataset=${run.dataset} documents=${run.documents} executions=${run.executions} ` +
      `orders=${run.orders} alerts=${run.alerts.length} in ${Date.now() - t0}ms`,
  );
  if (run.adapter_problems.length) {
    console.log(`\nadapter notes (${run.adapter_problems.length} shown, first 5):`);
    for (const p of run.adapter_problems.slice(0, 5)) console.log(`  ${p}`);
  }

  console.log("\nmetric                    instances  alerts  threshold        total USD");
  for (const s of run.stats) {
    console.log(
      s.metric.padEnd(24),
      String(s.instances).padStart(9),
      String(s.alerts).padStart(7),
      fmt(s.threshold).padStart(10),
      fmt(s.usd_total).padStart(16),
    );
  }

  // ---- scenario coverage ----
  const tagged = loadDocuments("synthetic").filter((d) => d.scenario_tag);
  const tagOfDoc = new Map(tagged.map((d) => [d.doc_id, d.scenario_tag!]));
  const byTag = new Map<string, { docs: number; alerts: number[] }>();
  for (const d of tagged) {
    const e = byTag.get(d.scenario_tag!) ?? { docs: 0, alerts: [] };
    e.docs++;
    byTag.set(d.scenario_tag!, e);
  }
  const docOfExec = (execId: string) => execId.split(":")[0];
  for (const a of run.alerts) {
    const tags = new Set<string>();
    for (const id of a.exec_ids) {
      const tag = tagOfDoc.get(docOfExec(id));
      if (tag) tags.add(tag);
    }
    for (const id of a.order_ids) {
      const tag = tagOfDoc.get(id);
      if (tag) tags.add(tag);
    }
    for (const tag of tags) byTag.get(tag)!.alerts.push(a.usd_value);
  }

  console.log("\nscenario tag                  docs  alerts    median USD        max USD");
  for (const [tag, v] of [...byTag].sort()) {
    const sorted = v.alerts.slice().sort((a, b) => a - b);
    const med = sorted.length ? sorted[Math.floor(sorted.length / 2)] : 0;
    const max = sorted.length ? sorted[sorted.length - 1] : 0;
    console.log(
      tag.padEnd(28),
      String(v.docs).padStart(5),
      String(v.alerts.length).padStart(7),
      fmt(med).padStart(14),
      fmt(max).padStart(14),
    );
  }

  console.log("\nalerts with no engineered document in them (background flow):");
  const counts = new Map<string, number>();
  for (const a of run.alerts) {
    const tagged2 =
      a.exec_ids.some((id) => tagOfDoc.has(docOfExec(id))) ||
      a.order_ids.some((id) => tagOfDoc.has(id));
    if (!tagged2) counts.set(a.metric, (counts.get(a.metric) ?? 0) + 1);
  }
  for (const s of run.stats) {
    console.log(
      `  ${s.metric.padEnd(24)} ${String(counts.get(s.metric) ?? 0).padStart(5)} of ${String(s.alerts).padStart(5)}`,
    );
  }

  // ---- alerts by product family ----
  const byFamily = new Map<string, number>();
  for (const a of run.alerts) byFamily.set(a.family, (byFamily.get(a.family) ?? 0) + 1);
  console.log(
    "\nalerts by product family: " +
      [...byFamily].map(([k, v]) => `${k} ${v}`).join(", "),
  );

  // ---- live config behaviour ----
  console.log("\nthreshold sweep (alerts at each USD Value threshold):");
  for (const metric of ["ramping", "wash_trading", "spoofing", "layering", "best_execution"] as const) {
    const row: string[] = [];
    for (const th of [5_000, 15_000, 50_000, 250_000, 1_000_000]) {
      const cfg2 = structuredClone(cfg);
      cfg2[metric].threshold_usd_value = th;
      const r = runAnalysis({ config: cfg2 });
      row.push(`${fmt(th)}: ${r.stats.find((s) => s.metric === metric)!.alerts}`);
    }
    console.log(`  ${metric.padEnd(16)} ${row.join("   ")}`);
  }

  const cfg3 = structuredClone(cfg);
  cfg3.wash_trading.require_same_product = 1;
  const r3 = runAnalysis({ config: cfg3 });
  console.log(
    `\nwash trading alerts: ${run.stats.find((s) => s.metric === "wash_trading")!.alerts} with any product, ` +
      `${r3.stats.find((s) => s.metric === "wash_trading")!.alerts} when both legs must be the same product`,
  );
}

main();
