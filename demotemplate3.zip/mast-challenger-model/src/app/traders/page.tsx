import Link from "next/link";
import { currentRun, traderRows } from "@/lib/queries";
import { fmtUsd } from "@/lib/format";

export const dynamic = "force-dynamic";

export default function TradersPage() {
  const run = currentRun();
  const rows = traderRows(run);

  return (
    <>
      <h1>Traders</h1>
      <p className="note">
        Every trader in the active dataset, taken from the data itself. Traders with an open alert
        are shown in red with the abuse types flagged; everyone else is listed with their activity
        regardless. Click a name for their blotter.
      </p>

      <p className="stats">
        <span>
          <b>Traders:</b> {rows.length}
        </span>
        <span>
          <b>With alerts:</b> {rows.filter((r) => r.alerts > 0).length}
        </span>
        <span>
          <b>Total USD Value:</b> {fmtUsd(rows.reduce((s, r) => s + r.usd_value, 0))}
        </span>
        <span>
          <b>From the data:</b> {rows.filter((r) => r.fromData).length}
        </span>
      </p>
      {rows.length > 0 && rows.every((r) => r.alerts === 0) && (
        <p className="note">
          No alerts in this dataset at the current thresholds. The traders and their activity are
          listed anyway — a clean run is a result, not an empty page.
        </p>
      )}

      <table>
        <thead>
          <tr>
            <th>Trader</th>
            <th>ID</th>
            <th>Primary role</th>
            <th className="n">Executions</th>
            <th className="n">Orders</th>
            <th className="n">Notional</th>
            <th className="n">Alerts</th>
            <th className="n">USD Value</th>
            <th>Market abuse flagged</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.trader_id} className={r.alerts ? "alerted" : ""}>
              <td className={r.alerts ? "trader-alert" : ""}>
                <Link href={`/blotter?trader=${r.trader_id}`}>{r.name}</Link>
              </td>
              <td className="mono">{r.trader_id}</td>
              <td>{r.trade_role === "prop" ? "own risk" : "client facilitation"}</td>
              <td className="n">{r.executions.toLocaleString("en-US")}</td>
              <td className="n">{r.orders ? r.orders.toLocaleString("en-US") : ""}</td>
              <td className="n">{fmtUsd(r.notional_usd)}</td>
              <td className="n">{r.alerts || ""}</td>
              <td className="n">{r.usd_value ? fmtUsd(r.usd_value) : ""}</td>
              <td className="abuse">
                {r.abuses.map((a) => `${a.label} (${a.count})`).join(", ")}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}
