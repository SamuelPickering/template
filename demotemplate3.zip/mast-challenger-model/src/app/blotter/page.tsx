import Link from "next/link";
import { getDataset } from "@/lib/config/store";
import {
  currentRun,
  distinctValues,
  queryExecutions,
  queryOrders,
  traderAbuse,
} from "@/lib/queries";
import { fmtAmount, fmtDateTime, fmtLevel, fmtUsd } from "@/lib/format";

export const dynamic = "force-dynamic";

const PAGE_SIZE = 150;

export default async function Blotter({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | undefined>>;
}) {
  const sp = await searchParams;
  const dataset = getDataset();
  const page = Math.max(0, Number(sp.page ?? 0) || 0);
  const view = sp.view === "orders" ? "orders" : "executions";
  const run = currentRun();
  const abuseOf = traderAbuse(run);

  const filters = {
    trader: sp.trader,
    instrument: sp.instrument,
    family: sp.family,
    product: sp.product,
    date: sp.date,
    role: sp.role,
    search: sp.q,
    onlyAlerts: sp.alerts === "1",
    limit: PAGE_SIZE,
    offset: page * PAGE_SIZE,
  };

  // Both are run so the tab labels can carry counts, which is how you see at a
  // glance that an order-driven feed has far more orders than fills.
  const execResult = queryExecutions(run, filters);
  const orderResult = queryOrders(run, filters);
  const active = view === "orders" ? orderResult : execResult;

  const opts = distinctValues();
  const pages = Math.ceil(active.total / PAGE_SIZE);
  const qs = (over: Record<string, string | number | undefined>) => {
    const p = new URLSearchParams();
    for (const [k, v] of Object.entries({ ...sp, ...over })) {
      if (v !== undefined && v !== "") p.set(k, String(v));
    }
    return `/blotter?${p.toString()}`;
  };

  const searchedTrader = sp.trader
    ? opts.traders.find(([id]) => id === sp.trader)
    : undefined;
  const searchedAbuse = sp.trader ? abuseOf(sp.trader) : [];

  return (
    <>
      <h1>Trade Blotter</h1>
      <p className="note">
        Everything in the active <b>{dataset}</b> dataset — every execution and every order,
        whether or not it is tied to an alert. Fenics order streams appear as their fills under
        Executions and in full under Orders; FX trades appear as one row per currency leg.
      </p>

      {searchedTrader && (
        <div className="box">
          <b>{searchedTrader[1]}</b>{" "}
          <span className="note">({searchedTrader[0]})</span>
          {searchedAbuse.length ? (
            <div style={{ marginTop: 4 }}>
              <span className="trader-alert">Market abuse flagged: </span>
              {searchedAbuse.map((label) => (
                <span className="pill" key={label}>
                  {label}
                </span>
              ))}
              <div className="note small" style={{ marginTop: 3 }}>
                Highlighted rows below are what those alerts are built from.
              </div>
            </div>
          ) : (
            <div className="note" style={{ marginTop: 4 }}>
              No alerts for this trader at the current thresholds — their activity is listed below
              regardless.
            </div>
          )}
        </div>
      )}

      <form method="get">
        <fieldset>
          <legend>Filters</legend>
          <input type="hidden" name="view" value={view} />
          <label className="f">
            Trader{" "}
            <select name="trader" defaultValue={sp.trader ?? ""}>
              <option value="">(all)</option>
              {opts.traders.map(([id, name]) => (
                <option key={id} value={id}>
                  {name === id ? id : `${name} (${id})`}
                </option>
              ))}
            </select>
          </label>
          <label className="f">
            Family{" "}
            <select name="family" defaultValue={sp.family ?? ""}>
              <option value="">(all)</option>
              {opts.families.map((f) => (
                <option key={f} value={f}>
                  {f}
                </option>
              ))}
            </select>
          </label>
          <label className="f">
            Product{" "}
            <select name="product" defaultValue={sp.product ?? ""}>
              <option value="">(all)</option>
              {opts.products.map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>
          </label>
          <label className="f">
            Instrument{" "}
            <select name="instrument" defaultValue={sp.instrument ?? ""}>
              <option value="">(all)</option>
              {opts.instruments.map(([key, label]) => (
                <option key={key} value={key}>
                  {label}
                </option>
              ))}
            </select>
          </label>
          <label className="f">
            Date{" "}
            <select name="date" defaultValue={sp.date ?? ""}>
              <option value="">(all)</option>
              {opts.dates.map((d) => (
                <option key={d} value={d}>
                  {d}
                </option>
              ))}
            </select>
          </label>
          <label className="f">
            Role{" "}
            <select name="role" defaultValue={sp.role ?? ""}>
              <option value="">(any)</option>
              <option value="client_facilitation">client facilitation</option>
              <option value="prop">own risk</option>
            </select>
          </label>
          <label className="f">
            <input type="checkbox" name="alerts" value="1" defaultChecked={sp.alerts === "1"} /> only
            alerted
          </label>
          <label className="f">
            Search{" "}
            <input
              name="q"
              defaultValue={sp.q ?? ""}
              size={22}
              placeholder="id, trader, counterparty, ISIN"
            />
          </label>
          <button type="submit">Apply</button> <Link href="/blotter">reset</Link>
        </fieldset>
      </form>

      <p className="small">
        View:{" "}
        {view === "executions" ? (
          <b>Executions ({execResult.total.toLocaleString("en-US")})</b>
        ) : (
          <Link href={qs({ view: "executions", page: 0 })}>
            Executions ({execResult.total.toLocaleString("en-US")})
          </Link>
        )}
        {" | "}
        {view === "orders" ? (
          <b>Orders ({orderResult.total.toLocaleString("en-US")})</b>
        ) : (
          <Link href={qs({ view: "orders", page: 0 })}>
            Orders ({orderResult.total.toLocaleString("en-US")})
          </Link>
        )}
        {"    "}
        <span className="note">
          {active.alertCount.toLocaleString("en-US")} of these are tied to an alert
        </span>
      </p>

      {pages > 1 && (
        <p className="small">
          Page {page + 1} of {pages}{" "}
          {page > 0 && <Link href={qs({ page: page - 1 })}>[prev]</Link>}{" "}
          {page + 1 < pages && <Link href={qs({ page: page + 1 })}>[next]</Link>}
        </p>
      )}

      {view === "executions" ? (
        execResult.rows.length === 0 ? (
          <p className="note">No executions match these filters.</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Trade / event</th>
                <th>Execution time</th>
                <th>Trader</th>
                <th>Instrument</th>
                <th>Product</th>
                <th>Side</th>
                <th className="n">Notional</th>
                <th className="n">USD</th>
                <th className="n">Price</th>
                <th>Counterparty</th>
                <th>Venue</th>
                <th>Book</th>
                <th>Role</th>
                <th>Market abuse</th>
              </tr>
            </thead>
            <tbody>
              {execResult.rows.map(({ execution: e, alerts }) => (
                <tr key={e.exec_id} className={alerts.length ? "alerted" : ""}>
                  <td className="mono">{e.trade_id}</td>
                  <td className="mono">{fmtDateTime(e.event_ms)}</td>
                  <td className={abuseOf(e.trader_id).length ? "trader-alert" : ""}>
                    <Link href={qs({ trader: e.trader_id, page: 0 })}>{e.trader_name}</Link>
                  </td>
                  <td className="mono">{e.instrument_label}</td>
                  <td>{e.product_type}</td>
                  <td>
                    {e.direction > 0 ? "+" : "-"}
                    {e.direction_known ? "" : "?"}
                  </td>
                  <td className="n">
                    {fmtAmount(e.notional)} {e.currency}
                  </td>
                  <td className="n">{fmtUsd(e.notional_usd)}</td>
                  <td className="n">{e.price ? fmtLevel(e.price) : "-"}</td>
                  <td>{e.counterparty_name ?? "-"}</td>
                  <td>{e.venue_name ?? "-"}</td>
                  <td className="mono">{e.book_name}</td>
                  <td>{e.trade_role === "prop" ? "own risk" : "client"}</td>
                  <td className="abuse">
                    {alerts.map((a) => (
                      <span key={a.instance_id}>
                        <Link href={`/instance/${encodeURIComponent(a.instance_id)}`}>
                          {a.label}
                        </Link>{" "}
                      </span>
                    ))}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )
      ) : orderResult.rows.length === 0 ? (
        <p className="note">
          No orders match these filters. Only order-stream feeds (Fenics) carry orders — a Credit,
          Rates or FX extract has executions only.
        </p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Order</th>
              <th>Placed</th>
              <th>Trader</th>
              <th>Instrument</th>
              <th>Side</th>
              <th className="n">Placed size</th>
              <th className="n">Displayed</th>
              <th className="n">Filled</th>
              <th className="n">Limit</th>
              <th className="n">Levels</th>
              <th className="n">Amend</th>
              <th className="n">Life</th>
              <th>Outcome</th>
              <th>Book</th>
              <th>Market abuse</th>
            </tr>
          </thead>
          <tbody>
            {orderResult.rows.map(({ order: o, alerts }) => (
              <tr key={o.order_id} className={alerts.length ? "alerted" : ""}>
                <td className="mono">{o.order_id}</td>
                <td className="mono">{fmtDateTime(o.start_ms)}</td>
                <td className={abuseOf(o.trader_id).length ? "trader-alert" : ""}>
                  <Link href={qs({ trader: o.trader_id, page: 0 })}>{o.trader_name}</Link>
                </td>
                <td className="mono">{o.instrument_label}</td>
                <td>
                  {o.side > 0 ? "bid" : "offer"}
                  {o.side_known ? "" : "?"}
                </td>
                <td className="n">{fmtAmount(o.placed_amount)}</td>
                <td className="n">{fmtAmount(o.display_amount)}</td>
                <td className="n">{fmtAmount(o.filled_amount)}</td>
                <td className="n">
                  {o.price_levels.length ? fmtLevel(o.price_levels[0]) : "-"}
                </td>
                <td className="n">{o.price_levels.length}</td>
                <td className="n">{o.amendments}</td>
                <td className="n">{((o.end_ms - o.start_ms) / 1000).toFixed(1)}s</td>
                <td>
                  {o.filled_amount >= o.placed_amount * 0.999
                    ? "filled"
                    : o.cancelled_unfilled
                      ? "cancelled unfilled"
                      : o.filled_amount > 0
                        ? "part filled"
                        : "open"}
                </td>
                <td className="mono">{o.book_name}</td>
                <td className="abuse">
                  {alerts.map((a) => (
                    <span key={a.instance_id}>
                      <Link href={`/instance/${encodeURIComponent(a.instance_id)}`}>{a.label}</Link>{" "}
                    </span>
                  ))}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      <p className="note small">
        Side: + acquires risk (buys the bond, pays fixed, buys protection, buys the currency), -
        sheds it. A ? means the source carried no side field and the direction was inferred from
        the sign of the amount.
      </p>
    </>
  );
}
