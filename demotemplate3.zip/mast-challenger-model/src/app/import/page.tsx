import { ImportClient } from "@/components/ImportClient";
import { getDataset } from "@/lib/config/store";
import { datasetSummary } from "@/lib/queries";

export const dynamic = "force-dynamic";

const SCHEMAS = [
  {
    family: "Credit",
    product: "Credit.CDS",
    shape:
      "Master.Transaction → Execution (TradeDate, TradeID, TraderID, Counterparty) → Economics (Notional, Maturity, Price, Frequency, Currency.ISOCode, Identifier{Ticker?, Tier, Tenor}), with Unit alongside.",
    notes:
      "Identifier.Ticker is optional and absent on many records — those group under NOTICKER rather than being rejected. Tenor is a string like 60M and is bucketed onto a standard curve point, so 58M and 61M meet on the 5Y. Economics.Price is upfront points, not a traded spread, so the pricing metrics skip CDS.",
  },
  {
    family: "Rates",
    product: "IR.Swaption / IR.CapFloor / IR.FRA",
    shape:
      "Same envelope, with a polymorphic Economics object keyed on Type. Swaptions carry SwaptionStrike, PayOrReceive and swap dates; caps and floors carry Strike and TradeType; FRAs carry FixedRate and no fixing index.",
    notes:
      "Some source records arrive with incomplete Economics — those are counted and skipped. Direction comes from PayOrReceive or TradeType where present; FRAs fall back to the sign of the notional. The curve point is derived from the start and end dates, and FRAs map onto their own short-dated points because they carry no FixingIndex.",
  },
  {
    family: "Fenics",
    product: "FixedIncome.Bond (order streams)",
    shape:
      "Execution.Type = Execution.OrderStream, with OrderStartDate, OrderEndDate, OrderMessageID and an Events array: OpenLimitOrder, Amendment, Fill and Close. Numbers arrive as strings and timestamps carry microseconds with no zone marker.",
    notes:
      "Events of different types carry different fields, and an array may hold several of each. Every Fill becomes an execution in its own right; the stream as a whole is what Spoofing and Layering score. There is no side field, so a signed amount is the convention — map your own side field if the feed has one.",
  },
  {
    family: "FX",
    product: "FX.Spot",
    shape:
      "The same envelope with buy and sell currencies and amounts, the headline pair and the executed rate.",
    notes:
      "Each trade is split into one execution per non-USD leg, so a position built across several pairs lands on one synthetic instrument. Each leg's own level is implied from the other side of the trade, triangulated through USD for crosses.",
  },
];

export default function ImportPage() {
  const dataset = getDataset();
  const summary = datasetSummary();

  return (
    <>
      <h1>Import Data</h1>
      <p className="note">
        Load a production extract in one of the four product schemas, check what the adapters make
        of it, then run every metric against it instead of the synthetic population. Generated and
        imported data travel the same path, so anything that works on the simulation works here.
      </p>

      <h2>Loaded datasets</h2>
      <table>
        <thead>
          <tr>
            <th>Source</th>
            <th className="n">Documents</th>
            <th>By family</th>
          </tr>
        </thead>
        <tbody>
          {summary.map((s) => (
            <tr key={s.source}>
              <td>
                {s.source}
                {s.source === dataset ? " (active)" : ""}
              </td>
              <td className="n">{s.documents.toLocaleString("en-US")}</td>
              <td>
                {Object.entries(s.byFamily)
                  .map(([k, v]) => `${k} ${v.toLocaleString("en-US")}`)
                  .join(", ")}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <ImportClient dataset={dataset} />

      <h2>Schemas the importer understands</h2>
      <table>
        <thead>
          <tr>
            <th>Family</th>
            <th>Product type</th>
            <th>Shape</th>
            <th>Handling</th>
          </tr>
        </thead>
        <tbody>
          {SCHEMAS.map((s) => (
            <tr key={s.family}>
              <td>{s.family}</td>
              <td className="mono">{s.product}</td>
              <td className="note" style={{ whiteSpace: "normal", maxWidth: 420 }}>
                {s.shape}
              </td>
              <td className="note" style={{ whiteSpace: "normal", maxWidth: 460 }}>
                {s.notes}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <p className="note small">
        Sample extracts in the schemas above are written to samples/ by{" "}
        <span className="mono">npx tsx scripts/make-sample-json.ts</span>, if you want to exercise
        the flow before pointing it at a real file.
      </p>
    </>
  );
}
