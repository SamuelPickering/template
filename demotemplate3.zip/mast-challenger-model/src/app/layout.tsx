import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { Nav } from "@/components/Nav";
import { getDataset } from "@/lib/config/store";
import { datasetCounts } from "@/lib/queries";

export const metadata: Metadata = {
  title: "MAST Challenger Model",
  description: "Multi-asset trade surveillance challenger model",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>
        <Nav dataset={getDataset()} counts={datasetCounts()} />
        <div id="wrap">{children}</div>
      </body>
    </html>
  );
}
