import { NextResponse } from "next/server";
import { MarketData } from "@/lib/models/market";
import {
  analyseImport,
  parseImport,
  toSourceDocuments,
  type ImportFamily,
} from "@/lib/import/json";
import {
  loadCounterparties,
  loadEvents,
  loadInstruments,
  loadMarketDaily,
  loadTraders,
  replaceDocuments,
} from "@/lib/db/repo";
import { invalidateAnalysis } from "@/lib/detect/engine";
import { setDataset } from "@/lib/config/store";
import type { AdaptContext } from "@/lib/schema/adapt";
import type { ImportOverrides } from "@/lib/types";

export const maxDuration = 120;

function adaptContext(overrides?: ImportOverrides): AdaptContext {
  const market = new MarketData(loadInstruments(), loadMarketDaily());
  market.setEvents(loadEvents());
  return {
    usdRate: (ccy, ms) => market.usdRate(ccy, ms),
    traders: new Map(loadTraders().map((t) => [t.trader_id, t])),
    counterparties: new Map(loadCounterparties().map((c) => [c.counterparty_code, c])),
    overrides,
  };
}

export async function POST(req: Request) {
  const body = (await req.json()) as {
    action: "preview" | "commit";
    text: string;
    family?: ImportFamily;
    overrides?: ImportOverrides;
    activate?: boolean;
  };

  if (!body?.text || typeof body.text !== "string") {
    return NextResponse.json({ error: "No file content received." }, { status: 400 });
  }

  const parsed = parseImport(body.text);
  if (!parsed.documents.length) {
    return NextResponse.json(
      { error: parsed.errors.join(" ") || "No documents found in the file." },
      { status: 400 },
    );
  }

  const family = body.family ?? "auto";
  const { documents, rejected } = toSourceDocuments(parsed, family);
  if (!documents.length) {
    return NextResponse.json(
      {
        error:
          "None of the documents could be matched to a product schema. Choose the product type explicitly instead of letting it be detected.",
        rejected: rejected.slice(0, 10),
      },
      { status: 400 },
    );
  }

  const analysis = analyseImport(
    documents,
    rejected,
    adaptContext(body.overrides),
    new Set(loadInstruments().map((i) => i.instrument)),
  );

  if (body.action === "preview") {
    return NextResponse.json({ format: parsed.format, fileErrors: parsed.errors, analysis });
  }

  replaceDocuments("imported", documents);
  invalidateAnalysis();
  if (body.activate !== false) setDataset("imported");

  return NextResponse.json({
    imported: documents.length,
    analysis,
    activated: body.activate !== false,
  });
}
