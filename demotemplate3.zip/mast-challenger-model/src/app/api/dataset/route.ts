import { NextResponse } from "next/server";
import { getDataset, setDataset } from "@/lib/config/store";
import { deleteDocumentsBySource } from "@/lib/db/repo";
import { invalidateAnalysis } from "@/lib/detect/engine";

export async function GET() {
  return NextResponse.json({ dataset: getDataset() });
}

export async function POST(req: Request) {
  const body = (await req.json()) as {
    dataset?: "synthetic" | "imported";
    action?: "clear_imported";
  };
  if (body.action === "clear_imported") {
    deleteDocumentsBySource("imported");
    setDataset("synthetic");
    invalidateAnalysis();
    return NextResponse.json({ dataset: getDataset(), cleared: true });
  }
  if (body.dataset === "synthetic" || body.dataset === "imported") {
    setDataset(body.dataset);
  }
  return NextResponse.json({ dataset: getDataset() });
}
