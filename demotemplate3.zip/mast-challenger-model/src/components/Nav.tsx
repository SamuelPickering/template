import Link from "next/link";
import { DatasetSwitch } from "./DatasetSwitch";

const LINKS: [string, string][] = [
  ["/", "Dashboard"],
  ["/alerts", "Alerts"],
  ["/alerts/ramping", "By Metric"],
  ["/blotter", "Blotter"],
  ["/traders", "Traders"],
  ["/admin", "Admin"],
  ["/import", "Import"],
  ["/methodology", "Methodology"],
];

export function Nav({
  dataset,
  counts,
}: {
  dataset: "synthetic" | "imported";
  counts: { synthetic: number; imported: number };
}) {
  return (
    <div id="nav">
      <div>
        <b>MAST Challenger Model</b>
        {LINKS.map(([href, label], i) => (
          <span key={href}>
            {i > 0 ? " | " : " "}
            <Link href={href}>{label}</Link>
          </span>
        ))}
      </div>
      <div style={{ marginTop: 4 }}>
        <DatasetSwitch dataset={dataset} counts={counts} />
      </div>
    </div>
  );
}
