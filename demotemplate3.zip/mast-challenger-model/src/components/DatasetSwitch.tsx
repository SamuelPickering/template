"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";

/**
 * The dataset switch, in the header so it is always visible and it is always
 * obvious which data is on screen.
 *
 * Switching to imported hides the synthetic population completely — traders,
 * trades, orders and alerts all come from the imported file and nothing else.
 */
export function DatasetSwitch({
  dataset,
  counts,
}: {
  dataset: "synthetic" | "imported";
  counts: { synthetic: number; imported: number };
}) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [pending, startTransition] = useTransition();

  async function choose(next: "synthetic" | "imported") {
    if (next === dataset) return;
    setBusy(true);
    await fetch("/api/dataset", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ dataset: next }),
    });
    setBusy(false);
    startTransition(() => router.refresh());
  }

  const button = (value: "synthetic" | "imported", label: string, n: number) => {
    const active = dataset === value;
    const empty = n === 0;
    return (
      <button
        type="button"
        onClick={() => choose(value)}
        disabled={busy || empty}
        title={empty ? "Nothing loaded for this source yet" : `${n.toLocaleString("en-US")} documents`}
        style={{
          fontWeight: active ? "bold" : "normal",
          border: active ? "2px solid #a00" : "1px solid #999",
          background: active ? "#ffecec" : empty ? "#eee" : "#fff",
          color: empty ? "#888" : "#000",
          padding: "1px 6px",
          marginRight: 4,
          cursor: empty ? "default" : "pointer",
        }}
      >
        {label} ({n.toLocaleString("en-US")})
      </button>
    );
  };

  return (
    <span>
      <b>Data source:</b>{" "}
      {button("synthetic", "Synthetic", counts.synthetic)}
      {button("imported", "Imported only", counts.imported)}
      {(busy || pending) && <span className="note"> switching...</span>}
      {dataset === "imported" && (
        <span className="note">
          {" "}
          showing imported data only — no synthetic traders or trades
        </span>
      )}
    </span>
  );
}
