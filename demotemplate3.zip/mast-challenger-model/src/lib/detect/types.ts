import type { MetricId } from "@/lib/config/metrics";
import type {
  Execution,
  MarketEvent,
  OrderStream,
  ProductFamily,
  SourceDocument,
  Trader,
} from "@/lib/types";
import type { MarketData } from "@/lib/models/market";
import type { MarketImpactModel } from "@/lib/models/mim";

export type ComponentUnit =
  | "usd"
  | "bps"
  | "level"
  | "ratio"
  | "percent"
  | "count"
  | "duration"
  | "text";

/** One intermediate value shown on the alert detail page. */
export interface Component {
  label: string;
  value: number | string;
  unit: ComponentUnit;
  help: string;
}

export interface ImpactPoint {
  ms: number;
  total_bps: number;
  highlight_bps: number;
  mid: number;
}

export interface TradeMarker {
  exec_id: string | null;
  trade_id: string;
  ms: number;
  role: "impacting" | "benefiting" | "context" | "order";
  label: string;
  notional_usd: number;
}

/** A candidate instance of abuse. It becomes an alert when it clears the threshold. */
export interface Instance {
  instance_id: string;
  metric: MetricId;
  instrument: string;
  instrument_label: string;
  family: ProductFamily;
  trader_id: string;
  trader_name: string;
  book_name: string;
  counterparty_name: string | null;
  trade_date: string;
  start_ms: number;
  end_ms: number;
  usd_value: number;
  headline: string;
  explanation: string;
  components: Component[];
  exec_ids: string[];
  trade_ids: string[];
  order_ids: string[];
  markers: TradeMarker[];
  /** Present only for QA views; detectors never read it. */
  scenario_tags?: string[];
}

export interface DetectionContext {
  executions: Execution[];
  byInstrument: Map<string, Execution[]>;
  orders: OrderStream[];
  ordersByInstrument: Map<string, OrderStream[]>;
  events: MarketEvent[];
  market: MarketData;
  mim: MarketImpactModel;
  traders: Map<string, Trader>;
  execById: Map<string, Execution>;
  docById: Map<string, SourceDocument>;
}

export type Detector = (
  ctx: DetectionContext,
  params: Record<string, number>,
) => Instance[];
