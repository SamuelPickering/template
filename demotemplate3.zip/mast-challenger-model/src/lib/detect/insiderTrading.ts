import type { Execution } from "@/lib/types";
import { MS_HOUR } from "@/lib/time";
import type { Detector, Instance } from "./types";
import { groupBy, makeInstance, marker, minutesStr, usd, usdCompact } from "./util";

/**
 * Insider Trading.
 *
 * The only metric about exploiting a price move rather than causing one, so no
 * market impact is modelled. For each event we compare the position a trader
 * actually held going into the announcement against the position a fair trader
 * could have been expected to hold.
 *
 * The expectation is time-weighted: a position established well before the
 * event is ordinary business, while one established in the final hours counts
 * barely at all. What is left over is the excess, and its value at the
 * realised move is the USD Value — converted into value terms, so a move on a
 * credit spread is multiplied through by duration rather than taken at face.
 */
export const detectInsiderTrading: Detector = (ctx, p) => {
  const lookbackMs = p.lookback_hours * MS_HOUR;
  const minMove = p.min_event_move_pct / 100;
  const halfLifeMs = p.expectation_half_life_hours * MS_HOUR;
  const out: Instance[] = [];

  for (const event of ctx.events) {
    const move = event.move_pct / 100;
    if (Math.abs(move) < minMove) continue;
    const all = ctx.byInstrument.get(event.instrument);
    if (!all) continue;

    const valueMove = move * ctx.market.valueFactor(event.instrument, event.public_ms);
    if (!Number.isFinite(valueMove) || valueMove === 0) continue;

    const from = event.public_ms - lookbackMs;
    const window = all.filter((e) => e.event_ms >= from && e.event_ms <= event.public_ms);
    if (!window.length) continue;

    for (const [traderId, execs] of groupBy(window, (e) => e.trader_id)) {
      if (execs.length < 2) continue;
      let actual = 0;
      let timeWeighted = 0;
      for (const e of execs) {
        const dt = event.public_ms - e.event_ms;
        const recency = Math.pow(0.5, dt / halfLifeMs);
        const signed = e.notional_usd * e.direction;
        actual += signed;
        timeWeighted += signed * (1 - recency);
      }
      const normal = baseline(ctx, event.instrument, traderId) * Math.sign(actual || 1);
      const expected = timeWeighted + normal;
      const excess = Math.abs(actual) > Math.abs(expected) ? actual - expected : 0;
      if (!excess || Math.abs(excess) < 0.4 * Math.abs(actual)) continue;

      const usdVal = excess * valueMove;
      if (usdVal < 1) continue;

      const first = execs[0];
      const closes = closingTrades(ctx, event.instrument, traderId, event.public_ms, excess);
      const combined = [...execs, ...closes];

      out.push(
        makeInstance({
          ctx,
          metric: "insider_trading",
          instrument: event.instrument,
          family: first.family,
          traderId,
          traderName: first.trader_name,
          tradeDate: event.trade_date,
          startMs: first.event_ms,
          endMs: closes.length ? closes[closes.length - 1].event_ms : event.public_ms,
          usdValue: usdVal,
          headline: `${usdCompact(Math.abs(excess))} ${excess > 0 ? "long" : "short"} ${first.instrument_label} into "${event.headline}" (${event.move_pct > 0 ? "+" : ""}${event.move_pct}%)`,
          explanation:
            `${first.trader_name} traded ${first.instrument_label} ${execs.length} times in the ` +
            `${p.lookback_hours}-hour window before "${event.headline}" became public, ending ` +
            `${usd(Math.abs(actual))} ${actual > 0 ? "long" : "short"}. Weighting each execution by how ` +
            `long before the announcement it was placed, a fair trader would have been expected to hold ` +
            `${usd(Math.abs(expected))}, leaving an excess of ${usd(Math.abs(excess))} concentrated in the ` +
            `hours immediately before the news. The event moved the quoted level by ${event.move_pct}%, ` +
            `worth ${(valueMove * 10_000).toFixed(1)} bps of value, so the excess position was worth ` +
            `${usd(usdVal)} the moment the announcement landed.` +
            (closes.length
              ? ` The position was closed ${minutesStr(closes[0].event_ms - event.public_ms)} after the news broke.`
              : ` No closing trade was found in the same session.`),
          components: [
            { label: "Observed position", value: actual, unit: "usd", help: "Net position held on the instrument when the event became public." },
            { label: "Expected position", value: expected, unit: "usd", help: "Time-weighted position a fair trader could have been expected to hold, plus their usual book size." },
            { label: "Excess position", value: excess, unit: "usd", help: "Observed less expected — the part that only makes sense with foreknowledge." },
            { label: "Event level move", value: event.move_pct, unit: "percent", help: "Realised move in the instrument's quoted level." },
            { label: "Value of the move", value: valueMove * 10_000, unit: "bps", help: "The same move converted into value terms using the instrument's duration." },
            { label: "Event", value: `${event.headline} (${event.kind})`, unit: "text", help: "The event this instance is measured against." },
            { label: "Time to announcement", value: event.public_ms - execs[execs.length - 1].event_ms, unit: "duration", help: "Gap between the last position-building execution and the announcement." },
            { label: "Product", value: [...new Set(execs.map((e) => e.product_type))].join(", "), unit: "text", help: "Products the position was built in." },
          ],
          executions: combined,
          markers: [
            ...execs.map((e) => marker(e, "impacting", "Position built")),
            ...closes.map((e) => marker(e, "benefiting", "Closed after news")),
          ],
        }),
      );
    }
  }
  return out;
};

/** The trader's typical end-of-day position on the instrument. */
const baselineCache = new WeakMap<object, Map<string, number>>();

function baseline(ctx: Parameters<Detector>[0], instrument: string, traderId: string): number {
  let cache = baselineCache.get(ctx);
  if (!cache) {
    cache = new Map<string, number>();
    const daily = new Map<string, number>();
    for (const e of ctx.executions) {
      const k = `${e.instrument}|${e.trader_id}|${e.trade_date}`;
      daily.set(k, (daily.get(k) ?? 0) + e.notional_usd * e.direction);
    }
    const byBook = new Map<string, number[]>();
    for (const [k, v] of daily) {
      const [inst, trader] = k.split("|");
      const key = `${inst}|${trader}`;
      const arr = byBook.get(key);
      if (arr) arr.push(Math.abs(v));
      else byBook.set(key, [Math.abs(v)]);
    }
    for (const [k, arr] of byBook) {
      arr.sort((a, b) => a - b);
      cache.set(k, arr[Math.floor(arr.length / 2)]);
    }
    baselineCache.set(ctx, cache);
  }
  return cache.get(`${instrument}|${traderId}`) ?? 0;
}

function closingTrades(
  ctx: Parameters<Detector>[0],
  instrument: string,
  traderId: string,
  publicMs: number,
  excess: number,
): Execution[] {
  const all = ctx.byInstrument.get(instrument) ?? [];
  const wantDir = excess > 0 ? -1 : 1;
  return all.filter(
    (e) =>
      e.trader_id === traderId &&
      e.direction === wantDir &&
      e.event_ms > publicMs &&
      e.event_ms - publicMs <= 8 * MS_HOUR,
  );
}
