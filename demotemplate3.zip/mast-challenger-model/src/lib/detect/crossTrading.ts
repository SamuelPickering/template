import { usdValue } from "@/lib/models/usdvalue";
import { HAS_EXECUTION_PRICE } from "@/lib/schema/products";
import type { Detector, Instance } from "./types";
import { groupBy, makeInstance, marker, usd, usdCompact } from "./util";

/**
 * Cross Trading.
 *
 * Two books inside the firm taking opposite sides of the same instrument at
 * effectively the same moment. The risk moves between them without going to
 * the street, so whatever level they agree decides how much value moves from
 * one book to the other.
 *
 *   EMI = deviation of the crossed level from the prevailing market level
 *   PTC = notional crossed between the books
 */
export const detectCrossTrading: Detector = (ctx, p) => {
  const maxGapMs = p.max_timestamp_gap_seconds * 1000;
  const tol = p.size_match_tolerance_pct / 100;
  const out: Instance[] = [];
  const used = new Set<string>();

  for (const execs of groupBy(ctx.executions, (e) => `${e.instrument}|${e.trade_date}`).values()) {
    for (let i = 0; i < execs.length; i++) {
      const a = execs[i];
      if (used.has(a.exec_id)) continue;
      if (!HAS_EXECUTION_PRICE[a.product_type] || !a.price) continue;

      for (let j = i + 1; j < execs.length; j++) {
        const b = execs[j];
        const gap = b.event_ms - a.event_ms;
        if (gap > maxGapMs) break;
        if (used.has(b.exec_id)) continue;
        if (a.direction === b.direction) continue;
        if (a.trader_id === b.trader_id) continue;
        if (!HAS_EXECUTION_PRICE[b.product_type] || !b.price) continue;
        if (Math.abs(a.notional_usd - b.notional_usd) > tol * Math.max(a.notional_usd, b.notional_usd))
          continue;

        const level = ctx.market.level(a.instrument, a.event_ms);
        if (!level) continue;
        const levelDeviation = Math.abs(a.price / level - 1);
        const valueDeviation = Math.abs(
          ctx.mim.toValue(a.instrument, a.event_ms, levelDeviation),
        );
        const crossed = Math.min(a.notional_usd, b.notional_usd);
        const parts = usdValue(valueDeviation, crossed);
        if (parts.usdValue < 1) continue;

        used.add(a.exec_id);
        used.add(b.exec_id);
        const internalSides = [a, b].filter((e) => e.counterparty_kind === "internal").length;

        out.push(
          makeInstance({
            ctx,
            metric: "cross_trading",
            instrument: a.instrument,
            family: a.family,
            traderId: a.trader_id,
            traderName: a.trader_name,
            counterpartyName: a.counterparty_name,
            tradeDate: a.trade_date,
            startMs: a.event_ms,
            endMs: b.event_ms,
            usdValue: parts.usdValue,
            headline: `${usdCompact(crossed)} of ${a.instrument_label} crossed between ${
              a.trader_name
            } and ${b.trader_name} at ${(levelDeviation * 10_000).toFixed(1)} bps off market`,
            explanation:
              `${a.trader_name} and ${b.trader_name} took opposite sides of ${a.instrument_label} ` +
              `within ${(gap / 1000).toFixed(1)} seconds of each other, for ${usd(a.notional_usd)} and ` +
              `${usd(b.notional_usd)}. ` +
              (internalSides
                ? `${internalSides === 2 ? "Both sides" : "One side"} booked against an internal account, so ` +
                  `the risk moved between books rather than to the street. `
                : `Neither side went to the street. `) +
              `The agreed level of ${ctx.market.formatLevel(a.instrument, a.price)} sits ` +
              `${(levelDeviation * 10_000).toFixed(1)} bps away from the modelled market level of ` +
              `${ctx.market.formatLevel(a.instrument, level)} — ${(valueDeviation * 10_000).toFixed(1)} bps ` +
              `in value terms. Applied to the ${usd(crossed)} crossed, ${usd(parts.usdValue)} of value moved ` +
              `from one book to the other.`,
            components: [
              { label: "Expected Market Impact (EMI)", value: valueDeviation * 10_000, unit: "bps", help: "Deviation of the crossed level from the market, in value terms." },
              { label: "Level deviation", value: levelDeviation * 10_000, unit: "bps", help: "The same deviation against the instrument's quoted level." },
              { label: "Profit-Taking Component (PTC)", value: crossed, unit: "usd", help: "Notional crossed between the two books." },
              { label: "Timestamp gap", value: gap, unit: "duration", help: "Time between the two sides of the cross." },
              { label: "Crossed level", value: a.price, unit: "level", help: "Level the two books agreed." },
              { label: "Market level", value: level, unit: "level", help: "Where the market model puts the instrument at that instant." },
              { label: "Books", value: `${a.book_name} / ${b.book_name}`, unit: "text", help: "The two books on either side." },
              { label: "Product", value: [a.product_type, b.product_type].join(" / "), unit: "text", help: "Products on each side of the cross." },
            ],
            executions: [a, b],
            markers: [
              marker(a, "impacting", `${a.trader_name} side`),
              marker(b, "benefiting", `${b.trader_name} side`),
            ],
          }),
        );
        break;
      }
    }
  }
  return out;
};
