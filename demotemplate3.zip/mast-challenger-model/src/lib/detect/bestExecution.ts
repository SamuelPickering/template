import type { Execution } from "@/lib/types";
import { usdValue } from "@/lib/models/usdvalue";
import { HAS_EXECUTION_PRICE } from "@/lib/schema/products";
import type { Detector, Instance } from "./types";
import { groupBy, makeInstance, marker, minutesStr, usd, usdCompact } from "./util";

/**
 * Best Execution.
 *
 * The standard that keeps the firm aligned with both client and regulatory
 * expectations: a client order should be filled on the best terms reasonably
 * available. This is the one metric here that measures detriment to the client
 * rather than gain to the trader.
 *
 * Two kinds of evidence, in order of strength:
 *
 *  1. The firm was printing a better price on the same instrument moments
 *     earlier — on the Fenics order streams that print is in the same feed,
 *     which makes it very hard to argue with.
 *  2. No contemporaneous print, so the client fill is compared against the
 *     modelled market level instead.
 *
 *   EMI = the price disadvantage the client suffered, in value terms
 *   PTC = the client notional
 */
export const detectBestExecution: Detector = (ctx, p) => {
  const minDeviation = p.deviation_bps / 10_000;
  const windowMs = p.max_reference_gap_seconds * 1000;
  const requireClient = p.require_client_counterparty >= 0.5;
  const out: Instance[] = [];

  const byInstrument = groupBy(ctx.executions, (e) => e.instrument);

  for (const [instrument, execs] of byInstrument) {
    const priced = execs.filter((e) => HAS_EXECUTION_PRICE[e.product_type] && e.price > 0);
    if (!priced.length) continue;

    for (const fill of priced) {
      if (fill.notional_usd < p.min_notional_usd) continue;
      if (requireClient && fill.counterparty_kind !== "client") continue;
      if (!fill.counterparty_name) continue;

      // What the firm itself was printing on this instrument just before.
      const refs = priced.filter(
        (e) =>
          e.exec_id !== fill.exec_id &&
          e.event_ms <= fill.event_ms &&
          fill.event_ms - e.event_ms <= windowMs,
      );

      // A client selling to the firm wanted a higher price; a client buying
      // from the firm wanted a lower one.
      const clientWantedHigher = fill.direction > 0;
      let reference = 0;
      let referenceExec: Execution | null = null;
      for (const r of refs) {
        if (clientWantedHigher ? r.price > reference : reference === 0 || r.price < reference) {
          reference = r.price;
          referenceExec = r;
        }
      }
      let basis = "the firm's own print on the same instrument";
      if (!referenceExec) {
        reference = ctx.market.level(instrument, fill.event_ms);
        basis = "the modelled market level";
      }
      if (!reference) continue;

      const detrimentPerUnit = clientWantedHigher ? reference - fill.price : fill.price - reference;
      if (detrimentPerUnit <= 0) continue;
      const levelFraction = detrimentPerUnit / reference;
      if (levelFraction < minDeviation) continue;

      const valueFraction = Math.abs(
        ctx.mim.toValue(instrument, fill.event_ms, levelFraction),
      );
      const parts = usdValue(valueFraction, fill.notional_usd);
      if (parts.usdValue < 1) continue;

      const involved = referenceExec ? [referenceExec, fill] : [fill];

      out.push(
        makeInstance({
          ctx,
          metric: "best_execution",
          instrument,
          family: fill.family,
          traderId: fill.trader_id,
          traderName: fill.trader_name,
          counterpartyName: fill.counterparty_name,
          tradeDate: fill.trade_date,
          startMs: referenceExec ? referenceExec.event_ms : fill.event_ms,
          endMs: fill.event_ms,
          usdValue: parts.usdValue,
          headline: `${fill.counterparty_name} filled ${usdCompact(fill.notional_usd)} of ${
            fill.instrument_label
          } ${(levelFraction * 10_000).toFixed(1)} bps worse than ${
            referenceExec ? "the firm's own print" : "the market level"
          }`,
          explanation:
            `${fill.counterparty_name} was filled ${usd(fill.notional_usd)} of ${fill.instrument_label} ` +
            `at ${ctx.market.formatLevel(instrument, fill.price)}, having ` +
            `${clientWantedHigher ? "sold to" : "bought from"} the firm. Measured against ${basis} of ` +
            `${ctx.market.formatLevel(instrument, reference)}` +
            (referenceExec
              ? `, printed ${minutesStr(fill.event_ms - referenceExec.event_ms)} earlier with ` +
                `${referenceExec.counterparty_name ?? "another counterparty"}`
              : "") +
            `, the client was ${(levelFraction * 10_000).toFixed(1)} bps worse off — ` +
            `${(valueFraction * 10_000).toFixed(1)} bps in value terms. Applied to the client notional, ` +
            `${usd(parts.usdValue)} of value moved away from the client relative to the terms the firm ` +
            `could demonstrably have achieved.`,
          components: [
            { label: "Client detriment (EMI)", value: valueFraction * 10_000, unit: "bps", help: "How much worse the client's price was than the reference, in value terms." },
            { label: "Level difference", value: levelFraction * 10_000, unit: "bps", help: "The same gap expressed against the instrument's quoted level." },
            { label: "Client notional (PTC)", value: fill.notional_usd, unit: "usd", help: "Size the client was filled in." },
            { label: "Client price", value: fill.price, unit: "level", help: "Level the client was filled at." },
            { label: "Reference price", value: reference, unit: "level", help: `Best available terms, taken from ${basis}.` },
            { label: "Reference basis", value: referenceExec ? "Firm's own contemporaneous print" : "Modelled market level", unit: "text", help: "A contemporaneous print by the firm itself is the stronger evidence; the modelled level is the fallback." },
            ...(referenceExec
              ? [{ label: "Gap to reference print", value: fill.event_ms - referenceExec.event_ms, unit: "duration" as const, help: "How long before the client fill the better price was printing." }]
              : []),
            { label: "Counterparty", value: `${fill.counterparty_name} (${fill.counterparty_kind})`, unit: "text", help: "Who was on the other side of the client fill." },
            { label: "Venue", value: fill.venue_name ?? "not recorded", unit: "text", help: "Execution venue, where the source carries one." },
          ],
          executions: involved,
          markers: [
            ...(referenceExec ? [marker(referenceExec, "context", "Better print available")] : []),
            marker(fill, "impacting", "Client fill"),
          ],
        }),
      );
    }
  }
  return out;
};
