import type { Execution, OrderStream } from "@/lib/types";
import { narrativeScore } from "@/lib/models/usdvalue";
import { MS_MIN } from "@/lib/time";
import type { Detector, Instance } from "./types";
import { makeInstance, marker, minutesStr, orderMarker, usd, usdCompact } from "./util";

/**
 * Spoofing.
 *
 * A single large, fully displayed order placed at the touch and pulled without
 * filling, while the trader executes on the opposite side. Order-driven, so it
 * needs the Fenics order streams: placement, display size and cancellation.
 * An execution-only feed produces nothing here, and says so.
 *
 *   Narrative         = impact the resting order creates, weighted by how
 *                       competitive and how visible it was, applied to the
 *                       notional executed on the other side
 *   Counter-Narrative = cost of unwinding had it actually filled, scaled by
 *                       how long it was exposed to that risk
 */
const HALF_SPREAD = 0.00005;

export const detectSpoofing: Detector = (ctx, p) => {
  if (!ctx.orders.length) return [];
  const maxLifeMs = p.max_order_life_seconds * 1000;
  const out: Instance[] = [];

  for (const order of ctx.orders) {
    if (!order.cancelled_unfilled) continue;
    if (order.placed_amount <= 0 || order.notional_usd <= 0) continue;

    const lifeMs = order.end_ms - order.start_ms;
    if (lifeMs > maxLifeMs) continue;

    const displayRatio = order.placed_amount ? order.display_amount / order.placed_amount : 0;
    if (displayRatio < p.min_display_ratio) continue;

    const comp = competitiveness(ctx, order);
    if (comp < p.min_competitiveness) continue;

    // The genuine trade: same trader, same instrument, opposite side, while
    // the decoy was resting.
    const opposite = (ctx.byInstrument.get(order.instrument) ?? []).filter(
      (e) =>
        e.trader_id === order.trader_id &&
        e.direction === (order.side > 0 ? -1 : 1) &&
        e.event_ms >= order.start_ms - MS_MIN &&
        e.event_ms <= order.end_ms + 2 * MS_MIN,
    );
    const oppositeUsd = opposite.reduce((s, e) => s + e.notional_usd, 0);
    if (oppositeUsd <= 0) continue;
    if (oppositeUsd < p.min_opposite_ratio * order.notional_usd) continue;

    const levelImpact =
      comp * displayRatio * ctx.mim.magnitude(order.instrument, order.start_ms, order.notional_usd);
    const valueImpact = Math.abs(ctx.mim.toValue(order.instrument, order.start_ms, levelImpact));
    const narrative = valueImpact * Math.min(oppositeUsd, order.notional_usd);

    // Exposure to being filled scales with how long the order actually rested.
    const exposure = Math.min(1, lifeMs / (5 * MS_MIN));
    const unwind =
      order.notional_usd *
      exposure *
      (HALF_SPREAD +
        0.5 *
          Math.abs(
            ctx.mim.toValue(
              order.instrument,
              order.start_ms,
              ctx.mim.magnitude(order.instrument, order.start_ms, order.notional_usd),
            ),
          ));
    const score = narrativeScore(narrative, unwind);
    if (score.usdValue < 1) continue;

    out.push(
      makeInstance({
        ctx,
        metric: "spoofing",
        instrument: order.instrument,
        instrumentLabel: order.instrument_label,
        family: order.family,
        traderId: order.trader_id,
        traderName: order.trader_name,
        bookName: order.book_name,
        tradeDate: new Date(order.start_ms).toISOString().slice(0, 10),
        startMs: order.start_ms,
        endMs: Math.max(order.end_ms, ...opposite.map((e) => e.event_ms)),
        usdValue: score.usdValue,
        headline: `${usdCompact(order.notional_usd)} ${order.side > 0 ? "bid" : "offer"} on ${
          order.instrument_label
        } pulled after ${minutesStr(lifeMs)}, ${usdCompact(oppositeUsd)} executed the other way`,
        explanation:
          `${order.trader_name} placed a single ${order.side > 0 ? "bid" : "offer"} for ` +
          `${usd(order.notional_usd)} of ${order.instrument_label} at ` +
          `${ctx.market.formatLevel(order.instrument, order.price_levels[0] ?? 0)}, with ` +
          `${(displayRatio * 100).toFixed(0)}% of it displayed to the market — competitive enough to shift ` +
          `the visible balance of the book. It was cancelled after ${minutesStr(lifeMs)} without filling. ` +
          `While it rested, the same trader executed ${usd(oppositeUsd)} in the opposite direction on the ` +
          `same instrument. The Narrative — order impact of ${(valueImpact * 10_000).toFixed(2)} bps applied ` +
          `to that execution — is worth ${usd(narrative)}. The Counter-Narrative, the cost of unwinding had ` +
          `the order been filled, is ${usd(unwind)} once scaled by how briefly it was exposed. ` +
          `Narrative less Counter-Narrative = ${usd(score.usdValue)}.`,
        components: [
          { label: "Narrative", value: narrative, unit: "usd", help: "Visibility- and competitiveness-weighted order impact applied to the notional executed the other way." },
          { label: "Counter-Narrative", value: unwind, unit: "usd", help: "Theoretical cost of unwinding the order had it filled, scaled by how long it rested." },
          { label: "Order notional", value: order.notional_usd, unit: "usd", help: "Size placed." },
          { label: "Displayed share", value: displayRatio, unit: "ratio", help: "How much of the order was visible. Spoofing depends on being seen." },
          { label: "Competitiveness", value: comp, unit: "ratio", help: "1 means the order sat at or through the market, 0 means far away from it." },
          { label: "Order life", value: lifeMs, unit: "duration", help: "How long the order rested before being pulled." },
          { label: "Executed the other way", value: oppositeUsd, unit: "usd", help: "Notional the trader executed in the opposite direction while the order rested." },
          { label: "Filled", value: order.filled_amount, unit: "count", help: "Amount of the order that actually traded. Spoofing is characterised by this being nil." },
          { label: "Side basis", value: order.side_known ? "from the feed" : "inferred — no side field in the source", unit: "text", help: "The Fenics structure carries no explicit side, so a signed amount is the convention. Map a side field on import to remove the assumption." },
        ],
        executions: opposite,
        orderIds: [order.order_id],
        markers: [
          orderMarker(order, `Decoy ${order.side > 0 ? "bid" : "offer"}`),
          ...opposite.map((e: Execution) => marker(e, "benefiting", "Executed while resting")),
        ],
      }),
    );
  }
  return out;
};

/** How close to the market the order sat, 1 = at or through it. */
export function competitiveness(ctx: Parameters<Detector>[0], order: OrderStream): number {
  const level = ctx.market.level(order.instrument, order.start_ms);
  if (!level) return 0;
  const limit = order.price_levels[0];
  if (limit === undefined) return 0;
  // A bid below the market and an offer above it are both "away"; the scale is
  // a few basis points of the level.
  const away = order.side > 0 ? (level - limit) / level : (limit - level) / level;
  const scale = 0.0008;
  return Math.max(0, Math.min(1, 1 - away / scale));
}
