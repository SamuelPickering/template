import type { Execution } from "@/lib/types";
import { usdValue } from "@/lib/models/usdvalue";
import { allocate, type AllocationResult } from "@/lib/models/allocation";
import { MS_HOUR } from "@/lib/time";
import type { Component, Detector, Instance } from "./types";
import {
  bpsStr,
  directionPhrase,
  groupBy,
  makeInstance,
  marker,
  minutesStr,
  sumUsd,
  usd,
  usdCompact,
} from "./util";

/**
 * Front Running and Internal Front Running.
 *
 * A trader who knows a large client order is coming opens a position first,
 * lets the impact of filling the client order move the instrument, then exits
 * into it. The internal variant is the same thing where the impact comes from
 * a different book inside the firm.
 *
 *   EMI = residual modelled impact of the impacting flow at the moment of the
 *         exit, so materiality rises as the gap shrinks
 *   PTC = the position exiting into it, capped at the impacting notional
 */
export const detectFrontRunning: Detector = (ctx, p) =>
  core(ctx, {
    maxLeadMs: p.max_lead_seconds * 1000,
    minPropUsd: p.min_prop_notional_usd,
    sameTraderOnly: p.require_same_trader >= 0.5,
    minImpact: 0,
    metric: "front_running",
  });

export const detectInternalFrontRunning: Detector = (ctx, p) =>
  core(ctx, {
    maxLeadMs: p.max_lead_seconds * 1000,
    minPropUsd: 250_000,
    sameTraderOnly: false,
    minImpact: p.min_impact_bps / 10_000,
    metric: "internal_front_running",
  });

interface CoreOpts {
  maxLeadMs: number;
  minPropUsd: number;
  sameTraderOnly: boolean;
  minImpact: number;
  metric: "front_running" | "internal_front_running";
}

function core(ctx: Parameters<Detector>[0], o: CoreOpts): Instance[] {
  const out: Instance[] = [];
  const byInstrumentDay = groupBy(ctx.executions, (e) => `${e.instrument}|${e.trade_date}`);
  const allocations = new Map<string, AllocationResult>();
  const bookAllocation = (e: Execution, pool: Execution[]): AllocationResult => {
    const key = `${e.trader_id}|${e.instrument}|${e.trade_date}`;
    let res = allocations.get(key);
    if (!res) {
      res = allocate(pool.filter((x) => x.trader_id === e.trader_id));
      allocations.set(key, res);
    }
    return res;
  };

  for (const execs of byInstrumentDay.values()) {
    const props = execs.filter((e) => e.trade_role === "prop");
    if (!props.length) continue;

    for (const exit of props) {
      if (exit.notional_usd < o.minPropUsd) continue;
      const t = exit.event_ms;

      const impacting = execs.filter((e) => {
        if (e.direction === exit.direction) return false;
        const dt = t - e.event_ms;
        if (dt < 0 || dt > o.maxLeadMs) return false;
        if (o.metric === "front_running") {
          if (e.trade_role !== "client_facilitation") return false;
          if (o.sameTraderOnly && e.trader_id !== exit.trader_id) return false;
        } else if (e.trader_id === exit.trader_id) {
          return false;
        }
        return true;
      });
      if (!impacting.length) continue;

      const levelEmi = Math.abs(ctx.mim.levelImpactFrom(impacting, t));
      if (levelEmi < o.minImpact) continue;
      const emi = Math.abs(ctx.mim.valueImpactFrom(impacting, t));
      if (emi <= 0) continue;

      // The position being exited must have been opened before that flow began.
      const flowStart = impacting[0].event_ms;
      const opens = execs.filter(
        (e) =>
          e.trade_role === "prop" &&
          e.trader_id === exit.trader_id &&
          e.direction !== exit.direction &&
          e.event_ms < flowStart &&
          flowStart - e.event_ms <= 4 * MS_HOUR,
      );
      const openUsd = sumUsd(opens);
      if (openUsd < 0.25 * exit.notional_usd) continue;

      const impactingUsd = sumUsd(impacting);
      const alloc = bookAllocation(exit, execs);
      const allocated = alloc.matchedUsd.get(exit.exec_id) ?? 0;
      const closingUsd = Math.min(exit.notional_usd, Math.max(allocated, 0) || exit.notional_usd, openUsd);
      const parts = usdValue(emi, closingUsd, impactingUsd);
      if (parts.usdValue < 1) continue;

      const gapMs = t - impacting[impacting.length - 1].event_ms;
      const internal = o.metric === "internal_front_running";
      const otherTraders = [...new Set(impacting.map((e) => e.trader_name))];
      const all = [...opens, ...impacting, exit];
      const directionUnknown = all.some((e) => !e.direction_known);

      const components: Component[] = [
        { label: "Expected Market Impact (EMI)", value: emi * 10_000, unit: "bps", help: internal ? "Residual modelled impact of the other book's flow at the moment of this trade, in value terms." : "Residual modelled impact of the client facilitation flow at the moment of the prop exit, in value terms." },
        { label: "Level impact", value: levelEmi * 10_000, unit: "bps", help: "The same impact as a move in the instrument's quoted level." },
        { label: "Profit-Taking Component (PTC)", value: parts.ptcUsd, unit: "usd", help: "Position exiting into that impact, capped at the impacting notional." },
        { label: "Impacting notional", value: impactingUsd, unit: "usd", help: internal ? "Notional traded by the other book in the window." : "Client facilitation notional executed in the window." },
        { label: "Position opened", value: openUsd, unit: "usd", help: "Proprietary position established before the impacting flow began." },
        { label: "Exit notional", value: exit.notional_usd, unit: "usd", help: "Size of the execution that exited the position." },
        { label: "Allocated as position closing", value: allocated, unit: "usd", help: "Portion of the exit the Allocation Algorithm matches back to earlier flow in the book." },
        { label: "Lead time", value: gapMs, unit: "duration", help: "Gap between the last impacting execution and the exit. Shorter gaps leave more impact intact." },
        { label: "Product", value: exit.product_type, unit: "text", help: "Product the position was run in." },
      ];
      if (internal) {
        components.push({ label: "Impacting traders", value: otherTraders.join(", "), unit: "text", help: "The other books whose flow created the impact." });
      }
      if (directionUnknown) {
        components.push({ label: "Direction basis", value: "inferred from notional sign", unit: "text", help: "At least one execution came from a schema with no explicit side field, so its direction was inferred. Map a side field on import to remove the assumption." });
      }

      out.push(
        makeInstance({
          ctx,
          metric: o.metric,
          instrument: exit.instrument,
          family: exit.family,
          traderId: exit.trader_id,
          traderName: exit.trader_name,
          counterpartyName: exit.counterparty_name,
          tradeDate: exit.trade_date,
          startMs: opens[0].event_ms,
          endMs: t,
          usdValue: parts.usdValue,
          headline: internal
            ? `${usdCompact(parts.ptcUsd)} exited ${minutesStr(gapMs)} after ${usdCompact(
                impactingUsd,
              )} of flow from ${otherTraders.join(", ")}`
            : `${usdCompact(parts.ptcUsd)} position exited ${minutesStr(gapMs)} after ${usdCompact(
                impactingUsd,
              )} of client business in ${exit.instrument_label}`,
          explanation:
            `${exit.trader_name} ${directionPhrase(opens[0])} ${usd(openUsd)} of ` +
            `${exit.instrument_label}, ` +
            (internal
              ? `then ${otherTraders.join(" and ")} pushed ${usd(impactingUsd)} through the same instrument in ` +
                `the same direction. `
              : `then filled ${usd(impactingUsd)} of client business in the same instrument and direction. `) +
            `The residual impact of that flow was ${bpsStr(emi)} in value terms when the position was ` +
            `closed ${minutesStr(gapMs)} later. Applied to the ${usd(parts.ptcUsd)} that exited into it, ` +
            `USD Value = ${usd(parts.usdValue)}` +
            (parts.ptcRequestedUsd > parts.ptcUsd
              ? ", with the PTC capped at the impacting notional under the exhaustion principle"
              : "") +
            `.`,
          components,
          executions: all,
          markers: [
            ...opens.map((e) => marker(e, "context", "Position opened")),
            ...impacting.map((e) => marker(e, "impacting", internal ? "Other book" : "Client facilitation")),
            marker(exit, "benefiting", "Exit"),
          ],
        }),
      );
    }
  }
  return dedupe(out);
}

function dedupe(list: Instance[]): Instance[] {
  const best = new Map<string, Instance>();
  for (const i of list) {
    const cur = best.get(i.instance_id);
    if (!cur || i.usd_value > cur.usd_value) best.set(i.instance_id, i);
  }
  return [...best.values()];
}
