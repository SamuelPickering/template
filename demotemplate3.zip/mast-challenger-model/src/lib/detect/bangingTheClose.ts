import type { Execution } from "@/lib/types";
import { usdValue } from "@/lib/models/usdvalue";
import { FIX_MIN, MS_MIN, SESSION_START_MIN, atMinute } from "@/lib/time";
import type { Detector, Instance } from "./types";
import {
  bpsStr,
  groupBy,
  levelMoveNote,
  makeInstance,
  marker,
  sumUsd,
  usd,
  usdCompact,
} from "./util";

/**
 * Banging the Close.
 *
 * Positions that settle against a closing or fixing level can be helped along
 * by concentrating trading into the final minutes before it. The simulation
 * publishes a daily close at 16:00 UTC.
 *
 *   EMI = modelled displacement of the closing level: the impact concentrated
 *         window trading leaves standing at the close, less what the same
 *         notional would have left if worked evenly through the session
 *   PTC = the exposure carried into the close, capped at the window notional
 */
export const detectBangingTheClose: Detector = (ctx, p) => {
  const windowMs = p.closing_window_minutes * MS_MIN;
  const out: Instance[] = [];

  const byDay = groupBy(ctx.executions, (e) => `${e.instrument}|${e.trade_date}`);
  for (const [key, execs] of byDay) {
    const [instrument, date] = key.split("|");
    const fixMs = atMinute(date, FIX_MIN);
    const windowStart = fixMs - windowMs;

    for (const [traderId, traderExecs] of groupBy(execs, (e) => e.trader_id)) {
      const inWindow = traderExecs.filter(
        (e) => e.event_ms >= windowStart && e.event_ms <= fixMs,
      );
      if (inWindow.length < 2) continue;

      const windowNotional = sumUsd(inWindow);
      if (windowNotional < p.min_window_notional_usd) continue;
      const dayNotional = sumUsd(traderExecs);
      const concentration = windowNotional / dayNotional;
      if (concentration < p.min_concentration) continue;

      const actualLevel = ctx.mim.levelImpactFrom(inWindow, fixMs);
      if (Math.abs(actualLevel) < 1e-12) continue;
      const fairLevel = evenlySpreadImpact(ctx, inWindow, instrument, date, fixMs);
      const levelEmi = Math.abs(actualLevel) - Math.abs(fairLevel);
      if (levelEmi <= 0) continue;
      const emi = Math.abs(ctx.mim.toValue(instrument, fixMs, levelEmi));

      const exposure = Math.abs(
        traderExecs
          .filter((e) => e.event_ms <= fixMs)
          .reduce((s, e) => s + e.notional_usd * e.direction, 0),
      );
      const parts = usdValue(emi, exposure, windowNotional);
      if (parts.usdValue < 1) continue;

      const first = inWindow[0];
      const pushedUp = inWindow.reduce((s, e) => s + e.notional_usd * e.direction, 0) > 0;

      out.push(
        makeInstance({
          ctx,
          metric: "banging_the_close",
          instrument,
          family: first.family,
          traderId,
          traderName: first.trader_name,
          tradeDate: date,
          startMs: first.event_ms,
          endMs: fixMs,
          usdValue: parts.usdValue,
          headline: `${usdCompact(windowNotional)} pushed through the last ${
            p.closing_window_minutes
          } minutes before the ${first.instrument_label} close`,
          explanation:
            `${first.trader_name} executed ${inWindow.length} times for ${usd(windowNotional)} in the ` +
            `${p.closing_window_minutes} minutes before the 16:00 close — ` +
            `${(concentration * 100).toFixed(0)}% of their whole day in ${first.instrument_label}, and all ` +
            `of it pushing toward ${pushedUp ? levelMoveNote(ctx, instrument) : "a lower level"}. ` +
            `Concentrated like that, the Market Impact Model leaves ${bpsStr(Math.abs(actualLevel))} of ` +
            `level impact standing at the close; the same notional worked evenly across the session would ` +
            `have left only ${bpsStr(Math.abs(fairLevel))}, because most of it would have decayed. The ` +
            `${bpsStr(levelEmi)} difference is the modelled displacement, worth ${bpsStr(emi)} in value ` +
            `terms, applied to the ${usd(parts.ptcUsd)} of exposure carried into the close.`,
          components: [
            { label: "Expected Market Impact (EMI)", value: emi * 10_000, unit: "bps", help: "Closing displacement in value terms: impact standing at the close, less what evenly-spread trading would have left." },
            { label: "Level displacement", value: levelEmi * 10_000, unit: "bps", help: "The same displacement as a move in the quoted level." },
            { label: "Profit-Taking Component (PTC)", value: parts.ptcUsd, unit: "usd", help: "Exposure carried into the close, capped at the window notional." },
            { label: "Actual closing impact", value: Math.abs(actualLevel) * 10_000, unit: "bps", help: "Modelled impact of the window trading still standing at 16:00." },
            { label: "Modelled fair impact", value: Math.abs(fairLevel) * 10_000, unit: "bps", help: "What the same notional would have left standing if spread evenly from the open." },
            { label: "Window notional", value: windowNotional, unit: "usd", help: "Notional executed inside the closing window." },
            { label: "Concentration", value: concentration, unit: "ratio", help: "Share of the trader's day in this instrument that fell inside the window." },
            { label: "Executions in window", value: inWindow.length, unit: "count", help: "Number of executions inside the closing window." },
          ],
          executions: traderExecs.filter((e) => e.event_ms <= fixMs),
          markers: [
            ...traderExecs
              .filter((e) => e.event_ms < windowStart)
              .map((e) => marker(e, "context", "Earlier exposure")),
            ...inWindow.map((e) => marker(e, "impacting", "In closing window")),
          ],
        }),
      );
    }
  }
  return out;
};

/** Impact left at the close had the same notional been worked evenly from the open. */
function evenlySpreadImpact(
  ctx: Parameters<Detector>[0],
  execs: Execution[],
  instrument: string,
  date: string,
  fixMs: number,
): number {
  const openMs = atMinute(date, SESSION_START_MIN);
  const span = fixMs - openMs;
  if (span <= 0) return 0;
  const slices = 24;
  const totalSigned = execs.reduce((s, e) => s + e.notional_usd * e.direction, 0);
  const perSlice = totalSigned / slices;
  let total = 0;
  for (let i = 0; i < slices; i++) {
    const ms = openMs + (span * (i + 0.5)) / slices;
    const mag = ctx.mim.magnitude(instrument, ms, Math.abs(perSlice)) * Math.sign(perSlice);
    total += mag * ctx.mim.decay(fixMs - ms);
  }
  return total;
}
