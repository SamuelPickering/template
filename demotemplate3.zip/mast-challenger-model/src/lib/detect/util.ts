import type { Execution, OrderStream } from "@/lib/types";
import type { MetricId } from "@/lib/config/metrics";
import type {
  Component,
  DetectionContext,
  ImpactPoint,
  Instance,
  TradeMarker,
} from "./types";
import { MS_MIN } from "@/lib/time";

export const usd = (v: number) =>
  (v < 0 ? "-" : "") + "$" + Math.abs(v).toLocaleString("en-US", { maximumFractionDigits: 0 });

export const usdCompact = (v: number) => {
  const a = Math.abs(v);
  const s = v < 0 ? "-" : "";
  if (a >= 1e9) return `${s}$${(a / 1e9).toFixed(2)}bn`;
  if (a >= 1e6) return `${s}$${(a / 1e6).toFixed(1)}m`;
  if (a >= 1e3) return `${s}$${(a / 1e3).toFixed(0)}k`;
  return `${s}$${a.toFixed(0)}`;
};

export const bpsStr = (fraction: number) => `${(fraction * 10_000).toFixed(2)} bps`;

export const minutesStr = (ms: number) => {
  const m = ms / MS_MIN;
  if (m < 1) return `${(ms / 1000).toFixed(1)} seconds`;
  if (m < 90) return `${m.toFixed(1)} minutes`;
  return `${(m / 60).toFixed(1)} hours`;
};

export function groupBy<T>(items: T[], key: (t: T) => string): Map<string, T[]> {
  const m = new Map<string, T[]>();
  for (const it of items) {
    const k = key(it);
    const arr = m.get(k);
    if (arr) arr.push(it);
    else m.set(k, [it]);
  }
  return m;
}

export const sumUsd = (es: Execution[]) => es.reduce((s, e) => s + e.notional_usd, 0);
export const netUsd = (es: Execution[]) =>
  es.reduce((s, e) => s + e.notional_usd * e.direction, 0);

export function uniqueTradeIds(es: Execution[]): string[] {
  return [...new Set(es.map((e) => e.trade_id))];
}

export function scenarioTags(ctx: DetectionContext, execIds: string[], orderIds: string[] = []) {
  const tags = new Set<string>();
  for (const id of execIds) {
    const tag = ctx.execById.get(id)?.scenario_tag;
    if (tag) tags.add(tag);
  }
  for (const id of orderIds) {
    const tag = ctx.orders.find((o) => o.order_id === id)?.scenario_tag;
    if (tag) tags.add(tag);
  }
  return [...tags];
}

export interface MakeInstanceArgs {
  ctx: DetectionContext;
  metric: MetricId;
  instrument: string;
  instrumentLabel?: string;
  family: Instance["family"];
  traderId: string;
  traderName: string;
  bookName?: string;
  counterpartyName?: string | null;
  tradeDate: string;
  startMs: number;
  endMs: number;
  usdValue: number;
  headline: string;
  explanation: string;
  components: Component[];
  executions: Execution[];
  orderIds?: string[];
  markers: TradeMarker[];
}

export function makeInstance(a: MakeInstanceArgs): Instance {
  const execIds = a.executions.map((e) => e.exec_id);
  const orderIds = a.orderIds ?? [];
  return {
    instance_id: `${a.metric}|${a.traderId}|${a.instrument}|${a.startMs}`,
    metric: a.metric,
    instrument: a.instrument,
    instrument_label:
      a.instrumentLabel ?? a.ctx.market.instrument(a.instrument)?.label ?? a.instrument,
    family: a.family,
    trader_id: a.traderId,
    trader_name: a.traderName,
    book_name: a.bookName ?? a.executions[0]?.book_name ?? "",
    counterparty_name: a.counterpartyName ?? null,
    trade_date: a.tradeDate,
    start_ms: a.startMs,
    end_ms: a.endMs,
    usd_value: a.usdValue,
    headline: a.headline,
    explanation: a.explanation,
    components: a.components,
    exec_ids: execIds,
    trade_ids: uniqueTradeIds(a.executions),
    order_ids: orderIds,
    markers: a.markers,
    scenario_tags: scenarioTags(a.ctx, execIds, orderIds),
  };
}

/**
 * Impact curve around an instance, padded either side for context. Built when
 * an alert is opened rather than stored with every instance.
 */
export function impactChart(
  ctx: DetectionContext,
  instrument: string,
  startMs: number,
  endMs: number,
  highlight: string[],
): ImpactPoint[] {
  const span = Math.max(endMs - startMs, 10 * MS_MIN);
  const pad = Math.min(90 * MS_MIN, Math.max(10 * MS_MIN, span * 0.4));
  return ctx.mim.curve(instrument, startMs - pad, endMs + pad, new Set(highlight), 90);
}

export function marker(
  e: Execution,
  role: TradeMarker["role"],
  label: string,
): TradeMarker {
  return {
    exec_id: e.exec_id,
    trade_id: e.trade_id,
    ms: e.event_ms,
    role,
    label,
    notional_usd: e.notional_usd,
  };
}

export function orderMarker(o: OrderStream, label: string): TradeMarker {
  return {
    exec_id: null,
    trade_id: o.order_id,
    ms: o.start_ms,
    role: "order",
    label,
    notional_usd: o.notional_usd,
  };
}

export const dirVerb = (d: number) => (d > 0 ? "bought" : "sold");

/** Phrasing that fits the asset class: you buy a bond, you pay fixed on a swap. */
export function directionPhrase(e: Execution): string {
  switch (e.family) {
    case "credit":
      return e.direction > 0 ? "bought protection on" : "sold protection on";
    case "rates":
      return e.direction > 0 ? "paid fixed on" : "received fixed on";
    case "fenics":
      return e.direction > 0 ? "bought" : "sold";
    default:
      return e.direction > 0 ? "bought" : "sold";
  }
}

export function levelMoveNote(ctx: DetectionContext, instrument: string): string {
  const inst = ctx.market.instrument(instrument);
  switch (inst?.price_type) {
    case "Spread":
      return "a wider spread";
    case "Rate":
      return "a higher rate";
    case "Price":
      return "a higher price";
    default:
      return "a higher level";
  }
}
