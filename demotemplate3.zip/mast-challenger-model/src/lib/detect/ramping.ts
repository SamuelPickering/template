import type { Execution } from "@/lib/types";
import { usdValue } from "@/lib/models/usdvalue";
import { allocate } from "@/lib/models/allocation";
import { MS_MIN } from "@/lib/time";
import type { Detector, Instance } from "./types";
import {
  bpsStr,
  directionPhrase,
  groupBy,
  levelMoveNote,
  makeInstance,
  marker,
  minutesStr,
  sumUsd,
  usd,
  usdCompact,
} from "./util";

/**
 * Ramping.
 *
 * A run of same-direction executions on one instrument that pushes its level,
 * followed by a reversal that exits into the level the trader just created.
 * Works identically on a CDS, a swaption, a bond or a currency, because the
 * adapters have already reduced all of them to a direction, a notional and an
 * instrument.
 *
 *   EMI = cumulative modelled impact of the build phase, in value terms,
 *         measured at the moment the reversal starts
 *   PTC = notional reversed out, capped at the build notional (exhaustion)
 */
export const detectRamping: Detector = (ctx, p) => {
  const minTrades = Math.max(2, Math.round(p.min_trade_count));
  const reversalWindowMs = p.max_reversal_window_minutes * MS_MIN;
  const buildWindowMs = p.max_build_minutes * MS_MIN;
  const minRatio = p.min_directional_ratio;
  const out: Instance[] = [];

  const books = groupBy(
    ctx.executions,
    (e) => `${e.trader_id}|${e.instrument}|${e.trade_date}`,
  );

  for (const execs of books.values()) {
    if (execs.length < minTrades + 1) continue;
    let i = 0;
    while (i < execs.length) {
      const seg = collectBuild(execs, i, buildWindowMs, minRatio);
      if (!seg || seg.build.length < minTrades) {
        i = seg ? Math.max(i + 1, seg.nextIndex) : i + 1;
        continue;
      }
      const rev = collectReversal(execs, seg.nextIndex, seg.direction, reversalWindowMs, seg.lastMs);
      if (!rev) {
        i = seg.nextIndex;
        continue;
      }

      const buildNotional = sumUsd(seg.build);
      const reversalNotional = sumUsd(rev.execs);
      const levelEmi = Math.abs(ctx.mim.levelImpactFrom(seg.build, rev.startMs));
      const emi = Math.abs(ctx.mim.valueImpactFrom(seg.build, rev.startMs));

      // How much of the reversal genuinely unwinds the build rather than
      // opening fresh exposure.
      const alloc = allocate([...seg.build, ...rev.execs]);
      const allocated = rev.execs.reduce((s, e) => s + (alloc.matchedUsd.get(e.exec_id) ?? 0), 0);
      const ptcRequested = allocated > 0 ? Math.min(reversalNotional, allocated) : reversalNotional;
      const parts = usdValue(emi, ptcRequested, buildNotional);

      if (parts.usdValue >= 1) {
        const first = seg.build[0];
        const last = rev.execs[rev.execs.length - 1];
        const gapMs = rev.startMs - seg.lastMs;
        const all = [...seg.build, ...rev.execs];
        out.push(
          makeInstance({
            ctx,
            metric: "ramping",
            instrument: first.instrument,
            family: first.family,
            traderId: first.trader_id,
            traderName: first.trader_name,
            tradeDate: first.trade_date,
            startMs: seg.startMs,
            endMs: last.event_ms,
            usdValue: parts.usdValue,
            headline: `${seg.build.length} ${directionPhrase(first)} ${usdCompact(
              buildNotional,
            )} of ${first.instrument_label}, reversed after ${minutesStr(gapMs)}`,
            explanation:
              `${first.trader_name} ${directionPhrase(first)} ${first.instrument_label} ` +
              `${seg.build.length} times in ${minutesStr(seg.lastMs - seg.startMs)}, ` +
              `${usd(buildNotional)} in one direction. The Market Impact Model puts the cumulative ` +
              `impact of that build at ${bpsStr(levelEmi)} of the quoted level — ${levelMoveNote(
                ctx,
                first.instrument,
              )} — worth ${bpsStr(emi)} in value terms once duration is taken into account. ` +
              `${usd(reversalNotional)} was then traded back the other way ` +
              `${minutesStr(gapMs)} later, of which ${usd(parts.ptcUsd)} counts as the ` +
              `Profit-Taking Component` +
              (parts.ptcRequestedUsd > parts.ptcUsd
                ? " (capped at the build notional under the exhaustion principle)"
                : "") +
              `. USD Value = ${bpsStr(emi)} x ${usd(parts.ptcUsd)} = ${usd(parts.usdValue)}.`,
            components: [
              { label: "Expected Market Impact (EMI)", value: emi * 10_000, unit: "bps", help: "Cumulative modelled impact of the build phase in value terms, measured when the reversal begins." },
              { label: "Level impact", value: levelEmi * 10_000, unit: "bps", help: "The same impact expressed as a move in the instrument's quoted level." },
              { label: "Profit-Taking Component (PTC)", value: parts.ptcUsd, unit: "usd", help: "Notional reversed out into that impact, capped at the build notional." },
              { label: "Build notional", value: buildNotional, unit: "usd", help: "Total accumulated in the dominant direction." },
              { label: "Reversal notional", value: reversalNotional, unit: "usd", help: "Total traded back the other way." },
              { label: "Allocated against the build", value: allocated, unit: "usd", help: "Portion of the reversal the Allocation Algorithm matches back to the build phase." },
              { label: "Build executions", value: seg.build.length, unit: "count", help: "Number of same-direction executions in the build." },
              { label: "Reversal delay", value: gapMs, unit: "duration", help: "Time between the last build execution and the start of the reversal." },
              { label: "Directional purity", value: buildNotional / (buildNotional + seg.oppositeNotional), unit: "ratio", help: "Share of build notional in the dominant direction." },
              { label: "Product", value: [...new Set(all.map((e) => e.product_type))].join(", "), unit: "text", help: "Product types the position was built in." },
            ],
            executions: all,
            markers: [
              ...seg.build.map((e) => marker(e, "impacting", "Build")),
              ...rev.execs.map((e) => marker(e, "benefiting", "Reversal")),
            ],
          }),
        );
      }
      i = rev.nextIndex;
    }
  }
  return out;
};

interface BuildSeg {
  build: Execution[];
  direction: 1 | -1;
  startMs: number;
  lastMs: number;
  nextIndex: number;
  oppositeNotional: number;
}

function collectBuild(
  execs: Execution[],
  start: number,
  buildWindowMs: number,
  minRatio: number,
): BuildSeg | null {
  const first = execs[start];
  if (!first) return null;
  const direction = first.direction;
  const kept: Execution[] = [first];
  let same = first.notional_usd;
  let opposite = 0;
  let j = start + 1;
  for (; j < execs.length; j++) {
    const e = execs[j];
    if (e.event_ms - first.event_ms > buildWindowMs) break;
    if (e.direction === direction) {
      kept.push(e);
      same += e.notional_usd;
      continue;
    }
    // An opposite clip small relative to the build so far is noise, not the exit.
    const size = e.notional_usd;
    if (size <= (1 - minRatio) * same && opposite + size <= (1 - minRatio) * same) {
      opposite += size;
      continue;
    }
    break;
  }
  if (same / (same + opposite) < minRatio) return null;
  const dirTrades = kept.filter((e) => e.direction === direction);
  return {
    build: dirTrades,
    direction,
    startMs: first.event_ms,
    lastMs: dirTrades[dirTrades.length - 1].event_ms,
    nextIndex: j,
    oppositeNotional: opposite,
  };
}

function collectReversal(
  execs: Execution[],
  from: number,
  direction: 1 | -1,
  reversalWindowMs: number,
  buildEndMs: number,
) {
  const picked: Execution[] = [];
  let j = from;
  let startMs = 0;
  for (; j < execs.length; j++) {
    const e = execs[j];
    if (e.direction === direction) break;
    if (e.event_ms - buildEndMs > reversalWindowMs) break;
    if (!picked.length) startMs = e.event_ms;
    picked.push(e);
  }
  if (!picked.length) return null;
  return { execs: picked, startMs, nextIndex: j };
}
