import type { Execution, OrderStream } from "@/lib/types";
import { narrativeScore } from "@/lib/models/usdvalue";
import { MS_MIN } from "@/lib/time";
import type { Detector, Instance } from "./types";
import { groupBy, makeInstance, marker, minutesStr, orderMarker, usd, usdCompact } from "./util";
import { competitiveness } from "./spoofing";

/**
 * Layering.
 *
 * Spoofing done in depth: several orders at successive price levels on one
 * side of the book, building an impression of weight behind the price, often
 * walked in with amendments, then pulled together — with the genuine
 * execution on the opposite side.
 *
 * Kept separate from Spoofing because the evidence is different. Spoofing is
 * about one conspicuous order; layering is about a ladder, and the number of
 * price levels it occupies is the thing that distinguishes it from a trader
 * legitimately working one order.
 *
 *   Narrative         = combined impact of the ladder, weighted by
 *                       competitiveness and by how many levels it occupied,
 *                       applied to the notional executed on the other side
 *   Counter-Narrative = cost of unwinding had the ladder filled
 */
const HALF_SPREAD = 0.00005;
const CLUSTER_GAP_MS = 60_000;

export const detectLayering: Detector = (ctx, p) => {
  if (!ctx.orders.length) return [];
  const minLevels = Math.max(2, Math.round(p.min_price_levels));
  const maxLifeMs = p.max_order_life_seconds * 1000;
  const out: Instance[] = [];

  // Group a trader's orders on one instrument and side, then split into bursts.
  const books = groupBy(
    ctx.orders,
    (o) => `${o.trader_id}|${o.instrument}|${o.side > 0 ? "bid" : "offer"}|${
      new Date(o.start_ms).toISOString().slice(0, 10)
    }`,
  );

  for (const orders of books.values()) {
    for (const ladder of cluster(orders)) {
      if (ladder.length < 2) continue;

      const levels = new Set<number>();
      for (const o of ladder) for (const l of o.price_levels) levels.add(Number(l.toFixed(6)));
      if (levels.size < minLevels) continue;

      const totalUsd = ladder.reduce((s, o) => s + o.notional_usd, 0);
      if (totalUsd <= 0) continue;
      const cancelledUsd = ladder
        .filter((o) => o.cancelled_unfilled)
        .reduce((s, o) => s + o.notional_usd, 0);
      const cancelRatio = cancelledUsd / totalUsd;
      if (cancelRatio < p.cancel_ratio_threshold) continue;

      const lives = ladder.map((o) => o.end_ms - o.start_ms);
      const avgLife = lives.reduce((s, v) => s + v, 0) / lives.length;
      if (avgLife > maxLifeMs) continue;

      const comp =
        ladder.reduce((s, o) => s + competitiveness(ctx, o) * o.notional_usd, 0) / totalUsd;
      if (comp < p.min_competitiveness) continue;

      const first = ladder[0];
      const startMs = Math.min(...ladder.map((o) => o.start_ms));
      const endMs = Math.max(...ladder.map((o) => o.end_ms));
      const amendments = ladder.reduce((s, o) => s + o.amendments, 0);

      const opposite = (ctx.byInstrument.get(first.instrument) ?? []).filter(
        (e) =>
          e.trader_id === first.trader_id &&
          e.direction === (first.side > 0 ? -1 : 1) &&
          e.event_ms >= startMs - MS_MIN &&
          e.event_ms <= endMs + 2 * MS_MIN,
      );
      const oppositeUsd = opposite.reduce((s, e) => s + e.notional_usd, 0);
      if (oppositeUsd <= 0) continue;

      // Depth multiplier: a ladder standing at several levels looks heavier
      // than the same notional at one price.
      const depthWeight = Math.min(1.5, 0.6 + 0.12 * levels.size);
      const levelImpact =
        comp * depthWeight * ctx.mim.magnitude(first.instrument, startMs, totalUsd);
      const valueImpact = Math.abs(ctx.mim.toValue(first.instrument, startMs, levelImpact));
      const narrative = valueImpact * Math.min(oppositeUsd, totalUsd);

      const exposure = Math.min(1, avgLife / (5 * MS_MIN));
      const unwind =
        totalUsd *
        exposure *
        (HALF_SPREAD +
          0.5 *
            Math.abs(
              ctx.mim.toValue(
                first.instrument,
                startMs,
                ctx.mim.magnitude(first.instrument, startMs, totalUsd),
              ),
            ));
      const score = narrativeScore(narrative, unwind);
      if (score.usdValue < 1) continue;

      out.push(
        makeInstance({
          ctx,
          metric: "layering",
          instrument: first.instrument,
          instrumentLabel: first.instrument_label,
          family: first.family,
          traderId: first.trader_id,
          traderName: first.trader_name,
          bookName: first.book_name,
          tradeDate: new Date(startMs).toISOString().slice(0, 10),
          startMs,
          endMs: Math.max(endMs, ...opposite.map((e) => e.event_ms)),
          usdValue: score.usdValue,
          headline: `${ladder.length}-order ${first.side > 0 ? "bid" : "offer"} ladder across ${
            levels.size
          } levels on ${first.instrument_label}, ${usdCompact(oppositeUsd)} executed the other way`,
          explanation:
            `${first.trader_name} placed ${ladder.length} ${first.side > 0 ? "bids" : "offers"} on ` +
            `${first.instrument_label} across ${levels.size} distinct price levels, ` +
            `${usd(totalUsd)} in total` +
            (amendments ? `, with ${amendments} amendment${amendments > 1 ? "s" : ""} walking the price in` : "") +
            `. ${(cancelRatio * 100).toFixed(0)}% of that notional was cancelled without filling, after an ` +
            `average life of ${minutesStr(avgLife)}. While the ladder stood, the same trader executed ` +
            `${usd(oppositeUsd)} in the opposite direction. The Narrative — ladder impact of ` +
            `${(valueImpact * 10_000).toFixed(2)} bps, weighted for the depth it appeared to add, applied to ` +
            `that execution — is worth ${usd(narrative)} against a Counter-Narrative of ${usd(unwind)} for the ` +
            `risk of being filled. Narrative less Counter-Narrative = ${usd(score.usdValue)}.`,
          components: [
            { label: "Narrative", value: narrative, unit: "usd", help: "Depth-weighted ladder impact applied to the notional executed the other way." },
            { label: "Counter-Narrative", value: unwind, unit: "usd", help: "Cost of unwinding had the ladder filled, scaled by how long it rested." },
            { label: "Price levels", value: levels.size, unit: "count", help: "Distinct limit prices the ladder occupied. This is what separates layering from one worked order." },
            { label: "Orders in ladder", value: ladder.length, unit: "count", help: "Number of orders placed on the same side." },
            { label: "Ladder notional", value: totalUsd, unit: "usd", help: "Total size placed across the ladder." },
            { label: "Cancel ratio", value: cancelRatio, unit: "ratio", help: "Share of the ladder cancelled without filling." },
            { label: "Amendments", value: amendments, unit: "count", help: "Price or size amendments across the ladder." },
            { label: "Average order life", value: avgLife, unit: "duration", help: "How long the rungs rested before being pulled." },
            { label: "Competitiveness", value: comp, unit: "ratio", help: "Size-weighted closeness to the market across the ladder." },
            { label: "Executed the other way", value: oppositeUsd, unit: "usd", help: "Notional executed in the opposite direction while the ladder stood." },
          ],
          executions: opposite,
          orderIds: ladder.map((o) => o.order_id),
          markers: [
            ...ladder.map((o, i) => orderMarker(o, `Rung ${i + 1}`)),
            ...opposite.map((e: Execution) => marker(e, "benefiting", "Executed while ladder stood")),
          ],
        }),
      );
    }
  }
  return out;
};

/** Split a trader's same-side orders into bursts placed close together. */
function cluster(orders: OrderStream[]): OrderStream[][] {
  const sorted = orders.slice().sort((a, b) => a.start_ms - b.start_ms);
  const out: OrderStream[][] = [];
  let cur: OrderStream[] = [];
  for (const o of sorted) {
    if (!cur.length || o.start_ms - cur[cur.length - 1].start_ms <= CLUSTER_GAP_MS) cur.push(o);
    else {
      out.push(cur);
      cur = [o];
    }
  }
  if (cur.length) out.push(cur);
  return out;
}
