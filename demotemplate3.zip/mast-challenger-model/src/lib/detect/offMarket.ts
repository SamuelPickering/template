import { usdValue } from "@/lib/models/usdvalue";
import { HAS_EXECUTION_PRICE } from "@/lib/schema/products";
import type { Detector, Instance } from "./types";
import { makeInstance, marker, usd, usdCompact } from "./util";

/**
 * Off-Market Trading.
 *
 * An execution booked meaningfully away from where the market was transfers
 * value between the two sides. It can conceal losses, move value between books
 * or periods, or compensate a counterparty off the record.
 *
 * Needs a traded level, which rules out CDS: the Credit schema's
 * Economics.Price is an upfront points figure rather than a traded spread, so
 * there is nothing to compare. Those records are skipped rather than scored on
 * a guess.
 *
 *   EMI = deviation of the executed level from the modelled market level
 *   PTC = notional executed at it
 */
export const detectOffMarket: Detector = (ctx, p) => {
  const minDeviation = p.deviation_bps / 10_000;
  const out: Instance[] = [];

  for (const e of ctx.executions) {
    if (!HAS_EXECUTION_PRICE[e.product_type]) continue;
    if (!e.price || e.notional_usd < p.min_notional_usd) continue;

    const level = ctx.market.level(e.instrument, e.event_ms);
    if (!level || !Number.isFinite(level)) continue;
    const signed = e.price / level - 1;
    const levelDeviation = Math.abs(signed);
    if (levelDeviation < minDeviation) continue;

    const valueDeviation = Math.abs(ctx.mim.toValue(e.instrument, e.event_ms, levelDeviation));
    const parts = usdValue(valueDeviation, e.notional_usd);
    if (parts.usdValue < 1) continue;

    // Acquiring risk below the market, or shedding it above, favours the trader.
    const favoursTrader = (e.direction > 0 && signed < 0) || (e.direction < 0 && signed > 0);

    out.push(
      makeInstance({
        ctx,
        metric: "off_market_trading",
        instrument: e.instrument,
        family: e.family,
        traderId: e.trader_id,
        traderName: e.trader_name,
        counterpartyName: e.counterparty_name,
        tradeDate: e.trade_date,
        startMs: e.event_ms,
        endMs: e.event_ms,
        usdValue: parts.usdValue,
        headline: `${usdCompact(e.notional_usd)} of ${e.instrument_label} booked ${(
          levelDeviation * 10_000
        ).toFixed(0)} bps ${signed > 0 ? "above" : "below"} the market`,
        explanation:
          `${e.trader_name} executed ${usd(e.notional_usd)} of ${e.instrument_label} ` +
          `(${e.product_type}) at ${ctx.market.formatLevel(e.instrument, e.price)} against a modelled ` +
          `market level of ${ctx.market.formatLevel(e.instrument, level)} — a deviation of ` +
          `${(levelDeviation * 10_000).toFixed(0)} bps, well beyond any plausible spread. In value terms ` +
          `that is ${(valueDeviation * 10_000).toFixed(1)} bps, so ${usd(parts.usdValue)} of value moved ` +
          `${favoursTrader ? "toward the trader's book" : "toward the counterparty"} relative to executing ` +
          `at the market. The counterparty was ${e.counterparty_name ?? "not recorded"}.`,
        components: [
          { label: "Expected Market Impact (EMI)", value: valueDeviation * 10_000, unit: "bps", help: "Distance from the market level, in value terms." },
          { label: "Level deviation", value: levelDeviation * 10_000, unit: "bps", help: "The same distance against the instrument's quoted level." },
          { label: "Profit-Taking Component (PTC)", value: e.notional_usd, unit: "usd", help: "Notional executed at the off-market level." },
          { label: "Executed level", value: e.price, unit: "level", help: "Level the execution printed at." },
          { label: "Market level", value: level, unit: "level", help: "Where the market model puts the instrument at that instant." },
          { label: "Direction of transfer", value: favoursTrader ? "Toward the trader's book" : "Toward the counterparty", unit: "text", help: "Which side the off-market level favours." },
          { label: "Product", value: e.product_type, unit: "text", help: "Product the execution was booked as." },
          { label: "Counterparty", value: `${e.counterparty_name ?? "not recorded"}${e.counterparty_kind ? ` (${e.counterparty_kind})` : ""}`, unit: "text", help: "Who was on the other side." },
        ],
        executions: [e],
        markers: [marker(e, "impacting", "Off-market execution")],
      }),
    );
  }
  return out;
};
