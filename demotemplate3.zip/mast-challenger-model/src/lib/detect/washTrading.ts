import type { Execution } from "@/lib/types";
import { narrativeScore } from "@/lib/models/usdvalue";
import { MS_MIN } from "@/lib/time";
import type { Detector, Instance } from "./types";
import {
  bpsStr,
  directionPhrase,
  groupBy,
  makeInstance,
  marker,
  minutesStr,
  usd,
  usdCompact,
} from "./util";

/**
 * Wash Trading, including the disguised variants.
 *
 * Offsetting legs on the same instrument, close together in time and
 * near-identical in size, with no genuine market risk taken in between. The
 * score is a Narrative / Counter-Narrative contest:
 *
 *   Narrative         = the impact the manufactured activity creates, applied
 *                       to the volume it manufactures, weighted by how closely
 *                       related the two sides are
 *   Counter-Narrative = the genuine market risk actually run between the legs,
 *                       plus any client-facilitation explanation
 *
 * Because legs are matched on the normalised instrument rather than on the
 * stated contract, a round trip split across two tenors of the same reference
 * entity, across a swaption and a cap on the same curve point, or across two
 * currency pairs, is caught the same way as one done twice in the same line.
 * Requiring the same product type narrows it back to the obvious case.
 */
export const detectWashTrading: Detector = (ctx, p) => {
  const maxGapMs = p.max_leg_gap_minutes * MS_MIN;
  const tol = p.size_match_tolerance_pct / 100;
  const requireSameProduct = p.require_same_product >= 0.5;
  const requirePriceMatch = p.require_price_match >= 0.5;
  const out: Instance[] = [];

  const books = groupBy(
    ctx.executions,
    (e) => `${e.trader_id}|${e.instrument}|${e.trade_date}`,
  );

  for (const execs of books.values()) {
    if (execs.length < 2) continue;
    const used = new Set<string>();
    for (let i = 0; i < execs.length; i++) {
      const anchor = execs[i];
      if (used.has(anchor.exec_id)) continue;
      const anchorSize = anchor.notional_usd;
      if (anchorSize <= 0) continue;

      // Accumulate opposite-direction legs until they offset the anchor.
      // One leg is the classic wash; several cover the round trip through
      // related accounts.
      const legs: Execution[] = [];
      let cum = 0;
      for (let j = i + 1; j < execs.length; j++) {
        const cand = execs[j];
        if (used.has(cand.exec_id)) continue;
        if (cand.event_ms - anchor.event_ms > maxGapMs) break;
        if (cand.direction === anchor.direction) continue;
        if (requireSameProduct && cand.product_type !== anchor.product_type) continue;
        if (requirePriceMatch && !priceMatches(anchor, cand)) continue;
        legs.push(cand);
        cum += cand.notional_usd;
        if (cum >= anchorSize * (1 - tol)) break;
      }
      if (!legs.length) continue;
      if (Math.abs(cum - anchorSize) > anchorSize * tol) continue;

      const related = relatedness(anchor, legs);
      if (related < 0.4) continue;

      const matched = Math.min(anchorSize, cum);
      const lastLeg = legs[legs.length - 1];
      const startMs = anchor.event_ms;
      const endMs = lastLeg.event_ms;
      const levelImpact = ctx.mim.magnitude(anchor.instrument, startMs, matched);
      const emi = Math.abs(ctx.mim.toValue(anchor.instrument, startMs, levelImpact));

      // Genuine market risk: how far the instrument actually moved while the
      // position was open, in value terms, applied to the matched notional.
      const startLevel = ctx.market.level(anchor.instrument, startMs);
      const endLevel = ctx.market.level(anchor.instrument, endMs);
      const realisedLevelMove = startLevel ? Math.abs(endLevel / startLevel - 1) : 0;
      const realisedValueMove = Math.abs(
        ctx.mim.toValue(anchor.instrument, endMs, realisedLevelMove),
      );
      const marketRiskUsd = 0.5 * realisedValueMove * matched;
      const clientLegs = [anchor, ...legs].filter((e) => e.trade_role === "client_facilitation");
      const clientExplanationUsd = clientLegs.length ? matched * 0.0004 : 0;
      const counter = marketRiskUsd + clientExplanationUsd;
      const narrative = emi * matched * related;
      const score = narrativeScore(narrative, counter);
      if (score.usdValue < 1) continue;

      used.add(anchor.exec_id);
      legs.forEach((l) => used.add(l.exec_id));

      const all = [anchor, ...legs];
      const variant = describeVariant(anchor, legs);

      out.push(
        makeInstance({
          ctx,
          metric: "wash_trading",
          instrument: anchor.instrument,
          family: anchor.family,
          traderId: anchor.trader_id,
          traderName: anchor.trader_name,
          counterpartyName: anchor.counterparty_name,
          tradeDate: anchor.trade_date,
          startMs,
          endMs,
          usdValue: score.usdValue,
          headline: `${usdCompact(matched)} ${variant.label} on ${anchor.instrument_label}, offset in ${minutesStr(
            endMs - startMs,
          )}`,
          explanation:
            `${anchor.trader_name} ${directionPhrase(anchor)} ${usd(anchorSize)} of ` +
            `${anchor.instrument_label} and reversed it with ${legs.length} offsetting ` +
            `leg${legs.length > 1 ? "s" : ""} totalling ${usd(cum)} ${minutesStr(endMs - startMs)} later. ` +
            `${variant.reason} The manufactured activity carries a modelled impact of ${bpsStr(emi)} in ` +
            `value terms, giving a Narrative of ${usd(narrative)}. Against that, the instrument moved only ` +
            `${(realisedValueMove * 10_000).toFixed(2)} bps of value while the position was open, so the ` +
            `genuine market risk run between the legs is worth ${usd(marketRiskUsd)}` +
            (clientExplanationUsd
              ? ` and there is a client facilitation explanation worth ${usd(clientExplanationUsd)}`
              : "") +
            `. Narrative less Counter-Narrative = ${usd(score.usdValue)}.`,
          components: [
            { label: "Narrative", value: narrative, unit: "usd", help: "Modelled impact of the manufactured activity applied to the volume it manufactured, weighted by relatedness." },
            { label: "Counter-Narrative", value: counter, unit: "usd", help: "Legitimate explanations: genuine market risk run between the legs, plus any client facilitation." },
            { label: "Matched notional", value: matched, unit: "usd", help: "Notional that offsets between the legs." },
            { label: "Modelled impact", value: emi * 10_000, unit: "bps", help: "Impact a clip of the matched size would create, in value terms." },
            { label: "Gap between legs", value: endMs - startMs, unit: "duration", help: "How long the position was actually exposed to the market." },
            { label: "Value move over the gap", value: realisedValueMove * 10_000, unit: "bps", help: "How far the instrument moved in value terms while the position was open." },
            { label: "Relatedness", value: related, unit: "ratio", help: "How closely the two sides are connected: internal accounts score highest, unrelated street names lowest." },
            { label: "Variant", value: variant.label, unit: "text", help: "Which wash trading pattern this matches." },
            { label: "Products involved", value: [...new Set(all.map((e) => e.product_type))].join(", "), unit: "text", help: "Product types on the two sides. More than one means the offset was split across contracts." },
          ],
          executions: all,
          markers: [
            marker(anchor, "impacting", "Opening leg"),
            ...legs.map((l) => marker(l, "benefiting", "Offsetting leg")),
          ],
        }),
      );
    }
  }
  return out;
};

function priceMatches(a: Execution, b: Execution): boolean {
  if (!a.price || !b.price) return false;
  return Math.abs(b.price / a.price - 1) <= 0.0005;
}

/** How connected the two sides are — the core of "no genuine risk transfer". */
function relatedness(anchor: Execution, legs: Execution[]): number {
  const all = [anchor, ...legs];
  const codes = all.map((e) => e.counterparty_code ?? "");
  const kinds = all.map((e) => e.counterparty_kind);
  if (kinds.every((k) => k === "internal")) return 1;
  const allSame = codes.every((c) => c === codes[0] && c !== "");
  if (allSame) return 0.85;
  if (kinds.some((k) => k === "internal")) return 0.7;
  return 0.45;
}

function describeVariant(anchor: Execution, legs: Execution[]) {
  const all = [anchor, ...legs];
  const products = new Set(all.map((e) => e.product_type));
  const codes = new Set(all.map((e) => e.counterparty_code ?? "—"));
  const tenors = new Set(all.map((e) => e.tenor ?? "—"));
  const pairs = new Set(
    all.map((e) => (e as Execution & { headline_pair?: string }).headline_pair ?? ""),
  );

  if (products.size > 1) {
    return {
      label: "cross-product wash",
      reason: `The legs were booked as different products (${[...products].join(
        " and ",
      )}), but both land on ${anchor.instrument_label}, where they cancel.`,
    };
  }
  if (pairs.size > 1 && [...pairs].every(Boolean)) {
    return {
      label: "cross-currency wash",
      reason: `The legs were booked in different currency pairs (${[...pairs].join(
        " and ",
      )}), but both map onto ${anchor.instrument_label} once split against USD.`,
    };
  }
  if (anchor.family === "credit" && tenors.size === 1 && legs.length === 1) {
    return {
      label: "wash",
      reason: `Both legs were booked against ${anchor.counterparty_name ?? "the same account"}, so no risk left the firm.`,
    };
  }
  if (legs.length > 1 || codes.size > 1) {
    return {
      label: "multi-counterparty wash",
      reason: `The offset was spread across ${codes.size} counterparties (${[...codes].join(
        ", ",
      )}), which disguises the round trip on any single account.`,
    };
  }
  return {
    label: "wash",
    reason: `Both legs were booked against ${anchor.counterparty_name ?? "the same account"}, so no risk left the firm.`,
  };
}
