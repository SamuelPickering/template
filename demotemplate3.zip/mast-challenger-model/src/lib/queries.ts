import { loadDocuments, loadTraders } from "@/lib/db/repo";
import {
  abuseByTrader,
  alertsByExecution,
  buildContext,
  runAnalysis,
  type RunResult,
} from "@/lib/detect/engine";
import { getConfig, getDataset } from "@/lib/config/store";
import { METRIC_BY_ID, type MetricId } from "@/lib/config/metrics";
import type { ImpactPoint, Instance } from "@/lib/detect/types";
import { impactChart } from "@/lib/detect/util";
import type { Execution, OrderStream, ProductFamily, SourceDocument } from "@/lib/types";

export function currentRun(): RunResult {
  return runAnalysis({ config: getConfig(), dataset: getDataset() });
}

export function context() {
  return buildContext(getDataset());
}

/* ---------------- traders ---------------- */

export interface TraderRow {
  trader_id: string;
  name: string;
  trade_role: string;
  executions: number;
  orders: number;
  notional_usd: number;
  alerts: number;
  usd_value: number;
  abuses: { metric: MetricId; label: string; count: number }[];
  /** True when the trader came from the data rather than the local registry. */
  fromData: boolean;
}

/**
 * Traders in the active dataset.
 *
 * Built from the data rather than from the local registry, so an imported
 * extract shows its own trader IDs and nothing else — no synthetic names leak
 * into a view of real data. Registry names are used where an ID is known.
 */
export function traderRows(run: RunResult): TraderRow[] {
  const ctx = context();
  const registry = new Map(loadTraders().map((t) => [t.trader_id, t]));

  const activity = new Map<
    string,
    { executions: number; orders: number; notional: number; role: string }
  >();
  const touch = (id: string) => {
    let v = activity.get(id);
    if (!v) {
      v = { executions: 0, orders: 0, notional: 0, role: registry.get(id)?.trade_role ?? "" };
      activity.set(id, v);
    }
    return v;
  };
  for (const e of ctx.executions) {
    const v = touch(e.trader_id);
    v.executions += 1;
    v.notional += e.notional_usd;
    if (!v.role) v.role = e.trade_role;
  }
  // A trader whose orders never filled still belongs in the list.
  for (const o of ctx.orders) touch(o.trader_id).orders += 1;

  const counts = new Map<string, Map<MetricId, number>>();
  const totals = new Map<string, { n: number; usd: number }>();
  for (const a of run.alerts) {
    const t = totals.get(a.trader_id) ?? { n: 0, usd: 0 };
    t.n += 1;
    t.usd += a.usd_value;
    totals.set(a.trader_id, t);
    const byMetric = counts.get(a.trader_id) ?? new Map<MetricId, number>();
    byMetric.set(a.metric, (byMetric.get(a.metric) ?? 0) + 1);
    counts.set(a.trader_id, byMetric);
  }

  return [...activity]
    .map(([trader_id, v]) => ({
      trader_id,
      name: registry.get(trader_id)?.name ?? trader_id,
      trade_role: v.role || "unknown",
      executions: v.executions,
      orders: v.orders,
      notional_usd: v.notional,
      alerts: totals.get(trader_id)?.n ?? 0,
      usd_value: totals.get(trader_id)?.usd ?? 0,
      abuses: [...(counts.get(trader_id) ?? new Map<MetricId, number>())]
        .map(([metric, count]) => ({ metric, label: METRIC_BY_ID[metric].label, count }))
        .sort((a, b) => b.count - a.count),
      fromData: !registry.has(trader_id),
    }))
    .sort(
      (a, b) =>
        b.usd_value - a.usd_value ||
        b.executions + b.orders - (a.executions + a.orders) ||
        a.trader_id.localeCompare(b.trader_id),
    );
}

/* ---------------- blotter: executions ---------------- */

export interface ExecutionFilters {
  trader?: string;
  instrument?: string;
  family?: string;
  product?: string;
  date?: string;
  role?: string;
  search?: string;
  onlyAlerts?: boolean;
  limit?: number;
  offset?: number;
}

export interface BlotterRow {
  execution: Execution;
  alerts: { metric: MetricId; label: string; instance_id: string; usd_value: number }[];
}

function matchesText(hay: string, needle?: string) {
  return !needle || hay.toLowerCase().includes(needle.toLowerCase());
}

export function queryExecutions(
  run: RunResult,
  f: ExecutionFilters,
): { rows: BlotterRow[]; total: number; alertCount: number } {
  const ctx = context();
  const byExec = alertsByExecution(run);

  const matched = ctx.executions.filter((e) => {
    if (f.trader && e.trader_id !== f.trader) return false;
    if (f.instrument && e.instrument !== f.instrument) return false;
    if (f.family && e.family !== f.family) return false;
    if (f.product && e.product_type !== f.product) return false;
    if (f.date && e.trade_date !== f.date) return false;
    if (f.role && e.trade_role !== f.role) return false;
    if (f.onlyAlerts && !byExec.has(e.exec_id)) return false;
    return matchesText(
      `${e.trade_id} ${e.trader_id} ${e.trader_name} ${e.counterparty_name ?? ""} ${
        e.instrument
      } ${e.instrument_label} ${e.book_name} ${e.venue_name ?? ""}`,
      f.search,
    );
  });

  const ordered = matched.slice().sort((a, b) => b.event_ms - a.event_ms);
  const offset = f.offset ?? 0;
  return {
    rows: ordered.slice(offset, offset + (f.limit ?? 150)).map((execution) => ({
      execution,
      alerts: (byExec.get(execution.exec_id) ?? []).map((a) => ({
        metric: a.metric,
        label: METRIC_BY_ID[a.metric].label,
        instance_id: a.instance_id,
        usd_value: a.usd_value,
      })),
    })),
    total: ordered.length,
    alertCount: ordered.filter((e) => byExec.has(e.exec_id)).length,
  };
}

/* ---------------- blotter: order streams ---------------- */

export interface OrderRowView {
  order: OrderStream;
  alerts: { metric: MetricId; label: string; instance_id: string; usd_value: number }[];
}

/** Which alerts each order appears in, for highlighting. */
function alertsByOrder(run: RunResult) {
  const m = new Map<string, Instance[]>();
  for (const a of run.alerts) {
    for (const id of a.order_ids) {
      const arr = m.get(id);
      if (arr) arr.push(a);
      else m.set(id, [a]);
    }
  }
  return m;
}

/**
 * Orders are the other half of the picture, and on an order-driven feed they
 * are most of it: an order that was placed and pulled never becomes an
 * execution, but it is exactly what Layering and Spoofing are about.
 */
export function queryOrders(
  run: RunResult,
  f: ExecutionFilters,
): { rows: OrderRowView[]; total: number; alertCount: number } {
  const ctx = context();
  const byOrder = alertsByOrder(run);

  const matched = ctx.orders.filter((o) => {
    const date = new Date(o.start_ms).toISOString().slice(0, 10);
    if (f.trader && o.trader_id !== f.trader) return false;
    if (f.instrument && o.instrument !== f.instrument) return false;
    if (f.family && o.family !== f.family) return false;
    if (f.product && o.product_type !== f.product) return false;
    if (f.date && date !== f.date) return false;
    if (f.onlyAlerts && !byOrder.has(o.order_id)) return false;
    return matchesText(
      `${o.order_id} ${o.trader_id} ${o.trader_name} ${o.instrument} ${o.instrument_label} ${o.book_name}`,
      f.search,
    );
  });

  const ordered = matched.slice().sort((a, b) => b.start_ms - a.start_ms);
  const offset = f.offset ?? 0;
  return {
    rows: ordered.slice(offset, offset + (f.limit ?? 150)).map((order) => ({
      order,
      alerts: (byOrder.get(order.order_id) ?? []).map((a) => ({
        metric: a.metric,
        label: METRIC_BY_ID[a.metric].label,
        instance_id: a.instance_id,
        usd_value: a.usd_value,
      })),
    })),
    total: ordered.length,
    alertCount: ordered.filter((o) => byOrder.has(o.order_id)).length,
  };
}

export function traderAbuse(run: RunResult) {
  const map = abuseByTrader(run);
  return (traderId: string) =>
    [...(map.get(traderId) ?? [])].map((m) => METRIC_BY_ID[m].label);
}

/** Filter options, taken from the active dataset only. */
export function distinctValues() {
  const ctx = context();
  const instruments = new Map<string, string>();
  const products = new Set<string>();
  const families = new Set<ProductFamily>();
  const dates = new Set<string>();
  const traders = new Map<string, string>();

  for (const e of ctx.executions) {
    instruments.set(e.instrument, e.instrument_label);
    products.add(e.product_type);
    families.add(e.family);
    dates.add(e.trade_date);
    traders.set(e.trader_id, e.trader_name);
  }
  for (const o of ctx.orders) {
    instruments.set(o.instrument, o.instrument_label);
    products.add(o.product_type);
    families.add(o.family);
    dates.add(new Date(o.start_ms).toISOString().slice(0, 10));
    traders.set(o.trader_id, o.trader_name);
  }

  return {
    instruments: [...instruments].sort((a, b) => a[1].localeCompare(b[1])),
    products: [...products].sort(),
    families: [...families].sort(),
    dates: [...dates].sort().reverse(),
    traders: [...traders].sort((a, b) => a[1].localeCompare(b[1])),
  };
}

/* ---------------- instances ---------------- */

export function findInstance(run: RunResult, id: string): Instance | undefined {
  return run.instances.find((i) => i.instance_id === id);
}

export function instanceChart(instance: Instance): ImpactPoint[] {
  const ctx = context();
  return impactChart(
    ctx,
    instance.instrument,
    instance.start_ms,
    instance.end_ms,
    [...instance.exec_ids, ...instance.trade_ids],
  );
}

export function executionsByIds(ids: string[]): Execution[] {
  const ctx = context();
  const wanted = new Set(ids);
  return ctx.executions
    .filter((e) => wanted.has(e.exec_id))
    .sort((a, b) => a.event_ms - b.event_ms);
}

export function ordersByIds(ids: string[]): OrderStream[] {
  if (!ids.length) return [];
  const ctx = context();
  const wanted = new Set(ids);
  return ctx.orders.filter((o) => wanted.has(o.order_id)).sort((a, b) => a.start_ms - b.start_ms);
}

export function documentById(docId: string): SourceDocument | undefined {
  return context().docById.get(docId);
}

/* ---------------- datasets ---------------- */

export interface DatasetSummaryRow {
  source: string;
  documents: number;
  byFamily: Record<string, number>;
}

export function datasetSummary(): DatasetSummaryRow[] {
  const out: DatasetSummaryRow[] = [];
  for (const source of ["synthetic", "imported"]) {
    const docs = loadDocuments(source);
    const byFamily: Record<string, number> = {};
    for (const d of docs) byFamily[d.family] = (byFamily[d.family] ?? 0) + 1;
    out.push({ source, documents: docs.length, byFamily });
  }
  return out;
}

/** Counts for the dataset switch in the header. */
export function datasetCounts(): { synthetic: number; imported: number } {
  return {
    synthetic: loadDocuments("synthetic").length,
    imported: loadDocuments("imported").length,
  };
}
