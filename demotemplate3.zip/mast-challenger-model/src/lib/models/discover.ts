import type { Execution, Instrument, OrderStream, ProductFamily } from "@/lib/types";
import { IMPACT_K } from "@/lib/gen/universe";
import { instrumentLabel } from "@/lib/schema/products";

/**
 * Instrument discovery for imported data.
 *
 * Real extracts reference instruments the tool has never seen — a Treasury
 * ISIN, a reference entity, a curve point that is not in the local universe.
 * Without a reference level for them, anything that compares a price against
 * the market has nothing to compare against, and silently treating the level
 * as 1 turns a perfectly ordinary fill at 99.23 into a 9,800 basis point
 * deviation. That is worse than no answer.
 *
 * So an instrument that is not already known gets one derived from the file
 * itself: the level is what the data was actually printing, and volatility and
 * average daily volume are stated defaults for the asset class. Those two are
 * assumptions, and everything built on them is marked as derived so the import
 * page and the methodology can say so.
 */
export interface DiscoveryDefaults {
  ann_vol: number;
  adtv_usd: number;
  duration_years: number;
  fallback_level: number;
}

export const FAMILY_DEFAULTS: Record<ProductFamily, DiscoveryDefaults> = {
  // A corporate or government bond quoted around par.
  fenics: { ann_vol: 0.05, adtv_usd: 5e8, duration_years: 5, fallback_level: 100 },
  // CDS spreads, in basis points.
  credit: { ann_vol: 0.4, adtv_usd: 5e8, duration_years: 4.6, fallback_level: 150 },
  // Swap rates, in percent.
  rates: { ann_vol: 0.2, adtv_usd: 1e10, duration_years: 5, fallback_level: 4 },
  // A currency against USD.
  fx: { ann_vol: 0.09, adtv_usd: 2e11, duration_years: 1, fallback_level: 1 },
};

const median = (xs: number[]): number | null => {
  const s = xs.filter((x) => Number.isFinite(x) && x > 0).sort((a, b) => a - b);
  return s.length ? s[Math.floor(s.length / 2)] : null;
};

export function discoverInstruments(
  executions: Execution[],
  orders: OrderStream[],
  known: Set<string>,
): Instrument[] {
  const seen = new Map<
    string,
    { family: ProductFamily; currency: string; prices: number[]; label: string }
  >();

  const note = (
    key: string,
    family: ProductFamily,
    currency: string,
    label: string,
    price: number | null,
  ) => {
    if (known.has(key)) return;
    const entry =
      seen.get(key) ?? { family, currency, prices: [], label };
    if (price !== null && Number.isFinite(price) && price > 0) entry.prices.push(price);
    seen.set(key, entry);
  };

  for (const e of executions) {
    note(e.instrument, e.family, e.currency, e.instrument_label, e.price || null);
  }
  for (const o of orders) {
    // An order that never filled still tells us where the instrument was.
    note(o.instrument, o.family, o.currency, o.instrument_label, o.price_levels[0] ?? null);
    for (const level of o.price_levels) {
      note(o.instrument, o.family, o.currency, o.instrument_label, level);
    }
  }

  const out: Instrument[] = [];
  for (const [key, v] of seen) {
    const d = FAMILY_DEFAULTS[v.family];
    const level = median(v.prices) ?? d.fallback_level;
    out.push({
      instrument: key,
      label: v.label || instrumentLabel(key),
      family: v.family,
      currency: v.currency,
      price_type:
        v.family === "credit"
          ? "Spread"
          : v.family === "rates"
            ? "Rate"
            : v.family === "fx"
              ? "FXRate"
              : "Price",
      base_level: level,
      ann_vol: d.ann_vol,
      adtv_usd: d.adtv_usd,
      impact_k: IMPACT_K[v.family],
      duration_years: d.duration_years,
      derived: true,
    });
  }
  return out.sort((a, b) => a.instrument.localeCompare(b.instrument));
}
