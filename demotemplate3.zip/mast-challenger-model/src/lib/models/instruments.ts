import type { Execution } from "@/lib/types";

/**
 * Grouping helpers. The equivalent of the FX General Market Model for a
 * multi-asset dataset: the adapters have already mapped every execution onto a
 * canonical instrument (a CDS reference entity at a tenor bucket, a bond ISIN,
 * a curve point, a currency against USD), so "the position a trader built"
 * is just the executions that share an instrument key.
 */
export function groupBy<T>(items: T[], key: (t: T) => string): Map<string, T[]> {
  const m = new Map<string, T[]>();
  for (const it of items) {
    const k = key(it);
    const arr = m.get(k);
    if (arr) arr.push(it);
    else m.set(k, [it]);
  }
  return m;
}

export const byInstrument = (executions: Execution[]) => {
  const m = groupBy(executions, (e) => e.instrument);
  for (const arr of m.values()) arr.sort((a, b) => a.event_ms - b.event_ms);
  return m;
};

export const bookKey = (e: Execution) =>
  `${e.trader_id}|${e.instrument}|${e.trade_date}`;

export const instrumentDayKey = (e: Execution) => `${e.instrument}|${e.trade_date}`;

/** Signed USD sensitivity: positive pushes the instrument's level up. */
export const signedUsd = (e: Execution) => e.notional_usd * e.direction;

export const sumUsd = (es: Execution[]) => es.reduce((s, e) => s + e.notional_usd, 0);

export const netUsd = (es: Execution[]) => es.reduce((s, e) => s + signedUsd(e), 0);

export function uniqueTradeIds(es: Execution[]): string[] {
  return [...new Set(es.map((e) => e.trade_id))];
}

export function uniqueExecIds(es: Execution[]): string[] {
  return [...new Set(es.map((e) => e.exec_id))];
}
