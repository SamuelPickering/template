import type { Instrument, MarketDay, MarketEvent, ProductFamily } from "@/lib/types";
import { gauss, mulberry32 } from "@/lib/gen/rng";
import { MS_DAY, dateKey, dayStartMs } from "@/lib/time";

const MINUTES = 1440;

/**
 * Market reference data, one series per instrument, with a deterministic
 * intraday path so a level is available at any millisecond without storing
 * minute-level rows.
 *
 * "Level" means whatever the instrument is quoted in: a clean price for a
 * bond, a spread in basis points for a CDS, a rate in percent for a swap, an
 * FX rate for a currency.
 */
export class MarketData {
  private byInstrument = new Map<string, Map<string, MarketDay>>();
  private instruments = new Map<string, Instrument>();
  private dates: string[] = [];
  private pathCache = new Map<string, Float64Array>();
  private events = new Map<string, MarketEvent[]>();

  constructor(instruments: Instrument[], rows: MarketDay[]) {
    for (const i of instruments) this.instruments.set(i.instrument, i);
    const dateSet = new Set<string>();
    for (const r of rows) {
      let m = this.byInstrument.get(r.instrument);
      if (!m) {
        m = new Map();
        this.byInstrument.set(r.instrument, m);
      }
      m.set(r.trade_date, r);
      dateSet.add(r.trade_date);
    }
    this.dates = [...dateSet].sort();
  }

  get instrumentKeys(): string[] {
    return [...this.instruments.keys()];
  }

  get allInstruments(): Instrument[] {
    return [...this.instruments.values()];
  }

  instrument(key: string): Instrument | undefined {
    return this.instruments.get(key);
  }

  familyOf(key: string): ProductFamily | undefined {
    return this.instruments.get(key)?.family;
  }

  get tradingDates(): string[] {
    return this.dates;
  }

  get firstDate(): string {
    return this.dates[0];
  }

  get lastDate(): string {
    return this.dates[this.dates.length - 1];
  }

  day(instrument: string, date: string): MarketDay | undefined {
    return this.byInstrument.get(instrument)?.get(date);
  }

  /** Nearest available session on or before `date`. */
  private nearestDay(instrument: string, date: string): MarketDay | undefined {
    const m = this.byInstrument.get(instrument);
    if (!m) return undefined;
    const direct = m.get(date);
    if (direct) return direct;
    let ms = dayStartMs(date);
    for (let i = 0; i < 10; i++) {
      ms -= MS_DAY;
      const hit = m.get(dateKey(ms));
      if (hit) return hit;
    }
    return m.get(this.dates[0]);
  }

  /**
   * Event overlay: a step change applied to an instrument the instant an
   * event becomes public. Keeping the shock as an overlay rather than baking
   * it into the series means the jump lands exactly on the public timestamp,
   * which is what Insider Trading measures against.
   */
  setEvents(events: MarketEvent[]) {
    this.events.clear();
    this.pathCache.clear();
    for (const e of events) {
      const arr = this.events.get(e.instrument) ?? [];
      arr.push(e);
      this.events.set(e.instrument, arr);
    }
    for (const arr of this.events.values()) arr.sort((a, b) => a.public_ms - b.public_ms);
  }

  eventsFor(instrument: string): MarketEvent[] {
    return this.events.get(instrument) ?? [];
  }

  private jumpFactor(instrument: string, ms: number): number {
    const arr = this.events.get(instrument);
    if (!arr || !arr.length) return 1;
    let f = 1;
    for (const e of arr) {
      if (e.public_ms > ms) break;
      f *= 1 + e.move_pct / 100;
    }
    return f;
  }

  private path(instrument: string, date: string): Float64Array | null {
    const key = `${instrument}|${date}`;
    const cached = this.pathCache.get(key);
    if (cached) return cached;
    const d = this.nearestDay(instrument, date);
    if (!d) return null;
    const rng = mulberry32(d.day_seed);
    const steps = new Float64Array(MINUTES + 1);
    const stepVol = d.volatility / Math.sqrt(MINUTES);
    let acc = 0;
    for (let i = 1; i <= MINUTES; i++) {
      acc += stepVol * gauss(rng);
      steps[i] = acc;
    }
    const end = steps[MINUTES];
    const out = new Float64Array(MINUTES + 1);
    for (let i = 0; i <= MINUTES; i++) {
      const t = i / MINUTES;
      const bridged = steps[i] - t * end; // pin both ends to open and close
      const trend = d.open + (d.close - d.open) * t;
      out[i] = trend * (1 + bridged);
    }
    this.pathCache.set(key, out);
    return out;
  }

  /** The instrument's quoted level at `ms`. */
  level(instrument: string, ms: number): number {
    const date = dateKey(ms);
    const p = this.path(instrument, date);
    if (!p) return this.instruments.get(instrument)?.base_level ?? 1;
    const minute = (ms - dayStartMs(date)) / 60000;
    const i = Math.max(0, Math.min(MINUTES - 1, Math.floor(minute)));
    const frac = Math.max(0, Math.min(1, minute - i));
    const base = p[i] * (1 - frac) + p[i + 1] * frac;
    return base * this.jumpFactor(instrument, ms);
  }

  /** USD per 1 unit of a currency — the FX instruments double as the fixings. */
  usdRate(currency: string, ms: number): number {
    const code = currency.toUpperCase();
    if (code === "USD") return 1;
    const key = `FX:${code}/USD`;
    if (!this.instruments.has(key)) return 1;
    return this.level(key, ms);
  }

  /** Daily volatility of the instrument's level, as a fraction. */
  volatility(instrument: string, date: string): number {
    return this.nearestDay(instrument, date)?.volatility ?? 0.005;
  }

  adtv(instrument: string, date: string): number {
    return (
      this.nearestDay(instrument, date)?.adtv_usd ??
      this.instruments.get(instrument)?.adtv_usd ??
      1e9
    );
  }

  toUsd(amount: number, currency: string, ms: number): number {
    return amount * this.usdRate(currency, ms);
  }

  /**
   * Converts a move in the quoted level into a move in value.
   *
   * For a bond price or an FX rate the two are the same thing. For a credit
   * spread or an interest rate they are not: a one basis point move is worth
   * a basis point of notional for every year of risk, so the level move has to
   * be multiplied through by duration before it means anything in dollars.
   */
  valueFactor(instrument: string, ms: number): number {
    const inst = this.instruments.get(instrument);
    if (!inst) return 1;
    switch (inst.family) {
      case "fx":
      case "fenics":
        return 1;
      case "credit": {
        // level is in bps of spread
        const levelBps = this.level(instrument, ms);
        return (levelBps * inst.duration_years) / 10_000;
      }
      case "rates": {
        // level is a rate in percent
        const levelPct = this.level(instrument, ms);
        return (levelPct * inst.duration_years) / 100;
      }
      default:
        return 1;
    }
  }

  /** Human-readable rendering of a level, per instrument convention. */
  formatLevel(instrument: string, value: number): string {
    const inst = this.instruments.get(instrument);
    switch (inst?.price_type) {
      case "Spread":
        return `${value.toFixed(1)} bps`;
      case "Rate":
        return `${value.toFixed(4)}%`;
      case "Price":
        return value.toFixed(4);
      default:
        return value.toPrecision(6);
    }
  }
}
