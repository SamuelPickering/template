import type { Execution } from "@/lib/types";
import type { MarketData } from "./market";
import { dateKey, MS_MIN } from "@/lib/time";
import { groupBy } from "./instruments";

/**
 * Market Impact Model, v1, across asset classes.
 *
 *   level impact = K x volatility x (notional / ADTV)      [signed]
 *   impact(t)    = level impact x exp(-lambda x dt)
 *   value impact = level impact x valueFactor(instrument)
 *
 * Proportional to trade size, proportional to volatility, inversely
 * proportional to average daily traded volume, instantaneous, additive across
 * nearby trades, decaying exponentially back toward zero.
 *
 * K is calibrated per asset class and carried on the instrument, because the
 * same participation rate moves a thin corporate bond far more than it moves a
 * major currency. The value conversion is what makes a credit spread move and
 * a bond price move comparable in dollars.
 */
export const MIM_DEFAULTS = {
  halfLifeMinutes: 30,
  /** Cap on a single execution's modelled level impact, as a fraction. */
  maxLevelImpact: 0.05,
};

export interface MimOptions {
  halfLifeMinutes?: number;
  maxLevelImpact?: number;
}

export class MarketImpactModel {
  readonly halfLifeMs: number;
  readonly maxLevelImpact: number;
  private lambda: number;
  private byInstrument: Map<string, Execution[]>;
  private levelCache = new WeakMap<Execution, number>();

  constructor(
    private market: MarketData,
    executions: Execution[],
    opts: MimOptions = {},
  ) {
    this.halfLifeMs = (opts.halfLifeMinutes ?? MIM_DEFAULTS.halfLifeMinutes) * MS_MIN;
    this.maxLevelImpact = opts.maxLevelImpact ?? MIM_DEFAULTS.maxLevelImpact;
    this.lambda = Math.LN2 / this.halfLifeMs;
    this.byInstrument = groupBy(executions, (e) => e.instrument);
    for (const arr of this.byInstrument.values()) arr.sort((a, b) => a.event_ms - b.event_ms);
  }

  instruments(): string[] {
    return [...this.byInstrument.keys()];
  }

  on(instrument: string): Execution[] {
    return this.byInstrument.get(instrument) ?? [];
  }

  /** Unsigned instantaneous impact on the quoted level, as a fraction. */
  magnitude(instrument: string, ms: number, notionalUsd: number): number {
    const inst = this.market.instrument(instrument);
    if (!inst) return 0;
    const date = dateKey(ms);
    const vol = this.market.volatility(instrument, date);
    const adtv = this.market.adtv(instrument, date);
    if (!adtv) return 0;
    const raw = inst.impact_k * vol * (Math.abs(notionalUsd) / adtv);
    return Math.min(this.maxLevelImpact, raw);
  }

  /** Signed instantaneous level impact of one execution. */
  levelImpactOf(e: Execution): number {
    const cached = this.levelCache.get(e);
    if (cached !== undefined) return cached;
    const v = this.magnitude(e.instrument, e.event_ms, e.notional_usd) * e.direction;
    this.levelCache.set(e, v);
    return v;
  }

  /** Converts a level impact on this instrument into a value impact. */
  toValue(instrument: string, ms: number, levelImpact: number): number {
    return levelImpact * this.market.valueFactor(instrument, ms);
  }

  decay(dtMs: number): number {
    if (dtMs <= 0) return dtMs > -1000 ? 1 : 0;
    return Math.exp(-this.lambda * dtMs);
  }

  residualOf(e: Execution, atMs: number): number {
    const dt = atMs - e.event_ms;
    if (dt < 0) return 0;
    return this.levelImpactOf(e) * this.decay(dt);
  }

  /**
   * Total residual level impact on an instrument at `atMs`, optionally
   * restricted to a subset of the flow. Executions older than eight
   * half-lives contribute nothing material and are skipped.
   */
  residual(instrument: string, atMs: number, filter?: (e: Execution) => boolean): number {
    const arr = this.byInstrument.get(instrument);
    if (!arr) return 0;
    const cutoff = atMs - 8 * this.halfLifeMs;
    let total = 0;
    for (let i = upperBound(arr, atMs) - 1; i >= 0; i--) {
      const e = arr[i];
      if (e.event_ms < cutoff) break;
      if (filter && !filter(e)) continue;
      total += this.residualOf(e, atMs);
    }
    return total;
  }

  /** Cumulative level impact created by an explicit list of executions. */
  levelImpactFrom(executions: Execution[], atMs: number): number {
    let total = 0;
    for (const e of executions) total += this.residualOf(e, atMs);
    return total;
  }

  /** Cumulative value impact created by an explicit list of executions. */
  valueImpactFrom(executions: Execution[], atMs: number): number {
    if (!executions.length) return 0;
    const level = this.levelImpactFrom(executions, atMs);
    return this.toValue(executions[0].instrument, atMs, level);
  }

  /** Sampled impact curve for charting, in basis points of the level. */
  curve(
    instrument: string,
    fromMs: number,
    toMs: number,
    highlight: Set<string>,
    steps = 80,
  ): { ms: number; total_bps: number; highlight_bps: number; mid: number }[] {
    const out = [];
    const step = Math.max(1, (toMs - fromMs) / steps);
    for (let i = 0; i <= steps; i++) {
      const ms = fromMs + i * step;
      const total = this.residual(instrument, ms);
      const hi = this.residual(instrument, ms, (e) => highlight.has(e.exec_id) || highlight.has(e.trade_id));
      out.push({
        ms: Math.round(ms),
        total_bps: total * 10_000,
        highlight_bps: hi * 10_000,
        mid: this.market.level(instrument, ms),
      });
    }
    return out;
  }
}

function upperBound(arr: Execution[], ms: number): number {
  let lo = 0;
  let hi = arr.length;
  while (lo < hi) {
    const mid = (lo + hi) >> 1;
    if (arr[mid].event_ms <= ms) lo = mid + 1;
    else hi = mid;
  }
  return lo;
}
