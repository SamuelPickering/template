import type { Execution } from "@/lib/types";
import { MS_HOUR } from "@/lib/time";

/**
 * Allocation Algorithm.
 *
 * Connects buys with sells inside a book so we can tell which executions were
 * done to facilitate others and which built a proprietary position. The
 * guiding heuristic is that opposite-direction executions are more likely to
 * be a pair the closer they are in both timestamp and notional, with client
 * facilitation prioritised, because filling client business is the main reason
 * a sell-side book trades at all. Whatever is left unmatched is proprietary,
 * and partial allocation is supported.
 */
export interface AllocationLink {
  a: string; // exec_id of the earlier leg
  b: string; // exec_id of the later leg
  usd: number;
  score: number;
}

export interface AllocationResult {
  links: AllocationLink[];
  /** exec_id -> USD matched against opposite-direction flow. */
  matchedUsd: Map<string, number>;
  /** exec_id -> USD left unmatched: proprietary exposure opened. */
  residualUsd: Map<string, number>;
  /** exec_id -> USD matched specifically against client facilitation flow. */
  clientMatchedUsd: Map<string, number>;
}

export interface AllocationOptions {
  halfLifeMs?: number;
  maxGapMs?: number;
  clientBias?: number;
}

const DEFAULTS = {
  halfLifeMs: 45 * 60_000,
  maxGapMs: 6 * MS_HOUR,
  clientBias: 1.6,
};

const isClient = (e: Execution) => e.trade_role === "client_facilitation";

export function allocate(
  executions: Execution[],
  opts: AllocationOptions = {},
): AllocationResult {
  const halfLife = opts.halfLifeMs ?? DEFAULTS.halfLifeMs;
  const maxGap = opts.maxGapMs ?? DEFAULTS.maxGapMs;
  const clientBias = opts.clientBias ?? DEFAULTS.clientBias;
  const lambda = Math.LN2 / halfLife;

  const items = executions.slice().sort((x, y) => x.event_ms - y.event_ms);
  const remaining = new Map<string, number>();
  for (const e of items) remaining.set(e.exec_id, e.notional_usd);

  type Cand = { i: number; j: number; score: number };
  const cands: Cand[] = [];
  for (let i = 0; i < items.length; i++) {
    for (let j = i + 1; j < items.length; j++) {
      const a = items[i];
      const b = items[j];
      const dt = b.event_ms - a.event_ms;
      if (dt > maxGap) break;
      if (a.direction === b.direction) continue;
      const sa = a.notional_usd;
      const sb = b.notional_usd;
      if (sa === 0 || sb === 0) continue;
      const sizeAffinity = Math.min(sa, sb) / Math.max(sa, sb);
      const bias = isClient(a) !== isClient(b) ? clientBias : 1;
      const score = Math.exp(-lambda * dt) * sizeAffinity * bias;
      if (score > 1e-4) cands.push({ i, j, score });
    }
  }
  cands.sort((p, q) => q.score - p.score);

  const links: AllocationLink[] = [];
  const matchedUsd = new Map<string, number>();
  const clientMatchedUsd = new Map<string, number>();
  const bump = (m: Map<string, number>, key: string, v: number) =>
    m.set(key, (m.get(key) ?? 0) + v);

  for (const c of cands) {
    const a = items[c.i];
    const b = items[c.j];
    const ra = remaining.get(a.exec_id) ?? 0;
    const rb = remaining.get(b.exec_id) ?? 0;
    if (ra <= 1 || rb <= 1) continue;
    const usd = Math.min(ra, rb);
    remaining.set(a.exec_id, ra - usd);
    remaining.set(b.exec_id, rb - usd);
    links.push({ a: a.exec_id, b: b.exec_id, usd, score: c.score });
    bump(matchedUsd, a.exec_id, usd);
    bump(matchedUsd, b.exec_id, usd);
    if (isClient(b)) bump(clientMatchedUsd, a.exec_id, usd);
    if (isClient(a)) bump(clientMatchedUsd, b.exec_id, usd);
  }

  return { links, matchedUsd, residualUsd: remaining, clientMatchedUsd };
}

/** Share of an execution the algorithm could not explain as facilitation. */
export function propShare(e: Execution, res: AllocationResult): number {
  if (!e.notional_usd) return 0;
  return Math.max(0, Math.min(1, (res.residualUsd.get(e.exec_id) ?? 0) / e.notional_usd));
}

/** Share of an execution matched against client facilitation flow. */
export function facilitationShare(e: Execution, res: AllocationResult): number {
  if (!e.notional_usd) return 0;
  return Math.max(0, Math.min(1, (res.clientMatchedUsd.get(e.exec_id) ?? 0) / e.notional_usd));
}
