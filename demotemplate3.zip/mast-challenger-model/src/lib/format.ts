import type { ComponentUnit } from "@/lib/detect/types";

export const fmtUsd = (v: number, digits = 0) =>
  (v < 0 ? "-" : "") +
  "$" +
  Math.abs(v).toLocaleString("en-US", {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  });

export function fmtUsdCompact(v: number): string {
  const a = Math.abs(v);
  const s = v < 0 ? "-" : "";
  if (a >= 1e9) return `${s}$${(a / 1e9).toFixed(2)}bn`;
  if (a >= 1e6) return `${s}$${(a / 1e6).toFixed(a >= 1e7 ? 1 : 2)}m`;
  if (a >= 1e3) return `${s}$${(a / 1e3).toFixed(a >= 1e4 ? 0 : 1)}k`;
  return `${s}$${a.toFixed(0)}`;
}

export function fmtDuration(ms: number): string {
  const abs = Math.abs(ms);
  if (abs < 1000) return `${abs.toFixed(0)} ms`;
  if (abs < 90_000) return `${(abs / 1000).toFixed(1)} s`;
  if (abs < 5_400_000) return `${(abs / 60_000).toFixed(1)} min`;
  if (abs < 86_400_000) return `${(abs / 3_600_000).toFixed(1)} h`;
  return `${(abs / 86_400_000).toFixed(1)} d`;
}

export const fmtDateTime = (ms: number) =>
  new Date(ms).toISOString().replace("T", " ").slice(0, 23) + "Z";

export const fmtTime = (ms: number) => new Date(ms).toISOString().slice(11, 23);

export const fmtDate = (ms: number) => new Date(ms).toISOString().slice(0, 10);

export function fmtAmount(v: number): string {
  const a = Math.abs(v);
  const digits = a >= 1000 ? 0 : a >= 1 ? 2 : 4;
  return v.toLocaleString("en-US", {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  });
}

/** A quoted level: a bond price, a spread in bps, a rate in percent, an FX rate. */
export function fmtLevel(v: number): string {
  const a = Math.abs(v);
  if (a >= 1000) return v.toFixed(1);
  if (a >= 10) return v.toFixed(3);
  if (a >= 1) return v.toFixed(5);
  return v.toPrecision(6);
}

export function fmtRate(v: number): string {
  if (v >= 100) return v.toFixed(3);
  if (v >= 1) return v.toFixed(5);
  return v.toPrecision(6);
}

export function fmtComponent(value: number | string, unit: ComponentUnit): string {
  if (typeof value === "string") return value;
  switch (unit) {
    case "usd":
      return fmtUsd(value);
    case "bps":
      return `${value.toFixed(2)} bps`;
    case "level":
      return fmtLevel(value);
    case "ratio":
      return `${(value * 100).toFixed(1)}%`;
    case "percent":
      return `${value > 0 ? "+" : ""}${value.toFixed(2)}%`;
    case "count":
      return value.toLocaleString("en-US");
    case "duration":
      return fmtDuration(value);
    default:
      return String(value);
  }
}

/** Colour ramp for USD Value: green -> amber -> red as risk rises. */
export function riskColor(usdValue: number, scaleMax: number): string {
  if (scaleMax <= 0) return "var(--surface-2)";
  const t = Math.min(1, Math.max(0, Math.log10(Math.max(1, usdValue)) / Math.log10(Math.max(10, scaleMax))));
  if (t < 0.5) {
    const k = t / 0.5;
    return `color-mix(in srgb, var(--ok) ${(1 - k) * 70 + 15}%, var(--warn) ${k * 70 + 15}%)`;
  }
  const k = (t - 0.5) / 0.5;
  return `color-mix(in srgb, var(--warn) ${(1 - k) * 70 + 15}%, var(--danger) ${k * 80 + 20}%)`;
}
