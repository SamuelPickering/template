import { getData, resetData, updateData } from "./index";
import type {
  Counterparty,
  Instrument,
  MarketDay,
  MarketEvent,
  SourceDocument,
  Trader,
} from "@/lib/types";

/* ---------------- writes ---------------- */

export function resetDb() {
  resetData();
}

export const insertTraders = (rows: Trader[]) =>
  updateData((d) => {
    d.traders = rows;
  });

export const insertCounterparties = (rows: Counterparty[]) =>
  updateData((d) => {
    d.counterparties = rows;
  });

export const insertInstruments = (rows: Instrument[]) =>
  updateData((d) => {
    d.instruments = rows;
  });

export const insertMarketDaily = (rows: MarketDay[]) =>
  updateData((d) => {
    d.market_daily = rows;
  });

export const insertEvents = (rows: MarketEvent[]) =>
  updateData((d) => {
    d.events = rows;
  });

/** Appends source documents, keeping each source's set separate. */
export function insertDocuments(rows: SourceDocument[]) {
  if (!rows.length) return;
  updateData((d) => {
    for (const doc of rows) {
      const bucket = (d.documents[doc.source] ??= []);
      bucket.push(doc);
    }
  });
}

export function replaceDocuments(source: string, rows: SourceDocument[]) {
  updateData((d) => {
    d.documents[source] = rows;
  });
}

export function deleteDocumentsBySource(source: string) {
  updateData((d) => {
    d.documents[source] = [];
  });
}

/* ---------------- reads ---------------- */

export const loadTraders = (): Trader[] => getData().traders;
export const loadCounterparties = (): Counterparty[] => getData().counterparties;
export const loadInstruments = (): Instrument[] => getData().instruments;
export const loadMarketDaily = (): MarketDay[] => getData().market_daily;
export const loadEvents = (): MarketEvent[] => getData().events;
export const loadDocuments = (source: string): SourceDocument[] =>
  getData().documents[source] ?? [];

export function documentCounts(): Record<string, number> {
  return Object.fromEntries(
    Object.entries(getData().documents).map(([k, v]) => [k, v.length]),
  );
}
