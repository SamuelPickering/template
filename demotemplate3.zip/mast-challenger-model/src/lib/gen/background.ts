import type {
  Counterparty,
  Instrument,
  ProductType,
  SourceDocument,
  Trader,
} from "@/lib/types";
import type { MarketData } from "@/lib/models/market";
import { creditDoc, fenicsDoc, ratesDoc } from "./docs";
import { fxTrade } from "./fxhelp";
import { focusOf, instrumentsFor } from "./universe";
import { hashSeed, lognormal, mulberry32, pick, randInt, randRange, type Rng } from "./rng";
import { SESSION_END_MIN, SESSION_START_MIN, atMinute } from "@/lib/time";

/**
 * The "fair" population: ordinary, non-abusive business across all four
 * product families, which is the overwhelming majority of the dataset.
 *
 * It deliberately includes activity that structurally resembles abuse — a
 * trader working a large order in clips and closing out later in the session,
 * an order placed and pulled because the market moved — because that is
 * exactly why a surveillance tool needs a USD Value threshold rather than a
 * pattern match.
 */
export function generateBackground(opts: {
  dates: string[];
  traders: Trader[];
  counterparties: Counterparty[];
  instruments: Instrument[];
  market: MarketData;
  seed?: number;
  perTraderDay?: number;
}): SourceDocument[] {
  const { dates, traders, counterparties, instruments, market } = opts;
  const seed = opts.seed ?? 20260101;
  const perDay = opts.perTraderDay ?? 1.6;
  const clients = counterparties.filter((c) => c.kind === "client");
  const dealers = counterparties.filter((c) => c.kind === "dealer");
  const out: SourceDocument[] = [];

  for (const date of dates) {
    for (const trader of traders) {
      const rng = mulberry32(hashSeed("bg", seed, trader.trader_id, date));
      const focus = focusOf(trader.trader_id);
      const pool = instrumentsFor(focus, instruments).filter(
        (i) => !i.instrument.includes("NOTICKER"),
      );
      if (!pool.length) continue;

      const activity = perDay * (0.4 + 1.6 * rng());
      let n = Math.floor(activity);
      if (rng() < activity - n) n += 1;

      // Ordinary working of a large order: a run of same-direction clips,
      // often closed out later in the day.
      if (rng() < 0.14) {
        const inst = pick(rng, pool);
        const dir: 1 | -1 = rng() < 0.5 ? 1 : -1;
        const clips = randInt(rng, 3, 6);
        const startMin = sessionMinute(rng);
        const spanMin = 8 + rng() * 40;
        const clipUsd = typicalNotional(rng, inst) * 0.6;
        for (let c = 0; c < clips; c++) {
          out.push(
            ...emit({
              rng,
              trader,
              inst,
              direction: dir,
              notionalUsd: clipUsd * (0.8 + rng() * 0.4),
              ms: atMinute(date, startMin + (spanMin * c) / clips, randInt(rng, 0, 45_000)),
              market,
              clients,
              dealers,
            }),
          );
        }
        if (rng() < 0.55) {
          out.push(
            ...emit({
              rng,
              trader,
              inst,
              direction: dir === 1 ? -1 : 1,
              notionalUsd: clipUsd * clips * randRange(rng, 0.8, 1.05),
              ms: atMinute(
                date,
                Math.min(16.8 * 60, startMin + spanMin + 5 + rng() * 70),
                randInt(rng, 0, 45_000),
              ),
              market,
              clients,
              dealers,
            }),
          );
        }
      }

      for (let i = 0; i < n; i++) {
        const inst = pick(rng, pool);
        out.push(
          ...emit({
            rng,
            trader,
            inst,
            direction: rng() < 0.5 ? 1 : -1,
            notionalUsd: typicalNotional(rng, inst),
            ms: atMinute(date, sessionMinute(rng), randInt(rng, 0, 59_999)),
            market,
            clients,
            dealers,
          }),
        );
      }
    }
  }

  out.sort((a, b) => docTime(a) - docTime(b));
  return out;
}

/** Typical clip size for the instrument's market, in USD. */
export function typicalNotional(rng: Rng, inst: Instrument): number {
  switch (inst.family) {
    case "credit":
      return lognormal(rng, 7.5e6, 0.8, 5e5, 1.2e8);
    case "rates":
      return lognormal(rng, 7.5e7, 0.85, 5e6, 7.5e8);
    case "fenics":
      return lognormal(rng, 4e6, 0.75, 2.5e5, 6e7);
    default:
      return lognormal(rng, 3e6, 0.85, 1e5, 9e7);
  }
}

interface EmitArgs {
  rng: Rng;
  trader: Trader;
  inst: Instrument;
  direction: 1 | -1;
  notionalUsd: number;
  ms: number;
  market: MarketData;
  clients: Counterparty[];
  dealers: Counterparty[];
  scenarioTag?: string | null;
}

/**
 * One ordinary execution in whichever schema the instrument belongs to.
 * Fenics instruments produce a whole order stream rather than a single trade.
 */
export function emit(a: EmitArgs): SourceDocument[] {
  const { rng, trader, inst, market, ms } = a;
  const clientFacing = trader.trade_role === "client_facilitation" && rng() < 0.6;
  const cp = clientFacing ? pick(rng, a.clients) : pick(rng, a.dealers);
  const notional = Math.max(1, Math.round(a.notionalUsd));

  if (inst.family === "credit") {
    return [
      creditDoc({
        trader,
        counterparty: cp,
        instrument: inst,
        notional,
        direction: a.direction,
        tradeMs: ms,
        upfront: pick(rng, [0, 0, 0, 0, 1, -1, -2, 2]),
        scenarioTag: a.scenarioTag ?? null,
      }),
    ];
  }

  if (inst.family === "rates") {
    const productType = pick(rng, [
      "IR.Swaption",
      "IR.Swaption",
      "IR.CapFloor",
      "IR.FRA",
    ] as ProductType[]) as "IR.Swaption" | "IR.CapFloor" | "IR.FRA";
    const level = market.level(inst.instrument, ms) * (1 + randRange(rng, -0.01, 0.01));
    return [
      ratesDoc({
        trader,
        counterparty: cp,
        instrument: inst,
        productType,
        notional,
        direction: a.direction,
        level,
        tradeMs: ms,
        // A small share of source records arrive with incomplete Economics.
        incomplete: rng() < 0.015,
        scenarioTag: a.scenarioTag ?? null,
      }),
    ];
  }

  if (inst.family === "fenics") {
    const mid = market.level(inst.instrument, ms);
    const side = a.direction; // buying the bond lifts its price
    const edge = randRange(rng, 0.01, 0.09); // price points away from mid
    const limit = side > 0 ? mid - edge * 0.4 : mid + edge * 0.4;
    const amount = notional / market.usdRate(inst.currency, ms);
    const fillCount = rng() < 0.65 ? 1 : randInt(rng, 2, 3);
    const willFill = rng() < 0.78;
    const fills = willFill
      ? Array.from({ length: fillCount }, (_, i) => ({
          ms: ms + (i + 1) * randInt(rng, 4_000, 90_000),
          price: side > 0 ? limit + randRange(rng, -0.004, 0.012) : limit + randRange(rng, -0.012, 0.004),
          amount: amount / fillCount,
          counterparty: clientFacing ? pick(rng, a.clients) : pick(rng, a.dealers),
          venueIndex: randInt(rng, 0, 3),
        }))
      : [];
    const amendments =
      rng() < 0.3
        ? [
            {
              ms: ms + randInt(rng, 20_000, 240_000),
              limitPrice: limit + randRange(rng, -0.03, 0.03),
              totalAmount: amount,
            },
          ]
        : [];
    return [
      fenicsDoc({
        trader,
        instrument: inst,
        side,
        limitPrice: limit,
        totalAmount: amount,
        displayAmount: amount * (rng() < 0.2 ? 0.5 : 1),
        startMs: ms,
        amendments,
        fills,
        closeMs: willFill ? undefined : ms + randInt(rng, 120_000, 40 * 60_000),
        scenarioTag: a.scenarioTag ?? null,
      }),
    ];
  }

  // FX: ~30% of activity is a genuine cross rather than a dollar pair.
  const currency = inst.currency_code ?? inst.currency;
  const against =
    rng() < 0.3 ? pick(rng, ["EUR", "GBP", "JPY", "CHF"].filter((c) => c !== currency)) : "USD";
  return [
    fxTrade({
      trader,
      counterparty: cp,
      currency,
      against,
      direction: a.direction,
      notionalUsd: notional,
      ms,
      market,
      spread: 0.00002 + rng() * 0.00008,
      scenarioTag: a.scenarioTag ?? null,
    }),
  ];
}

export function docTime(doc: SourceDocument): number {
  const exec = (doc.payload.Execution ?? {}) as Record<string, unknown>;
  const raw = (exec.TradeDate ?? exec.OrderStartDate ?? "") as string;
  const t = Date.parse(raw.includes("Z") ? raw : `${raw.replace(" ", "T")}Z`);
  return Number.isFinite(t) ? t : 0;
}

/** Busier around the European open, the US open and the 16:00 fix. */
function sessionMinute(rng: Rng): number {
  const peaks = [
    { center: 8 * 60, spread: 60, weight: 0.28 },
    { center: 13 * 60 + 30, spread: 75, weight: 0.34 },
    { center: 16 * 60, spread: 35, weight: 0.16 },
  ];
  const r = rng();
  let acc = 0;
  for (const p of peaks) {
    acc += p.weight;
    if (r < acc) {
      return clamp(p.center + p.spread * (rng() + rng() + rng() - 1.5) * 1.2);
    }
  }
  return clamp(SESSION_START_MIN + rng() * (SESSION_END_MIN - SESSION_START_MIN));
}

const clamp = (m: number) =>
  Math.max(SESSION_START_MIN, Math.min(SESSION_END_MIN - 1, m));
