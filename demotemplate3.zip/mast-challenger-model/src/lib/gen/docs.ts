import type {
  Counterparty,
  Instrument,
  ProductType,
  SourceDocument,
  Trader,
} from "@/lib/types";
import { bookFor, focusOf, regionFor, VENUES } from "./universe";
import { isoMs } from "@/lib/time";

/**
 * Document builders.
 *
 * Generated data is emitted as Master.Transaction documents in the same
 * product schemas a production extract arrives in, then normalised by the same
 * adapters the import path uses. Nothing downstream can tell generated data
 * from imported data, which is the point: if a metric works here it works on
 * the real extract.
 *
 * Signed-amount convention: the Credit, FRA and Fenics schemas carry no side
 * field, so a negative notional means the sell side. Feeds that only send
 * positive amounts are handled at import time, where a side field can be
 * mapped explicitly.
 */

let counter = 0;
export function resetDocIds() {
  counter = 0;
}
const nextId = (prefix: string) => `${prefix}-${String(++counter).padStart(6, "0")}`;

const MONTH_MS = 30.44 * 24 * 3600 * 1000;

function unit(trader: Trader, unitType: string, businessUnit: string) {
  return {
    Type: unitType,
    BookName: bookFor(trader.trader_id, focusOf(trader.trader_id)),
    BusinessUnit: businessUnit,
    Region: regionFor(trader.trader_id),
  };
}

function cpObject(cp: Counterparty) {
  return {
    Type: cp.kind === "internal" ? "Counterparty.Internal" : "Counterparty.Professional",
    CounterpartyName: cp.name,
    CounterpartyCode: cp.counterparty_code,
  };
}

const price7 = (v: number) => v.toFixed(7);
const amountStr = (v: number) => (Math.round(v * 100) / 100).toFixed(1);

/* ------------------------------------------------------------------ */
/* Credit.CDS                                                          */
/* ------------------------------------------------------------------ */

export interface CreditArgs {
  trader: Trader;
  counterparty: Counterparty;
  instrument: Instrument; // CDS:TICKER/TIER/TENOR
  notional: number; // absolute, USD
  direction: 1 | -1; // +1 = buy protection (spread wider)
  tradeMs: number;
  /** Upfront points, as the source carries them. Often zero. */
  upfront?: number;
  internalTrade?: boolean;
  omitTicker?: boolean;
  scenarioTag?: string | null;
}

export function creditDoc(a: CreditArgs): SourceDocument {
  const [, rest] = a.instrument.instrument.split(":");
  const [ticker, tier, tenorBucket] = rest.split("/");
  const years = Number(tenorBucket.replace(/[^\d.]/g, "")) || 5;
  const tenorMonths = `${Math.round(years * 12)}M`;
  const docId = nextId("CRD");

  const identifier: Record<string, unknown> = {
    Type: "ID.CDS",
    Tier: tier,
    Tenor: tenorMonths,
  };
  if (!a.omitTicker) identifier.Ticker = ticker;

  return {
    doc_id: docId,
    family: "credit",
    source: "synthetic",
    scenario_tag: a.scenarioTag ?? null,
    payload: {
      Type: "Master.Transaction",
      ExtractDate: isoMs(a.tradeMs + 3 * 86_400_000),
      Execution: {
        Type: a.internalTrade ? "internalTrade" : "withClientTrade",
        TradeDate: isoMs(a.tradeMs),
        TradeID: docId,
        TraderID: a.trader.trader_id,
        Counterparty: cpObject(a.counterparty),
        Economics: {
          Type: "Credit.CDS",
          AssetType: "Single",
          Notional: Math.round(a.notional) * a.direction,
          Maturity: isoMs(a.tradeMs + years * 12 * MONTH_MS),
          Price: a.upfront ?? 0,
          Frequency: "3M",
          Currency: { Type: "ID.ISO", ISOCode: "USD" },
          Identifier: identifier,
        },
      },
      Unit: unit(a.trader, "Unit.Desk", "Credit"),
    },
  };
}

/* ------------------------------------------------------------------ */
/* Rates: IR.Swaption | IR.CapFloor | IR.FRA                           */
/* ------------------------------------------------------------------ */

export interface RatesArgs {
  trader: Trader;
  counterparty: Counterparty;
  instrument: Instrument; // IR:INDEX/TENOR
  productType: Extract<ProductType, "IR.Swaption" | "IR.CapFloor" | "IR.FRA">;
  notional: number;
  direction: 1 | -1; // +1 = long rates (pay fixed / buy cap)
  /** Traded level: strike or fixed rate, in percent. */
  level: number;
  tradeMs: number;
  internalTrade?: boolean;
  /** Emit a record with incomplete Economics, as the source sometimes does. */
  incomplete?: boolean;
  scenarioTag?: string | null;
}

export function ratesDoc(a: RatesArgs): SourceDocument {
  const [, rest] = a.instrument.instrument.split(":");
  const [index, bucket] = rest.split("/");
  const years = bucket.endsWith("Y")
    ? Number(bucket.replace("Y", ""))
    : Number(bucket.replace("M", "")) / 12;
  const docId = nextId("RTS");
  const currency = a.instrument.currency;
  const startMs = a.tradeMs + MONTH_MS;
  const endMs = startMs + years * 12 * MONTH_MS;
  const fixingTenor = years <= 1 ? "3M" : "1Y";

  let economics: Record<string, unknown>;
  if (a.incomplete) {
    economics = { Currency: {} };
  } else if (a.productType === "IR.Swaption") {
    economics = {
      Type: "IR.Swaption",
      AssetType: "Swaption European",
      SwapStartDate: isoMs(startMs),
      SwapEndDate: isoMs(endMs),
      Notional: Math.round(a.notional),
      SwaptionStrike: Number(a.level.toFixed(4)),
      Frequency: 1,
      FloatFrequency: 1,
      FloatSpread: 0,
      TradeType: `${a.direction > 0 ? "Pay" : "Receive"} fixed ${bucket} vs ${index}`,
      ExerciseType: "Bermudan",
      PayOrReceive: a.direction > 0 ? "Pay" : "Receive",
      ExpiryDate: isoMs(startMs - 5 * 86_400_000),
      Currency: { Type: "ID.ISO", ISOCode: currency },
      FixingIndex: { Type: "ID.FixingCurve", FixingIndex: index, FixingTenor: fixingTenor },
      PremiumCurrency: { Currency: { Type: "ID.ISO", ISOCode: currency } },
    };
  } else if (a.productType === "IR.CapFloor") {
    // A bought cap is long rates; a bought floor is short rates.
    const isFloor = a.direction < 0;
    economics = {
      Type: "IR.CapFloor",
      AssetType: isFloor ? "Interest Rate Floor" : "Interest Rate Cap",
      Notional: Math.round(a.notional),
      Strike: Number(a.level.toFixed(4)),
      TradeType: "Buy",
      Frequency: 3,
      StartDate: isoMs(startMs),
      MaturityDate: isoMs(endMs),
      ForwardOrBackwardFixing: false,
      Currency: { Type: "ID.ISO", ISOCode: currency },
      FixingIndex: { Type: "ID.FixingCurve", FixingIndex: index, FixingTenor: "3M" },
    };
  } else {
    economics = {
      Type: "IR.FRA",
      Notional: Math.round(a.notional) * a.direction,
      FixedRate: Number(a.level.toFixed(4)),
      StartDate: isoMs(startMs),
      MaturityDate: isoMs(endMs),
      Currency: { Type: "ID.ISO", ISOCode: currency },
    };
  }

  return {
    doc_id: docId,
    family: "rates",
    source: "synthetic",
    scenario_tag: a.scenarioTag ?? null,
    payload: {
      Type: "Master.Transaction",
      ExtractDate: isoMs(a.tradeMs + 3 * 86_400_000),
      Execution: {
        Type: a.internalTrade ? "internalTrade" : "withClientTrade",
        TradeDate: isoMs(a.tradeMs),
        TradeID: docId,
        TraderID: a.trader.trader_id,
        Counterparty: cpObject(a.counterparty),
        Economics: economics,
      },
      Unit: unit(a.trader, "Unit.Desk", "Rates"),
    },
  };
}

/* ------------------------------------------------------------------ */
/* Fenics order streams (FixedIncome.Bond)                             */
/* ------------------------------------------------------------------ */

export interface FenicsFill {
  ms: number;
  price: number;
  amount: number; // absolute
  counterparty: Counterparty;
  venueIndex?: number;
}

export interface FenicsArgs {
  trader: Trader;
  instrument: Instrument; // BOND:ISIN
  side: 1 | -1; // +1 = bid, -1 = offer
  limitPrice: number;
  totalAmount: number; // absolute
  displayAmount?: number;
  startMs: number;
  /** Amendments: [ms, newLimitPrice, newTotalAmount] */
  amendments?: { ms: number; limitPrice: number; totalAmount: number }[];
  fills?: FenicsFill[];
  /** When set, a Close event is written at this time (order pulled). */
  closeMs?: number;
  scenarioTag?: string | null;
}

export function fenicsDoc(a: FenicsArgs): SourceDocument {
  const isin = a.instrument.instrument.split(":")[1];
  const docId = nextId("FNX");
  const sign = a.side;
  const events: Record<string, unknown>[] = [];

  events.push({
    Type: "OrderEvent.OpenLimitOrder",
    EventID: `${docId}-E1`,
    LimitPrice: price7(a.limitPrice),
    TotalAmount: amountStr(a.totalAmount * sign),
    DisplayAmount: amountStr((a.displayAmount ?? a.totalAmount) * sign),
    EventDateTime: fenicsTime(a.startMs),
  });

  (a.amendments ?? []).forEach((am, i) => {
    events.push({
      Type: "OrderEvent.Amendment",
      EventID: `${docId}-A${i + 1}`,
      LimitPrice: price7(am.limitPrice),
      TotalAmount: amountStr(am.totalAmount * sign),
      DisplayAmount: amountStr(am.totalAmount * sign),
      EventDateTime: fenicsTime(am.ms),
    });
  });

  (a.fills ?? []).forEach((f, i) => {
    events.push({
      Type: "OrderEvent.Fill",
      EventID: `${docId}-F${i + 1}`,
      Price: price7(f.price),
      PriceType: "Price",
      Amount: amountStr(f.amount * sign),
      Counterparty: cpObject(f.counterparty),
      Venue: VENUES[(f.venueIndex ?? i) % VENUES.length],
      EventDateTime: fenicsTime(f.ms),
    });
  });

  const lastMs = a.closeMs ?? Math.max(a.startMs, ...(a.fills ?? []).map((f) => f.ms));
  if (a.closeMs) {
    events.push({
      Type: "OrderEvent.Close",
      EventID: `${docId}-C1`,
      EventDateTime: fenicsTime(a.closeMs),
    });
  }

  return {
    doc_id: docId,
    family: "fenics",
    source: "synthetic",
    scenario_tag: a.scenarioTag ?? null,
    payload: {
      Type: "Master.Transaction",
      ExtractDate: fenicsTime(lastMs).slice(0, 10),
      Execution: {
        Type: "Execution.OrderStream",
        OrderStartDate: fenicsTime(a.startMs),
        OrderEndDate: fenicsTime(lastMs),
        OrderMessageID: docId,
        TraderID: a.trader.trader_id,
        Economics: {
          Type: "FixedIncome.Bond",
          Identifier: { Type: "ID.ISIN", ISINCode: isin },
          PrincipalAmount: amountStr(a.totalAmount * sign),
          Price: price7(a.limitPrice),
          PriceType: "Price",
          PriceCurrency: { Type: "ID.ISO", ISOCode: a.instrument.currency },
        },
        Events: events,
      },
      Unit: unit(a.trader, "Unit.Book", "Rates"),
    },
  };
}

/** Fenics timestamps have no zone marker and microsecond precision. */
function fenicsTime(ms: number): string {
  const iso = new Date(ms).toISOString(); // YYYY-MM-DDTHH:MM:SS.sssZ
  return `${iso.slice(0, 10)} ${iso.slice(11, 23)}000`;
}

/* ------------------------------------------------------------------ */
/* FX.Spot                                                             */
/* ------------------------------------------------------------------ */

export interface FxArgs {
  trader: Trader;
  counterparty: Counterparty;
  buyCurrency: string;
  sellCurrency: string;
  buyAmount: number;
  sellAmount: number;
  /** Quote per base for the headline pair. */
  rate: number;
  pair: string;
  notionalUsd: number;
  tradeMs: number;
  internalTrade?: boolean;
  scenarioTag?: string | null;
}

export function fxDoc(a: FxArgs): SourceDocument {
  const docId = nextId("FXS");
  return {
    doc_id: docId,
    family: "fx",
    source: "synthetic",
    scenario_tag: a.scenarioTag ?? null,
    payload: {
      Type: "Master.Transaction",
      ExtractDate: isoMs(a.tradeMs + 86_400_000),
      Execution: {
        Type: a.internalTrade ? "internalTrade" : "withClientTrade",
        TradeDate: isoMs(a.tradeMs),
        TradeID: docId,
        TraderID: a.trader.trader_id,
        Counterparty: cpObject(a.counterparty),
        Economics: {
          Type: "FX.Spot",
          AssetType: "Spot",
          CurrencyPair: a.pair,
          Notional: Math.round(a.notionalUsd),
          Price: Number(a.rate.toPrecision(9)),
          PriceType: "Price",
          BuyCurrency: { Type: "ID.ISO", ISOCode: a.buyCurrency },
          SellCurrency: { Type: "ID.ISO", ISOCode: a.sellCurrency },
          BuyAmount: Number(a.buyAmount.toFixed(2)),
          SellAmount: Number(a.sellAmount.toFixed(2)),
          Currency: { Type: "ID.ISO", ISOCode: "USD" },
        },
      },
      Unit: unit(a.trader, "Unit.Desk", "FX"),
    },
  };
}
