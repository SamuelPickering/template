import type { MarketData } from "@/lib/models/market";
import { dayStartMs } from "@/lib/time";

/**
 * Scenario sizing.
 *
 * Most metrics score as USD Value = EMI x PTC, and both terms scale with the
 * notional traded, so the score is roughly quadratic in size:
 *
 *   USD Value ~ decay x K x volatility x valueFactor x N^2 / ADTV
 *
 * Inverting that gives the notional an engineered scenario needs to land at a
 * chosen USD Value on a given instrument and day. That keeps the severity
 * tiers meaningful across asset classes with wildly different liquidity —
 * a tier that needs $200m of a major currency needs a small fraction of that
 * in a thin corporate bond.
 */
export function notionalForTarget(
  market: MarketData,
  instrument: string,
  date: string,
  targetUsd: number,
  decayFactor = 0.7,
): number {
  const inst = market.instrument(instrument);
  if (!inst) return 0;
  const ms = dayStartMs(date) + 12 * 3600 * 1000;
  const vol = market.volatility(instrument, date);
  const adtv = market.adtv(instrument, date);
  const valueFactor = market.valueFactor(instrument, ms);
  const coef = decayFactor * inst.impact_k * vol * valueFactor;
  if (coef <= 0) return 0;
  const n = Math.sqrt((targetUsd * adtv) / coef);
  // Keep a single scenario from claiming an implausible share of the day.
  return Math.round(Math.min(n, adtv * 0.6));
}

/** Notional needed for a linear score: deviation x notional. */
export function notionalForLinearTarget(targetUsd: number, deviationFraction: number): number {
  return Math.round(targetUsd / Math.max(1e-9, deviationFraction));
}
