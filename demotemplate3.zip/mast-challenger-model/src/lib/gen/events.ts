import type { Instrument, MarketEvent } from "@/lib/types";
import { atMinute, isoMs } from "@/lib/time";
import { hashSeed, mulberry32, pick, randInt, randRange } from "./rng";

/**
 * Event Generator.
 *
 * A calendar of things that move a market: rating actions and profit warnings
 * on credit names, rate decisions and inflation prints on the curves, issuer
 * news on bonds, macro surprises on currencies. Each event carries the
 * instrument it moves, a signed move and the timestamp at which it became
 * public, and the market model applies it as a step change at exactly that
 * timestamp — so a position held into the announcement is worth precisely what
 * the model says it is worth.
 */
const CREDIT_EVENTS = [
  { title: "Rating downgrade for {REF}", detail: "An agency cut the issuer rating; protection repriced wider.", sign: 1 },
  { title: "Profit warning at {REF}", detail: "The issuer guided materially below consensus.", sign: 1 },
  { title: "{REF} refinancing completed", detail: "The issuer termed out its near-dated maturities.", sign: -1 },
  { title: "Rating outlook raised on {REF}", detail: "An agency moved the outlook to positive.", sign: -1 },
  { title: "Leveraged bid reported for {REF}", detail: "Press reported a debt-funded approach for the issuer.", sign: 1 },
];

const RATES_EVENTS = [
  { title: "{CCY} central bank rate decision", detail: "The policy rate and statement landed away from consensus.", sign: 0 },
  { title: "{CCY} inflation print", detail: "Headline CPI surprised the survey median.", sign: 0 },
  { title: "{CCY} employment report", detail: "Payrolls and wage growth repriced the policy path.", sign: 0 },
  { title: "Unscheduled {CCY} policy statement", detail: "An unscheduled statement reset the front end.", sign: 0 },
  { title: "{CCY} supply announcement", detail: "A larger-than-expected auction calendar steepened the curve.", sign: 1 },
];

const BOND_EVENTS = [
  { title: "Tender offer announced for {REF}", detail: "The issuer offered to buy back the line above market.", sign: 1 },
  { title: "Covenant breach reported at {REF}", detail: "A reporting covenant was missed; the line gapped lower.", sign: -1 },
  { title: "Index inclusion for {REF}", detail: "The line enters a benchmark index at the next rebalance.", sign: 1 },
];

const FX_EVENTS = [
  { title: "{CCY} central bank decision", detail: "The policy decision and statement moved the currency.", sign: 0 },
  { title: "Geopolitical headline hits {CCY}", detail: "A cross-border security headline reset risk premia.", sign: 0 },
  { title: "{CCY} intervention speculation", detail: "Officials were reported checking rates with dealers.", sign: 0 },
];

export function generateEvents(opts: {
  instruments: Instrument[];
  dates: string[];
  seed?: number;
  count?: number;
}): MarketEvent[] {
  const rng = mulberry32(hashSeed("events", opts.seed ?? 20260101));
  // Leave a few sessions at each end so every event has a full lookback window.
  const usable = opts.dates.slice(3, opts.dates.length - 1);
  const count = opts.count ?? 46;
  const out: MarketEvent[] = [];
  const used = new Set<string>();

  for (let i = 0; i < count; i++) {
    const inst = pick(rng, opts.instruments);
    let date = pick(rng, usable);
    let guard = 0;
    while (used.has(`${inst.instrument}|${date}`) && guard++ < 20) date = pick(rng, usable);
    used.add(`${inst.instrument}|${date}`);

    const scheduled = rng() < 0.55;
    let headline = "";
    let description = "";
    let magnitude = 0;
    let sign = rng() < 0.5 ? -1 : 1;

    if (inst.family === "credit") {
      const t = pick(rng, CREDIT_EVENTS);
      const ref = inst.instrument.split(":")[1].split("/")[0];
      headline = t.title.replace("{REF}", ref);
      description = t.detail.replace("{REF}", ref);
      if (t.sign !== 0) sign = t.sign as 1 | -1;
      // Credit spreads move in big relative steps on name-specific news.
      magnitude = scheduled ? randRange(rng, 1.5, 5) : randRange(rng, 5, 16);
    } else if (inst.family === "rates") {
      const t = pick(rng, RATES_EVENTS);
      headline = t.title.replace("{CCY}", inst.currency);
      description = t.detail.replace("{CCY}", inst.currency);
      if (t.sign !== 0) sign = t.sign as 1 | -1;
      magnitude = scheduled ? randRange(rng, 0.6, 2.4) : randRange(rng, 2, 6);
    } else if (inst.family === "fenics") {
      const t = pick(rng, BOND_EVENTS);
      headline = t.title.replace("{REF}", inst.label);
      description = t.detail.replace("{REF}", inst.label);
      sign = t.sign as 1 | -1;
      magnitude = randRange(rng, 0.4, 2.2);
    } else {
      const t = pick(rng, FX_EVENTS);
      headline = t.title.replace("{CCY}", inst.currency);
      description = t.detail.replace("{CCY}", inst.currency);
      magnitude = scheduled ? randRange(rng, 0.3, 1.1) : randRange(rng, 0.8, 2.4);
    }

    const minute = scheduled
      ? pick(rng, [8 * 60, 9 * 60, 12 * 60 + 30, 13 * 60 + 30, 14 * 60, 18 * 60])
      : randInt(rng, 7 * 60, 17 * 60);
    const publicMs = atMinute(date, minute, randInt(rng, 0, 59_000));

    out.push({
      event_id: `EV${String(i + 1).padStart(3, "0")}`,
      headline,
      description,
      instrument: inst.instrument,
      kind: scheduled ? "scheduled" : "surprise",
      move_pct: Number((sign * magnitude).toFixed(3)),
      public_ms: publicMs,
      public_datetime: isoMs(publicMs),
      trade_date: date,
    });
  }
  out.sort((a, b) => a.public_ms - b.public_ms);
  return out;
}
