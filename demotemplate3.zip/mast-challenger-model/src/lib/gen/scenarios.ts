import type {
  Counterparty,
  Instrument,
  MarketEvent,
  ProductFamily,
  SourceDocument,
  Trader,
} from "@/lib/types";
import type { MarketData } from "@/lib/models/market";
import { creditDoc, fenicsDoc, ratesDoc } from "./docs";
import { fxTrade } from "./fxhelp";
import { notionalForTarget } from "./calibrate";
import { docTime, emit } from "./background";
import { hashSeed, mulberry32, pick, randInt, randRange, type Rng } from "./rng";
import { FIX_MIN, MS_MIN, atMinute, dateKey } from "@/lib/time";

/**
 * Scenario-engineered instances.
 *
 * Every in-scope metric gets deliberately-constructed cases across the
 * product families the metric can actually be evidenced in, and the five the
 * business cares about most — Wash Trading, Front Running, Best Execution,
 * Spoofing and Layering — get three severity tiers each so the admin
 * thresholds visibly change what is flagged.
 *
 * Each engineered document carries a `scenario_tag`. It exists purely so the
 * QA script can check coverage; no detector reads it.
 */
export interface ScenarioBundle {
  documents: SourceDocument[];
}

interface Ctx {
  rng: Rng;
  dates: string[];
  traders: Trader[];
  counterparties: Counterparty[];
  instruments: Instrument[];
  market: MarketData;
  events: MarketEvent[];
  docs: SourceDocument[];
}

export const TIERS = ["barely", "significant", "major"] as const;
export type Tier = (typeof TIERS)[number];

/* ------------------------------------------------------------------ */
/* helpers                                                             */
/* ------------------------------------------------------------------ */

function instFor(ctx: Ctx, family: ProductFamily): Instrument {
  const pool = ctx.instruments.filter(
    (i) => i.family === family && !i.instrument.includes("NOTICKER"),
  );
  return pick(ctx.rng, pool);
}

function trader(ctx: Ctx, role: Trader["trade_role"], exceptId?: string): Trader {
  const pool = ctx.traders.filter(
    (t) => t.trade_role === role && (!exceptId || t.trader_id !== exceptId),
  );
  return pick(ctx.rng, pool.length ? pool : ctx.traders);
}

function cp(ctx: Ctx, kind: "client" | "dealer" | "internal"): Counterparty {
  const prefix = kind === "client" ? "CP-CL" : kind === "dealer" ? "CP-DL" : "INT";
  const pool = ctx.counterparties.filter((c) => c.counterparty_code.startsWith(prefix));
  return pick(ctx.rng, pool);
}

function midDate(ctx: Ctx): string {
  return pick(ctx.rng, ctx.dates.slice(5, ctx.dates.length - 2));
}

const FAMILY_ROTATION: ProductFamily[] = ["credit", "rates", "fenics", "fx"];

/** One ordinary-looking execution in the right schema for the instrument. */
function one(
  ctx: Ctx,
  args: {
    trader: Trader;
    inst: Instrument;
    direction: 1 | -1;
    notionalUsd: number;
    ms: number;
    tag: string;
    counterparty?: Counterparty;
    internal?: boolean;
    levelOverride?: number;
  },
) {
  const { inst, ms } = args;
  const tradeMs = Math.round(ms);
  if (inst.family === "credit") {
    ctx.docs.push(
      creditDoc({
        trader: args.trader,
        counterparty: args.counterparty ?? cp(ctx, "dealer"),
        instrument: inst,
        notional: args.notionalUsd,
        direction: args.direction,
        tradeMs,
        upfront: pick(ctx.rng, [0, 0, 1, -1]),
        internalTrade: args.internal,
        scenarioTag: args.tag,
      }),
    );
    return;
  }
  if (inst.family === "rates") {
    ctx.docs.push(
      ratesDoc({
        trader: args.trader,
        counterparty: args.counterparty ?? cp(ctx, "dealer"),
        instrument: inst,
        productType: pick(ctx.rng, ["IR.Swaption", "IR.CapFloor", "IR.FRA"] as const),
        notional: args.notionalUsd,
        direction: args.direction,
        level: args.levelOverride ?? ctx.market.level(inst.instrument, tradeMs),
        tradeMs,
        internalTrade: args.internal,
        scenarioTag: args.tag,
      }),
    );
    return;
  }
  if (inst.family === "fenics") {
    const mid = ctx.market.level(inst.instrument, tradeMs);
    const price = args.levelOverride ?? mid + (args.direction > 0 ? 0.01 : -0.01);
    const amount = args.notionalUsd / ctx.market.usdRate(inst.currency, tradeMs);
    ctx.docs.push(
      fenicsDoc({
        trader: args.trader,
        instrument: inst,
        side: args.direction,
        limitPrice: price,
        totalAmount: amount,
        startMs: tradeMs,
        fills: [
          {
            ms: tradeMs + randInt(ctx.rng, 1_000, 20_000),
            price,
            amount,
            counterparty: args.counterparty ?? cp(ctx, "dealer"),
          },
        ],
        scenarioTag: args.tag,
      }),
    );
    return;
  }
  // An FX level override is expressed in the instrument's terms (USD per unit
  // of the currency); fxTrade turns that into the right headline rate.
  const fxLevel = ctx.market.level(inst.instrument, tradeMs);
  ctx.docs.push(
    fxTrade({
      trader: args.trader,
      counterparty: args.counterparty ?? cp(ctx, "dealer"),
      currency: inst.currency_code ?? inst.currency,
      direction: args.direction,
      notionalUsd: args.notionalUsd,
      ms: tradeMs,
      market: ctx.market,
      levelDeviation:
        args.levelOverride && fxLevel ? args.levelOverride / fxLevel - 1 : undefined,
      internalTrade: args.internal,
      scenarioTag: args.tag,
    }),
  );
}

/* ------------------------------------------------------------------ */
/* Ramping                                                             */
/* ------------------------------------------------------------------ */

function ramping(ctx: Ctx, tier: Tier, target: number, family: ProductFamily) {
  const t = trader(ctx, "prop");
  const inst = instFor(ctx, family);
  const date = midDate(ctx);
  const dir: 1 | -1 = ctx.rng() < 0.5 ? 1 : -1;
  const total = notionalForTarget(ctx.market, inst.instrument, date, target, 0.72);
  if (total <= 0) return;
  const n = randInt(ctx.rng, 5, 8);
  const startMin = randRange(ctx.rng, 8 * 60, 13.5 * 60);
  const buildMin = randRange(ctx.rng, 22, 45);
  const tag = `ramping_${tier}`;

  for (let i = 0; i < n; i++) {
    one(ctx, {
      trader: t,
      inst,
      direction: dir,
      notionalUsd: (total / n) * randRange(ctx.rng, 0.82, 1.18),
      ms: atMinute(date, startMin + (buildMin * i) / n, randInt(ctx.rng, 0, 20_000)),
      tag,
    });
  }
  const revStart = startMin + buildMin + randRange(ctx.rng, 4, 18);
  const legs = randInt(ctx.rng, 2, 3);
  for (let i = 0; i < legs; i++) {
    one(ctx, {
      trader: t,
      inst,
      direction: dir === 1 ? -1 : 1,
      notionalUsd: (total / legs) * randRange(ctx.rng, 0.9, 1.1),
      ms: atMinute(date, revStart + i * randRange(ctx.rng, 1, 4), randInt(ctx.rng, 0, 20_000)),
      tag,
    });
  }
}

/* ------------------------------------------------------------------ */
/* Wash trading — five variants, three tiers on the plain one           */
/* ------------------------------------------------------------------ */

function washPlain(ctx: Ctx, tier: Tier, target: number, family: ProductFamily) {
  const t = trader(ctx, "prop");
  const inst = instFor(ctx, family);
  const date = midDate(ctx);
  const dir: 1 | -1 = ctx.rng() < 0.5 ? 1 : -1;
  const size = notionalForTarget(ctx.market, inst.instrument, date, target, 0.95);
  if (size <= 0) return;
  const startMin = randRange(ctx.rng, 8 * 60, 15 * 60);
  const gap = randRange(ctx.rng, 1.5, 9);
  const internal = cp(ctx, "internal");
  const tag = `wash_${tier}`;

  one(ctx, {
    trader: t, inst, direction: dir, notionalUsd: size,
    ms: atMinute(date, startMin, randInt(ctx.rng, 0, 30_000)),
    tag, counterparty: internal, internal: true,
  });
  one(ctx, {
    trader: t, inst, direction: dir === 1 ? -1 : 1,
    notionalUsd: size * randRange(ctx.rng, 0.97, 1.03),
    ms: atMinute(date, startMin + gap, randInt(ctx.rng, 0, 30_000)),
    tag, counterparty: internal, internal: true,
  });
}

/**
 * Cross-tenor wash: the two legs quote different tenors — 58M against 61M —
 * which both sit on the same five-year curve point once bucketed, so the
 * offset only becomes visible after the tenor normalisation.
 */
function washCrossTenor(ctx: Ctx, target: number) {
  const t = trader(ctx, "prop");
  const inst = instFor(ctx, "credit");
  const date = midDate(ctx);
  const dir: 1 | -1 = ctx.rng() < 0.5 ? 1 : -1;
  const size = notionalForTarget(ctx.market, inst.instrument, date, target, 0.95);
  if (size <= 0) return;
  const startMin = randRange(ctx.rng, 8 * 60, 15 * 60);
  const internal = cp(ctx, "internal");
  const years = Number((inst.tenor ?? "5Y").replace("Y", "")) || 5;
  const months = [years * 12 - 2, years * 12 + 1];
  const tag = "wash_cross_tenor";

  months.forEach((m, i) => {
    const doc = creditDoc({
      trader: t,
      counterparty: internal,
      instrument: inst,
      notional: size * randRange(ctx.rng, 0.98, 1.02),
      direction: i === 0 ? dir : dir === 1 ? -1 : 1,
      tradeMs: atMinute(date, startMin + i * randRange(ctx.rng, 2, 8), randInt(ctx.rng, 0, 30_000)),
      internalTrade: true,
      scenarioTag: tag,
    });
    // Restate the tenor so the two legs look like different contracts.
    const econ = (doc.payload.Execution as Record<string, unknown>).Economics as Record<string, unknown>;
    (econ.Identifier as Record<string, unknown>).Tenor = `${m}M`;
    ctx.docs.push(doc);
  });
}

/**
 * Cross-product wash: the offset is split across two different rates products
 * on the same curve point — a swaption against a cap — so neither product's
 * own blotter shows a round trip.
 */
function washCrossProduct(ctx: Ctx, target: number) {
  const t = trader(ctx, "prop");
  const inst = instFor(ctx, "rates");
  const date = midDate(ctx);
  const dir: 1 | -1 = ctx.rng() < 0.5 ? 1 : -1;
  const size = notionalForTarget(ctx.market, inst.instrument, date, target, 0.95);
  if (size <= 0) return;
  const startMin = randRange(ctx.rng, 8 * 60, 15 * 60);
  const internal = cp(ctx, "internal");
  const level = ctx.market.level(inst.instrument, atMinute(date, startMin));
  const tag = "wash_cross_product";

  ctx.docs.push(
    ratesDoc({
      trader: t, counterparty: internal, instrument: inst, productType: "IR.Swaption",
      notional: size, direction: dir, level, tradeMs: atMinute(date, startMin, 0),
      internalTrade: true, scenarioTag: tag,
    }),
    ratesDoc({
      trader: t, counterparty: internal, instrument: inst, productType: "IR.CapFloor",
      notional: size * randRange(ctx.rng, 0.98, 1.02), direction: dir === 1 ? -1 : 1,
      level, tradeMs: atMinute(date, startMin + randRange(ctx.rng, 2, 10), 0),
      internalTrade: true, scenarioTag: tag,
    }),
  );
}

/** Multi-counterparty wash: a round trip spread across related accounts. */
function washMultiCounterparty(ctx: Ctx, target: number, family: ProductFamily) {
  const t = trader(ctx, "prop");
  const inst = instFor(ctx, family);
  const date = midDate(ctx);
  const dir: 1 | -1 = ctx.rng() < 0.5 ? 1 : -1;
  const size = notionalForTarget(ctx.market, inst.instrument, date, target, 0.95);
  if (size <= 0) return;
  const startMin = randRange(ctx.rng, 8 * 60, 14.5 * 60);
  const internals = ctx.counterparties.filter((c) => c.kind === "internal");
  const tag = "wash_multi_counterparty";

  one(ctx, {
    trader: t, inst, direction: dir, notionalUsd: size,
    ms: atMinute(date, startMin, 0), tag, counterparty: internals[0], internal: true,
  });
  [0.5, 0.5].forEach((frac, i) => {
    one(ctx, {
      trader: t, inst, direction: dir === 1 ? -1 : 1,
      notionalUsd: size * frac * randRange(ctx.rng, 0.97, 1.03),
      ms: atMinute(date, startMin + randRange(ctx.rng, 2, 12), randInt(ctx.rng, 0, 30_000)),
      tag, counterparty: internals[(i + 1) % internals.length], internal: true,
    });
  });
}

/** Cross-currency wash: offsetting FX legs booked in two different pairs. */
function washCrossCurrency(ctx: Ctx, target: number) {
  const t = trader(ctx, "prop");
  const inst = instFor(ctx, "fx");
  const date = midDate(ctx);
  const dir: 1 | -1 = ctx.rng() < 0.5 ? 1 : -1;
  const size = notionalForTarget(ctx.market, inst.instrument, date, target, 0.95);
  if (size <= 0) return;
  const startMin = randRange(ctx.rng, 8 * 60, 15 * 60);
  const internal = cp(ctx, "internal");
  const ccy = inst.currency_code ?? inst.currency;
  const others = ["JPY", "EUR", "GBP", "CHF"].filter((c) => c !== ccy);
  const tag = "wash_cross_currency";

  [
    { against: others[0], direction: dir, min: startMin },
    { against: others[1], direction: (dir === 1 ? -1 : 1) as 1 | -1, min: startMin + randRange(ctx.rng, 2, 12) },
  ].forEach((leg) => {
    ctx.docs.push(
      fxTrade({
        trader: t,
        counterparty: internal,
        currency: ccy,
        against: leg.against,
        direction: leg.direction,
        notionalUsd: size * randRange(ctx.rng, 0.98, 1.02),
        ms: atMinute(date, leg.min, randInt(ctx.rng, 0, 30_000)),
        market: ctx.market,
        internalTrade: true,
        scenarioTag: tag,
      }),
    );
  });
}

/* ------------------------------------------------------------------ */
/* Front running / internal front running                              */
/* ------------------------------------------------------------------ */

function frontRunning(
  ctx: Ctx,
  tier: Tier | "internal",
  target: number,
  family: ProductFamily,
) {
  const internal = tier === "internal";
  const facilitator = trader(ctx, "client_facilitation");
  const beneficiary = internal ? trader(ctx, "prop", facilitator.trader_id) : facilitator;
  const inst = instFor(ctx, family);
  const date = midDate(ctx);
  const dir: 1 | -1 = ctx.rng() < 0.5 ? 1 : -1;
  const size = notionalForTarget(ctx.market, inst.instrument, date, target, 0.9);
  if (size <= 0) return;
  const startMin = randRange(ctx.rng, 8 * 60, 14 * 60);
  const tag = internal ? "internal_front_running" : `front_running_${tier}`;

  // 1. Proprietary position opened ahead of the client flow.
  one(ctx, {
    trader: beneficiary, inst, direction: dir,
    notionalUsd: size * randRange(ctx.rng, 0.9, 1.05),
    ms: atMinute(date, startMin, 0), tag, counterparty: cp(ctx, "dealer"),
  });
  // 2. The client order is filled in the market, moving the level.
  const legs = randInt(ctx.rng, 2, 4);
  const facMin = startMin + randRange(ctx.rng, 2, 6);
  for (let i = 0; i < legs; i++) {
    one(ctx, {
      trader: facilitator, inst, direction: dir,
      notionalUsd: (size / legs) * randRange(ctx.rng, 0.85, 1.15),
      ms: atMinute(date, facMin + i * randRange(ctx.rng, 0.2, 0.8), randInt(ctx.rng, 0, 20_000)),
      tag, counterparty: cp(ctx, "client"),
    });
  }
  // 3. The prop position exits into that impact.
  one(ctx, {
    trader: beneficiary, inst, direction: dir === 1 ? -1 : 1,
    notionalUsd: size * randRange(ctx.rng, 0.9, 1.05),
    ms: atMinute(date, facMin + randRange(ctx.rng, 1.5, 5), randInt(ctx.rng, 0, 20_000)),
    tag, counterparty: cp(ctx, "dealer"),
  });
}

/* ------------------------------------------------------------------ */
/* Best Execution                                                      */
/* ------------------------------------------------------------------ */

/**
 * Best Execution: the client is filled materially worse than the firm could
 * have achieved. Two evidenced shapes:
 *
 *  - Fenics: a better price was printing on the same ISIN moments earlier, in
 *    the firm's own order data, and the client fill ignored it.
 *  - Rates and FX: the client is priced away from the prevailing market level
 *    by far more than any plausible spread.
 */
function bestExecution(ctx: Ctx, tier: Tier, target: number, family: ProductFamily) {
  const t = trader(ctx, "client_facilitation");
  // Best execution needs a comparable execution price, which means bonds or FX.
  const inst = instFor(ctx, family === "fx" ? "fx" : "fenics");
  const date = midDate(ctx);
  const client = cp(ctx, "client");
  const tag = `best_execution_${tier}`;
  const startMin = randRange(ctx.rng, 8.5 * 60, 15.5 * 60);
  const baseMs = atMinute(date, startMin, 0);

  if (inst.family === "fenics") {
    const mid = ctx.market.level(inst.instrument, baseMs);
    // Detriment in price points; the client notional sets the dollar value.
    const detriment = randRange(ctx.rng, 0.12, 0.55);
    const clientNotional = Math.round(target / (detriment / mid));
    const amount = clientNotional / ctx.market.usdRate(inst.currency, baseMs);
    const side: 1 | -1 = ctx.rng() < 0.5 ? 1 : -1;

    // The better price, printed with another counterparty moments earlier.
    const refAmount = amount * randRange(ctx.rng, 0.35, 0.8);
    ctx.docs.push(
      fenicsDoc({
        trader: t,
        instrument: inst,
        side,
        limitPrice: mid,
        totalAmount: refAmount,
        startMs: baseMs - randInt(ctx.rng, 40_000, 150_000),
        fills: [
          {
            ms: baseMs - randInt(ctx.rng, 10_000, 35_000),
            price: mid,
            amount: refAmount,
            counterparty: cp(ctx, "dealer"),
          },
        ],
        scenarioTag: tag,
      }),
      // The client fill, away from that level on the wrong side for the client.
      fenicsDoc({
        trader: t,
        instrument: inst,
        side,
        limitPrice: side > 0 ? mid - detriment : mid + detriment,
        totalAmount: amount,
        startMs: baseMs,
        fills: [
          {
            ms: baseMs + randInt(ctx.rng, 2_000, 25_000),
            price: side > 0 ? mid - detriment : mid + detriment,
            amount,
            counterparty: client,
          },
        ],
        scenarioTag: tag,
      }),
    );
    return;
  }

  // Rates and FX: price the client away from the prevailing level.
  const level = ctx.market.level(inst.instrument, baseMs);
  const deviation = randRange(ctx.rng, 0.004, 0.02);
  const notional = Math.round(target / deviation);
  const dir: 1 | -1 = ctx.rng() < 0.5 ? 1 : -1;
  one(ctx, {
    trader: t,
    inst,
    direction: dir,
    notionalUsd: notional,
    ms: baseMs,
    tag,
    counterparty: client,
    levelOverride: level * (1 + deviation * (dir > 0 ? -1 : 1)),
  });
}

/* ------------------------------------------------------------------ */
/* Spoofing and Layering (separate metrics, both order-driven)          */
/* ------------------------------------------------------------------ */

/**
 * Spoofing: one large, highly visible order placed at the touch and pulled
 * within seconds without filling, while the trader executes on the other side.
 */
function spoofing(ctx: Ctx, tier: Tier, target: number) {
  const t = trader(ctx, "prop");
  const inst = instFor(ctx, "fenics");
  const date = midDate(ctx);
  const startMin = randRange(ctx.rng, 8.5 * 60, 15.5 * 60);
  const startMs = atMinute(date, startMin, 0);
  const mid = ctx.market.level(inst.instrument, startMs);
  const decoySide: 1 | -1 = ctx.rng() < 0.5 ? 1 : -1;
  const tag = `spoofing_${tier}`;

  const decoyUsd = notionalForTarget(ctx.market, inst.instrument, date, target, 0.9) * 1.8;
  if (decoyUsd <= 0) return;
  const decoyAmount = decoyUsd / ctx.market.usdRate(inst.currency, startMs);
  const life = randInt(ctx.rng, 3_000, 25_000);

  // The decoy: sits right at the touch, fully displayed, never fills.
  ctx.docs.push(
    fenicsDoc({
      trader: t,
      instrument: inst,
      side: decoySide,
      limitPrice: decoySide > 0 ? mid - 0.002 : mid + 0.002,
      totalAmount: decoyAmount,
      displayAmount: decoyAmount,
      startMs,
      closeMs: startMs + life,
      scenarioTag: tag,
    }),
  );
  // The genuine trade, on the other side, while the decoy is resting.
  const realAmount = decoyAmount * randRange(ctx.rng, 0.3, 0.55);
  ctx.docs.push(
    fenicsDoc({
      trader: t,
      instrument: inst,
      side: decoySide === 1 ? -1 : 1,
      limitPrice: decoySide > 0 ? mid + 0.01 : mid - 0.01,
      totalAmount: realAmount,
      startMs: startMs + Math.round(life * 0.3),
      fills: [
        {
          ms: startMs + Math.round(life * 0.6),
          price: decoySide > 0 ? mid + 0.012 : mid - 0.012,
          amount: realAmount,
          counterparty: cp(ctx, "dealer"),
        },
      ],
      scenarioTag: tag,
    }),
  );
}

/**
 * Layering: a ladder of orders at successive price levels on one side,
 * building apparent depth, pulled together without filling, with the real
 * execution on the opposite side.
 */
function layering(ctx: Ctx, tier: Tier, target: number) {
  const t = trader(ctx, "prop");
  const inst = instFor(ctx, "fenics");
  const date = midDate(ctx);
  const startMin = randRange(ctx.rng, 8.5 * 60, 15.5 * 60);
  const startMs = atMinute(date, startMin, 0);
  const mid = ctx.market.level(inst.instrument, startMs);
  const side: 1 | -1 = ctx.rng() < 0.5 ? 1 : -1;
  const tag = `layering_${tier}`;

  const ladderUsd = notionalForTarget(ctx.market, inst.instrument, date, target, 0.9) * 1.8;
  if (ladderUsd <= 0) return;
  const rungs = randInt(ctx.rng, 4, 7);
  const perRung = ladderUsd / rungs / ctx.market.usdRate(inst.currency, startMs);
  const tick = 0.015;

  for (let i = 0; i < rungs; i++) {
    const placed = startMs + i * randInt(ctx.rng, 700, 2_600);
    const level = side > 0 ? mid - 0.002 - i * tick : mid + 0.002 + i * tick;
    ctx.docs.push(
      fenicsDoc({
        trader: t,
        instrument: inst,
        side,
        limitPrice: level,
        totalAmount: perRung * randRange(ctx.rng, 0.85, 1.15),
        displayAmount: perRung,
        startMs: placed,
        // Walking the price in with amendments is part of the pattern.
        amendments:
          ctx.rng() < 0.45
            ? [
                {
                  ms: placed + randInt(ctx.rng, 1_500, 6_000),
                  limitPrice: side > 0 ? level + tick * 0.5 : level - tick * 0.5,
                  totalAmount: perRung,
                },
              ]
            : [],
        closeMs: placed + randInt(ctx.rng, 8_000, 50_000),
        scenarioTag: tag,
      }),
    );
  }
  // The execution the ladder was built for.
  const realAmount = (ladderUsd * randRange(ctx.rng, 0.25, 0.5)) /
    ctx.market.usdRate(inst.currency, startMs);
  ctx.docs.push(
    fenicsDoc({
      trader: t,
      instrument: inst,
      side: side === 1 ? -1 : 1,
      limitPrice: side > 0 ? mid + 0.01 : mid - 0.01,
      totalAmount: realAmount,
      startMs: startMs + rungs * 1_200,
      fills: [
        {
          ms: startMs + rungs * 1_500 + randInt(ctx.rng, 1_000, 9_000),
          price: side > 0 ? mid + 0.014 : mid - 0.014,
          amount: realAmount,
          counterparty: cp(ctx, "dealer"),
        },
      ],
      scenarioTag: tag,
    }),
  );
}

/* ------------------------------------------------------------------ */
/* Cross trading, off-market, insider, banging the close               */
/* ------------------------------------------------------------------ */

function crossTrading(ctx: Ctx, target: number, family: ProductFamily) {
  const a = trader(ctx, "prop");
  const b = trader(ctx, "client_facilitation", a.trader_id);
  const inst = instFor(ctx, family === "fx" ? "fx" : "fenics");
  const date = midDate(ctx);
  const deviation = randRange(ctx.rng, 0.004, 0.02);
  const size = Math.round(target / deviation);
  const ms = atMinute(date, randRange(ctx.rng, 8 * 60, 16 * 60), randInt(ctx.rng, 0, 59_000));
  const level = ctx.market.level(inst.instrument, ms);
  const agreed = level * (1 + deviation);
  const internal = cp(ctx, "internal");

  one(ctx, {
    trader: a, inst, direction: 1, notionalUsd: size, ms, tag: "cross_trading",
    counterparty: internal, internal: true, levelOverride: agreed,
  });
  one(ctx, {
    trader: b, inst, direction: -1, notionalUsd: size * randRange(ctx.rng, 0.99, 1.01),
    ms: ms + randInt(ctx.rng, 100, 4_000), tag: "cross_trading",
    counterparty: internal, internal: true, levelOverride: agreed,
  });
}

function offMarket(ctx: Ctx, target: number, family: ProductFamily) {
  const t = pick(ctx.rng, ctx.traders);
  // Only bonds and FX carry an execution price to be off-market against.
  const inst = instFor(ctx, family === "fx" ? "fx" : "fenics");
  const date = midDate(ctx);
  const deviation = randRange(ctx.rng, 0.012, 0.05) * (ctx.rng() < 0.5 ? -1 : 1);
  const size = Math.round(target / Math.abs(deviation));
  const ms = atMinute(date, randRange(ctx.rng, 8 * 60, 16.5 * 60), randInt(ctx.rng, 0, 59_000));
  const level = ctx.market.level(inst.instrument, ms);
  one(ctx, {
    trader: t, inst, direction: ctx.rng() < 0.5 ? 1 : -1, notionalUsd: size, ms,
    tag: "off_market",
    counterparty: ctx.rng() < 0.5 ? cp(ctx, "internal") : cp(ctx, "client"),
    levelOverride: level * (1 + deviation),
  });
}

function insider(ctx: Ctx, event: MarketEvent, target: number) {
  const t = trader(ctx, "prop");
  const inst = ctx.instruments.find((i) => i.instrument === event.instrument);
  if (!inst) return;
  const move = event.move_pct / 100;
  if (Math.abs(move) < 0.004) return;
  // Value moves, not level moves: a 5% move on a credit spread is worth far
  // less than a 5% move on a bond price.
  const valueMove = Math.abs(move) * ctx.market.valueFactor(inst.instrument, event.public_ms);
  if (valueMove <= 0) return;
  const position = Math.round(target / valueMove);
  const dir: 1 | -1 = move > 0 ? 1 : -1;
  const legs = randInt(ctx.rng, 3, 5);

  for (let i = 0; i < legs; i++) {
    const hoursBefore = randRange(ctx.rng, 1.5, 9) + (legs - i) * 0.7;
    const ms = event.public_ms - hoursBefore * 3_600_000;
    const minute = new Date(ms).getUTCHours() * 60 + new Date(ms).getUTCMinutes();
    one(ctx, {
      trader: t, inst, direction: dir,
      notionalUsd: (position / legs) * randRange(ctx.rng, 0.8, 1.2),
      ms: atMinute(dateKey(ms), Math.max(7 * 60 + 5, Math.min(16 * 60 + 45, minute)), randInt(ctx.rng, 0, 50_000)),
      tag: "insider_trading",
    });
  }
  one(ctx, {
    trader: t, inst, direction: dir === 1 ? -1 : 1, notionalUsd: position,
    ms: event.public_ms + randRange(ctx.rng, 8, 70) * MS_MIN,
    tag: "insider_trading",
  });
}

function bangingTheClose(ctx: Ctx, target: number, family: ProductFamily) {
  const t = trader(ctx, "prop");
  const inst = instFor(ctx, family);
  const date = midDate(ctx);
  const dir: 1 | -1 = ctx.rng() < 0.5 ? 1 : -1;
  const size = notionalForTarget(ctx.market, inst.instrument, date, target, 0.55);
  if (size <= 0) return;

  // Exposure that settles against the fix.
  one(ctx, {
    trader: t, inst, direction: dir, notionalUsd: size * randRange(ctx.rng, 0.85, 1.1),
    ms: atMinute(date, randRange(ctx.rng, 8 * 60, 11 * 60), 0),
    tag: "banging_the_close", counterparty: cp(ctx, "client"),
  });
  const legs = randInt(ctx.rng, 4, 7);
  for (let i = 0; i < legs; i++) {
    one(ctx, {
      trader: t, inst, direction: dir, notionalUsd: (size / legs) * randRange(ctx.rng, 0.8, 1.2),
      ms: atMinute(date, FIX_MIN - randRange(ctx.rng, 0.5, 11), randInt(ctx.rng, 0, 30_000)),
      tag: "banging_the_close", counterparty: cp(ctx, "dealer"),
    });
  }
}

/* ------------------------------------------------------------------ */

export function generateScenarios(o: {
  dates: string[];
  traders: Trader[];
  counterparties: Counterparty[];
  instruments: Instrument[];
  market: MarketData;
  events: MarketEvent[];
  seed?: number;
}): ScenarioBundle {
  const ctx: Ctx = {
    rng: mulberry32(hashSeed("scenarios", o.seed ?? 20260101)),
    dates: o.dates,
    traders: o.traders,
    counterparties: o.counterparties,
    instruments: o.instruments,
    market: o.market,
    events: o.events,
    docs: [],
  };

  // Tier targets sit just above, well above and far above the default
  // thresholds, so moving a threshold visibly changes what is flagged.
  const tierTarget: Record<Tier, number> = {
    barely: 30_000,
    significant: 150_000,
    major: 800_000,
  };

  // Ramping: three tiers across every family.
  for (const tier of TIERS) {
    FAMILY_ROTATION.forEach((family) => ramping(ctx, tier, tierTarget[tier], family));
  }

  // Wash trading: three tiers of the plain variant across families, plus one
  // of each disguised variant.
  for (const tier of TIERS) {
    FAMILY_ROTATION.forEach((family) => washPlain(ctx, tier, tierTarget[tier] * 0.8, family));
  }
  for (let i = 0; i < 4; i++) washCrossTenor(ctx, 140_000);
  for (let i = 0; i < 4; i++) washCrossProduct(ctx, 160_000);
  for (let i = 0; i < 4; i++) washMultiCounterparty(ctx, 150_000, FAMILY_ROTATION[i % 4]);
  for (let i = 0; i < 4; i++) washCrossCurrency(ctx, 140_000);

  // Front running: three tiers across families, plus internal cases.
  for (const tier of TIERS) {
    FAMILY_ROTATION.forEach((family) => frontRunning(ctx, tier, tierTarget[tier], family));
  }
  FAMILY_ROTATION.forEach((family) => frontRunning(ctx, "internal", 120_000, family));
  FAMILY_ROTATION.forEach((family) => frontRunning(ctx, "internal", 300_000, family));

  // Best execution: three tiers, weighted toward Fenics where a better
  // contemporaneous print is in the same feed.
  for (const tier of TIERS) {
    (["fenics", "fenics", "fenics", "fenics", "fx", "fx"] as ProductFamily[]).forEach((family) =>
      bestExecution(ctx, tier, tierTarget[tier] * 0.6, family),
    );
  }

  // Spoofing and layering: three tiers each, both on the order-stream data.
  for (const tier of TIERS) {
    for (let i = 0; i < 5; i++) spoofing(ctx, tier, tierTarget[tier] * 0.5);
    for (let i = 0; i < 5; i++) layering(ctx, tier, tierTarget[tier] * 0.5);
  }

  // The rest.
  FAMILY_ROTATION.forEach((family) => crossTrading(ctx, 90_000, family));
  for (let i = 0; i < 6; i++) offMarket(ctx, 60_000 * (1 + i * 0.4), FAMILY_ROTATION[i % 4]);
  (["fx", "fenics"] as ProductFamily[]).forEach((family) => {
    bangingTheClose(ctx, 120_000, family);
    bangingTheClose(ctx, 320_000, family);
  });

  const material = o.events.filter((e) => Math.abs(e.move_pct) > 1).slice(0, 14);
  material.filter((_, i) => i % 2 === 0).slice(0, 6).forEach((e, i) => {
    insider(ctx, e, 120_000 * (1 + i * 0.5));
  });

  ctx.docs.sort((a, b) => docTime(a) - docTime(b));
  return { documents: ctx.docs };
}

export { emit };
