import type { Counterparty, Instrument, Trader } from "@/lib/types";
import { hashSeed, mulberry32, pick, randRange, type Rng } from "./rng";

/**
 * The simulated firm and the instruments it trades.
 *
 * `impact_k` is the Market Impact Model calibration per asset class, set so
 * that a large clip in each market moves the modelled level by a believable
 * amount: a couple of basis points for a major currency, a few basis points of
 * spread for a liquid CDS, a handful of price ticks for a corporate bond.
 */
export const IMPACT_K = {
  fx: 750,
  credit: 27,
  rates: 7,
  fenics: 3,
} as const;

/* ------------------------------------------------------------------ */
/* People and counterparties                                           */
/* ------------------------------------------------------------------ */

const FIRST = [
  "Alan", "Bridget", "Caleb", "Dana", "Elliot", "Frances", "Gordon", "Harriet", "Isaac", "Janet",
  "Keith", "Laurel", "Martin", "Nadine", "Owen", "Paula", "Quentin", "Renee", "Stanley", "Tessa",
  "Ulysses", "Vivian", "Walter", "Yvonne", "Zachary", "Marcus", "Deborah", "Curtis", "Sheila", "Roland",
  "Priya", "Devon", "Camille", "Reggie", "Noel", "Bianca", "Terrence", "Marisol", "Grant", "Adele",
];

const LAST = [
  "Whitfield", "Carrow", "Blanchard", "Ostrander", "Falkner", "Renshaw", "Mabry", "Kilgore", "Dunphy",
  "Vandermeer", "Prescott", "Alderman", "Cutler", "Hollins", "Stroud", "Beaumont", "Ridley", "Marlowe",
  "Halstead", "Wexford", "Crane", "Ferris", "Lockhart", "Sandoval", "Thorne", "Ellery", "Bramwell",
  "Nagata", "Okafor", "Reyes", "Castellano", "Draper", "Quilling", "Vance", "Ashworth", "Pettigrew",
];

export function generateTraders(seed = 20260101, count = 72): Trader[] {
  const rng = mulberry32(hashSeed("traders", seed));
  const traders: Trader[] = [];
  const used = new Set<string>();
  for (let n = 1; n <= count; n++) {
    let name = "";
    do {
      name = `${pick(rng, FIRST)} ${pick(rng, LAST)}`;
    } while (used.has(name));
    used.add(name);
    traders.push({
      trader_id: `TR-${String(n).padStart(3, "0")}`,
      name,
      trade_role: rng() < 0.62 ? "client_facilitation" : "prop",
    });
  }
  return traders;
}

/** Which markets a trader works in. Derived from the id, not stored. */
export type TraderFocus = "credit" | "rates" | "fenics" | "fx" | "multi";

export function focusOf(traderId: string): TraderFocus {
  const r = hashSeed("focus", traderId) % 100;
  if (r < 26) return "credit";
  if (r < 50) return "rates";
  if (r < 72) return "fenics";
  if (r < 90) return "fx";
  return "multi";
}

/** Books are carried straight from Unit.BookName; they are not a hierarchy. */
export const BOOKS = [
  "CRD-FLOW-01", "CRD-FLOW-02", "CRD-PROP-01",
  "RTS-SWAP-01", "RTS-SWAP-02", "RTS-VOL-01",
  "FI-GOVT-01", "FI-CORP-01", "FI-CORP-02",
  "FX-SPOT-01", "FX-SPOT-02", "TREASURY-01",
];

export const REGIONS = ["EU", "UK", "US", "APAC"];

export function bookFor(traderId: string, focus: TraderFocus): string {
  const pool = BOOKS.filter((b) => {
    if (focus === "credit") return b.startsWith("CRD");
    if (focus === "rates") return b.startsWith("RTS");
    if (focus === "fenics") return b.startsWith("FI-");
    if (focus === "fx") return b.startsWith("FX-");
    return true;
  });
  const idx = hashSeed("book", traderId) % pool.length;
  return pool[idx];
}

export function regionFor(traderId: string): string {
  return REGIONS[hashSeed("region", traderId) % REGIONS.length];
}

const CLIENT_NAMES = [
  "Halcyon Asset Management", "Bridgeport Capital", "Sierra Vista Pension Fund", "Kesterly Global Macro",
  "Ardent Insurance Group", "Northgate Treasury Services", "Pemberton Industries", "Vireo Energy Corp",
  "Landmark Retirement Trust", "Ashgrove Partners", "Calderwood Holdings", "Tri-State Freight Systems",
  "Miller Brand Foods", "Oakline Semiconductor", "Granite Peak Advisors", "Corbin Family Office",
  "Rosehill Multi-Strategy", "Dunmore Credit Partners",
];

const DEALER_NAMES = [
  "Meridian Bank", "Fifth Harbor Securities", "Ellisberg & Co.", "Wychwood Bank",
  "Continental Trust Bank", "Ravensworth Markets", "Petersen Global", "Ironside Brokerage",
];

const INTERNAL_NAMES = [
  "Internal Book Transfer", "Internal Nominee Account", "Affiliate: Kestrel Overseas Ltd",
  "Affiliate: Marlowe Securities (IE)",
];

export const VENUES = [
  { VenueCode: "FENX", VenueName: "Fenics UST" },
  { VenueCode: "MKTA", VenueName: "MarketAxess" },
  { VenueCode: "TRDW", VenueName: "Tradeweb" },
  { VenueCode: "BBGM", VenueName: "Bloomberg MTF" },
];

export function generateCounterparties(): Counterparty[] {
  const out: Counterparty[] = [];
  CLIENT_NAMES.forEach((name, i) =>
    out.push({ counterparty_code: `CP-CL-${String(i + 1).padStart(3, "0")}`, name, kind: "client" }),
  );
  DEALER_NAMES.forEach((name, i) =>
    out.push({ counterparty_code: `CP-DL-${String(i + 1).padStart(3, "0")}`, name, kind: "dealer" }),
  );
  INTERNAL_NAMES.forEach((name, i) =>
    out.push({ counterparty_code: `INT-${String(i + 1).padStart(3, "0")}`, name, kind: "internal" }),
  );
  return out;
}

/* ------------------------------------------------------------------ */
/* Instrument universe                                                 */
/* ------------------------------------------------------------------ */

/** Credit reference entities. Tickers are fictional. */
const CREDIT_REFS: { ticker: string; name: string; ig: boolean }[] = [
  { ticker: "ARDNT", name: "Ardent Insurance Group", ig: true },
  { ticker: "PMBTN", name: "Pemberton Industries", ig: true },
  { ticker: "OAKLN", name: "Oakline Semiconductor", ig: true },
  { ticker: "GRNTP", name: "Granite Peak Advisors", ig: true },
  { ticker: "CALDW", name: "Calderwood Holdings", ig: true },
  { ticker: "VIREO", name: "Vireo Energy Corp", ig: false },
  { ticker: "TRIST", name: "Tri-State Freight Systems", ig: false },
  { ticker: "MLBRD", name: "Miller Brand Foods", ig: false },
  { ticker: "WYCHW", name: "Wychwood Bank", ig: true },
  { ticker: "DNMOR", name: "Dunmore Credit Partners", ig: false },
  // Records whose Identifier.Ticker is absent all land here. The schema marks
  // Ticker as optional, so the bucket has to exist and carry market data.
  { ticker: "NOTICKER", name: "Unidentified reference entity", ig: true },
];

const CREDIT_TENORS = ["3Y", "5Y", "10Y"];

const RATE_CURVES = [
  { index: "USD SOFR", currency: "USD", level: 4.15, adtv: 6.0e10 },
  { index: "EUR ESTR", currency: "EUR", level: 2.55, adtv: 3.2e10 },
  { index: "GBP SONIA", currency: "GBP", level: 4.05, adtv: 1.4e10 },
  { index: "SEK STIBOR", currency: "SEK", level: 2.35, adtv: 3.0e9 },
  { index: "JPY TONA", currency: "JPY", level: 0.85, adtv: 8.0e9 },
];

const RATE_TENORS: { bucket: string; years: number }[] = [
  { bucket: "1Y", years: 1 },
  { bucket: "2Y", years: 2 },
  { bucket: "5Y", years: 5 },
  { bucket: "10Y", years: 10 },
  { bucket: "30Y", years: 30 },
];

/** Bonds traded on the Fenics order streams. ISIN-shaped, fictional. */
const BONDS = [
  { isin: "XS2417295478", label: "ARDNT 4.25% 2031", currency: "USD", price: 98.75, duration: 5.4 },
  { isin: "XS2544190836", label: "PMBTN 3.875% 2029", currency: "USD", price: 96.4, duration: 3.9 },
  { isin: "XS2671104492", label: "OAKLN 5.125% 2034", currency: "USD", price: 101.2, duration: 7.6 },
  { isin: "XS2289417730", label: "GRNTP 2.75% 2028", currency: "EUR", price: 94.8, duration: 3.1 },
  { isin: "XS2803561194", label: "CALDW 4.5% 2033", currency: "EUR", price: 99.6, duration: 6.8 },
  { isin: "XS2156338827", label: "VIREO 7.25% 2030", currency: "USD", price: 92.1, duration: 4.4 },
  { isin: "XS2498720351", label: "TRIST 6.875% 2029", currency: "USD", price: 93.7, duration: 3.6 },
  { isin: "XS2735118604", label: "MLBRD 5.5% 2032", currency: "GBP", price: 97.3, duration: 5.9 },
  { isin: "XS2610447215", label: "WYCHW 3.25% 2027", currency: "GBP", price: 99.1, duration: 2.2 },
  { isin: "XS2367195583", label: "DNMOR 8.0% 2031", currency: "USD", price: 89.5, duration: 4.8 },
  { isin: "US91282CJL60", label: "UST 4.0% 2034", currency: "USD", price: 100.4, duration: 8.1 },
  { isin: "DE000BU2Z023", label: "DBR 2.5% 2035", currency: "EUR", price: 97.9, duration: 9.2 },
  { isin: "GB00BTHH2R79", label: "UKT 4.25% 2032", currency: "GBP", price: 101.6, duration: 6.4 },
  { isin: "XS2452104881", label: "ASHGV 4.75% 2030", currency: "USD", price: 98.2, duration: 4.6 },
];

export const FX_CURRENCIES = [
  { code: "EUR", name: "Euro", rate: 1.084, vol: 0.072, adtv: 1.6e12 },
  { code: "GBP", name: "Pound Sterling", rate: 1.268, vol: 0.082, adtv: 9.7e11 },
  { code: "JPY", name: "Japanese Yen", rate: 0.00662, vol: 0.094, adtv: 1.1e12 },
  { code: "CHF", name: "Swiss Franc", rate: 1.121, vol: 0.076, adtv: 3.9e11 },
  { code: "AUD", name: "Australian Dollar", rate: 0.664, vol: 0.098, adtv: 4.8e11 },
  { code: "CAD", name: "Canadian Dollar", rate: 0.733, vol: 0.068, adtv: 4.1e11 },
  { code: "SEK", name: "Swedish Krona", rate: 0.0951, vol: 0.104, adtv: 9.0e10 },
  { code: "NOK", name: "Norwegian Krone", rate: 0.0932, vol: 0.112, adtv: 7.5e10 },
  { code: "MXN", name: "Mexican Peso", rate: 0.0542, vol: 0.142, adtv: 5.5e10 },
  { code: "ZAR", name: "South African Rand", rate: 0.0538, vol: 0.168, adtv: 3.2e10 },
];

export interface CreditRef {
  ticker: string;
  name: string;
  ig: boolean;
}

export const CREDIT_REFERENCES: CreditRef[] = CREDIT_REFS;
export const BOND_REFERENCE = BONDS;
export const RATE_REFERENCE = RATE_CURVES;

export function generateInstruments(seed = 20260101): Instrument[] {
  const rng = mulberry32(hashSeed("instruments", seed));
  const out: Instrument[] = [];

  // Credit: one instrument per reference entity, tier and tenor bucket.
  for (const ref of CREDIT_REFS) {
    for (const tenor of CREDIT_TENORS) {
      const years = Number(tenor.replace("Y", ""));
      const base = ref.ig
        ? randRange(rng, 55, 165) * (0.75 + years / 10)
        : randRange(rng, 240, 580) * (0.8 + years / 12);
      out.push({
        instrument: `CDS:${ref.ticker}/SNRFOR/${tenor}`,
        label: `${ref.ticker} SNRFOR ${tenor} CDS`,
        family: "credit",
        currency: "USD",
        price_type: "Spread",
        base_level: Math.round(base * 10) / 10,
        ann_vol: ref.ig ? randRange(rng, 0.3, 0.45) : randRange(rng, 0.45, 0.65),
        adtv_usd: (ref.ig ? randRange(rng, 6e8, 1.6e9) : randRange(rng, 2e8, 7e8)) / (years / 5),
        impact_k: IMPACT_K.credit,
        duration_years: years * 0.92,
        tenor,
      });
    }
  }

  // Rates: one instrument per curve point.
  for (const curve of RATE_CURVES) {
    for (const t of RATE_TENORS) {
      const slope = 1 + (t.years - 5) * 0.012;
      out.push({
        instrument: `IR:${curve.index}/${t.bucket}`,
        label: `${curve.index} ${t.bucket}`,
        family: "rates",
        currency: curve.currency,
        price_type: "Rate",
        base_level: Math.round(curve.level * slope * 1000) / 1000,
        ann_vol: randRange(rng, 0.16, 0.28),
        adtv_usd: curve.adtv / (1 + Math.abs(t.years - 5) * 0.18),
        impact_k: IMPACT_K.rates,
        duration_years: t.years,
        tenor: t.bucket,
      });
    }
  }

  // Rates: FRA records carry no FixingIndex, so they map onto their own
  // short-dated curve points.
  for (const curve of RATE_CURVES) {
    for (const bucket of ["3M", "6M", "1Y"]) {
      const years = bucket === "1Y" ? 1 : Number(bucket.replace("M", "")) / 12;
      out.push({
        instrument: `IR:${curve.currency} FRA/${bucket}`,
        label: `${curve.currency} FRA ${bucket}`,
        family: "rates",
        currency: curve.currency,
        price_type: "Rate",
        base_level: Math.round(curve.level * 0.98 * 1000) / 1000,
        ann_vol: randRange(rng, 0.14, 0.24),
        adtv_usd: curve.adtv * 0.35,
        impact_k: IMPACT_K.rates,
        duration_years: Math.max(0.25, years),
        tenor: bucket,
      });
    }
  }

  // Fenics: one instrument per bond.
  for (const b of BONDS) {
    out.push({
      instrument: `BOND:${b.isin}`,
      label: b.label,
      family: "fenics",
      currency: b.currency,
      price_type: "Price",
      base_level: b.price,
      ann_vol: randRange(rng, 0.035, 0.085),
      adtv_usd: randRange(rng, 1.5e8, 2.2e9),
      impact_k: IMPACT_K.fenics,
      duration_years: b.duration,
    });
  }

  // FX: one synthetic instrument per non-USD currency.
  for (const c of FX_CURRENCIES) {
    out.push({
      instrument: `FX:${c.code}/USD`,
      label: `${c.code}/USD`,
      family: "fx",
      currency: c.code,
      currency_code: c.code,
      price_type: "FXRate",
      base_level: c.rate,
      ann_vol: c.vol,
      adtv_usd: c.adtv,
      impact_k: IMPACT_K.fx,
      duration_years: 1,
    });
  }

  return out;
}

export function instrumentsFor(focus: TraderFocus, all: Instrument[]): Instrument[] {
  if (focus === "multi") return all;
  return all.filter((i) => i.family === focus);
}

export function pickInstrument(rng: Rng, pool: Instrument[]): Instrument {
  return pick(rng, pool);
}
