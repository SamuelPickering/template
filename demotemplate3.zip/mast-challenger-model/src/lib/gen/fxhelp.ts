import type { Counterparty, Instrument, SourceDocument, Trader } from "@/lib/types";
import type { MarketData } from "@/lib/models/market";
import { fxDoc } from "./docs";

/**
 * FX quoting conventions and a helper that turns "trade this much of this
 * currency" into a schema-shaped FX.Spot document.
 */
const USD_BASE = new Set(["JPY", "CHF", "CAD", "SEK", "NOK", "MXN", "ZAR", "PLN", "SGD", "TRY"]);

export function conventionalPair(a: string, b: string): [string, string] {
  if (a === "USD") return USD_BASE.has(b) ? ["USD", b] : [b, "USD"];
  if (b === "USD") return USD_BASE.has(a) ? ["USD", a] : [a, "USD"];
  const order = [
    "EUR", "GBP", "AUD", "NZD", "USD", "CAD", "CHF", "SEK", "NOK",
    "SGD", "PLN", "MXN", "ZAR", "TRY", "JPY",
  ];
  return order.indexOf(a) <= order.indexOf(b) ? [a, b] : [b, a];
}

export interface FxTradeArgs {
  trader: Trader;
  counterparty: Counterparty;
  /** The non-USD currency the trader is taking a view on. */
  currency: string;
  /** What it is traded against: USD, or another currency for a cross. */
  against?: string;
  /** +1 = acquiring `currency`, -1 = selling it. */
  direction: 1 | -1;
  notionalUsd: number;
  ms: number;
  market: MarketData;
  /** Half-spread paid, as a fraction of the mid. */
  spread?: number;
  /**
   * Deviation to apply in the leg currency's own terms — a positive value
   * prints the currency higher against USD. The headline rate is derived from
   * it, inverting where the currency is the quote rather than the base, so a
   * scenario can say "20 bps rich on this instrument" without caring how the
   * pair happens to be quoted.
   */
  levelDeviation?: number;
  internalTrade?: boolean;
  scenarioTag?: string | null;
}

export function fxTrade(a: FxTradeArgs): SourceDocument {
  const against = a.against ?? "USD";
  const [base, quote] = conventionalPair(a.currency, against);
  // Buying the currency means buying the pair when the currency is the base.
  const buyingBase = base === a.currency ? a.direction > 0 : a.direction < 0;
  const mid = a.market.usdRate(base, a.ms) / a.market.usdRate(quote, a.ms);
  const spread = a.spread ?? 0.00004;
  let rate = mid * (1 + (buyingBase ? spread : -spread));
  if (a.levelDeviation) {
    const currencyIsBase = base === a.currency;
    const rateDev = currencyIsBase
      ? a.levelDeviation
      : 1 / (1 + a.levelDeviation) - 1;
    rate = mid * (1 + rateDev);
  }
  const baseAmount = a.notionalUsd / a.market.usdRate(base, a.ms);
  const quoteAmount = baseAmount * rate;

  return fxDoc({
    trader: a.trader,
    counterparty: a.counterparty,
    buyCurrency: buyingBase ? base : quote,
    sellCurrency: buyingBase ? quote : base,
    buyAmount: buyingBase ? baseAmount : quoteAmount,
    sellAmount: buyingBase ? quoteAmount : baseAmount,
    rate,
    pair: `${base}/${quote}`,
    notionalUsd: a.notionalUsd,
    tradeMs: a.ms,
    internalTrade: a.internalTrade,
    scenarioTag: a.scenarioTag,
  });
}

export const fxInstrumentFor = (instruments: Instrument[], currency: string) =>
  instruments.find((i) => i.instrument === `FX:${currency}/USD`);
