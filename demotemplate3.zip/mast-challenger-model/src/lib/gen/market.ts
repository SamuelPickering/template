import type { Instrument, MarketDay } from "@/lib/types";
import { gauss, hashSeed, mulberry32 } from "./rng";

/**
 * Daily market reference data per instrument: a level series, a daily
 * volatility and an ADTV figure. This is what the Market Impact Model and the
 * pricing checks (Off-Market Trading, Best Execution) run against.
 */
export function generateMarketDaily(
  instruments: Instrument[],
  dates: string[],
  seed = 20260101,
): MarketDay[] {
  const out: MarketDay[] = [];
  for (const inst of instruments) {
    const rng = mulberry32(hashSeed("market", seed, inst.instrument));
    let level = inst.base_level;
    const baseDaily = inst.ann_vol / Math.sqrt(252);
    let regime = 1;
    for (const date of dates) {
      regime = 0.9 * regime + 0.1 * (0.7 + rng() * 0.7);
      const dailyVol = baseDaily * regime;
      const open = level;
      // Mild pull back toward the starting level so nothing drifts away over
      // a few months of simulated sessions.
      const pull = 0.012 * (inst.base_level - level) / inst.base_level;
      const close = Math.max(inst.base_level * 0.35, open * (1 + pull + dailyVol * gauss(rng)));
      out.push({
        instrument: inst.instrument,
        trade_date: date,
        open,
        close,
        volatility: dailyVol,
        adtv_usd: inst.adtv_usd * (0.75 + rng() * 0.5),
        day_seed: hashSeed("intraday", seed, inst.instrument, date) % 2147483647,
      });
      level = close;
    }
  }
  return out;
}
