export type MetricId =
  | "insider_trading"
  | "front_running"
  | "internal_front_running"
  | "ramping"
  | "banging_the_close"
  | "wash_trading"
  | "cross_trading"
  | "off_market_trading"
  | "spoofing"
  | "layering"
  | "best_execution";

export interface ParamDef {
  key: string;
  label: string;
  help: string;
  type: "number" | "toggle";
  default: number;
  min?: number;
  max?: number;
  step?: number;
  unit?: string;
}

export interface MetricDef {
  id: MetricId;
  label: string;
  short: string;
  about: string;
  /** How USD Value is specialised for this metric. */
  usdValue: string;
  /** Which source data the metric needs to produce anything. */
  needs: string;
  params: ParamDef[];
}

const threshold = (def: number): ParamDef => ({
  key: "threshold_usd_value",
  label: "USD Value threshold",
  help: "An instance becomes an alert when its USD Value score exceeds this amount.",
  type: "number",
  default: def,
  min: 0,
  max: 5_000_000,
  step: 500,
  unit: "USD",
});

export const METRICS: MetricDef[] = [
  {
    id: "insider_trading",
    label: "Insider Trading",
    short: "Position built ahead of a non-public price move.",
    about:
      "Insider Trading looks for traders who held an unusually large position in the direction of a price shock immediately before that shock became public. Unlike every other metric here it is not about causing a price move - it is about exploiting one, so no market impact is modelled.",
    usdValue:
      "The realised move on the instrument replaces EMI; PTC is the excess of the trader's actual position over the time-weighted position a fair trader could have been expected to hold. The move is converted into value terms, so a spread move is multiplied through by duration.",
    needs: "Trade timestamps, notionals and a direction, plus an event calendar.",
    params: [
      threshold(50_000),
      {
        key: "lookback_hours",
        label: "Lookback window",
        help: "How far before the event becoming public we examine position-building.",
        type: "number",
        default: 48,
        min: 1,
        max: 240,
        step: 1,
        unit: "hours",
      },
      {
        key: "min_event_move_pct",
        label: "Event sensitivity",
        help: "Minimum absolute move in the instrument's quoted level for an event to be material.",
        type: "number",
        default: 0.5,
        min: 0,
        max: 20,
        step: 0.1,
        unit: "%",
      },
      {
        key: "expectation_half_life_hours",
        label: "Expectation half-life",
        help: "How quickly the position a fair trader could be expected to hold decays back toward flat as the event approaches.",
        type: "number",
        default: 18,
        min: 1,
        max: 120,
        step: 1,
        unit: "hours",
      },
    ],
  },
  {
    id: "front_running",
    label: "Front Running",
    short: "Prop position exited into the impact of the trader's own client flow.",
    about:
      "A trader who knows a large client order is coming can open a proprietary position first and exit into the price impact that filling the client order creates. Materiality rises as the gap between the prop exit and the client flow shrinks.",
    usdValue:
      "EMI is the modelled impact of the client facilitation trades; PTC is the position exiting into that impact, capped at the impacting notional under the exhaustion principle.",
    needs: "An execution classification that distinguishes client business from the firm's own.",
    params: [
      threshold(20_000),
      {
        key: "max_lead_seconds",
        label: "Max lead time",
        help: "Largest gap between the prop exit and the client facilitation trade that still counts.",
        type: "number",
        default: 900,
        min: 5,
        max: 14_400,
        step: 5,
        unit: "seconds",
      },
      {
        key: "min_prop_notional_usd",
        label: "Min prop notional",
        help: "Prop exits smaller than this are ignored.",
        type: "number",
        default: 250_000,
        min: 0,
        max: 100_000_000,
        step: 50_000,
        unit: "USD",
      },
      {
        key: "require_same_trader",
        label: "Same trader only",
        help: "When on, the prop position and the client facilitation must belong to the same trader. Turn off to catch arrangements between two traders.",
        type: "toggle",
        default: 1,
      },
    ],
  },
  {
    id: "internal_front_running",
    label: "Internal Front Running",
    short: "One book trading ahead of the impact caused by another book in the firm.",
    about:
      "The same mechanic as Front Running, but the impact comes from a different book inside the firm. It captures information leakage across internal walls: one trader positions themselves just before another trader's large flow moves the instrument.",
    usdValue:
      "EMI is the impact of the other book's flow; PTC is the position held into that impact, capped at the impacting notional.",
    needs: "Trader or book identifiers on every execution.",
    params: [
      threshold(25_000),
      {
        key: "max_lead_seconds",
        label: "Max lead time",
        help: "Largest gap between the benefiting trade and the other book's impacting flow.",
        type: "number",
        default: 1_200,
        min: 5,
        max: 14_400,
        step: 5,
        unit: "seconds",
      },
      {
        key: "min_impact_bps",
        label: "Min modelled impact",
        help: "Ignore impacting flow whose modelled level impact is below this.",
        type: "number",
        default: 0.05,
        min: 0,
        max: 200,
        step: 0.01,
        unit: "bps",
      },
    ],
  },
  {
    id: "ramping",
    label: "Ramping",
    short: "Aggressive directional trading, then a profitable reversal.",
    about:
      "A run of aggressive same-direction executions that pushes the instrument's level, followed by an exit into the level the trader just created. The build phase generates the impact; the reversal is where the profit is taken.",
    usdValue:
      "EMI is the cumulative modelled impact of the build phase measured at the moment of reversal; PTC is the notional reversed out, capped at the build notional.",
    needs: "Timestamps, notionals and a direction.",
    params: [
      threshold(15_000),
      {
        key: "min_trade_count",
        label: "Min trades in build",
        help: "Minimum number of same-direction executions before a reversal counts as ramping.",
        type: "number",
        default: 4,
        min: 2,
        max: 50,
        step: 1,
        unit: "trades",
      },
      {
        key: "max_reversal_window_minutes",
        label: "Max reversal window",
        help: "How long after the build phase the reversal must begin.",
        type: "number",
        default: 90,
        min: 1,
        max: 1_440,
        step: 1,
        unit: "minutes",
      },
      {
        key: "min_directional_ratio",
        label: "Min directional purity",
        help: "Share of build-phase notional that must be in the same direction.",
        type: "number",
        default: 0.8,
        min: 0.5,
        max: 1,
        step: 0.01,
      },
      {
        key: "max_build_minutes",
        label: "Max build duration",
        help: "Longest span the build phase may cover.",
        type: "number",
        default: 180,
        min: 5,
        max: 1_440,
        step: 5,
        unit: "minutes",
      },
    ],
  },
  {
    id: "banging_the_close",
    label: "Banging the Close",
    short: "Concentrated trading inside the closing window to move the closing level.",
    about:
      "Positions that settle against a closing or fixing level can be helped along by concentrating trading into the final minutes before it, rather than spreading the same volume across the session.",
    usdValue:
      "EMI is the modelled displacement of the closing level — what concentrated trading leaves standing at the close, less what evenly-spread trading would have left; PTC is the exposure carried into the close.",
    needs: "Timestamps precise enough to identify a closing window.",
    params: [
      threshold(20_000),
      {
        key: "closing_window_minutes",
        label: "Closing window",
        help: "Length of the closing window before the daily fix.",
        type: "number",
        default: 15,
        min: 1,
        max: 120,
        step: 1,
        unit: "minutes",
      },
      {
        key: "min_window_notional_usd",
        label: "Min window notional",
        help: "Ignore traders with less than this notional inside the window.",
        type: "number",
        default: 2_000_000,
        min: 0,
        max: 500_000_000,
        step: 250_000,
        unit: "USD",
      },
      {
        key: "min_concentration",
        label: "Min concentration",
        help: "Share of the trader's day in that instrument that must fall inside the window.",
        type: "number",
        default: 0.3,
        min: 0,
        max: 1,
        step: 0.01,
      },
    ],
  },
  {
    id: "wash_trading",
    label: "Wash Trading",
    short: "Offsetting legs that leave no genuine market risk.",
    about:
      "Trading with yourself, or with a related account, so the two legs cancel. It manufactures the appearance of volume and price without transferring real risk. The disguised variants split the round trip across tenors, products, counterparties or currency pairs so that no single blotter shows it.",
    usdValue:
      "Narrative is the modelled impact the manufactured activity creates applied to the volume it manufactures, weighted by how related the two sides are; Counter-Narrative is the genuine market risk actually run between the legs plus any client facilitation explanation. An alert is raised where the Narrative dominates.",
    needs: "Counterparty identifiers, to tell an internal account from a street name.",
    params: [
      threshold(15_000),
      {
        key: "max_leg_gap_minutes",
        label: "Max gap between legs",
        help: "Longest time between the two offsetting legs.",
        type: "number",
        default: 30,
        min: 0,
        max: 1_440,
        step: 1,
        unit: "minutes",
      },
      {
        key: "size_match_tolerance_pct",
        label: "Size match tolerance",
        help: "How closely the legs must offset in size.",
        type: "number",
        default: 15,
        min: 0,
        max: 100,
        step: 1,
        unit: "%",
      },
      {
        key: "require_same_product",
        label: "Require same product type",
        help: "When on, both legs must be the same product. Turning it off is what surfaces the cross-product and cross-tenor variants, where the offset hides behind a different contract.",
        type: "toggle",
        default: 0,
      },
      {
        key: "require_price_match",
        label: "Require price match",
        help: "When on, the two legs must also execute at a near-identical level.",
        type: "toggle",
        default: 0,
      },
    ],
  },
  {
    id: "cross_trading",
    label: "Cross Trading",
    short: "Two internal books trading against each other at the same instant.",
    about:
      "Two books inside the firm taking opposite sides of the same instrument at effectively the same moment. Risk moves between them without going to the street, so whatever level they agree decides how much value moves from one book to the other.",
    usdValue:
      "EMI is the deviation of the crossed level from the prevailing market level; PTC is the notional crossed.",
    needs: "A traded level and millisecond timestamps.",
    params: [
      threshold(15_000),
      {
        key: "max_timestamp_gap_seconds",
        label: "Max timestamp gap",
        help: "How close in time the two sides must be.",
        type: "number",
        default: 10,
        min: 0,
        max: 3_600,
        step: 1,
        unit: "seconds",
      },
      {
        key: "size_match_tolerance_pct",
        label: "Size match tolerance",
        help: "How closely the two sides must match in size.",
        type: "number",
        default: 15,
        min: 0,
        max: 100,
        step: 1,
        unit: "%",
      },
    ],
  },
  {
    id: "off_market_trading",
    label: "Off-Market Trading",
    short: "Execution priced away from the prevailing market level.",
    about:
      "A trade booked meaningfully away from where the market actually was transfers value between the two sides. It can conceal losses, move value between books or periods, or compensate a counterparty off the record.",
    usdValue:
      "EMI is the deviation of the executed level from the modelled market level; PTC is the notional executed at it.",
    needs: "A traded level. CDS records carry upfront points rather than a traded spread, so they are out of scope for this check.",
    params: [
      threshold(10_000),
      {
        key: "deviation_bps",
        label: "Deviation from market",
        help: "How far from the modelled level an execution must print to qualify.",
        type: "number",
        default: 60,
        min: 1,
        max: 2_000,
        step: 1,
        unit: "bps",
      },
      {
        key: "min_notional_usd",
        label: "Min notional",
        help: "Ignore small executions regardless of deviation.",
        type: "number",
        default: 250_000,
        min: 0,
        max: 100_000_000,
        step: 50_000,
        unit: "USD",
      },
    ],
  },
  {
    id: "spoofing",
    label: "Spoofing",
    short: "A large visible order placed and pulled, with the real trade on the other side.",
    about:
      "Spoofing is placing an order you never intend to have filled. A large, fully displayed order at the touch shifts the apparent balance of supply and demand, the price moves, and the order is pulled before it can trade - while the trader executes on the opposite side.",
    usdValue:
      "Narrative is the modelled impact the resting order creates, weighted by how competitive and how visible it was, applied to the notional executed on the other side; Counter-Narrative is the cost of unwinding had the order actually filled, scaled by how long it was exposed.",
    needs: "Order-level data: placement, display size and cancellation. Execution-only feeds produce nothing here.",
    params: [
      threshold(12_000),
      {
        key: "min_competitiveness",
        label: "Min order competitiveness",
        help: "How close to the touch the order must sit (1 = at or through the market, 0 = far away).",
        type: "number",
        default: 0.5,
        min: 0,
        max: 1,
        step: 0.01,
      },
      {
        key: "min_display_ratio",
        label: "Min displayed share",
        help: "Share of the order that was visible to the market. Spoofing depends on being seen.",
        type: "number",
        default: 0.7,
        min: 0,
        max: 1,
        step: 0.05,
      },
      {
        key: "max_order_life_seconds",
        label: "Max order life",
        help: "Orders resting longer than this are treated as genuine liquidity.",
        type: "number",
        default: 60,
        min: 1,
        max: 3_600,
        step: 1,
        unit: "seconds",
      },
      {
        key: "min_opposite_ratio",
        label: "Min opposite-side execution",
        help: "Notional executed the other way while the order rested, as a share of the order.",
        type: "number",
        default: 0.15,
        min: 0,
        max: 2,
        step: 0.05,
      },
    ],
  },
  {
    id: "layering",
    label: "Layering",
    short: "A ladder of orders across price levels, pulled together unfilled.",
    about:
      "Layering is spoofing done in depth: several orders at successive price levels on one side of the book, building an impression of weight behind the price, often walked in with amendments, then pulled together. The genuine execution is on the opposite side.",
    usdValue:
      "Narrative is the combined impact of the ladder, weighted by competitiveness and by how many levels it occupied, applied to the notional executed on the other side; Counter-Narrative is the cost of unwinding had the ladder filled.",
    needs: "Order-level data with limit prices, so distinct price levels can be counted.",
    params: [
      threshold(12_000),
      {
        key: "min_price_levels",
        label: "Min price levels",
        help: "How many distinct limit prices the ladder must occupy. This is what separates layering from a single spoof order.",
        type: "number",
        default: 4,
        min: 2,
        max: 20,
        step: 1,
        unit: "levels",
      },
      {
        key: "max_order_life_seconds",
        label: "Max order life",
        help: "Average rest time across the ladder, above which it is treated as genuine liquidity.",
        type: "number",
        default: 120,
        min: 1,
        max: 3_600,
        step: 1,
        unit: "seconds",
      },
      {
        key: "cancel_ratio_threshold",
        label: "Cancel ratio threshold",
        help: "Share of the ladder's notional cancelled without filling.",
        type: "number",
        default: 0.8,
        min: 0,
        max: 1,
        step: 0.01,
      },
      {
        key: "min_competitiveness",
        label: "Min competitiveness",
        help: "How close to the touch the ladder has to start.",
        type: "number",
        default: 0.35,
        min: 0,
        max: 1,
        step: 0.01,
      },
    ],
  },
  {
    id: "best_execution",
    label: "Best Execution",
    short: "Client filled worse than the firm could demonstrably have achieved.",
    about:
      "Best execution is the standard that keeps the firm aligned with both client and regulatory expectations: a client order should be filled on the best terms reasonably available. This metric looks for client fills that were materially worse than a price the firm itself was printing moments earlier on the same instrument, or that sat well away from the prevailing market level. Unlike the other metrics it is about detriment to the client rather than gain to the trader.",
    usdValue:
      "EMI is the price disadvantage the client suffered, measured against the better contemporaneous print where one exists and against the modelled market level otherwise; PTC is the client notional. The score is the value that moved away from the client.",
    needs:
      "Client-identifiable counterparties and a traded level. Fenics order streams give the strongest evidence, because a better print on the same ISIN is in the same feed.",
    params: [
      threshold(15_000),
      {
        key: "deviation_bps",
        label: "Min client detriment",
        help: "How far from the reference price the client fill must sit before it is flagged.",
        type: "number",
        default: 25,
        min: 1,
        max: 2_000,
        step: 1,
        unit: "bps",
      },
      {
        key: "max_reference_gap_seconds",
        label: "Reference window",
        help: "How far back to look for a better price the firm was printing on the same instrument.",
        type: "number",
        default: 300,
        min: 5,
        max: 7_200,
        step: 5,
        unit: "seconds",
      },
      {
        key: "min_notional_usd",
        label: "Min client notional",
        help: "Ignore small client fills regardless of the deviation.",
        type: "number",
        default: 250_000,
        min: 0,
        max: 100_000_000,
        step: 50_000,
        unit: "USD",
      },
      {
        key: "require_client_counterparty",
        label: "Client counterparty required",
        help: "When on, only fills facing a client count. Turn off to review dealer and internal fills on the same basis.",
        type: "toggle",
        default: 1,
      },
    ],
  },
];

export const METRIC_BY_ID: Record<MetricId, MetricDef> = Object.fromEntries(
  METRICS.map((m) => [m.id, m]),
) as Record<MetricId, MetricDef>;

export const METRIC_IDS: MetricId[] = METRICS.map((m) => m.id);

export type MetricConfig = Record<string, number>;
export type FullConfig = Record<MetricId, MetricConfig>;

export function defaultConfig(): FullConfig {
  const out = {} as FullConfig;
  for (const m of METRICS) {
    out[m.id] = Object.fromEntries(m.params.map((p) => [p.key, p.default]));
  }
  return out;
}
