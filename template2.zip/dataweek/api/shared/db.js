const mysql = require('mysql2/promise');

let pool = null;

async function getPool() {
    if (!pool) {
        try {
            pool = mysql.createPool({
                host: process.env.MYSQL_HOST || 'localhost',
                user: process.env.MYSQL_USER || 'root',
                password: process.env.MYSQL_PASSWORD,
                database: process.env.MYSQL_DATABASE || 'quiz_db',
                port: parseInt(process.env.MYSQL_PORT) || 3306,
                waitForConnections: true,
                connectionLimit: 10,
                queueLimit: 0,
                ssl: process.env.MYSQL_SSL === 'true' ? {
                    rejectUnauthorized: true
                } : false
            });

            // Test connection
            const connection = await pool.getConnection();
            console.log('✅ MySQL Connected Successfully');
            connection.release();
        } catch (error) {
            console.error('❌ MySQL Connection Error:', error.message);
            throw error;
        }
    }
    return pool;
}

module.exports = { getPool };