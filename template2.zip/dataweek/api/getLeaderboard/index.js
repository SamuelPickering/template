const { getPool } = require('../shared/db');

module.exports = async function (context, req) {
    context.log('🏆 Get leaderboard function triggered');

    context.res = {
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type'
        }
    };

    if (req.method === 'OPTIONS') {
        context.res.status = 200;
        return;
    }

    try {
        const pool = await getPool();
        const [leaderboard] = await pool.query(
            `SELECT 
                u.id as user_id,
                u.name,
                u.email,
                IFNULL(SUM(qs.amount), 0) as total_score,
                IFNULL(SUM(qs.questions_correct), 0) as total_questions_correct,
                COUNT(qs.score_id) as days_completed,
                RANK() OVER (
                    ORDER BY IFNULL(SUM(qs.amount), 0) DESC, 
                    IFNULL(SUM(qs.questions_correct), 0) DESC
                ) as \`rank\`
             FROM users u
             LEFT JOIN quiz_scores qs ON u.id = qs.user_id
             GROUP BY u.id, u.name, u.email
             ORDER BY total_score DESC, total_questions_correct DESC`
        );

        context.log(`✅ Leaderboard retrieved with ${leaderboard.length} users`);
        context.res.status = 200;
        context.res.body = {
            leaderboard: leaderboard,
            total_users: leaderboard.length
        };

    } catch (error) {
        context.log.error('❌ Error fetching leaderboard:', error);
        context.res.status = 500;
        context.res.body = { 
            error: 'Internal server error', 
            details: error.message 
        };
    }
};