const { getPool } = require('../shared/db');

module.exports = async function (context, req) {
    context.log('📊 Submit score function triggered');

    context.res = {
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'POST, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type'
        }
    };

    if (req.method === 'OPTIONS') {
        context.res.status = 200;
        return;
    }

    try {
        const { user_id, amount, questions_correct, day } = req.body;

        if (!user_id || amount === undefined || questions_correct === undefined || !day) {
            context.res.status = 400;
            context.res.body = { 
                error: 'user_id, amount, questions_correct, and day are required' 
            };
            return;
        }

        const pool = await getPool();

        // Verify user exists
        const [users] = await pool.query(
            'SELECT id FROM users WHERE id = ?',
            [user_id]
        );

        if (users.length === 0) {
            context.res.status = 404;
            context.res.body = { error: 'User not found' };
            return;
        }

        // Insert score
        try {
            await pool.query(
                `INSERT INTO quiz_scores (user_id, amount, questions_correct, day)
                 VALUES (?, ?, ?, ?)`,
                [user_id, amount, questions_correct, day]
            );

            const [newScore] = await pool.query(
                `SELECT score_id, user_id, amount, questions_correct, date, day
                 FROM quiz_scores
                 WHERE score_id = LAST_INSERT_ID()`
            );

            context.log(`✅ Score submitted for user ${user_id}, day ${day}`);
            context.res.status = 201;
            context.res.body = {
                message: 'Score submitted successfully',
                score: newScore[0]
            };
        } catch (insertError) {
            if (insertError.code === 'ER_DUP_ENTRY') {
                context.res.status = 409;
                context.res.body = { error: 'Score for this day already submitted' };
            } else {
                throw insertError;
            }
        }

    } catch (error) {
        context.log.error('❌ Error submitting score:', error);
        context.res.status = 500;
        context.res.body = { 
            error: 'Internal server error', 
            details: error.message 
        };
    }
};