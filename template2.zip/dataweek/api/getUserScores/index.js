const { getPool } = require('../shared/db');

module.exports = async function (context, req) {
    context.log('📈 Get user scores function triggered');

    context.res = {
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type'
        }
    };

    if (req.method === 'OPTIONS') {
        context.res.status = 200;
        return;
    }

    try {
        const userId = req.params.userId;

        if (!userId) {
            context.res.status = 400;
            context.res.body = { error: 'userId parameter is required' };
            return;
        }

        const pool = await getPool();
        const [scores] = await pool.query(
            `SELECT 
                score_id,
                user_id,
                amount,
                questions_correct,
                date,
                day
             FROM quiz_scores
             WHERE user_id = ?
             ORDER BY day ASC`,
            [userId]
        );

        context.log(`✅ Retrieved ${scores.length} scores for user ${userId}`);
        context.res.status = 200;
        context.res.body = {
            user_id: userId,
            scores: scores,
            total_scores: scores.length
        };

    } catch (error) {
        context.log.error('❌ Error fetching user scores:', error);
        context.res.status = 500;
        context.res.body = { 
            error: 'Internal server error', 
            details: error.message 
        };
    }
};