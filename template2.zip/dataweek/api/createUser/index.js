const { getPool } = require('../shared/db');

module.exports = async function (context, req) {
    context.log('📝 Create user function triggered');

    // Enable CORS
    context.res = {
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'POST, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type'
        }
    };

    // Handle OPTIONS preflight
    if (req.method === 'OPTIONS') {
        context.res.status = 200;
        return;
    }

    try {
        const { id, name, email } = req.body;

        if (!id || !name) {
            context.res.status = 400;
            context.res.body = { error: 'id and name are required' };
            return;
        }

        const pool = await getPool();

        // Check if user exists
        const [existingUsers] = await pool.query(
            'SELECT id, name, email FROM users WHERE id = ?',
            [id]
        );

        if (existingUsers.length > 0) {
            context.res.status = 409;
            context.res.body = { 
                error: 'User already exists',
                user: existingUsers[0]
            };
            return;
        }

        // Create user
        await pool.query(
            'INSERT INTO users (id, name, email) VALUES (?, ?, ?)',
            [id, name, email || null]
        );

        // Fetch created user
        const [newUser] = await pool.query(
            'SELECT id, name, email FROM users WHERE id = ?',
            [id]
        );

        context.log(`✅ User created: ${id}`);
        context.res.status = 201;
        context.res.body = {
            message: 'User created successfully',
            user: newUser[0]
        };

    } catch (error) {
        context.log.error('❌ Error creating user:', error);
        context.res.status = 500;
        context.res.body = { 
            error: 'Internal server error', 
            details: error.message 
        };
    }
};