const API_BASE = '/api';

export const api = {
    // Create user
    createUser: async (userData) => {
        try {
            const response = await fetch(`${API_BASE}/users`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(userData)
            });
            
            const data = await response.json();
            
            if (!response.ok) {
                throw new Error(data.error || 'Failed to create user');
            }
            
            return data;
        } catch (error) {
            console.error('API Error (createUser):', error);
            throw error;
        }
    },

    // Submit quiz score
    submitScore: async (scoreData) => {
        try {
            const response = await fetch(`${API_BASE}/scores`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(scoreData)
            });
            
            const data = await response.json();
            
            if (!response.ok) {
                throw new Error(data.error || 'Failed to submit score');
            }
            
            return data;
        } catch (error) {
            console.error('API Error (submitScore):', error);
            throw error;
        }
    },

    // Get user's scores
    getUserScores: async (userId) => {
        try {
            const response = await fetch(`${API_BASE}/users/${userId}/scores`);
            const data = await response.json();
            
            if (!response.ok) {
                throw new Error(data.error || 'Failed to fetch user scores');
            }
            
            return data;
        } catch (error) {
            console.error('API Error (getUserScores):', error);
            throw error;
        }
    },

    // Get leaderboard
    getLeaderboard: async () => {
        try {
            const response = await fetch(`${API_BASE}/leaderboard`);
            const data = await response.json();
            
            if (!response.ok) {
                throw new Error(data.error || 'Failed to fetch leaderboard');
            }
            
            return data;
        } catch (error) {
            console.error('API Error (getLeaderboard):', error);
            throw error;
        }
    }
};