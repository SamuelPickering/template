import { useState } from 'react';
import { api } from '../services/api';

function ApiTest() {
    const [result, setResult] = useState(null);
    const [error, setError] = useState(null);
    const [loading, setLoading] = useState(false);

    const testCreateUser = async () => {
        setLoading(true);
        setError(null);
        try {
            const data = await api.createUser({
                id: 'TEST001',
                name: 'Test User',
                email: 'test@example.com'
            });
            setResult(data);
        } catch (err) {
            setError(err.message);
        }
        setLoading(false);
    };

    const testSubmitScore = async () => {
        setLoading(true);
        setError(null);
        try {
            const data = await api.submitScore({
                user_id: 'TEST001',
                amount: 85,
                questions_correct: 17,
                day: 1
            });
            setResult(data);
        } catch (err) {
            setError(err.message);
        }
        setLoading(false);
    };

    const testGetUserScores = async () => {
        setLoading(true);
        setError(null);
        try {
            const data = await api.getUserScores('TEST001');
            setResult(data);
            console.log(data)
        } catch (err) {
            setError(err.message);
        }
        setLoading(false);
    };

    const testGetLeaderboard = async () => {
        setLoading(true);
        setError(null);
        try {
            const data = await api.getLeaderboard();
            setResult(data);
        } catch (err) {
            setError(err.message);
        }
        setLoading(false);
    };

    return (
        <div style={{ padding: '20px', fontFamily: 'Arial' }}>
            <h1>🧪 API Test Panel</h1>
            
            <div style={{ marginBottom: '20px' }}>
                <button onClick={testCreateUser} disabled={loading} style={buttonStyle}>
                    1. Create User (TEST001)
                </button>
                <button onClick={testSubmitScore} disabled={loading} style={buttonStyle}>
                    2. Submit Score (Day 1)
                </button>
                <button onClick={testGetUserScores} disabled={loading} style={buttonStyle}>
                    3. Get User Scores
                </button>
                <button onClick={testGetLeaderboard} disabled={loading} style={buttonStyle}>
                    4. Get Leaderboard
                </button>
            </div>

            {loading && <p>⏳ Loading...</p>}
            
            {error && (
                <div style={{ padding: '10px', backgroundColor: '#ffebee', color: '#c62828', borderRadius: '4px' }}>
                    ❌ Error: {error}
                </div>
            )}
            
            {result && (
                <div style={{ marginTop: '20px' }}>
                    <h3>✅ Result:</h3>
                    <pre style={{ 
                        backgroundColor: '#f5f5f5', 
                        padding: '15px', 
                        borderRadius: '4px',
                        overflow: 'auto'
                    }}>
                        {JSON.stringify(result, null, 2)}
                    </pre>
                </div>
            )}
        </div>
    );
}

const buttonStyle = {
    margin: '5px',
    padding: '10px 20px',
    fontSize: '14px',
    cursor: 'pointer',
    backgroundColor: '#070b0fff',
    color: 'white',
    border: 'none',
    borderRadius: '4px'
};

export default ApiTest;